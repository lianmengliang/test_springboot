create package body P_SMS_Send is

  /*短信发送*/

  procedure PW_Add_Code
  /*****************************************************************
        Procedure Name :PW_Add
        Purpose: 短信添加
        Edit: 2018-07-05 add by 小沈
    ****************************************************************/
  (I_Phone     In Varchar2, --手机号码
   I_SendType  In Number, --发送类型 1:管理员登录
   I_SendCode  In Varchar2, --发送验证码 
   I_SendLevel In Number, --发送优先级,99为手工插入，最高优先级
   O_Result    Out Number,
   O_Message   Out Varchar2) is
  
  begin
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
  
    O_Result  := 0;
    O_Message := '添加成功';
  
    if I_Phone is null then
      O_Result  := 1;
      O_Message := '手机号码不能为空';
      return;
    end if;
  
    if I_SendType is null then
      O_Result  := 2;
      O_Message := '发送类型错误！';
      return;
    end if;
  
    if I_SendCode is null then
      O_Result  := 3;
      O_Message := '验证码不能为空！';
      return;
    end if;
  
    if I_SendLevel is null then
      O_Result  := 4;
      O_Message := '发送等级错误！';
      return;
    end if;
  
    ----------------------------------------------------
    --步骤二：添加
    ----------------------------------------------------
    insert into sms_send_alarm
      (id, phone, sendtype, channel, message, sendlevel)
    values
      (sq_sms_send.nextval,
       I_Phone,
       2,
       1,
       '【嘻趣】管理后台登陆验证码：' || I_SendCode,
       1);
  
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    commit;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 1001;
      O_Message := '添加异常！';
      o_message := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_Add_Code;

  procedure PQ_List
  /*****************************************************************
        Procedure Name :PQ_List
        Purpose: 获取短信列表
        Edit: 2018-07-05 add by 小沈
    ****************************************************************/
  (I_PageSize       In Number,
   I_PageNO         In Number,
   O_OutRecordCount Out Number,
   O_OutCursor      Out t_cursor, --返回游标
   O_Result         Out Number,
   O_Message        Out Varchar2) is
    v_sql       varchar2(2000);
    V_HeiRownum Number;
    V_LowRownum Number;
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    v_sql := ' select id, phone,s_channel, tpl_s_name,tpl_id,tpl_param      from sms_send where  status=0  ';
  
    execute immediate ' select count(1) from (' || v_sql || ')'
      into O_OUTRECORDCOUNT;
  
    v_sql := v_sql || ' order by  send_level desc ,itime  asc    ';
  
    ----执行分页查询
    V_HeiRownum := I_PageNO * I_PageSize;
    V_LowRownum := V_HeiRownum - I_PageSize + 1;
    V_SQL       := 'select id, phone,s_channel,tpl_s_name,tpl_id,tpl_param,rn
                    from  (
                    select id, phone,s_channel,tpl_s_name,tpl_id,tpl_param,rownum rn
                    from (' || v_sql || ') A
                    where rownum <= ' ||
                   to_char(V_HeiRownum) || '
                    ) B
                    where rn >= ' || to_char(V_LowRownum);
    open O_OutCursor for v_sql;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 110;
      O_Message := '获取失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PQ_List;

  procedure PW_UpStatus
  /*****************************************************************
        Procedure Name :PW_UpStatus
        Purpose: 修改短信状态为正在发送中
        Edit: 2018-07-05 add by 小沈
    ****************************************************************/
  (I_SmsId   In Number, --短信ID
   O_Result  Out Number,
   O_Message Out Varchar2) is
    v_n Number;
  
  begin
    o_result  := 0;
    o_message := '修改成功';
  
    select count(1)
      into v_n
      from sms_send
     where id = I_SmsId
       and status = 0;
    if v_n <= 0 then
      o_result  := 1;
      o_message := '短信已再发送中';
      return;
    end if;
  
    update sms_send
       set status = 1, send_time = sysdate
     where id = I_SmsId
       and status = 0;
  
    commit;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 1001;
      O_Message := '处理异常！';
      --O_Message := '处理异常 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_UpStatus;

  procedure PW_Result
  /*****************************************************************
        Procedure Name :PW_Result
        Purpose: 短信发送结果返回
        Edit: 2018-07-05 add by 小沈
    ****************************************************************/
  (I_SmsId   In Number, --短信ID
   I_Status  In Number, -- 返回状态 0：失败  1：成功
   I_Result  In Varchar2, --返回信息
   O_Result  Out Number,
   O_Message Out Varchar2) is
    v_n Number;
  
  begin
    o_result  := 0;
    o_message := '处理成功';
  
    select count(1)
      into v_n
      from sms_send
     where id = I_SmsId
       and status = 1;
  
    if v_n <= 0 then
      o_result  := 1;
      o_message := '短信已处理或未处理';
      return;
    end if;
  
    if I_Status = 0 then
      update sms_send
         set status = 3, send_time = sysdate, send_result = I_Result
       where id = I_SmsId
         and status = 1;
    end if;
  
    if I_Status = 1 then
      update sms_send
         set status = 2, send_time = sysdate, send_result = I_Result
       where id = I_SmsId
         and status = 1;
    end if;
  
    commit;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 1001;
      O_Message := '处理异常！';
      -- O_Message := '处理异常 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_Result;

end P_SMS_Send;
/


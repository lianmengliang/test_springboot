create package P_AD_Award_Check is

  TYPE T_CURSOR IS REF CURSOR;

  /* 奖励检查 */

  Procedure Job_AutoCheck;
  /*****************************************************************
      procedure name: Job_AutoCheck
      purpose: 自动检查奖励订单
      edit: 2018-08-23 add by 小沈
  ****************************************************************/

end P_AD_Award_Check;
/


create package P_AD_Award_Main is

  TYPE T_CURSOR IS REF CURSOR;

  /*奖励主入口 2.0 */

  procedure PQ_AllMain
  /*****************************************************************
        Procedure Name :PQ_AllMain
        Purpose: 奖励判断全部入口
        Edit: 2018-04-12 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_SIMID    In Varchar2, --返回sim卡id
   I_Userid   In Number, --闲玩用户编号
   I_PType    In Number, --1、ios  2、安卓
   I_MerId    In Varchar2, --用户注册帐号id
   I_MerName  In Varchar2, --用户注册帐号
   I_Levle    In Number, --用户等级、金额等
   I_AType    In Number, --  发奖类型 1 按固定值发放
   I_AGroup   In Number, --组别
   O_AMoney   Out Number, --奖励金额
   O_Result   Out Number,
   O_Message  Out Varchar2);

  procedure PQ_Common
  /*****************************************************************
        Procedure Name :PQ_Common
        Purpose: 普通固定奖励发放
        Edit: 2018-04-11 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_SIMID    In Varchar2, --返回sim卡id
   I_Userid   In Number, --闲玩用户编号
   I_PType    In Number, --1、ios  2、安卓
   I_MerId    In Varchar2, --用户注册帐号id
   I_MerName  In Varchar2, --用户注册帐号
   I_Levle    In Number, --用户等级、金额等
   I_AGroup   In Number, --组别
   O_AMoney   Out Number, --奖励金额
   O_Result   Out Number,
   O_Message  Out Varchar2);
  procedure PQ_AllMain_windows
  /*****************************************************************
        Procedure Name :PQ_AllMain
        Purpose: 奖励判断全部入口
        Edit: 2018-11-21 add by 小胡
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_SIMID    In Varchar2, --返回sim卡id
   I_MerId    In Varchar2, --用户注册帐号id
   I_MerName  In Varchar2, --用户注册帐号
   I_Levle    In Number, --用户等级、金额等
   I_AType    In Number, --  发奖类型 1 按固定值发放 
   I_AGroup   In Number, --组别
   O_AMoney   Out Number, --奖励金额
   O_Result   Out Number,
   O_Message  Out Varchar2);
  procedure PQ_Common_Windows
  /*****************************************************************
        Procedure Name :PQ_Common
        Purpose: 普通固定奖励发放 
        Edit: 2018-11-21 add by 小胡
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_SIMID    In Varchar2, --返回sim卡id
   I_MerId    In Varchar2, --用户注册帐号id
   I_MerName  In Varchar2, --用户注册帐号
   I_Levle    In Number, --用户等级、金额等
   I_AGroup   In Number, --组别
   O_AMoney   Out Number, --奖励金额
   O_Result   Out Number,
   O_Message  Out Varchar2);
end P_AD_Award_Main;
/


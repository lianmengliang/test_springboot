create PACKAGE BODY P_AD_List AS

  /*广告列表显示*/

  procedure PQ_List
  /*****************************************************************
        Procedure Name :PQ_List
        Purpose: 获取列表
        Edit: 2017-02-13 add by 小沈
    ****************************************************************/
  (I_APPId          In Number, --渠道应用ID
   I_Deviceid       In Varchar2, --设备号ID
   I_SIMID          In Varchar2, --sim卡编号
   I_PType          In Number, --1、ios  2、安卓
   I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始
   O_Outrecordcount Out Number, --返回总记录数
   O_Outcursor      Out t_cursor, --返回游标
   O_Result         Out Number, --判断 0：查询成功，其他：出错
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n         number;
    v_unit      varchar2(50); --货币单位描述 默认元 
    V_SQL       varchar2(3000);
    V_HeiRowNUM number; --小于第几行 分页用
    V_LowROWNUM number; --大于第几行 分页用
    V_SQLSelect varchar2(2000);
    v_PageSize  number;
    v_PageNO    number;
    v_DeviceId  varchar2(100);
  begin
    O_Result  := 0;
    O_Message := '查询成功';
    --去空格处理
    v_DeviceId := fq_str_delspace(i_str => I_Deviceid);
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
 /* 
    insert into aaa_ad_log
      (appid, deviceid, simid, ptype, itime)
    values
      (I_APPId, I_Deviceid, I_SIMID, 1, sysdate);
    commit;*/
  
    /*    v_PageSize := I_PageSize;
    v_PageNO   := I_PageNO;*/
    v_PageSize := 100;
    v_PageNO   := 1;
    --return;
  
    if v_DeviceId is null then
      O_Result  := 1;
      O_Message := '用户信息不能为空';
      return;
    end if;
  
    if I_PType != 2 then
      O_Result  := 2;
      O_Message := '苹果用户不处理！';
      return;
    end if;
  
    if I_PageSize is null then
      O_Result  := 3;
      O_Message := '记录数不能为空';
      return;
    end if;
  
    if I_PageNO is null then
      O_Result  := 4;
      O_Message := '页数不能为空';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_channel
     where appid = I_APPId
       and status != 2;
  
    if v_n <= 0 then
      O_Result  := 5;
      O_Message := '渠道信息不存在';
      return;
    
    end if;
  
    select unit
      into v_unit
      from ad_channel
     where appid = I_APPId
       and status != 2;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
    V_SQLSelect := 'select adid,adname,status,  money, intro, pagename  ,adtypedes,  appsize, imgurl, adlink, showorder  from ad_adinfo where status in (1,2,3)  and phonetype in (2,3) ';
  
    V_SQLSelect := 'select   adid,adname,status, money, intro, pagename,adtypedes ,  appsize, imgurl, adlink, showorder ,
        p_ad_showmoney.fq_deviceid_easy(adid,' || I_APPId ||
                   ', status,''' || I_Deviceid || ''',' || I_PType ||
                   ') MoneyMsg from
       (' || V_SQLSelect ||
                   ' ) where  p_ad_isshow.fq_isshow(adid,' || I_APPId ||
                   ',status, ''' || I_Deviceid || ''',' || I_PType || ')=1';
  
    V_SQLSelect := '  select   adid,adname,status, money, intro, pagename,adtypedes ,  appsize, imgurl, adlink, showorder ,substr(MoneyMsg,0,instr(MoneyMsg,''_'')-1) UStatus,substr(MoneyMsg,instr(MoneyMsg,''_'')+1) ShowMoney  from
  ( ' || V_SQLSelect || '  )';
  
    V_SQLSelect := 'select   adid,adname,status, money, intro, pagename ,adtypedes,  appsize, imgurl, adlink, showorder ,UStatus,ShowMoney,P_AD_List.FQ_Sorting(status,UStatus) Sorting from ( ' ||
                   V_SQLSelect || ' )   ';
    --where UStatus!=2 当天无法拿到奖励则不显示
  
    ----执行分页查询
    V_HeiRowNUM := v_PageNO * v_PageSize;
    V_LowROWNUM := V_HeiRowNUM - v_PageSize + 1;
  
    execute immediate 'select count(1) from (' || V_SQLSelect || ')'
      into O_Outrecordcount;
  
    V_SQLSelect := 'select  adid,adname,status, money, intro, pagename,adtypedes ,  appsize, imgurl, adlink, showorder ,UStatus,ShowMoney,Sorting from (' ||
                   V_SQLSelect || ') order by Sorting desc,showorder asc ';
  
    V_SQL := ' select   adid,adname, money, intro, pagename,adtypedes ,  appsize, imgurl, adlink ,UStatus,replace(ShowMoney,''元'','''') ShowMoney2 , ShowMoney,''' ||
             v_unit ||
             ''' unit  ,Sorting,rn from (
     select    adid,adname, money, intro, pagename ,adtypedes,  appsize, imgurl, adlink ,ShowMoney, UStatus,Sorting ,rownum rn from (  ' ||
             V_SQLSelect || ') a where rownum <=' || to_char(V_HeiRowNUM) ||
             ') b where  rn >= ' || to_char(V_LowROWNUM) ||
             ' ';
    --注意对rownum别名的使用,第一次直接用rownum,第二次一定要用别名rn
    --- order by 放里面会影响速度
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    OPEN O_OUTCURSOR FOR V_SQL;
  
    commit;
    return;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      ROLLBACK;
      O_Result  := -9;
      O_Message := '查询失败';
      RETURN;
  end PQ_List;

  procedure PQ_ListH5
  /*****************************************************************
        Procedure Name :PQ_ListH5
        Purpose: H5获取广告列表
        Edit: 2017-06-07 add by 小沈
    ****************************************************************/
  (I_APPId          In Number, --渠道应用ID
   I_Deviceid       In Varchar2, --设备号ID
   I_SIMID          In Varchar2, --sim卡编号
   I_PType          In Number, --1、ios  2、安卓
   I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始
   O_Outrecordcount Out Number, --返回总记录数
   O_Outcursor      Out t_cursor, --返回游标
   O_Result         Out Number, --判断 0：查询成功，其他：出错
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n         number;
    v_unit      varchar2(50); --货币单位描述 默认元 
    V_SQL       varchar2(3000);
    V_HeiRowNUM number; --小于第几行 分页用
    V_LowROWNUM number; --大于第几行 分页用
    V_SQLSelect varchar2(2000);
    v_PageSize  number;
    v_PageNO    number;
    v_DeviceId  varchar2(100);
  begin
    O_Result  := 0;
    O_Message := '查询成功';
    --去空格处理
    v_DeviceId := fq_str_delspace(i_str => I_Deviceid);
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
    /*    v_PageSize := I_PageSize;
    v_PageNO   := I_PageNO;*/
    v_PageSize := 100;
    v_PageNO   := 1;
  
    --设备号校验是否合法 0否 1是
    if p_base_fun.fq_deviceid_check(I_Deviceid, I_PType) = 0 then
      return;
    end if;
  
   /* insert into aaa_ad_log
      (appid, deviceid, simid, ptype, itime)
    values
      (I_APPId, I_Deviceid, I_SIMID, 2, sysdate);
    commit;*/
  
    /*  if I_APPId = 1070 then
      return;
    end if;*/
  
    if v_DeviceId is null then
      O_Result  := 1;
      O_Message := '用户信息不能为空';
      return;
    end if;
  
    if I_PType != 2 then
      O_Result  := 2;
      O_Message := '苹果用户不处理！';
      return;
    end if;
  
    if I_PageSize is null then
      O_Result  := 3;
      O_Message := '记录数不能为空';
      return;
    end if;
  
    if I_PageNO is null then
      O_Result  := 4;
      O_Message := '页数不能为空';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_channel
     where appid = I_APPId
       and status != 2;
  
    if v_n <= 0 then
      O_Result  := 5;
      O_Message := '渠道信息不存在';
      return;
    
    end if;
  
    select unit
      into v_unit
      from ad_channel
     where appid = I_APPId
       and status != 2;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
    V_SQLSelect := 'select adid,adname,status,  money, intro, pagename,adtypedes , appsize, imgurl, adlink, showorder  from ad_adinfo where status in (1,2,3)  and phonetype in (2,3) ';
  
    V_SQLSelect := 'select   adid,adname,status, money, intro, pagename,adtypedes ,  appsize, imgurl, adlink, showorder ,
        p_ad_showmoney.fq_deviceid_easy(adid,' || I_APPId ||
                   ', status,''' || I_Deviceid || ''',' || I_PType ||
                   ') MoneyMsg from
       (' || V_SQLSelect ||
                   ' ) where  p_ad_isshow.fq_isshow(adid,' || I_APPId ||
                   ',status, ''' || I_Deviceid || ''',' || I_PType || ')=1';
  
    V_SQLSelect := '  select   adid,adname,status, money, intro, pagename ,adtypedes,  appsize, imgurl, adlink, showorder ,substr(MoneyMsg,0,instr(MoneyMsg,''_'')-1) UStatus,substr(MoneyMsg,instr(MoneyMsg,''_'')+1) ShowMoney  from
  ( ' || V_SQLSelect || '  )';
  
    V_SQLSelect := 'select   adid,adname,status, money, intro, pagename,adtypedes ,  appsize, imgurl, adlink, showorder ,UStatus,ShowMoney,P_AD_List.FQ_Sorting(status,UStatus) Sorting from ( ' ||
                   V_SQLSelect || ' )   ';
    --where UStatus!=2 当天无法拿到奖励则不显示
  
    ----执行分页查询
    V_HeiRowNUM := v_PageNO * v_PageSize;
    V_LowROWNUM := V_HeiRowNUM - v_PageSize + 1;
  
    execute immediate 'select count(1) from (' || V_SQLSelect || ')'
      into O_Outrecordcount;
   --regexp_substr(ShowMoney,''[0-9.0-9]+'') ShowMoney 只允许数字
    V_SQLSelect := 'select  adid,adname,status, money, intro, pagename,adtypedes , appsize, imgurl, adlink, showorder ,UStatus,ShowMoney,Sorting from (' ||
                   V_SQLSelect || ') order by Sorting desc,showorder asc ';
  
    V_SQL := ' select   adid,adname, intro, appsize,adtypedes,  imgurl, adlink , case when '||I_APPId||'=1070 then  regexp_substr(ShowMoney,''[0-9.0-9]+'') else  ShowMoney end as  ShowMoney ,''' ||
             v_unit ||
             ''' unit  from (
     select    adid,adname, money, intro, pagename ,adtypedes,  appsize, imgurl, adlink ,ShowMoney, UStatus,Sorting ,rownum rn from (  ' ||
             V_SQLSelect || ') a where rownum <=' || to_char(V_HeiRowNUM) ||
             ') b where  rn >= ' || to_char(V_LowROWNUM) ||
             ' ';
    --注意对rownum别名的使用,第一次直接用rownum,第二次一定要用别名rn
    --- order by 放里面会影响速度
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    OPEN O_OUTCURSOR FOR V_SQL;
    commit;
    return;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      ROLLBACK;
      O_Result  := -9;
      O_Message := '查询失败';
      RETURN;
  end PQ_ListH5;

  Function FQ_Sorting
  /*****************************************************************
        Procedure Name :FQ_Sorting
        Purpose: 判断试玩赚钱广告列表 排序
        Edit: 2017-02-18 add by 小沈
    ****************************************************************/
  (I_ADStatus In Number, --投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放） 
   I_UStatus  In Number --用户当前状态 0 表示未绑定 1表示用户已绑定但是无追加奖励 2表示为用户已绑定并有追加奖励  3表示为用户仅绑定
   ) Return Number As
  
    v_Sorting number;
  
  begin
    v_Sorting := 0;
  
    --未绑定广告正常
    if I_UStatus = 0 and I_ADStatus = 1 then
      v_Sorting := 3;
      return v_Sorting;
    end if;
  
    if I_UStatus = 3 then
      v_Sorting := 2;
      return v_Sorting;
    end if;
  
    --用户有追加奖励
    if I_UStatus = 2 then
      v_Sorting := 1;
      return v_Sorting;
    end if;
  
    if I_UStatus = 1 then
      v_Sorting := 0;
      return v_Sorting;
    end if;
  
    if I_ADStatus in (2, 3, 4) and I_UStatus = 0 then
      v_Sorting := -1;
      return v_Sorting;
    end if;
  
    return 0;
  exception
    --失败
    when others then
      rollback;
      return 0;
  end FQ_Sorting;

  procedure PQ_List_CooHua
  /*****************************************************************
        Procedure Name :PQ_List_CooHua
        Purpose: 获取列表_酷划 定制
        Edit: 2017-03-21 add by 小沈
    ****************************************************************/
  (I_APPId          In Number, --渠道应用ID
   I_Deviceid       In Varchar2, --设备号ID
   I_SIMID          In Varchar2, --sim卡编号
   I_PType          In Number, --1、ios  2、安卓
   I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始
   O_Outrecordcount Out Number, --返回总记录数
   O_Outcursor      Out t_cursor, --返回游标
   O_Result         Out Number, --判断 0：查询成功，其他：出错
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n         number;
    v_unit      varchar2(50); --货币单位描述 默认元 
    V_SQL       varchar2(3000);
    V_HeiRowNUM number; --小于第几行 分页用
    V_LowROWNUM number; --大于第几行 分页用
    V_SQLSelect varchar2(2000);
    v_PageSize  number;
    v_PageNO    number;
    v_DeviceId  varchar2(100);
  begin
    O_Result  := 0;
    O_Message := '查询成功';
    --去空格处理
    v_DeviceId := fq_str_delspace(i_str => I_Deviceid);
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
    /*    v_PageSize := I_PageSize;
    v_PageNO   := I_PageNO;*/
    v_PageSize := 100;
    v_PageNO   := 1;
  
    if v_DeviceId is null then
      O_Result  := 1;
      O_Message := '用户信息不能为空';
      return;
    end if;
  
    if I_PType != 2 then
      O_Result  := 2;
      O_Message := '苹果用户不处理！';
      return;
    end if;
  
    if I_PageSize is null then
      O_Result  := 3;
      O_Message := '记录数不能为空';
      return;
    end if;
  
    if I_PageNO is null then
      O_Result  := 4;
      O_Message := '页数不能为空';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_channel
     where appid = I_APPId
       and status != 2;
  
    if v_n <= 0 then
      O_Result  := 5;
      O_Message := '渠道信息不存在';
      return;
    
    end if;
  
    select unit
      into v_unit
      from ad_channel
     where appid = I_APPId
       and status != 2;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
    V_SQLSelect := 'select adid,adname,status,  money, intro,  appsize, imgurl, adlink  from ad_adinfo where status in (1,2,3)  and phonetype in (2,3) ';
  
    V_SQLSelect := 'select   adid,adname,status, money, intro,  appsize, imgurl, adlink ,
        p_ad_showmoney.fq_deviceid_easy(adid,' || I_APPId ||
                   ', status,''' || I_Deviceid || ''',' || I_PType ||
                   ') MoneyMsg from
       (' || V_SQLSelect ||
                   ' ) where  p_ad_isshow.fq_isshow(adid,' || I_APPId ||
                   ',status, ''' || I_Deviceid || ''',' || I_PType || ')=1';
  
    V_SQLSelect := '  select   adid,adname,status, money, intro,  appsize, imgurl, adlink ,substr(MoneyMsg,0,instr(MoneyMsg,''_'')-1) UStatus,substr(MoneyMsg,instr(MoneyMsg,''_'')+1) ShowMoney  from
  ( ' || V_SQLSelect || '  )';
  
    V_SQLSelect := 'select   adid,adname,status, money, intro,  appsize, imgurl, adlink ,UStatus,ShowMoney,P_AD_List.FQ_Sorting(status,UStatus) Sorting from ( ' ||
                   V_SQLSelect || ' ) where UStatus!=2  ';
  
    ----执行分页查询
    V_HeiRowNUM := v_PageNO * v_PageSize;
    V_LowROWNUM := V_HeiRowNUM - v_PageSize + 1;
  
    execute immediate 'select count(1) from (' || V_SQLSelect || ')'
      into O_Outrecordcount;
  
    V_SQL := ' select   adid,adname, money, intro,  appsize, imgurl, adlink ,UStatus,ShowMoney,''' ||
             v_unit ||
             ''' unit  ,Sorting,rn from (
     select    adid,adname, money, intro,  appsize, imgurl, adlink ,ShowMoney, UStatus,Sorting ,rownum rn from (  ' ||
             V_SQLSelect || ') a where rownum <=' || to_char(V_HeiRowNUM) ||
             ') b where  rn >= ' || to_char(V_LowROWNUM) ||
             ' order by Sorting desc ';
    --注意对rownum别名的使用,第一次直接用rownum,第二次一定要用别名rn
    --- order by 放里面会影响速度
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    OPEN O_OUTCURSOR FOR V_SQL;
    return;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      ROLLBACK;
      O_Result  := -9;
      O_Message := '查询失败';
      RETURN;
  end PQ_List_CooHua;

end P_AD_List;
/


create package P_AD_Register_V2 is

  TYPE T_CURSOR IS REF CURSOR;

  /*广告渠道主信息*/

  procedure PW_Back_Reg
  /*****************************************************************
        Procedure Name :PW_Back_Reg
        Purpose: 广告主返回注册信息
        Edit: 2016-12-08 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告id
   I_FID       In Varchar2, --广告主统计的来源id[apk渠道编号]
   I_DeviceId  In Varchar2, --返回设备号imei idfa
   I_SIMID     In Varchar2, --返回sim卡id
   I_UserId    In Varchar2, --用户注册帐号id
   I_Name      In Varchar2, --用户注册帐号
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);

  function FQ_ChangeDeviceid
  /*****************************************************************
    过程名称：修改绑定表为注册信息设备号
    创建日期：2018-06-12 add by 小沈
    返回：修改是否成功 0：否 1：是
    ****************************************************************/
  (I_ADID     In Number, --广告id 
   I_DeviceId In Varchar2, --返回设备号imei idfa
   I_UserId   In Varchar2 --用户注册帐号id
   ) return Number; --返回修改是否成功 0：否 1：是

  procedure PW_Select_Reg
  /*****************************************************************
        Procedure Name :PW_Select_Reg
        Purpose: 闲玩主动查询注册信息值记录
        Edit: 2018-06-12 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告id
   I_FID      In Varchar2, --广告主统计的来源id[apk渠道编号]
   I_DeviceId In Varchar2, --注册设备号imei idfa
   I_SIMID    In Varchar2, --返回sim卡id
   I_Merid    In Varchar2, --用户注册帐号id
   I_MerName  In Varchar2, --用户注册帐号
   I_XWUserid In Number, --闲玩用户ID 
   O_Result   Out Number,
   O_Message  Out Varchar2);

end P_AD_Register_V2;


/


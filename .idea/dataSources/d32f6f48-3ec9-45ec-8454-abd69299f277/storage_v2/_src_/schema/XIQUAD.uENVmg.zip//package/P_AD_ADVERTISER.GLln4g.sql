create package P_AD_Advertiser is

  TYPE T_CURSOR IS REF CURSOR;

  /*广告渠道主信息*/

  procedure PW_Back_Reg
  /*****************************************************************
        Procedure Name :PW_Back_Reg
        Purpose: 广告主返回注册信息
        Edit: 2016-12-08 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告id 
   I_FID       In Varchar2, --广告主统计的来源id[apk渠道编号] 
   I_DeviceId  In Varchar2, --返回设备号imei idfa
   I_SIMID     In Varchar2, --返回sim卡id
   I_UserId    In Varchar2, --用户注册帐号id
   I_Name      In Varchar2, --用户注册帐号
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);

end P_AD_Advertiser;
/


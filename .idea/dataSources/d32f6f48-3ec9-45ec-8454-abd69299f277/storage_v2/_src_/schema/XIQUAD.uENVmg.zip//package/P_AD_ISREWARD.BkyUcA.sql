create PACKAGE P_AD_IsReward AS

  /*判断该广告该设备号是否可以继续获得奖励*/

  Function FQ_Deviceid
  /*****************************************************************
        Procedure Name :FQ_Deviceid
        Purpose: 根据设备号 判断用户是否还有奖励可以获取
        note: 返回  状态 0 未完成 1已完成 2 已过期 3 正在完成中 4 不予奖励
        Edit: 2017-02-16 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Dlevel   Number, --奖励级别
   I_Deviceid In varchar2, --设备号ID
   I_PType    In number --1、ios  2、安卓
   ) Return Number;

end P_AD_IsReward;


/


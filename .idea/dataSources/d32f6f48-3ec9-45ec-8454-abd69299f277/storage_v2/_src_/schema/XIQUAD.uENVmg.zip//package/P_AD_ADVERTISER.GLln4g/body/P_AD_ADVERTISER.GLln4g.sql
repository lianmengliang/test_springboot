create package body P_AD_Advertiser is

  /*广告主信息*/

  procedure PW_Back_Reg
  /*****************************************************************
        Procedure Name :PW_Back_Reg
        Purpose: 广告主返回注册信息
        Edit: 2016-12-08 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告id 
   I_FID       In Varchar2, --广告主统计的来源id[apk渠道编号] 
   I_DeviceId  In Varchar2, --返回设备号imei idfa
   I_SIMID     In Varchar2, --返回sim卡id
   I_UserId    In Varchar2, --用户注册帐号id
   I_Name      In Varchar2, --用户注册帐号
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    v_n       Number;
    v_appid   Number; --渠道合作编号
    v_appsign Varchar2(200); --渠道合作编号
    v_status  Number; --匹配状态 0 失败 ； 1  成功  
    v_amoney  Number; --奖励金额
    v_result  Number; --
    v_message Varchar2(100); -- 
    v_record  Number := 0; --之前是否已有记录 0否 1是
  begin
    o_result  := 0;
    o_message := '接收成功';
    v_status  := 0;
    v_appid   := 0;
    v_appsign := '0';
    open O_OUTCURSOR for
      select 1 from dual;
  
    select count(1)
      into v_n
      from ad_adv_back_reg
     where adid = I_ADID
       and userid = I_UserId;
  
    if v_n > 0 then
      v_record := 1;
      --判断是否已匹配
      select count(1)
        into v_n
        from ad_adv_back_reg
       where adid = I_ADID
         and userid = I_UserId
         and status = 1;
      --如果存在且已匹配成功
      if v_n > 0 then
        open O_OUTCURSOR for
          select I_DeviceId as deviceid,
                 v_appsign  as appsign,
                 v_amoney   as amoney
            from dual;
      
        o_result  := 0;
        o_message := '该用户信息已记录！';
        return;
      end if;
    end if;
  
    --查看设备号是否有点击记录 且帐号未返回
  
    select count(1)
      into v_n
      from ad_app_bind
     where adid = I_ADID
       and upper(deviceid) = upper(I_DeviceId)
       and ustatus = 1;
    if v_n > 0 then
      select appid, appsign
        into v_appid, v_appsign
        from ad_app_bind
       where adid = I_ADID
         and upper(deviceid) = upper(I_DeviceId);
      v_status := 1;
    
    end if;
  
    if v_record = 0 then
    
      --添加
      insert into ad_adv_back_reg
        (adid,
         fid,
         appid,
         appsign,
         deviceid,
         simid,
         userid,
         name,
         status,
         lasttime)
      values
        (I_adid,
         I_FID,
         v_appid,
         v_appsign,
         I_DeviceId,
         I_SIMID,
         I_UserId,
         I_Name,
         v_status,
         sysdate);
    
    end if;
  
    commit;
  
    --如果匹配成功 则 进行注册奖励
    --匹配状态 0 失败 ； 1  成功  
    if v_status = 1 then
    
      --如果是之前有返回帐号信息的，后来重新匹配上的 则需要修改 【一般出现在有注册返回和注册查询接口 的情况】
      if v_record = 1 then
        --修改原先匹配帐号信息
        update ad_adv_back_reg
           set deviceid = I_DeviceId,
               appid    = v_appid,
               appsign  = v_appsign,
               status   = v_status,
               lasttime = sysdate
         where adid = I_adid
           and userid = I_UserId;
      end if;
    
      select count(1)
        into v_n
        from ad_app_bind
       where adid = I_adid
         and appid = v_appid
         and ustatus = 1
         and upper(deviceid) = upper(I_DeviceId);
    
      if v_n > 0 then
        update ad_app_bind
           set merid    = I_UserId,
               mername  = I_Name,
               ustatus  = 3,
               lasttime = sysdate
         where adid = I_adid
           and appid = v_appid
           and ustatus = 1
           and upper(deviceid) = upper(I_DeviceId);
      
        commit;
      
        p_ad_award_main.pq_allmain_windows(i_adid     => I_ADID,
                                   i_appid    => v_appid,
                                   i_deviceid => I_DeviceId,
                                   i_simid    => I_SIMID,
                                   i_merid    => I_UserId,
                                   i_mername  => I_Name,
                                   i_levle    => 0, --注册为0等级
                                   i_atype    => 1, --  发奖类型 1 按固定值发放 
                                   i_agroup   => 1, --注册为第一组别
                                   o_amoney   => v_amoney,
                                   o_result   => v_result,
                                   o_message  => v_message);
        commit;
      end if;
    
    end if;
  
    if I_ADID = 2054 then
      v_appsign := 0;
    end if;
  
    open O_OUTCURSOR for
      select I_DeviceId as deviceid,
             v_appsign  as appsign,
             v_amoney   as amoney
        from dual;
  
  exception
    --失败 
    when others then
      rollback;
      O_Result  := 1001;
      O_Message := '接收异常！';
      -- o_message := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_Back_Reg;

end P_AD_Advertiser;
/


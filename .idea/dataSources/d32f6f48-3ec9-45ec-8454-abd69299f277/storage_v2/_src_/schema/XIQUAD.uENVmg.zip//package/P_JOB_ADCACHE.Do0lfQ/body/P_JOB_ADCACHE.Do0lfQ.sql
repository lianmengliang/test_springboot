create PACKAGE BODY P_Job_ADCache AS

  /*广告 缓存 JOB*/

  procedure Job_ADCache
  /*****************************************************************
        procedure name: Job_ADCache
        purpose: 广告缓存
       edit: 2018-11-17 add by 小沈
    ****************************************************************/
  (I_Sign In Number) is
    v_reward       number := 0; --0 剩余可以获得奖励
    v_reward_times number := 0;
    v_adstatus     number := 0; --投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放） 
    v_isShow       number := 0; --是否显示  0 不显示 1 显示
  begin
  
    declare
      cursor myCur is
        select id, adid, appid, deviceid, userid, ptype, ip, ip_num
          from cache_ad_list
         where status = 2
           and mod(id, 5) = I_Sign;
    begin
    
      for cur in myCur loop
        v_reward       := 0;
        v_reward_times := 0;
        select status into v_adstatus from ad_adinfo where adid = cur.adid;
        -- 根据闲玩用户 获得还可获得奖励金额
        p_ad_showmoney_v2.pq_usermoney(i_adid     => cur.adid,
                                       i_appid    => cur.appid,
                                       i_adstatus => v_adstatus,
                                       i_deviceid => cur.deviceid,
                                       i_userid   => cur.userid,
                                       i_ptype    => cur.ptype,
                                       o_allmoney => v_reward,
                                       o_alltimes => v_reward_times);
      
        v_isShow := p_ad_isshow_v3.fq_isshow(i_adid     => cur.adid,
                                             i_appid    => cur.appid,
                                             i_deviceid => cur.deviceid,
                                             i_userid   => cur.userid,
                                             i_ip       => cur.ip,
                                             i_ip_num   => cur.ip_num,
                                             i_ptype    => cur.ptype);
      
        update cache_ad_list
           set reward       = v_reward,
               reward_times = v_reward_times,
               isshow       = v_isShow,
               status       = 1,
               ltime        = sysdate
         where id = cur.id;
      
        commit;
      end loop;
    
      commit;
    end;
  
  exception
    when others then
      rollback;
      return;
  end Job_ADCache;

  procedure Job_ADCache_FluxUser
  /*****************************************************************
        procedure name: Job_ADCache_FluxUser
        purpose: 广告缓存  --已经获得过奖励的用户进行缓存的更新
       edit: 2018-11-17 add by 小沈
    ****************************************************************/
   is
    v_Adid         number := 0; --
    v_UserdId      number := 0; --用户
    v_reward       number := 0; --0 剩余可以获得奖励
    v_reward_times number := 0;
    v_adstatus     number := 0; --投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放） 
    v_isShow       number := 0; --是否显示  0 不显示 1 显示
  begin
  
    declare
      cursor FluxUserCur is
      
        select adid, userid
          from ad_app_flux
         where itime >= sysdate - 30 / (24 * 60)
         group by adid, userid;
    
      cursor myCur is
        select id, adid, appid, deviceid, userid, ptype
          from cache_ad_money
         where adid = v_Adid
           and userid = v_UserdId;
    begin
    
      for CUser in FluxUserCur loop
        v_Adid    := CUser.adid;
        v_UserdId := CUser.userid;
      
        for cur in myCur loop
          v_reward       := 0;
          v_reward_times := 0;
          select status
            into v_adstatus
            from ad_adinfo
           where adid = cur.adid;
          -- 根据闲玩用户 获得还可获得奖励金额
          p_ad_showmoney_v2.pq_usermoney(i_adid     => cur.adid,
                                         i_appid    => cur.appid,
                                         i_adstatus => v_adstatus,
                                         i_deviceid => cur.deviceid,
                                         i_userid   => cur.userid,
                                         i_ptype    => cur.ptype,
                                         o_allmoney => v_reward,
                                         o_alltimes => v_reward_times);
        
         
        
          update cache_ad_money
             set reward       = v_reward,
                 reward_times = v_reward_times, 
                 ltime        = sysdate
           where id = cur.id;
        
          commit;
        end loop;
      
      end loop;
    
      commit;
    end;
  
  exception
    when others then
      rollback;
      return;
  end Job_ADCache_FluxUser;

  procedure Job_ADCache_0
  /*****************************************************************
        procedure name: Job_ADCache_0
        
    ****************************************************************/
   is
    v_n number;
  
  begin
    p_job_adcache.job_adcache(i_sign => 0);
  
  exception
    when others then
      rollback;
      return;
  end Job_ADCache_0;

  procedure Job_ADCache_1
  /*****************************************************************
        procedure name: Job_ADCache_0
        
    ****************************************************************/
   is
    v_n number;
  
  begin
    p_job_adcache.job_adcache(i_sign => 1);
  
  exception
    when others then
      rollback;
      return;
  end Job_ADCache_1;

  procedure Job_ADCache_2
  /*****************************************************************
        procedure name: Job_ADCache_0
        
    ****************************************************************/
   is
    v_n number;
  
  begin
    p_job_adcache.job_adcache(i_sign => 2);
  
  exception
    when others then
      rollback;
      return;
  end Job_ADCache_2;

  procedure Job_ADCache_3
  /*****************************************************************
        procedure name: Job_ADCache_0
        
    ****************************************************************/
   is
    v_n number;
  
  begin
    p_job_adcache.job_adcache(i_sign => 3);
  
  exception
    when others then
      rollback;
      return;
  end Job_ADCache_3;

  procedure Job_ADCache_4
  /*****************************************************************
        procedure name: Job_ADCache_0
        
    ****************************************************************/
   is
    v_n number;
  
  begin
    p_job_adcache.job_adcache(i_sign => 4);
  
  exception
    when others then
      rollback;
      return;
  end Job_ADCache_4;

end P_Job_ADCache;
/


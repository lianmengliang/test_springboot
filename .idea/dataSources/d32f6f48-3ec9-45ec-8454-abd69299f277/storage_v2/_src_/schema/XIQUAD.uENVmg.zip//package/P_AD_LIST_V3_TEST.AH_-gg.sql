create PACKAGE P_AD_List_V3_Test AS

  TYPE T_CURSOR IS REF CURSOR;

  /*
  广告列表显示_3.0版本 --增加IP 限制判断
  2018-09-17
  */

  procedure PQ_List
  /*****************************************************************
        Procedure Name :PQ_ListH5
        Purpose: 获取广告列表
        Edit: 2018-03-27 add by 小沈
    ****************************************************************/
  (I_APPId          In Number, --渠道应用ID
   I_Deviceid       In Varchar2, --设备号ID
   I_SIMID          In Varchar2, --sim卡编号
   I_Userid         In Number, --闲玩用户编号
   I_PType          In Number, --1、ios  2、安卓
   I_UType          In Number, --用户需要状态 0：全部 1：正在参与
   I_IP             In Varchar2, --用户当前IP
   I_IP_Num         In Number, --用户当前IP 数字化
   I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始
   O_Outrecordcount Out Number, --返回总记录数
   O_Outcursor      Out t_cursor, --返回游标
   O_Result         Out Number, --判断 0：查询成功，其他：出错
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  Function FQ_Sorting
  /*****************************************************************
        Procedure Name :FQ_Sorting
        Purpose: 判断试玩赚钱广告列表 排序
        Edit: 2017-02-18 add by 小沈
    ****************************************************************/
  (I_ADStatus In Number, --投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放）
   I_UStatus  In Number --用户当前状态 0 表示未绑定 1表示用户已绑定但是无追加奖励 2表示为用户已绑定并有追加奖励  3表示为用户仅绑定
   ) Return Number;

  procedure PQ_List_RandomAD
  /*****************************************************************
        Procedure Name :PQ_List_RandomAD
        Purpose: 获取随机广告
        Edit: 2018-09-17  add by 小沈
    ****************************************************************/
  (I_APPId     In Number, --渠道应用ID
   I_Deviceid  In Varchar2, --设备号ID
   I_SIMID     In Varchar2, --sim卡编号
   I_PType     In Number, --1、ios  2、安卓
   I_IP        In Varchar2, --用户当前IP
   I_IP_Num    In Number, --用户当前IP 数字化
   I_Userid    In Number, --闲玩用户编号
   I_Count     In Number, --获取随机广告的数量
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number, --判断 0：查询成功，其他：出错
   O_Message   Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

end P_AD_List_V3_Test;


/


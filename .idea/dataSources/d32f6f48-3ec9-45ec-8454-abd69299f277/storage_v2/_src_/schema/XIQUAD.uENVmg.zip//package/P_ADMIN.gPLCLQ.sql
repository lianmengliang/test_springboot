create Package P_Admin is

  Type T_Cursor Is Ref Cursor;

  /*管理员操作*/

  Function FQ_IsQX
  /******************************************************************
    function Name: FQ_IsQX
    Purpose: 判断管理员是否有权限
    Author: 沈志江
    
    *****************************************************************/
  (I_AdminID In Varchar2,
   I_QXID    In Number --权限编号
   ) Return Number; --0有此权限，不等于零没有此权限

  procedure PQ_Privilege_List
  /*****************************************************************
        Procedure Name :PQ_Privilege_List
        Purpose: 当前已有权限列表
        Edit: 2018-02-24 add by 小沈
    ****************************************************************/
  (I_AdminID        In Varchar2, --管理员ID 
   I_PageSize       In Number,
   I_PageNO         In Number,
   O_OutRecordCount Out Number,
   O_OutCursor      Out T_CURSOR, --返回游标
   O_Result         Out Number, --返回（0正确，其他为提示或错误）
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  Procedure PW_AddQX
  /*****************************************************************
        Procedure Name :PW_AddQX
        Purpose: 权限的增加
        Edit: 2017-05-01 add by 小沈
    ****************************************************************/
  (I_AdminID     In Varchar2,
   I_QXName      In Varchar2, --权限名称 
   I_Description In Varchar2, -- 描述 
   I_Url         In Varchar2, -- 权限地址 
   I_Rank        In Number, -- 权限排序号
   I_GName       In Varchar2, -- 分组名称 
   I_GRank       In Varchar2, -- 分组排序号需和之前的一样
   I_ReportId    In Number, -- 报表ID  
   I_IsShow      In Number, -- 1表示显示，0表示不显示 
   I_OpenType    In Number, -- 页面打开方式 ： 0：否 ；1：_blank 新窗 
   I_IsIp        In Number, --ip限制（1限制，0默认不限制）  
   O_Result      Out Number,
   O_Message     Out Varchar2);

  Procedure PW_EditQX
  /*****************************************************************
        Procedure Name :PW_EditQX
        Purpose: 权限的修改
        Edit: 2017-05-01 add by 小沈
    ****************************************************************/
  (I_AdminID     In Varchar2,
   I_QXID        In Number, --权限编号 
   I_QXName      In Varchar2, --权限名称 
   I_Description In Varchar2, -- 描述 
   I_Url         In Varchar2, -- 权限地址 
   I_Rank        In Number, -- 权限排序号
   I_GName       In Varchar2, -- 分组名称 
   I_GRank       In Varchar2, -- 分组排序号需和之前的一样
   I_ReportId    In Number, -- 报表ID 无报表写0 
   I_IsShow      In Number, -- 1表示显示，0表示不显示 
   I_OpenType    In Number, -- 页面打开方式 ： 0：否 ；1：_blank 新窗 
   I_IsIp        In Number, --ip限制（1限制，0默认不限制） 
   O_Result      Out Number,
   O_Message     Out Varchar2);

  Procedure PW_DelQX
  /*****************************************************************
        Procedure Name :PW_DelQX
        Purpose: 权限的删除
        Edit: 2018-03-06 add by 小沈
    ****************************************************************/
  (I_AdminID In Varchar2,
   I_QXID    In Number, --权限编号  
   O_Result  Out Number,
   O_Message Out Varchar2);

  procedure PQ_AdminList
  /*****************************************************************
        Procedure Name :PQ_AdminList
        Purpose: 查询管理员列表
        Edit: 2018-02-23 add by 小沈
    ****************************************************************/
  (I_AdminID        In Varchar2, --管理员ID
   O_OutRecordCount Out Number,
   O_OutCursor      Out T_CURSOR, --返回游标
   O_Result         Out Number, --返回（0正确，其他为提示或错误）
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  procedure PQ_Privilege_Admin
  /*****************************************************************
        Procedure Name :PQ_Privilege_Admin
        Purpose: 根据操作获取管理员权限查询
        Edit: 2018-02-23 add by 小沈
    ****************************************************************/
  (I_AdminID        In Varchar2, --管理员ID
   I_SubAdminID     In Varchar2, --被查询管理员ID
   I_Type           In Number, --要操作的方式（0：当前权限；1：待授权限）
   I_PageSize       In Number,
   I_PageNO         In Number,
   O_OutRecordCount Out Number,
   O_OutCursor      Out T_CURSOR, --返回游标
   O_Result         Out Number, --返回（0正确，其他为提示或错误）
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  Procedure PW_ConfigQX
  /*****************************************************************
        Procedure Name :PW_ConfigQX
        Purpose: 权限配置
        Edit: 2017-05-01 add by 小沈
    ****************************************************************/
  (I_AdminID   In Varchar2, --
   I_QXID      In Number, --权限编号 
   I_ToAdminID In Varchar2, --受权管理员 
   I_Status    In Number, --状态 1添加 2去除 
   O_Result    Out Number,
   O_Message   Out Varchar2);

  Procedure PQ_MenuList
  /*****************************************************************
        Procedure Name :PQ_MenuList
        Purpose: 获取权限列表
        Edit: 2017-05-01 add by 小沈
    ****************************************************************/
  (I_AdminID   In Varchar2,
   O_Outcursor out t_cursor, --返回游标
   O_Result    out number, --判断 0：查询成功，其他：出错
   O_Message   out varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  Procedure PW_ChangePSW
  /*****************************************************************
        Procedure Name :PW_ChangePSW
        Purpose: 管理员修改密码
        Edit: 2017-05-01 add by 小沈
    ****************************************************************/
  (I_AdminID     In Varchar2,
   I_OldPassWord IN VARCHAR2, --老密码
   I_NewPassWord IN VARCHAR2, --新密码
   O_Result      out number, --判断 0：查询成功，其他：出错
   O_Message     out varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  procedure PW_LoginSendCode
  /*****************************************************************
        Procedure Name :PW_LoginSendCode
        Purpose: 管理员登录发送验证码
        Edit: 2018-07-05 add by 小沈
    ****************************************************************/
  (I_AdminId in varchar2, --管理员id
   I_PWD     in varchar2, --用户密码
   I_IP      in varchar2, --ip
   O_Result  out number, --返回（0正确，其他为提示或错误）
   O_Message out varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  procedure PW_AdminLogin
  /*****************************************************************
        Procedure Name :PW_AdminLogin
        Purpose: 管理员登录
        Edit: 2016-10-31 add by 小沈
    ****************************************************************/
  (I_AdminId in varchar2, --管理员id
   I_PWD     in varchar2, --用户密码
   I_Code    in varchar2, --用户验证码
   I_IP      in varchar2, --ip
   O_Result  out number, --返回（0正确，其他为提示或错误）
   O_Message out varchar2 --返回信息（操作结果，成功或者错误信息）
   );

End P_Admin;


/


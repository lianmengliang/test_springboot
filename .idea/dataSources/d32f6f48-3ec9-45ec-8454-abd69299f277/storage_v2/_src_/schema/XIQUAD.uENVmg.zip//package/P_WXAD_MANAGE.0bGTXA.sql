create package P_WXAD_Manage is

  procedure PW_AD_Add
  /*****************************************************************
        Procedure Name :pw_AD_Add
        Purpose: 微信广告增加
        Edit: 2017-10-14 add by 小沈
    ****************************************************************/
  (I_AdminID   In Varchar2,
   I_Title     In Varchar2, --广告名称[内部使用] 
   I_ADName    In Varchar2, --前台显示广告名称 
   I_Status    In Number, --投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放） 
   I_ShowType  In Number, --0不显示，1显示 
   I_ADType    In Number, --广告类型（1转发，2关注） 
   I_Intro     In Varchar2, --广告简介 
   I_Money     In Varchar2, --奖励总金额 
   I_StartTime In Varchar2, --广告投放时间 
   I_StopTime  In Varchar2, --停止投放时间 
   I_PhoneType In Number, --1、ios，  2、安卓， 3、ios和安卓都显示 
   I_Wechat    In Varchar2, --微信号 
   I_Imgurl    In Varchar2, --广告小图片地址
   I_ADLink    In Varchar2, --广告地址
   I_AMoney    In Number, --到款金额 
   I_ShowOrder In Number, --排序号 
   O_Result    Out number,
   O_Message   Out varchar2);

end P_WXAD_Manage;


/


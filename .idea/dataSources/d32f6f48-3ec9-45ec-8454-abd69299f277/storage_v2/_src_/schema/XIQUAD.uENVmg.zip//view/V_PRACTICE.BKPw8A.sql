create view V_PRACTICE as
select pname,sex from practice
/


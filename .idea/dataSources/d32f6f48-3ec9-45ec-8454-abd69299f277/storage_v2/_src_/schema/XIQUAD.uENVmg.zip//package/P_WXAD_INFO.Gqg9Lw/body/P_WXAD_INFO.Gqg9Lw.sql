create PACKAGE BODY P_WXAD_Info AS

  /*分享广告页*/

  procedure PQ_ADInfo
  /*****************************************************************
        Procedure Name :PQ_ADInfo
        Purpose: 获取微信广告页面信息
        Edit: 2017-10-14 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   I_APPId     In Number, --渠道应用ID
   I_Deviceid  In Varchar2, --设备号ID
   I_SIMID     In Varchar2, --sim卡编号
   I_AppSign   In Varchar2, ---渠道标识
   I_PType     In Number, --1、ios  2、安卓
   O_Outcursor out t_cursor, --返回游标
   O_Result    out number, --判断 0：查询成功，其他：出错
   O_Message   out varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n           number;
    v_LimitStatus number; --限制状态
    v_LimitMsg    varchar2(500); --限制信息
    v_ShowMsg     varchar2(500); --页面显示信息
    v_bind        number; --是否绑定 0 否 1 是
    v_z_times     number; --转发/关注-奖励次数 
    v_z_reward    number; --转发/关注-已获得报酬 
    v_is_invite   number; --是否为可邀请广告 0：否 1：是 
    v_awardtime   varchar2(200); --最近奖励时间
    v_wechatname  varchar2(50); --微信名称 
  begin
    O_Result  := 0;
    O_Message := '查询成功';
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
    v_bind        := 0;
    v_LimitStatus := 0; --限制状态
    v_z_times     := 0; --转发/关注-奖励次数 
    v_z_reward    := 0; --转发/关注-已获得报酬 
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
  
    if I_Deviceid is null then
      O_Result  := 1;
      O_Message := '请返回后重新进入';
      return;
    end if;
  
    if I_ADID is null then
      O_Result  := 2;
      O_Message := '请返回后刷新，再重新点击进入';
      return;
    end if;
  
    select count(1)
      into v_n
      from wx_adinfo
     where adid = I_ADID
       and phonetype in (2, 3);
  
    if v_n <= 0 then
      O_Result  := 3;
      O_Message := '该广告暂时无法体验，请返回后选择其他广告';
      return;
    end if;
  
    select count(1)
      into v_n
      from wx_ad_bind
     where adid = I_ADID
       and deviceid = I_Deviceid;
  
    --如果用户没转发过该广告，判断其是否可参与
    if v_n <= 0 then
      v_bind := 0; --是否绑定 0 否 1 是
    
      P_WXAD_Info.pq_adlimit(i_adid     => i_adid,
                             i_appid    => i_appid,
                             i_deviceid => i_deviceid,
                             i_simid    => i_simid,
                             i_ptype    => i_ptype,
                             o_status   => v_LimitStatus,
                             o_msg      => v_LimitMsg);
    
      --如果用户无法参与广告则返回
      if v_LimitStatus != 0 then
        v_ShowMsg := v_LimitMsg;
      end if;
    
      --如果用户已经绑定 获得过奖励
    else
      v_bind := 1; --是否绑定 0 否 1 是
      select z_times, z_reward
        into v_z_times, v_z_reward
        from wx_ad_bind
       where adid = I_ADID
         and deviceid = I_Deviceid;
    
      --查看是否有待奖励金额
      select count(1)
        into v_n
        from wx_ad_flux
       where adid = I_ADID
         and deviceid = I_Deviceid
         and status = 0;
      if v_n > 0 then
      
        select is_invite
          into v_is_invite
          from wx_adinfo
         where adid = I_ADID;
      
        select to_char(min(exptime) + 60 / (24 * 60 * 60),
                       'yyyy-mm-dd hh24:mi:ss')
          into v_awardtime
          from wx_ad_flux
         where adid = I_ADID
           and deviceid = I_Deviceid
           and status = 0;
      
        select wechatname
          into v_wechatname
          from wx_ad_token
         where adid = I_ADID;
      
        if v_is_invite = 1 then
          v_ShowMsg := '您已成功关注了' || v_wechatname || ',还有<span style="color:red">' || v_n ||
                       '</span>笔奖励等待发放，最近的奖励发放时间预计在<span style="color:red">' || v_awardtime ||
                       '</span>，邀请更多好友关注并回复密令可获得更多奖励哦！';
        else
          v_ShowMsg := '您已成功关注了' || v_wechatname || ',还有<span style="color:red">' || v_n ||
                       '</span>笔奖励等待发放，最近的奖励发放时间预计在<span style="color:red">' || v_awardtime || '</span>,请耐心等待！';
        end if;
      
      end if;
    
    end if;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
  
    OPEN O_OutCursor FOR
      select adid,
             adname,
             money, --奖励总金额 
             money_one, --单次可获得奖励 
             is_invite, --是否为可邀请广告 0：否 1：是 
             intro, --广告简介
             status, --投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放）
             v_LimitStatus as LimitStatus,
             adtype, ----广告类型（1转发，2关注） 
             wechat, ---微信号
             imgurl,
             sharelink, --分享连接
             v_ShowMsg     as ShowMsg,
             v_bind        as isbind,
             v_z_times     as z_times, --分享转发次数
             v_z_reward    as z_reward --分享转发获得奖励
      
        from wx_adinfo
       where adid = i_adid;
  
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    return;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      ROLLBACK;
      O_Result  := -9;
      O_Message := '查询失败';
      RETURN;
  end PQ_ADInfo;

  PROCEDURE PQ_ADLimit
  /*****************************************************************
        Procedure Name :PQ_ADLimit
        Purpose: 获取微信广告用户限制信息 只有未参与的用户才回进入
        Edit: 2017-04-23 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_SIMID    In Varchar2, --sim卡编号
   I_PType    In Number, --1、ios  2、安卓
   O_Status   out number, -- 限制状态 0 正常 1、广告尚未投放 2、日流量到量 3、总流量到量 4、已停止投放 5、用户被限制  6、广告被限制 7、SIMID被限制  8、设备号限制
   O_Msg      out varchar2 --描述信息
   ) is
    v_n      number;
    v_status number;
  
  begin
    O_Status := 0;
    O_Msg    := '';
  
    if I_Deviceid is null then
      O_Status := 9;
      O_Msg    := '请返回后重新进入';
      return;
    end if;
  
    --判断奖励是否已设置
    select count(1) into v_n from wx_ad_awardset where adid = i_adid;
  
    if v_n <= 0 then
      O_Status := 1; --广告尚未投放
      O_Msg    := '该广告还未设置奖励或尚未投放，请先体验其他广告！';
      return;
    end if;
  
    select status into v_status from wx_adinfo where adid = i_adid;
  
    /*判断广告状态*/
    case v_status
      when 0 then
        O_Status := 1; --广告尚未投放
        O_Msg    := '该广告尚未投放，请先体验其他广告！';
        return;
      when 2 then
        select count(1)
          into v_n
          from wx_ad_bind
         where adid = i_adid
           and deviceid = I_Deviceid;
        if v_n = 0 then
          O_Status := 2; --日流量到量
          O_Msg    := '广告今日已到量，请先体验其他广告';
          return;
        end if;
      when 3 then
        select count(1)
          into v_n
          from wx_ad_bind
         where adid = i_adid
           and deviceid = I_Deviceid;
        if v_n = 0 then
          O_Status := 3; --总流量到量
          O_Msg    := '广告已到量，请体验其他广告';
          return;
        end if;
      when 4 then
        O_Status := 4; --已停止投放
        O_Msg    := '该广告尚已停止投放，请体验其他广告！';
        return;
      else
        O_Status := 0;
    end case;
  
    --设备号限制表判断
    select count(1)
      into v_n
      from ad_limit_deviceid
     where adid = i_adid
       and deviceid = I_Deviceid;
    if v_n > 0 then
      O_Status := 8; --限制体验
      O_Msg    := '您的手机暂时无法体验该广告';
      return;
    end if;
  
    return;
  
  end PQ_ADLimit;

  procedure PW_CreateWechatKL
  /*****************************************************************
        Procedure Name :PW_CreateWechatKL
        Purpose: 创建微信口令
        Edit: 2017-10-14 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_SIMID    In Varchar2, --sim卡编号
   I_AppSign  In Varchar2, ---渠道标识
   I_PType    In Number, --1、ios  2、安卓 
   I_IP       In Varchar2, ---IP
   O_WechatKL Out Varchar2, --微信关注口令
   O_Result   Out Number, --判断 0：查询成功，其他：出错
   O_Message  Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n        number;
    v_WechatKL varchar2(50); --微信关注口令
  
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
  
    if I_Deviceid is null then
      O_Result  := 1;
      O_Message := '请返回后重新进入';
      return;
    end if;
  
    if I_ADID is null then
      O_Result  := 2;
      O_Message := '请返回后刷新，再重新点击进入';
      return;
    end if;
  
    select count(1)
      into v_n
      from wx_adinfo
     where adid = I_ADID
       and phonetype in (2, 3);
  
    if v_n <= 0 then
      O_Result  := 3;
      O_Message := '该广告暂时无法体验，请返回后选择其他广告';
      return;
    end if;
  
    select count(1)
      into v_n
      from wx_ad_kl
     where adid = I_ADID
       and deviceid = I_Deviceid;
  
    if v_n <= 0 then
    
      --生成密令
      loop
      
        v_WechatKL := '#' || p_base_fun.fq_random_str(4) || '#';
        select count(1)
          into v_n
          from wx_ad_kl
         where wechat_kl = v_WechatKL;
        exit when v_n <= 0;
      
      end loop;
    
      O_WechatKL := v_WechatKL;
    
      insert into wx_ad_kl
        (adid, appid, deviceid, simid, appsign, wechat_kl, ptype, ip)
      values
        (i_adid,
         i_appid,
         i_deviceid,
         i_simid,
         i_appsign,
         v_WechatKL,
         I_PType,
         I_ip);
      commit;
    else
      select wechat_kl
        into O_WechatKL
        from wx_ad_kl
       where adid = I_ADID
         and deviceid = I_Deviceid;
    end if;
  
    return;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      ROLLBACK;
      O_Result  := -9;
      O_Message := '查询失败';
      RETURN;
  end PW_CreateWechatKL;

  procedure PQ_GZ_List
  /*****************************************************************
        Procedure Name :PQ_List
        Purpose: 获取关注广告列表
        Edit: 2017-10-16 add by 小沈
    ****************************************************************/
  (I_APPId          In Number, --渠道应用ID
   I_Deviceid       In Varchar2, --设备号ID
   I_SIMID          In Varchar2, --sim卡编号
   I_AppSign        In Varchar2, ---渠道标识
   I_PType          In Number, --1、ios  2、安卓
   I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始 
   O_Outrecordcount Out Number, --返回总记录数
   O_Outcursor      Out t_cursor, --返回游标
   O_Result         Out Number, --判断 0：查询成功，其他：出错
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
  
    V_SQL       varchar2(3000);
    V_HeiRowNum number; --小于第几行 分页用
    V_LowROWNum number; --大于第几行 分页用 
    v_PageSize  number;
    v_PageNO    number;
  
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
    v_PageSize := I_PageSize;
    v_PageNO   := I_PageNO;
    v_PageSize := 20;
    v_PageNO   := 1;
  
    if I_Deviceid is null then
      O_Result  := 1;
      O_Message := '设备号不能为空';
      return;
    end if;
  
    if I_PageSize is null then
      O_Result  := 3;
      O_Message := '记录数不能为空';
      return;
    end if;
  
    if I_PageNO is null then
      O_Result  := 4;
      O_Message := '页数不能为空';
      return;
    end if;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
  
    V_SQL := 'select adid ,adname ,adlink  ,  imgurl, money  ,money_one,intro    from  wx_adinfo 
     where  status in (0, 1)  and p_wxad_info.fq_gz_isshow(' ||
             I_APPId || ', adid, ''' || I_Deviceid || ''',' || I_PType ||
             ') = 1
         order by adid asc';
  
    ----执行分页查询
    V_HeiRowNUM := v_PageNO * v_PageSize;
    V_LowROWNUM := V_HeiRowNUM - v_PageSize + 1;
  
    execute immediate 'select count(1) from (' || V_SQL || ')'
      into O_Outrecordcount;
  
    V_SQL := ' select   adid ,adname ,adlink  ,  imgurl, money  ,money_one,intro  ,rn from (
     select  adid ,adname ,adlink  ,  imgurl, money  ,money_one ,intro , rownum rn from (  ' ||
             V_SQL || '  ) a where rownum <=' || to_char(V_HeiRowNUM) ||
             ') b where  rn >= ' || to_char(V_LowROWNUM);
    --注意对rownum别名的使用,第一次直接用rownum,第二次一定要用别名rn
    --- order by 放里面会影响速度
    OPEN O_OUTCURSOR FOR V_SQL;
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    return;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      ROLLBACK;
      O_Result  := -9;
      O_Message := '查询失败';
      RETURN;
  end PQ_GZ_List;

  Function FQ_GZ_IsShow
  /*****************************************************************
        Procedure Name :FQ_IsShow
        Purpose: 根据用户ID判断是否显示   -- 是否显示 0 不显示 1 显示关注
        Edit:  2017-01-17 by 小沈  
    ****************************************************************/
  (I_APPId    In Number, --渠道应用ID
   I_ADID     In Number, --广告ID 
   I_Deviceid In Varchar2, --设备号ID 
   I_PType    In Number --1、ios  2、安卓
   ) Return Number As
    -- 是否显示 0 不显示 1 显示关注
  
    v_NeedA number; --需要关注数  默认20次
    v_n     number;
  
    v_status    number;
    v_showtype  number; ---0不显示，1显示
    v_adstatus  number; --广告状态
    v_bind      number; --是否绑定 0 否 1 是
    v_adtype    number; --广告类型（1转发，2关注）
    v_times     number; --限制奖励次数
    v_z_times   number; --转发/关注-奖励次数 
    v_phonetype number; --1、ios  2、安卓 3、全部
  
  begin
  
    v_bind  := 0;
    v_NeedA := 1;
    if I_Deviceid is null or I_ADID = 0 then
      v_status := 0; --不显示
      return v_status;
    end if;
  
    --判断奖励是否已设置
    select count(1)
      into v_n
      from wx_ad_awardset
     where adid = i_adid
       and appid = I_APPId;
  
    if v_n <= 0 then
      v_status := 0;
      return v_status;
    end if;
  
    select showtype, status, phonetype, adtype
      into v_showtype, v_adstatus, v_phonetype, v_adtype
      from wx_adinfo
     where adid = I_ADID;
  
    --非关注广告
    if v_adtype != 2 then
      v_status := 0;
      return v_status;
    end if;
  
    --0不显示，1显示 如果广告还在测试阶段 只有测试用户才可以看见
  
    --非正常投放
    if v_adstatus not in (0, 1) then
      v_status := 0;
      return v_status;
    end if;
  
    if v_showtype = 0 then
      select count(1)
        into v_n
        from ad_testdevice
       where deviceid = I_Deviceid
         and status = 0;
      if v_n <= 0 then
        v_status := 0;
        return v_status;
      end if;
    end if;
  
    --1、ios  2、安卓 3、全部
    if nvl(v_phonetype, 3) != 3 then
      if v_phonetype != I_PType then
        v_status := 0; --不显示
        return v_status;
      end if;
    end if;
  
    --设备号限制表判断
    select count(1)
      into v_n
      from ad_limit_deviceid
     where adid = i_adid
       and deviceid = I_Deviceid;
    if v_n > 0 then
      v_status := 0;
      return v_status;
    end if;
  
    --是否关注过
    select count(1)
      into v_bind
      from wx_ad_bind
     where adid = I_ADID
       and deviceid = I_Deviceid;
  
    if v_bind <= 0 then
      v_status := 1;
      return v_status;
    end if;
  
    --判断是否拿完全部奖励
  
    if v_bind > 0 then
      select times
        into v_times
        from wx_ad_awardset
       where adid = I_ADID
         and appid = I_APPId
         and atype = 2;
    
      select z_times
        into v_z_times
        from wx_ad_bind
       where adid = I_ADID
         and deviceid = I_Deviceid;
    
      --如果已经拿满奖励
      if v_z_times >= v_times then
        v_status := 0; --不显示
        return v_status;
      end if;
    
    end if;
  
    return 1;
  exception
    --失败
    when others then
      rollback;
      return 0;
  end FQ_GZ_IsShow;

end P_WXAD_Info;
/


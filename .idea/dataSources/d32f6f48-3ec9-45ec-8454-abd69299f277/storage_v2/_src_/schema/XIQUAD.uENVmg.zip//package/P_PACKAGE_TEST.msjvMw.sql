create package p_package_test is

  TYPE T_CURSOR IS REF CURSOR;

  procedure pq_AD_ActRecordList
  /*****************************************************************
        Procedure Name :pq_AD_ActAwardList
        Purpose: 冲级赛名单
        Edit: 2018-8-29 add by 小胡
    ****************************************************************/
  (I_AdmInId        In Varchar2, --管理员id
   I_ADID           In Number, --广告id
   I_ACTID          In Number, --活动ID
   I_PageSize       In Number,
   I_PageNO         In Number,
   O_OutRecordCount Out Number,
   O_OutCursor      Out t_cursor, --返回游标
   O_Result         Out Number,
   O_Message        Out Varchar2);

  procedure pq_Ad_BannerList
  /*****************************************************************
    Procedure Name:pq_Ad_BannerList 
    Purpose: 查询Banner图
    Edit: 2018-08-30 add by 小胡
    ****************************************************************/
  (I_ADMINID   In Varchar2,
   I_ADID      In Number,
   I_ADNAME    In Varchar2,
   I_STATUS    In Number,
   I_PhoneType In Number,
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure pw_Ad_AddBanner
  /*****************************************************************
    Procedure Name:pw_Ad_AddBanner 
    Procedure Name: 添加Banner图
    Edit: 2018-08-30 add by 小胡
    ****************************************************************/
  (I_ADMINID   In Varchar2, --管理员id
   I_ADID      In Number, --广告Id
   I_ADNAME    In Varchar2, --广告名称
   I_IMGURL    In Varchar2, --Banner图存储路径
   I_STATUS    In Number, --状态 0：未开启 1：正常 2：关闭
   I_PHONETYPE In Number, --应用类型 1、ios，  2、安卓， 3、ios和安卓都显示
   I_ADTYPE    In Number, --广告类型 1：普通广告 2：关注广告
   I_STIME     In Varchar2, --Banner投放开始时间
   I_ETIME     In Varchar2, --Banner停止投放时间
   O_Result    Out Number,
   O_Message   Out Varchar2);
  procedure pw_AD_EditBanner
  /*****************************************************************
    Procedure Name:pw_Ad_AddBanner 
    Procedure Name: 编辑Banner图
    Edit: 2018-08-30 add by 小胡
    ****************************************************************/
  (I_ID        In Varchar2, --Banner图id
   I_ADMINID   In Varchar2, --管理员id
   I_ADID      In Number, --广告Id
   I_ADNAME    In Varchar2, --广告名称
   I_IMGURL    In Varchar2, --Banner图存储路径
   I_STATUS    In Number, --状态 0：未开启 1：正常 2：关闭
   I_PHONETYPE In Number, --应用类型 1、ios，  2、安卓， 3、ios和安卓都显示
   I_ADTYPE    In Number, --广告类型 1：普通广告 2：关注广告
   I_STIME     In Varchar2, --Banner投放开始时间
   I_ETIME     In Varchar2, --Banner停止投放时间
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure PQ_AD_ChangeXH
  /*****************************************************************
       Procedure Name:PQ_AD_ChangeXH 
       Procedure Name: 查询广告消耗报表的额外金额修改记录
       Edit: 2018-09-7 add by 小胡
    ****************************************************************/
  (I_ADMINID   In Varchar2, --管理员id
   I_ADID      In Number, --广告ID
   I_TYPE      In Number, --记录类型 1、调整 2、余额
   I_ID        In Number, --记录ID
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);
  procedure PW_AD_AddChangeXH
  /*****************************************************************
       Procedure Name:PW_AD_AddChangeXH 
       Procedure Name:  添加广告消耗报表的额外金额修改记录
       Edit: 2018-09-7 add by 小胡
    ****************************************************************/
  (I_ADMINID In Varchar2, --管理员id
   I_ADID    In Number, --广告ID
   I_TYPE    In Number, --记录类型 1、调整 2、余额
   I_MONEY   In Number, --金额
   I_Text    In Varchar2, --备注
   O_Result  Out Number,
   O_Message Out Varchar2);
  procedure PW_AD_UpdateChangeXH
  /*****************************************************************
       Procedure Name:PW_AD_UpdateChangeXH 
       Procedure Name:  修改广告消耗报表的额外金额修改记录
       Edit: 2018-09-7 add by 小胡
    ****************************************************************/
  (I_ADMINID In Varchar2, --管理员id
   I_ID      In Number, --记录ID
   I_ADID    In Number, --广告ID
   I_TYPE    In Number, --记录类型 1、调整 2、余额
   I_MONEY   In Number, --金额
   I_Text    In Varchar2, --备注
   O_Result  Out Number,
   O_Message Out Varchar2);
  procedure PW_AD_DeleteChangeXH
  /*****************************************************************
       Procedure Name:PW_AD_DeleteChangeXH 
       Procedure Name:  删除广告消耗报表的额外金额修改记录
       Edit: 2018-09-7 add by 小胡
    ****************************************************************/
  (I_ADMINID In Varchar2, --管理员id
   I_ID      In Number, --记录ID
   O_Result  Out Number,
   O_Message Out Varchar2);
  procedure pq_fin_AD_list
  /*****************************************************************
        Procedure Name :pq_fin_AD_list
        Purpose: 广告列表
        Edit: 2018-9-08 add by 小胡
    ****************************************************************/
  (I_AdmInId        In Varchar2,
   I_ADID           In Number,
   I_ADName         In Varchar2,
   I_Status         In Number,
   I_ShowType       In Number,
   I_PhoneType      In Number,
   I_ADType         In Number,
   I_Market         In Varchar2,
   I_SDATE          In Varchar2,
   I_EDATE          In Varchar2,
   I_PageSize       In Number,
   I_PageNO         In Number,
   O_OutRecordCount Out Number,
   O_OutCursor      Out t_cursor, --返回游标
   O_Result         Out Number,
   O_Message        Out Varchar2);

  procedure PW_Back_Reg
  /*****************************************************************
        Procedure Name :PW_Back_Reg
        Purpose: 广告主返回注册信息
        Edit: 2018-04-12 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告id
   I_FID       In Varchar2, --广告主统计的来源id[apk渠道编号]
   I_DeviceId  In Varchar2, --返回设备号imei idfa
   I_SIMID     In Varchar2, --返回sim卡id
   I_UserId    In Varchar2, --用户注册帐号id
   I_Name      In Varchar2, --用户注册帐号
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure pq_AD_Info
  /*****************************************************************
        Procedure Name :pq_AD_Info
        Purpose: 广告信息
        Edit: 2016-12-05 add by 小沈
    ****************************************************************/
  (I_AdminID   in varchar2,
   I_ADID      in Number,
   O_OutCursor OUT t_cursor, --返回游标
   O_Result    Out number,
   O_Message   Out varchar2);

  procedure pw_AD_Add
  /*****************************************************************
        Procedure Name :pw_AD_Add
        Purpose: 广告增加
        Edit: 2016-12-05 add by 小沈
    ****************************************************************/
  (I_AdminID       In Varchar2,
   I_Title         In Varchar2, -- 广告名称[内部使用]
   I_ADName        In Varchar2, --   前台显示广告名称
   I_Money         In Number, --  奖励总金额
   I_Intro         In Varchar2, --   广告简介
   I_Status        In Number, --   投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放）
   I_ShowType      In Number, --   0不显示，1显示
   I_StartTime     In Varchar2, --广告投放时间
   I_StopTime      In Varchar2, --停止投放时间
   I_PhoneType     In Number, --   1、ios，  2、安卓， 3、ios和安卓都显示
   I_ADType        In Number, --   广告类型（1游戏，2应用，3其他）
   I_APPSize       In Varchar2, --   文件大小
   I_ImgURL        In Varchar2, --   广告小图片地址
   I_Description   In Varchar2, --   广告介绍描述
   I_DesImgUrls    In Varchar2, --   广告图片描述 
   I_ADLink        In Varchar2, --   安卓广告地址
   I_PageName      In Varchar2, --   安卓应用的包名称
   I_IOSADLink     In Varchar2, --   IOS广告地址
   I_IOSPageName   In Varchar2, --   IOS应用程序名称 BoundleId
   I_IOSURLSchemes In Varchar2, --   IOS用于打开APP应用的 URL Schemes
   I_IOSPROName    In Varchar2, --   IOS 进程名称 ProcessName
   I_IOSVersion    In Varchar2, --   IOS应用版本号
   I_IOSKEYWord    In Varchar2, --   搜索关键字
   I_IOSRank       In Number, --   关键字在appstore排位
   I_APPSign       In Number, --   绑定方式 0、下载绑定 1、账号返回 2、自助提交  3、下载安装返回
   I_ButtonShow    In Number, --   下载按钮和进度条是否显示（1显示，0不显示）
   I_ButtonName    In Varchar2, --   试玩按钮名称
   I_ShowOrder     In Number, --  排序号
   I_MSGNOInstall  In Varchar2, --   未安装提示-无需下载app则提示和未注册一致
   I_MSGNoReg      In Varchar2, --   未注册提示
   I_MsgReg        In Varchar2, --   已注册提示
   I_MSGDayLimit   In Varchar2, --  日限量提示信息
   I_MSGAllLimit   In Varchar2, --  到量提示信息
   I_ISRECOMMEND   In Number, --  是否推荐该广告 1：推荐 0：不推荐
   I_ISEASY        In Number, --  是否为简单广告 1：是 0：否   
   O_Result        Out number,
   O_Message       Out varchar2);

  procedure pw_AD_Edit
  /*****************************************************************
        Procedure Name :pw_AD_Edit
        Purpose: 广告修改
        Edit: 2016-12-05 add by 小沈
    ****************************************************************/
  (I_AdminID       In Varchar2,
   I_ADID          In Number, --  广告ID
   I_Title         In Varchar2, -- 广告名称[内部使用]
   I_ADName        In Varchar2, --   前台显示广告名称
   I_Money         In Number, --  奖励总金额
   I_Intro         In Varchar2, --   广告简介
   I_Status        In Number, --   投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放）
   I_ShowType      In Number, --   0不显示，1显示
   I_StartTime     In Varchar2, --广告投放时间
   I_StopTime      In Varchar2, --停止投放时间
   I_PhoneType     In Number, --   1、ios，  2、安卓， 3、ios和安卓都显示
   I_ADType        In Number, --   广告类型（1游戏，2应用，3其他）
   I_APPSize       In Varchar2, --   文件大小
   I_ImgURL        In Varchar2, --   广告小图片地址
   I_Description   In Varchar2, --   广告介绍描述
   I_DesImgUrls    In Varchar2, --   广告图片描述 
   I_ADLink        In Varchar2, --   安卓广告地址
   I_PageName      In Varchar2, --   安卓应用的包名称
   I_IOSADLink     In Varchar2, --   IOS广告地址
   I_IOSPageName   In Varchar2, --   IOS应用程序名称 BoundleId
   I_IOSURLSchemes In Varchar2, --   IOS用于打开APP应用的 URL Schemes
   I_IOSPROName    In Varchar2, --   IOS 进程名称 ProcessName
   I_IOSVersion    In Varchar2, --   IOS应用版本号
   I_IOSKEYWord    In Varchar2, --   搜索关键字
   I_IOSRank       In Number, --   关键字在appstore排位
   I_APPSign       In Number, --   绑定方式 0、下载绑定 1、账号返回 2、自助提交  3、下载安装返回
   I_ButtonShow    In Number, --   下载按钮和进度条是否显示（1显示，0不显示）
   I_ButtonName    In Varchar2, --   试玩按钮名称
   I_ShowOrder     In Number, --  排序号
   I_MSGNOInstall  In Varchar2, --   未安装提示-无需下载app则提示和未注册一致
   I_MSGNoReg      In Varchar2, --   未注册提示
   I_MsgReg        In Varchar2, --   已注册提示
   I_MSGDayLimit   In Varchar2, --  日限量提示信息
   I_MSGAllLimit   In Varchar2, --  到量提示信息
   I_ISRECOMMEND   In Number, --  是否推荐该广告 1：推荐 0：不推荐
   I_ISEASY        In Number, --  是否为简单广告 1：是 0：否 
   O_Result        Out number,
   O_Message       Out varchar2);

  procedure pq_HavGetedMoney
  /*****************************************************************
        Procedure Name :pq_HavGetedMoney
        Purp:2018-12-18 Edit by 胡银杜
    ****************************************************************/
  (I_USERID     In Number, --用户
   O_ISGETMONEY Out Number,
   O_Result     Out number,
   O_Message    Out varchar2);
  procedure PQ_Common
  /*****************************************************************
        Procedure Name :PQ_Common
        Purpose: 普通固定奖励发放
        Edit: 2018-04-11 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_SIMID    In Varchar2, --返回sim卡id
   I_Userid   In Number, --闲玩用户编号
   I_PType    In Number, --1、ios  2、安卓
   I_MerId    In Varchar2, --用户注册帐号id
   I_MerName  In Varchar2, --用户注册帐号
   I_Levle    In Number, --用户等级、金额等
   I_AGroup   In Number, --组别
   O_AMoney   Out Number, --奖励金额
   O_Result   Out Number,
   O_Message  Out Varchar2);
  procedure PQ_AwardOrderCheck
  /*****************************************************************
        Procedure Name :PQ_AwardOrderCheck
        Purpose: 奖励订单审核
        Edit: 2018-11-01 add by 小胡
    ****************************************************************/
  (I_AdmInId  In Varchar2, --管理员id
   I_ORDERNUM In Varchar2, --订单编号
   I_STATUS   In Number, --订单状态
   I_ADID     In Varchar2,
   I_APPID    In Varchar2,
   O_Result   Out Number,
   O_Message  Out Varchar2);
  procedure PQ_Syncad
  /*****************************************************************
        Procedure Name :PQ_syncad
        Purpose: 同步闲玩广告
        Edit: 2019-05-29 add by 小刘
    ****************************************************************/
  (I_AdmInId In Varchar2, --管理员id
   I_ADID    In Varchar2,
   O_Result  Out Number,
   O_Message Out Varchar2);

end p_package_test;
/


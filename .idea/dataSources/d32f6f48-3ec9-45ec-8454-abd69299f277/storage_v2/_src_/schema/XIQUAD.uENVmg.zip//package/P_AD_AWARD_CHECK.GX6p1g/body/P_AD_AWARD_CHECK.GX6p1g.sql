create package body P_AD_Award_Check is

  /*奖励检查*/

  Procedure Job_AutoCheck
  /*****************************************************************
        procedure name: Job_AutoCheck
        purpose: 自动检查奖励订单
        edit: 2018-08-23 add by 小沈
    ****************************************************************/
   is
    v_n     number;
    v_price number;
  
    v_UTotal number := 0; --用户合计拿奖次数
    v_STimes number := 0; --奖励设置允许次数
  
    v_admin      varchar2(100); --广告负责人
    v_adminPhone varchar2(18); ---负责人手机号码
    v_msg        varchar2(100); --需要发送内容
  
    v_adminPhone_s varchar2(18) := '15111489689'; --超级管理员号码
  
    v_result  number;
    v_message varchar2(100);
  
    cursor Order_List is
    
      select adid,
             appid,
             ordernum,
             deviceid,
             Dlevel,
             merid,
             price,
             p_status
        from ad_channel_order
       where itime > sysdate - 30 / (24 * 60)
         and p_status = -1;
  
  begin
    v_n := 0;
  
    for C_Order in Order_List loop
    
      --判断订单是否已被处理过
      select count(1)
        into v_n
        from ad_channel_order
       where adid = C_Order.Adid
         and appid = C_Order.appid
         and ordernum = C_Order.Ordernum
         and p_status = -1;
    
      if v_n <= 0 then
        goto Next_C_Order;
      end if;
    
      if C_Order.Appid in (1010, 1011) then
        update ad_channel_order
           set p_status = 3, check_time = sysdate
         where adid = C_Order.Adid
           and appid = C_Order.Appid
           and deviceid = C_Order.Deviceid
           and itime >= sysdate - 40 / (24 * 60)
           and p_status = -1;
        commit;
      end if;
    
      --1、判断20分钟内的结算金额是否超过3000
    
      select sum(price)
        into v_price
        from ad_app_flux
       where itime > sysdate - 20 / (24 * 60)
         and adid = C_Order.Adid
         and deviceid = C_Order.Deviceid;
    
      if v_price > 3000 then
      
        update ad_channel_order
           set p_status = 9, check_time = sysdate
         where adid = C_Order.Adid
           and appid = C_Order.Appid
           and deviceid = C_Order.Deviceid
           and itime >= sysdate - 40 / (24 * 60)
           and p_status = -1;
        commit;
      
        --添加短信报警
      
        select trim(marketer)
          into v_admin
          from ad_downurl
         where adid = C_Order.Adid;
      
        select phone into v_adminPhone from t_admin where name = v_admin;
        v_msg := '广告ID:' || C_Order.Adid || '有奖励需要审核';
        p_sms.pw_alarm_add(i_phone     => v_adminPhone,
                           i_message   => v_msg,
                           i_sendlevel => 1,
                           i_sendtype  => 1,
                           o_result    => v_result,
                           o_message   => v_message);
      
        p_sms.pw_alarm_add(i_phone     => v_adminPhone_s,
                           i_message   => v_msg,
                           i_sendlevel => 1,
                           i_sendtype  => 1,
                           o_result    => v_result,
                           o_message   => v_message);
      
        goto Next_C_Order;
      end if;
    
      --2、判断订单是否存在多条相同奖励
    
      select count(1)
        into v_UTotal
        from ad_app_flux
       where adid = C_Order.Adid
         and appid = C_Order.Appid
         and deviceid = C_Order.Deviceid
         and dlevel = C_Order.Dlevel;
    
      select times
        into v_STimes
        from ad_awardset
       where adid = C_Order.Adid
         and appid = C_Order.Appid
         and dlevel = C_Order.Dlevel;
    
      if v_UTotal > v_STimes then
      
        --如果只是多一条 则直接删除
        if v_UTotal = v_STimes + 1 then
        
          delete ad_channel_order
           where adid = C_Order.Adid
             and appid = C_Order.Appid
             and merid = C_Order.Merid
             and dlevel = C_Order.Dlevel
             and rownum = 1
             and p_status = -1;
        
          delete ad_app_flux
           where adid = C_Order.Adid
             and merid = C_Order.Merid
             and dlevel = C_Order.Dlevel
             and rownum = 1;
          commit;
        
          insert into aaa_ad_log
            (appid, deviceid, simid, ptype, itime, adid, dlevel, merid)
          values
            (C_Order.Appid,
             C_Order.Deviceid,
             C_Order.Deviceid,
             2,
             sysdate,
             C_Order.Adid,
             C_Order.Dlevel,
             C_Order.Merid);
          commit;
        
        else
          update ad_channel_order
             set p_status = 9, check_time = sysdate
           where adid = C_Order.Adid
             and appid = C_Order.Appid
             and deviceid = C_Order.Deviceid
             and dlevel = C_Order.Dlevel
             and p_status = -1;
          commit;
        
          v_msg := '广告ID:' || C_Order.Adid || '等级' || C_Order.Dlevel ||
                   '并发用户需要审核';
          p_sms.pw_alarm_add(i_phone     => '15111489689',
                             i_message   => v_msg,
                             i_sendlevel => 1,
                             i_sendtype  => 1,
                             o_result    => v_result,
                             o_message   => v_message);
        
        end if;
        goto Next_C_Order;
      
      end if;
    
      --如果都没有问题 修改为待推送
      update ad_channel_order
         set p_status = 0, check_time = sysdate
       where adid = C_Order.Adid
         and appid = C_Order.appid
         and ordernum = C_Order.Ordernum
         and p_status = -1;
    
      <<Next_C_Order>>
      null;
    
    end loop;
    commit;
  exception
    when others then
      rollback;
      v_message := '错误编码：' || sqlcode || '  错误信息 ：' || sqlerrm;
    
      return;
  end Job_AutoCheck;

end P_AD_Award_Check;
/


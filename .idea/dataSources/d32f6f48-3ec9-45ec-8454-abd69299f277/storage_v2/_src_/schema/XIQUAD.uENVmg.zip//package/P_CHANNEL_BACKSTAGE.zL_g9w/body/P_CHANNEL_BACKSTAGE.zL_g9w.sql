create PACKAGE BODY P_Channel_Backstage AS

  /*渠道管理后台*/

  procedure PW_Register
  /*****************************************************************
        Procedure Name :PW_Register
        Purpose: 渠道管理员注册帐号
        Edit: 2018-05-14 add by 小沈
    ****************************************************************/
  (I_Account   In Varchar2, --管理员帐号
   I_Password  In Varchar2, --用户密码
   I_Name      In Varchar2, --渠道管理员姓名 
   I_Phone     In Varchar2, --管理员联系电话  
   I_IP        In Varchar2, --ip
   O_AccountID Out Number, --管理员帐号ID
   O_Result    Out Number, --返回（0正确，其他为提示或错误）
   O_Message   Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n number;
  begin
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
    O_Result    := 0;
    O_Message   := '登录成功';
    O_AccountID := 0;
  
    --管理员帐号是否为空
    if I_Account is null then
      O_Result  := 1;
      O_Message := '请输入你的帐号！';
      return;
    end if;
  
    --密码不允许为空
    if I_Password is null then
      O_Result  := 2;
      O_Message := '请输入你的密码！';
      return;
    end if;
  
    --渠道管理员姓名 是否为空
    if I_Name is null then
      O_Result  := 3;
      O_Message := '请输入管理员姓名 ！';
      return;
    end if;
  
    --渠道管理员电话 是否为空
    if I_Phone is null then
      O_Result  := 4;
      O_Message := '请输入管理员联系电话 ！';
      return;
    end if;
  
    --管理员联系电话是否为空
    if I_IP is null then
      O_Result  := 5;
      O_Message := '请刷新页面后重试！';
      return;
    end if;
  
    ----------------------------------------------------
    --步骤二：注册帐号
    ----------------------------------------------------
  
    --判断用户
    select count(1) into v_n from ch_admin t where t.Account = I_Account;
  
    --如果帐号已存在
    if (v_n > 0) then
      O_Result  := 6;
      O_Message := '该帐号已存在请重新注册! ';
      return;
    end if;
  
    O_AccountID := SQ_ch_admin.Nextval;
    insert into ch_admin
      (account_id, account, password, name, phone)
    values
      (O_AccountID, i_account, i_password, i_name, i_phone);
  
    insert into ch_power_config
      (id, account_id, powerid, admin_id, itime)
      select sq_ch_power_config.nextval,
             O_AccountID,
             powerid,
             'system',
             sysdate
        from ch_power
       where status = 1
         and powerid not in (12, 13, 14);
  
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    commit;
    return;
  exception
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '创建渠道帐号异常！' || sqlerrm;
      return;
    
  end PW_Register;

  procedure PW_Login
  /*****************************************************************
        Procedure Name :PW_Login
        Purpose: 渠道管理员登录
        Edit: 2018-05-14 add by 小沈
    ****************************************************************/
  (I_Account   In Varchar2, --管理员帐号
   I_Password  In Varchar2, --用户密码
   I_IP        In Varchar2, --ip
   O_AccountID Out Number, --管理员帐号ID
   O_Result    Out Number, --返回（0正确，其他为提示或错误）
   O_Message   Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n number;
  begin
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
    O_Result    := 0;
    O_Message   := '登录成功';
    O_AccountID := 0;
  
    --管理员帐号是否为空
    if I_Account is null then
      O_Result  := 10;
      O_Message := '请输入你的帐号！';
      return;
    end if;
  
    --密码不允许为空
    if I_Password is null then
      O_Result  := 11;
      O_Message := '请输入你的密码！';
      return;
    end if;
  
    --ip是否为空
    if I_IP is null then
      O_Result  := 13;
      O_Message := '请刷新页面后重试！';
      return;
    end if;
  
    ----------------------------------------------------
    --步骤二：登录
    ----------------------------------------------------
  
    --判断用户
    select count(1)
      into v_n
      from ch_admin t
     where t.Account = I_Account
       and t.password = I_Password;
  
    --用户名或密码是否错误
    if (v_n != 1) then
      O_Result  := 99;
      O_Message := '用户名或密码错误! ';
      return;
    end if;
  
    select account_id
      into O_AccountID
      from ch_admin t
     where t.Account = I_Account
       and t.password = I_Password;
  
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
  
    return;
  exception
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '登录异常！';
      return;
    
  end PW_Login;

  Procedure PW_ChangePSW
  /*****************************************************************
        Procedure Name :PW_ChangePSW
        Purpose: 管理员修改密码
        Edit: 2018-05-14 add by 小沈
    ****************************************************************/
  (I_AccountID   In Number, --管理员帐号ID
   I_OldPassWord In VARCHAR2, --老密码
   I_NewPassWord In VARCHAR2, --新密码
   O_Result      Out Number, --判断 0：查询成功，其他：出错
   O_Message     Out VARCHAR2 --返回信息（操作结果，成功或者错误信息）
   ) is
  
    v_n Number;
  begin
    O_Result  := 0;
    O_Message := '密码修改成功，请重新登录！';
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
  
    --管理员帐号是否为空
    if I_AccountID is null or I_AccountID <= 0 then
      O_Result  := 1;
      O_Message := '请先登录后台';
      return;
    end if;
  
    select count(1)
      into v_n
      from ch_admin
     where account_id = I_AccountID
       and status = 1;
  
    if v_n = 0 then
      O_Result  := 2;
      O_Message := '您还不是管理员';
      return;
    end if;
  
    --输入参数是否正确
    if I_OldPassWord is null then
      O_Result  := 3;
      O_Message := '输入不能为空，请检查！';
      return;
    end if;
  
    --输入参数是否正确
    if I_NewPassWord is null then
      O_Result  := 4;
      O_Message := '请输入新密码！';
      return;
    end if;
  
    --管理员旧密码是否正确
    select count(1)
      into v_n
      from ch_admin
     where account_id = I_AccountID
       and password = I_OldPassWord;
  
    if V_N = 0 then
      O_Result  := 10;
      O_Message := '旧密码错误，请检查！';
      return;
    end if;
  
    --校验新密码的复杂性
    if length(I_NewPassWord) < 5 then
      O_Result  := 107;
      O_Message := '密码长度太短，请检查！';
      return;
    end if;
  
    ----------------------------------------------------
    --步骤二：修改
    ----------------------------------------------------
    update ch_admin
       set password = I_NewPassWord
     where account_id = I_AccountID;
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    commit;
    return;
  
  Exception
    --失败
    When Others Then
      rollback;
      O_Result  := -9;
      O_Message := '查询失败';
      Return;
  end PW_ChangePSW;

  Procedure PQ_MenuList
  /*****************************************************************
        Procedure Name :PQ_MenuList
        Purpose: 获取权限列表
        Edit: 2018-05-14 add by 小沈
    ****************************************************************/
  (I_AccountID In Number, --管理员帐号ID
   O_Outcursor out t_cursor, --返回游标
   O_Result    out number, --判断 0：查询成功，其他：出错
   O_Message   out varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
  
    v_n Number;
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
    select count(1) into v_n from ch_admin where account_id = I_AccountID;
  
    if v_n = 0 then
      O_Result  := 1;
      O_Message := '您的帐号有误，请重新登录';
      return;
    end if;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
  
    OPEN O_OUTCURSOR FOR
      select a.gname,
             a.grank,
             (select count(1) from ch_power where gname = a.gname) CTotal,
             a.powerid,
             a.powername,
             a.url,
             a.opentype
        from ch_power a, ch_power_config b
       where a.powerid = b.powerid
         and b.account_id = I_AccountID
         and a.isshow = 1
       order by grank, gname, rank asc;
  
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    commit;
    return;
  
  Exception
    --失败
    When Others Then
      rollback;
      O_Result  := -9;
      O_Message := '查询失败';
      Return;
  end PQ_MenuList;

  Procedure PQ_AppList
  /*****************************************************************
        Procedure Name :PQ_AppList
        Purpose: 获取应用列表
        Edit: 2018-05-14 add by 小沈
    ****************************************************************/
  (I_AccountID In Number, --管理员帐号ID
   O_Outcursor out t_cursor, --返回游标
   O_Result    out number, --判断 0：查询成功，其他：出错
   O_Message   out varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
  
    v_n Number;
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
    select count(1) into v_n from ch_admin where account_id = I_AccountID;
  
    if v_n = 0 then
      O_Result  := 1;
      O_Message := '您的帐号有误，请重新登录';
      return;
    end if;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
  
    OPEN O_OUTCURSOR FOR
      select appid, name
        from ad_channel a
       where a.ch_account_id = I_AccountID
         and a.status in (0, 1)
       order by appid asc;
  
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    commit;
    return;
  
  Exception
    --失败
    When Others Then
      rollback;
      O_Result  := -9;
      O_Message := '查询失败';
      Return;
  end PQ_AppList;

  Procedure PQ_Revenue
  /*****************************************************************
        Procedure Name :PQ_Revenue
        Purpose: 渠道收入概况
        Edit: 2018-05-19 add by 小沈
    ****************************************************************/
  (I_AccountID In Number, --管理员帐号ID
   I_APPID     In Number, --渠道应用编号
   O_Outcursor out t_cursor, --返回游标
   O_Result    out number, --判断 0：查询成功，其他：出错
   O_Message   out varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
  
    v_n                Number := 0;
    v_SqlWhere         varchar(1000); --条件语句
    v_RevenueToday     Number := 0; --今日收入
    v_RevenueYesterday Number := 0; --昨日收入
    v_RevenueTotal     Number := 0; --总收入
    v_Balance          Number := 0; --余额
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
    select count(1) into v_n from ch_admin where account_id = I_AccountID;
  
    if v_n = 0 then
      O_Result  := 1;
      O_Message := '您的帐号有误，请重新登录';
      return;
    end if;
  
    --如果不是0 则需要判断应用编号是否属于该渠道
    if I_APPID != 0 then
      select count(1)
        into v_n
        from ad_channel
       where appid = I_APPID
         and ch_account_id = I_AccountID;
      if v_n <= 0 then
        O_Result  := 10;
        O_Message := '请重新选择你要查询的应用信息！';
        return;
      end if;
    
      v_SqlWhere := ' and appid=' || I_APPID;
    else
      v_SqlWhere := ' and appid in ( select appid from ad_channel where ch_account_id =' ||
                    I_AccountID || ' ) ';
    end if;
  
    ----------------------------------------------------
    --步骤二：查询信息
    ----------------------------------------------------
    -- 今日收入
    execute immediate ' select  nvl(sum(price),0) from ad_app_flux where itime>=trunc(sysdate)  ' ||
                      v_SqlWhere
      into v_RevenueToday;
  
    -- 昨日收入
    execute immediate 'select  nvl(sum(round(expend_c,2)),0)   from   fin_expend_day where dtime=trunc(sysdate)-1   ' ||
                      v_SqlWhere
      into v_RevenueYesterday;
  
    -- 总收入
    execute immediate 'select  nvl(sum(round(expend_c,2)),0)   from   fin_expend_day where 1=1   ' ||
                      v_SqlWhere
      into v_RevenueTotal;
    v_RevenueTotal := v_RevenueTotal + v_RevenueToday;
  
    -- 余额
    v_Balance := 0;
  
    ----------------------------------------------------
    --步骤三：返回记录集
    ----------------------------------------------------
  
    OPEN O_OUTCURSOR FOR
      select v_RevenueToday     as RevenueToday,
             v_RevenueYesterday as RevenueYesterday,
             v_RevenueTotal     as RevenueTotal,
             v_Balance          as Balance
        from dual;
    commit;
    return;
  
  Exception
    --失败
    When Others Then
      rollback;
      O_Result  := -9;
      O_Message := '查询失败';
      Return;
  end PQ_Revenue;

  procedure PQ_Revenue_Trend
  /*****************************************************************
        Procedure Name :PQ_Revenue_Trend
        Purpose:  渠道收入趋势
        Edit: 2018-05-19 add by 小沈
    ****************************************************************/
  (I_AccountID      In Number, --管理员帐号ID
   I_APPID          In Number, --渠道应用编号
   I_SDate          In Varchar2, --开始日期
   I_EDate          In Varchar2, --截止日期
   I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始
   O_Outrecordcount Out Number, --返回总记录数
   O_Outcursor      Out t_cursor, --返回游标
   O_Result         Out Number, --判断 0：查询成功，其他：出错
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n         number;
    v_SqlWhere  varchar(1000); --条件语句 
    V_SQL       varchar2(3000);
    V_HeiRowNUM number; --小于第几行 分页用
    V_LowRowNUM number; --大于第几行 分页用
  
    v_PageSize number;
    v_PageNO   number;
  
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
  
    if I_SDate is null then
      O_Result  := 10;
      O_Message := '开始日期不能为空';
      return;
    end if;
  
    if I_EDate is null then
      O_Result  := 11;
      O_Message := '截止日期不能为空';
      return;
    end if;
  
    if I_PageSize is null then
      O_Result  := 12;
      O_Message := '记录数不能为空';
      return;
    end if;
  
    if I_PageNO is null then
      O_Result  := 13;
      O_Message := '页数不能为空';
      return;
    end if;
  
    select count(1) into v_n from ch_admin where account_id = I_AccountID;
  
    if v_n = 0 then
      O_Result  := 1;
      O_Message := '您的帐号有误，请重新登录';
      return;
    end if;
  
    v_PageSize := I_PageSize;
    v_PageNO   := I_PageNO;
  
    --如果不是0 则需要判断应用编号是否属于该渠道
    if I_APPID != 0 then
      select count(1)
        into v_n
        from ad_channel
       where appid = I_APPID
         and ch_account_id = I_AccountID;
      if v_n <= 0 then
        O_Result  := 10;
        O_Message := '请重新选择你要查询的应用信息！';
        return;
      end if;
    
      v_SqlWhere := ' and appid=' || I_APPID;
    else
      v_SqlWhere := ' and appid in ( select appid from ad_channel where ch_account_id =' ||
                    I_AccountID || ' ) ';
    end if;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
  
    V_SQL := ' select  dtime,sum(expend_c) expend_c from fin_expend_day where dtime>=to_date(''' ||
             I_SDate || ''',''yyyy-mm-dd'') and   dtime<=to_date(''' ||
             I_EDate || ''',''yyyy-mm-dd'')  ' || v_SqlWhere ||
             'group by dtime';
  
    ----执行分页查询
    V_HeiRowNUM := v_PageNO * v_PageSize;
    V_LowROWNUM := V_HeiRowNUM - v_PageSize + 1;
  
    execute immediate 'select count(1) from (' || V_SQL || ')'
      into O_Outrecordcount;
  
    V_SQL := 'select   dtime,expend_c  from (' || V_SQL ||
             ') order by dtime asc ';
  
    V_SQL := ' select    to_char(dtime,''yyyy-mm-dd'') dtime,round(expend_c,2) as Revenue  from (
     select      dtime,expend_c ,rownum rn from (  ' || V_SQL ||
             ') a where rownum <=' || to_char(V_HeiRowNUM) ||
             ') b where  rn >= ' || to_char(V_LowROWNUM) || ' ';
    --注意对rownum别名的使用,第一次直接用rownum,第二次一定要用别名rn
    --- order by 放里面会影响速度
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    OPEN O_OUTCURSOR FOR V_SQL;
    commit;
    return;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '查询失败';
      return;
  end PQ_Revenue_Trend;

  procedure PQ_Revenue_Days
  /*****************************************************************
        Procedure Name :PQ_Revenue_Days
        Purpose:  渠道收入日表
        Edit: 2018-05-19 add by 小沈
    ****************************************************************/
  (I_AccountID      In Number, --管理员帐号ID
   I_APPID          In Number, --渠道应用编号
   I_SDate          In Varchar2, --开始日期
   I_EDate          In Varchar2, --截止日期
   I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始
   O_Outrecordcount Out Number, --返回总记录数
   O_Outcursor      Out t_cursor, --返回游标
   O_Result         Out Number, --判断 0：查询成功，其他：出错
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n         number;
    v_SqlWhere  varchar(1000); --条件语句 
    V_SQL       varchar2(4500);
    V_HeiRowNUM number; --小于第几行 分页用
    V_LowRowNUM number; --大于第几行 分页用
  
    v_PageSize number;
    v_PageNO   number;
  
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
  
    if I_SDate is null then
      O_Result  := 10;
      O_Message := '开始日期不能为空';
      return;
    end if;
  
    if I_EDate is null then
      O_Result  := 11;
      O_Message := '截止日期不能为空';
      return;
    end if;
  
    if I_PageSize is null then
      O_Result  := 12;
      O_Message := '记录数不能为空';
      return;
    end if;
  
    if I_PageNO is null then
      O_Result  := 13;
      O_Message := '页数不能为空';
      return;
    end if;
  
    select count(1) into v_n from ch_admin where account_id = I_AccountID;
  
    if v_n = 0 then
      O_Result  := 1;
      O_Message := '您的帐号有误，请重新登录';
      return;
    end if;
  
    v_PageSize := I_PageSize;
    v_PageNO   := I_PageNO;
  
    --如果不是0 则需要判断应用编号是否属于该渠道
    if I_APPID != 0 then
      select count(1)
        into v_n
        from ad_channel
       where appid = I_APPID
         and ch_account_id = I_AccountID;
      if v_n <= 0 then
        O_Result  := 10;
        O_Message := '请重新选择你要查询的应用信息！';
        return;
      end if;
    
      v_SqlWhere := ' and appid=' || I_APPID;
    else
      v_SqlWhere := ' and appid in ( select appid from ad_channel where ch_account_id =' ||
                    I_AccountID || ' ) ';
    end if;
  
    if I_SDate is not null then
      v_SqlWhere := v_SqlWhere || ' and dtime>=to_date(''' || I_SDate ||
                    ''',''yyyy-mm-dd'') ';
    end if;
  
    if I_EDate is not null then
      v_SqlWhere := v_SqlWhere || '  and   dtime<=to_date(''' || I_EDate ||
                    ''',''yyyy-mm-dd'')';
    end if;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
  
    V_SQL := 'select to_char(dtime,''yyyy-mm-dd'') dtime , nvl(sum(l_req_uv),0) l_req_uv ,nvl(sum(l_req_pv),0) l_req_pv,nvl(sum(d_show_uv),0) d_show_uv ,nvl(sum(down),0) down ,nvl(sum(reg),0) reg, nvl(sum(expend_c ),0) expend_c ,nvl(sum(amoney_c),0) amoney_c,nvl(sum(money),0) money from 
         (
            select  dtime ,0 l_req_uv ,0 l_req_pv,0 d_show_uv,case when dtime>=to_date(''2019-01-24'',''yyyy-mm-dd'') then sum(down_newer ) else sum(down) end as  down ,case when dtime>=to_date(''2019-01-24'',''yyyy-mm-dd'') then sum(reg_newer  ) else sum(reg) end as reg,
             0 expend_c , 0 amoney_c,0 money  from rep_ad_dayreg where  1=1  ' ||
             v_SqlWhere ||
             '   group by dtime 
            union 
            select dtime,0 l_req_uv ,0 l_req_pv,0 d_show_uv, 0 down,  0 reg , sum(expend_c ) expend_c ,sum(amoney_c) amoney_c,0 money from fin_channel_expend  where 1=1 and status=0 ' ||
             v_SqlWhere ||
             '   group by dtime 
             union
             select dtime, l_req_uv , l_req_pv, d_show_uv, 0 down, 0 reg , 0 expend_c ,0 amoney_c,0 money from AD_STATS_DAY where 1=1  ' ||
             v_SqlWhere || '
              union
            select dtime,0 l_req_uv ,0  l_req_pv,0 d_show_uv, 0 down,0 reg ,0 expend_c ,0 amoney_c,sum(award_money) money from (select trunc(award_asktime ) dtime,award_money,appid,award_status from ad_award_ranklist ) where award_status = 2  ' ||  
             v_SqlWhere ||
             '    group by dtime  
             
         )  group by dtime  ';
  
    V_SQL := '   select 1 sort, dtime ,l_req_uv , l_req_pv, d_show_uv, down,reg,expend_c,amoney_c,money from (  ' ||
             V_SQL ||
             '  ) 
     union  select 99 srot, ''合计''  dtime,nvl(sum(l_req_uv),0) l_req_uv ,nvl(sum(l_req_pv),0) l_req_pv,nvl(sum(d_show_uv),0) d_show_uv ,nvl(sum(down),0) down ,nvl(sum(reg),0) reg, nvl(sum(expend_c),0) expend_c ,nvl(sum(amoney_c),0) amoney_c,nvl(sum(money),0) money from (' ||
             V_SQL || '  ) ';
  
    ----执行分页查询
    V_HeiRowNUM := v_PageNO * v_PageSize;
    V_LowROWNUM := V_HeiRowNUM - v_PageSize + 1;
  
    execute immediate 'select count(1) from (' || V_SQL || ')'
      into O_Outrecordcount;
  
    V_SQL := 'select  dtime ,l_req_uv , l_req_pv, d_show_uv, down,reg,expend_c as Revenue,amoney_c as  amoney,money as money  from (' ||
             V_SQL || ') order by sort desc, dtime desc ';
  
    V_SQL := ' select  dtime,l_req_uv , l_req_pv, d_show_uv , down,reg ,revenue ,amoney,money,revenue-amoney profit,case when down =0 then 0 else  round(reg/down,2)*100 end || ''%'' regrate from (
     select   dtime , down,l_req_uv , l_req_pv, d_show_uv ,reg ,revenue ,amoney,money ,rownum rn from (  ' ||
             V_SQL || ') a where rownum <=' || to_char(V_HeiRowNUM) ||
             ') b where  rn >= ' || to_char(V_LowROWNUM) || ' ';
    --注意对rownum别名的使用,第一次直接用rownum,第二次一定要用别名rn
    --- order by 放里面会影响速度
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
  
    dbms_output.put_line(V_SQL);
    OPEN O_OUTCURSOR FOR V_SQL;
    commit;
    return;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '查询失败';
      return;
  end PQ_Revenue_Days;

  procedure PQ_Revenue_ThatDay
  /*****************************************************************
        Procedure Name :PQ_Revenue_ThatDay
        Purpose:  渠道当天收入情况 
        Edit: 2018-05-19 add by 小沈
    ****************************************************************/
  (I_AccountID In Number, --管理员帐号ID
   I_APPID     In Number, --渠道应用编号
   I_Date      In Varchar2, --日期  
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number, --判断 0：查询成功，其他：出错
   O_Message   Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n         number;
    v_SqlWhere  varchar(1000); --条件语句 
    v_SqlWhere2 varchar(500) := ''; --条件语句 
    V_SQL       varchar2(4000);
  
    v_PageSize number;
    v_PageNO   number;
  
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
  
    if I_Date is null then
      O_Result  := 10;
      O_Message := '日期不能为空';
      return;
    end if;
  
    select count(1) into v_n from ch_admin where account_id = I_AccountID;
  
    if v_n = 0 then
      O_Result  := 1;
      O_Message := '您的帐号有误，请重新登录';
      return;
    end if;
  
    --如果不是0 则需要判断应用编号是否属于该渠道
    if I_APPID != 0 then
      select count(1)
        into v_n
        from ad_channel
       where appid = I_APPID
         and ch_account_id = I_AccountID;
      if v_n <= 0 then
        O_Result  := 10;
        O_Message := '请重新选择你要查询的应用信息！';
        return;
      end if;
    
      v_SqlWhere := ' and appid=' || I_APPID;
    else
      v_SqlWhere := ' and appid in ( select appid from ad_channel where ch_account_id =' ||
                    I_AccountID || ' ) ';
    end if;
  
    if I_Date is not null then
      v_SqlWhere := v_SqlWhere || ' and itime>=to_date(''' || I_Date ||
                    ''',''yyyy-mm-dd'')  and   itime<to_date(''' || I_Date ||
                    ''',''yyyy-mm-dd'')+1 ';
    end if;
  
    if I_Date = to_char(sysdate, 'yyyy-mm-dd') then
      v_SqlWhere2 := ' and h_time <= to_number(to_char(sysdate,''hh24'')) ';
    
    end if;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
  
    V_SQL := '  select htime ,sum (down) down ,sum (reg) reg ,sum (expend) expend ,sum(money ) money  from (
select to_char(itime,''hh24'') htime ,0 down ,0 reg，sum(price) expend ,sum(money ) money from ad_app_flux where 1=1  ' ||
             v_SqlWhere ||
             '  group by to_char(itime,''hh24'') 
union
select to_char(itime,''hh24'') htime ,sum(case when itime>to_date(''2019-01-24'',''yyyy-mm-dd'') then decode(isold,0,1,0) else 0 end ) down ,0 reg，0 expend ，0 money from ad_app_bind where 1=1    ' ||
             v_SqlWhere ||
             '   group by to_char(itime,''hh24'') 
union
select to_char(itime,''hh24'') htime ,0 down , sum(case when itime>to_date(''2019-01-24'',''yyyy-mm-dd'') then decode(isold,0,1,0) else 0 end ) reg ，0 expend  ，0 money  from ad_app_bind where 1=1   ' ||
             v_SqlWhere ||
             '   and ustatus in(2,3) group by to_char(itime,''hh24'') 
             union 
select h_time as htime ,0 down ,0 reg，0 expend ，0 money from t_Hours where 1=1 ' ||
             v_SqlWhere2 || '
) group by htime   ';
  
    V_SQL := '   select 1 sort, htime , down,reg,expend,money from (  ' ||
             V_SQL ||
             '  ) 
     union  select 99 srot, ''99''  htime ,sum(down) down ,sum(reg) reg, sum(expend ) expend ,sum(money) money from (' ||
             V_SQL || '  ) ';
  
    V_SQL := ' select case when  htime = 99 then ''合计'' else to_char(htime)  end as htime, down,reg,revenue,money ,revenue-money profit  from ( 
     select htime , down,reg,expend as revenue,money ,expend-money profit  from (' ||
             V_SQL || ') order by sort desc, to_number(htime) desc )';
  
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    dbms_output.put_line(V_SQL);
    OPEN O_OUTCURSOR FOR V_SQL;
    commit;
    return;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '查询失败';
      return;
  end PQ_Revenue_ThatDay;

  procedure PQ_Revenue_AD
  /*****************************************************************
        Procedure Name :PQ_Revenue_AD
        Purpose: 广告支出明细
        Edit: 2018-06-19 add by 小沈
    ****************************************************************/
  (I_AccountID      In Number, --管理员帐号ID
   I_APPID          In Number, --渠道应用编号
   I_SDate          In Varchar2, --开始日期
   I_EDate          In Varchar2, --截止日期
   I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始
   O_Outrecordcount Out Number, --返回总记录数
   O_Outcursor      Out t_cursor, --返回游标
   O_Result         Out Number, --判断 0：查询成功，其他：出错
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n         number;
    v_SqlWhere  varchar(1000); --条件语句 
    V_SQL       varchar2(4000);
    V_HeiRowNUM number; --小于第几行 分页用
    V_LowRowNUM number; --大于第几行 分页用
  
    v_PageSize number;
    v_PageNO   number;
  
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
  
    if I_SDate is null then
      O_Result  := 10;
      O_Message := '开始日期不能为空';
      return;
    end if;
  
    if I_EDate is null then
      O_Result  := 11;
      O_Message := '截止日期不能为空';
      return;
    end if;
  
    if I_PageSize is null then
      O_Result  := 12;
      O_Message := '记录数不能为空';
      return;
    end if;
  
    if I_PageNO is null then
      O_Result  := 13;
      O_Message := '页数不能为空';
      return;
    end if;
  
    select count(1) into v_n from ch_admin where account_id = I_AccountID;
  
    if v_n = 0 then
      O_Result  := 1;
      O_Message := '您的帐号有误，请重新登录';
      return;
    end if;
  
    v_PageSize := I_PageSize;
    v_PageNO   := I_PageNO;
  
    --如果不是0 则需要判断应用编号是否属于该渠道
    if I_APPID != 0 then
      select count(1)
        into v_n
        from ad_channel
       where appid = I_APPID
         and ch_account_id = I_AccountID;
      if v_n <= 0 then
        O_Result  := 10;
        O_Message := '请重新选择你要查询的应用信息！';
        return;
      end if;
    
      v_SqlWhere := ' and appid=' || I_APPID;
    else
      v_SqlWhere := ' and appid in ( select appid from ad_channel where ch_account_id =' ||
                    I_AccountID || ' ) ';
    end if;
  
    if to_date(I_SDate, 'yyyy-mm-dd') <= trunc(sysdate) - 90 then
      O_Result  := 11;
      O_Message := '仅限查询最近3个月记录！';
      return;
    end if;
  
    if I_SDate is not null then
      v_SqlWhere := v_SqlWhere || ' and itime>=to_date(''' || I_SDate ||
                    ''',''yyyy-mm-dd'') ';
    end if;
  
    if I_EDate is not null then
      v_SqlWhere := v_SqlWhere || '  and   itime<to_date(''' || I_EDate ||
                    ''',''yyyy-mm-dd'')+1';
    end if;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
  
    V_SQL := 'select a.adid ,a.adname,b.price,b.money   from ad_adinfo a ,(
select adid, sum(price) price, sum(money) money from ad_app_flux  where  1=1  ' ||
             v_SqlWhere || ' group by adid 
) b where a.adid=b.adid
 ';
  
    ----执行分页查询
    V_HeiRowNUM := v_PageNO * v_PageSize;
    V_LowROWNUM := V_HeiRowNUM - v_PageSize + 1;
  
    execute immediate 'select count(1) from (' || V_SQL || ')'
      into O_Outrecordcount;
  
    V_SQL := 'select   adid , adname, price, money from (' || V_SQL ||
             ') order by adname desc  ';
  
    V_SQL := ' select   adid , adname, price, money as amoney from (
     select  adid , adname, price, money ,rownum rn from (  ' ||
             V_SQL || ') a where rownum <=' || to_char(V_HeiRowNUM) ||
             ') b where  rn >= ' || to_char(V_LowROWNUM) || ' ';
    --注意对rownum别名的使用,第一次直接用rownum,第二次一定要用别名rn
    --- order by 放里面会影响速度
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    OPEN O_OUTCURSOR FOR V_SQL;
    commit;
    return;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '查询失败';
      return;
  end PQ_Revenue_AD;

 procedure PQ_Revenue_Order
  /*****************************************************************
        Procedure Name :PQ_Revenue_order
        Purpose: 渠道订单
        Edit: 2019-07-23 add by 小刘
    ****************************************************************/
  (I_AccountID      In Number, --管理员帐号ID
   I_APPID          In Number, --渠道应用编号
   I_SDate          In Varchar2, --开始日期
   I_EDate          In Varchar2, --截止日期
   I_OrderNum       In varchar2, --订单编号
   I_AppSign        In varchar2, --渠道账号
   I_Deviceid       In varchar2, --设备号
   I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始
   O_Outrecordcount Out Number, --返回总记录数
   O_Outcursor      Out t_cursor, --返回游标
   O_Result         Out Number, --判断 0：查询成功，其他：出错
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n         number;
    v_SqlWhere  varchar(1000); --条件语句 
    V_SQL       varchar2(4000);
    V_HeiRowNUM number; --小于第几行 分页用
    V_LowRowNUM number; --大于第几行 分页用
  
    v_PageSize number;
    v_PageNO   number;
  
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
    if I_PageSize is null then
      O_Result  := 12;
      O_Message := '记录数不能为空';
      return;
    end if;
  
    if I_PageNO is null then
      O_Result  := 13;
      O_Message := '页数不能为空';
      return;
    end if;
  
    select count(1) into v_n from ch_admin where account_id = I_AccountID;
  
    if v_n = 0 then
      O_Result  := 1;
      O_Message := '您的帐号有误，请重新登录';
      return;
    end if;
  
    v_PageSize := I_PageSize;
    v_PageNO   := I_PageNO;
  
    --如果不是0 则需要判断应用编号是否属于该渠道
    if I_APPID != 0 then
      select count(1)
        into v_n
        from ad_channel
       where appid = I_APPID
         and ch_account_id = I_AccountID;
      if v_n <= 0 then
        O_Result  := 10;
        O_Message := '请重新选择你要查询的应用信息！';
        return;
      end if;
    
      v_SqlWhere := ' and appid=' || I_APPID;
    else
      v_SqlWhere := ' and appid in ( select appid from ad_channel where ch_account_id =' ||
                    I_AccountID || ' ) ';
    end if;
  
    if I_SDate is not null then
      v_SqlWhere := v_SqlWhere || ' and itime>=to_date(''' || I_SDate ||
                    ''',''yyyy-mm-dd'') ';
    end if;
  
    if I_EDate is not null then
      v_SqlWhere := v_SqlWhere || '  and   itime<=to_date(''' || I_EDate ||
                    ''',''yyyy-mm-dd'')';
    end if;
  
    if I_OrderNum is not null then
      v_SqlWhere := v_SqlWhere || 'and  ordernum = ''' || I_OrderNum ||'''' ;
    end if;
    if I_AppSign is not null then
      v_SqlWhere := v_SqlWhere || 'and appsign =''' || I_AppSign||'''';
    end if;
    if I_Deviceid is not null then
      v_Sqlwhere := v_Sqlwhere || 'and deviceid =''' || I_Deviceid||'''';
    end if;
  
    V_SQL := 'select to_char(itime,''yyyy-mm-dd hh24:mi:ss'') itime,ordernum,appsign,deviceid,event,price,money,p_status,p_backmsg from AD_CHANNEL_ORDER where p_status in (1,2)' ||  
             v_SqlWhere || ' order by itime';
  
    ----执行分页查询
    V_HeiRowNUM := v_PageNO * v_PageSize;
    V_LowROWNUM := V_HeiRowNUM - v_PageSize + 1;
  
    execute immediate 'select count(1) from (' || V_SQL || ')'
      into O_Outrecordcount;
  
    V_SQL := 'select   itime,ordernum,appsign,deviceid,event,price,money,p_status,p_backmsg from (' || V_SQL ||
             ') order by itime desc,ordernum  ';
  
    V_SQL := ' select   itime,ordernum,appsign,deviceid,event,price,money,p_status,p_backmsg from (
     select  itime,ordernum,appsign,deviceid,event,price,money,p_status,p_backmsg ,rownum rn from (  ' ||
             V_SQL || ') a where rownum <=' || to_char(V_HeiRowNUM) ||
             ') b where  rn >= ' || to_char(V_LowROWNUM) || ' ';
    --注意对rownum别名的使用,第一次直接用rownum,第二次一定要用别名rn
    --- order by 放里面会影响速度
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    OPEN O_OUTCURSOR FOR V_SQL;
    commit;
    return;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '查询失败';
      return;
    
  end PQ_Revenue_Order;

end P_Channel_Backstage;
/


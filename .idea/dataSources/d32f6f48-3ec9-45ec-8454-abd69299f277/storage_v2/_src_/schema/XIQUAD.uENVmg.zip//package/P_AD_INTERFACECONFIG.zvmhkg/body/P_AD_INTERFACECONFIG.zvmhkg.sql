create package body P_AD_InterfaceConfig is

  procedure PQ_QueryInterface
  /*****************************************************************
        Procedure Name :P_QueryInterface
        Purpose: 查询数据接口
        Edit: 2018-5-29 add by 小胡
    ****************************************************************/
  (I_AdminId    in varchar2, --管理员id
   I_ADID       in number, --广告ID
   I_INTERFTYPE in number, --接口类型（1、老用户激活 2、IOS通知 3、注册查询 4、等级查询 5、组别接口）
   O_OutCursor  Out t_cursor, --返回游标
   O_Result     out number, --返回（0正确，其他为提示或错误）
   O_Message    out varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n      number;
    V_QX     number;
    v_SQLStr varchar2(1000);
  begin
  
    O_RESULT  := 0;
    O_MESSAGE := '查询成功';
  
    V_QX := 104; --编辑权限
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    select count(1) into v_n from ad_adinfo where adid = I_ADID;
    --检查广告是否存在
    if v_n <= 0 then
      O_RESULT  := 101;
      O_MESSAGE := '广告不存在！';
      return;
    end if;
  
    if I_INTERFTYPE is null then
      O_RESULT  := 2;
      O_MESSAGE := '接口类型不能为空，请检查！';
      RETURN;
    end if;
  
    OPEN O_OUTCURSOR FOR 'select 0 as hasInterf from dual'; --游标初始化
  
    ---老用户激活接口
    IF I_INTERFTYPE = 1 then
      select count(1) into v_n from ad_interf_olduser where adid = I_ADID;
      --检查接口是否存在
      if v_n <= 0 THEN
        v_SQLStr := 'select 0 as hasInterf from dual';
      else
        v_SQLStr := 'select 1 as hasInterf,adid,adid_list,fid,isauto,url,params,keycode,isupper,jsont,jsons,jsonv,method,code,htype,islog,status,type,ismer,note from ad_interf_olduser where adid=' ||
                    I_ADID;
      end if;
    end if;
  
    --IOS通知接口
    if I_INTERFTYPE = 2 then
      select count(1) into v_n from ad_interf_inform where adid = I_ADID;
      IF v_n <= 0 then
        v_SQLStr := 'select 0 as hasInterf from dual';
      else
        v_SQLStr := 'select 1 as hasInterf,adid,url,params,keycode,isupper,jsont,jsons,jsonv,method,code,htype,islog,status from ad_interf_inform where adid=' ||
                    I_ADID;
      end if;
    end if;
  
    --注册查询接口
    if I_INTERFTYPE = 3 then
      select count(1) into v_n from ad_interf_reg where adid = I_ADID;
      if v_n <= 0 then
        v_SQLStr := 'select 0 as hasInterf from dual';
      else
        v_SQLStr := 'select 1 as hasInterf,adid,url,params,keycode,isupper,jsont,jsons,jsonv,jsonitem,fid,merid,mername,method,code,htype,islog,status  from ad_interf_reg where adid=' ||
                    I_ADID;
      end if;
    end if;
  
    --等级查询接口
    if I_INTERFTYPE = 4 then
      select count(1) into v_n from ad_interf_levle where adid = I_ADID;
      if v_n <= 0 then
        v_SQLStr := 'select 0 as hasInterf from dual';
      else
        v_SQLStr := 'select 1 as hasInterf,adid,url,params,keycode,isupper,jsont,jsons,jsonv,jsonitem,method,code,otime ,htype,islog,status from ad_interf_levle where adid=' ||
                    I_ADID;
      end if;
    end if;
  
    --广告组别接口
    if I_INTERFTYPE = 5 then
      select count(1) into v_n from ad_interf_group where adid = I_ADID;
      if v_n <= 0 then
        v_SQLStr := 'select 0 as hasInterf from dual';
      else
        v_SQLStr := 'select 1 as hasInterf,adid,event,atype,awardgroup,param,preparam,prevaule,pretype from ad_interf_group where adid=' ||
                    I_ADID || ' order by awardgroup asc';
      end if;
    end if;
  
    open O_OUTCURSOR for v_SQLStr;
  
  exception
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '查询异常！';
      return;
  end PQ_QueryInterface;

  procedure PW_InterfConfig_AwardGroupSet
  /*****************************************************************
    Procedure Name: PW_InterfConfig_AwardGroupSet
    Purpose: 广告奖励组别设置录入
    Edit: 2018-06-6 add by 小胡
    ****************************************************************/
  (I_AdmInId     In Varchar2, --管理员ID
   I_ADID        In Number, --广告ID
   I_Events      In Varchar2, --组别名称
   I_ATypes      In Varchar2, --奖励组别类型 （0：显示用的组别，1 普通奖励）
   I_AwardGroups In Varchar2, --奖励组别（0为显示用的组别，从1开始）
   I_Params      In Varchar2, --组别奖励对应的接口参数名称
   I_PreParams   In Varchar2, --前提参数，获得该奖励的前提参数名，一般用于判断新用户
   I_PreValues   In Varchar2, --前提参数值
   I_PreTypes    In Varchar2, --前提参数判断类型 （0：不判断，1：与前提参数值相同，2：大于或等于，3：小于或等于）
   O_Result      Out Number,
   O_Message     Out Varchar2) is
  
    v_n  number;
    V_QX number;
  
    V_Event_List      Varchar2(4000); --组别名称
    V_AType_List      Varchar2(4000); --奖励组别类型 （0：显示用的组别，1 普通奖励）
    V_AwardGroup_List Varchar2(4000); --奖励组别（0为显示用的组别，从1开始）
    V_Param_List      Varchar2(4000); --组别奖励对应的接口参数名称
    V_PreParam_List   Varchar2(4000); --前提参数，获得该奖励的前提参数名，一般用于判断新用户
    V_PreValue_List   Varchar2(4000); --前提参数值
    V_PreType_List    Varchar2(4000); --前提参数判断类型 （0：不判断，1：与前提参数值相同，2：大于或等于，3：小于或等于）
  
    V_Event      Varchar2(500); --组别名称
    V_AType      Number(2); --奖励组别类型 （0：显示用的组别，1 普通奖励）
    V_AwardGroup Number(2); --奖励组别（0为显示用的组别，从1开始）
    V_Param      Varchar2(100); --组别奖励对应的接口参数名称
    V_PreParam   Varchar2(50); --前提参数，获得该奖励的前提参数名，一般用于判断新用户
    V_PreValue   Varchar2(50); --前提参数值
    V_PreType    Number(2); --前提参数判断类型 （0：不判断，1：与前提参数值相同，2：大于或等于，3：小于或等于）
  
  BEGIN
    -------------------------------------------------------------------
    --步骤一：变量初始化
    -------------------------------------------------------------------
    O_RESULT  := 0;
    O_MESSAGE := '设置成功';
  
    V_Event_List      := I_Events; --组别名称
    V_AType_List      := I_ATypes; --奖励组别类型 （0：显示用的组别，1 普通奖励）
    V_AwardGroup_List := I_AwardGroups; --奖励组别（0为显示用的组别，从1开始）
    V_Param_List      := I_Params; --组别奖励对应的接口参数名称
    V_PreParam_List   := I_PreParams; --前提参数，获得该奖励的前提参数名，一般用于判断新用户
    V_PreValue_List   := I_PreValues; --前提参数值
    V_PreType_List    := I_PreTypes; --前提参数判断类型 （0：不判断，1：与前提参数值相同，2：大于或等于，3：小于或等于）
  
    --管理员输入是否正确
    if I_AdminID is null then
      O_RESULT  := 101;
      O_MESSAGE := '请重新登录后在操作！';
      RETURN;
    end if;
  
    --有下列权限的管理员有本模块的设置权限
    V_QX := 371; --配置组别接口权限
  
    --管理员是否有操作此模块的权限
    if p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    select count(1) into v_n from ad_adinfo where adid = I_ADID;
    if v_n <= 0 then
      O_RESULT  := 1;
      O_MESSAGE := '广告不存在';
      return;
    end if;
  
    -------------------------------------------------------------------
    --步骤二：删除原有组别
    -------------------------------------------------------------------
  
    select count(1) into v_n from ad_interf_group where adid = I_ADID;
  
    if v_n > 0 then
      delete ad_interf_group where adid = I_ADID;
      commit;
    end if;
  
    -------------------------------------------------------------------
    --循环添加奖励组别
    -------------------------------------------------------------------
  
    LOOP
      --拆分组别名称
      if INSTR(V_Event_List, '$#@') <= 0 then
        --如果没有“$#@”符号，则直接取值，不拆分
        V_Event      := V_Event_List;
        V_Event_List := '';
      else
        V_Event      := substr(V_Event_List,
                               0,
                               instr(V_Event_List, '$#@') - 1); --从字符串0开始复制，到第一个"$#@"退一位结束
        V_Event_List := substr(V_Event_List, instr(V_Event_List, '$#@') + 3); --从第一组分隔符开始取 到结束
      end if;
    
      --拆分奖励组别类型
      if INSTR(V_AType_List, '$#@') <= 0 then
        --如果没有“$#@”符号，则直接取值，不拆分
        V_AType      := V_AType_List;
        V_AType_List := '';
      else
        V_AType      := substr(V_AType_List,
                               0,
                               instr(V_AType_List, '$#@') - 1);
        V_AType_List := substr(V_AType_List, instr(V_AType_List, '$#@') + 3);
      end if;
    
      --拆分奖励组别
      if INSTR(V_AwardGroup_List, '$#@') <= 0 then
        --如果没有“$#@”符号，则直接取值，不拆分
        V_AwardGroup      := V_AwardGroup_List;
        V_AwardGroup_List := '';
      else
        V_AwardGroup      := substr(V_AwardGroup_List,
                                    0,
                                    instr(V_AwardGroup_List, '$#@') - 1);
        V_AwardGroup_List := substr(V_AwardGroup_List,
                                    instr(V_AwardGroup_List, '$#@') + 3);
      end if;
    
      --拆分组别奖励对应的接口参数名称
      if INSTR(V_Param_List, '$#@') <= 0 then
        --如果没有“$#@”符号，则直接取值，不拆分
        V_Param      := V_Param_List;
        V_Param_List := '';
      else
        V_Param      := substr(V_Param_List,
                               0,
                               instr(V_Param_List, '$#@') - 1);
        V_Param_List := substr(V_Param_List, instr(V_Param_List, '$#@') + 3);
      end if;
    
      --拆分前提参数
      if INSTR(V_PreParam_List, '$#@') <= 0 then
        --如果没有“$#@”符号，则直接取值，不拆分
        V_PreParam      := V_PreParam_List;
        V_PreParam_List := '';
      else
        V_PreParam      := substr(V_PreParam_List,
                                  0,
                                  instr(V_PreParam_List, '$#@') - 1);
        V_PreParam_List := substr(V_PreParam_List,
                                  instr(V_PreParam_List, '$#@') + 3);
      end if;
    
      --拆分前提参数值
      if INSTR(V_PreValue_List, '$#@') <= 0 then
        --如果没有“$#@”符号，则直接取值，不拆分
        V_PreValue      := V_PreValue_List;
        V_PreValue_List := '';
      else
        V_PreValue      := substr(V_PreValue_List,
                                  0,
                                  instr(V_PreValue_List, '$#@') - 1);
        V_PreValue_List := substr(V_PreValue_List,
                                  instr(V_PreValue_List, '$#@') + 3);
      end if;
    
      --拆分前提参数判断类型
      if INSTR(V_PreType_List, '$#@') <= 0 then
        --如果没有“$#@”符号，则直接取值，不拆分
        V_PreType      := V_PreType_List;
        V_PreType_List := '';
      else
        V_PreType      := substr(V_PreType_List,
                                 0,
                                 instr(V_PreType_List, '$#@') - 1);
        V_PreType_List := substr(V_PreType_List,
                                 instr(V_PreType_List, '$#@') + 3);
      end if;
    
      if V_Event IS NULL then
        O_RESULT  := -5;
        O_MESSAGE := '组别名称不能为空，请检查';
        ROLLBACK;
        RETURN;
      end if;
    
      if V_AType IS NULL then
        O_RESULT  := -5;
        O_MESSAGE := '组别类型不能为空，请检查';
        ROLLBACK;
        RETURN;
      end if;
    
      if V_AwardGroup IS NULL then
        O_RESULT  := -5;
        O_MESSAGE := '奖励组别不能为空，请检查';
        ROLLBACK;
        RETURN;
      end if;
    
      if V_Param IS NULL then
        O_RESULT  := -5;
        O_MESSAGE := '组别参数名不能为空，请检查';
        ROLLBACK;
        RETURN;
      end if;
    
      if V_PreType IS NULL then
        O_RESULT  := -5;
        O_MESSAGE := '前提参数判断类型不能为空，请检查';
        ROLLBACK;
        RETURN;
      end if;
    
      --------添加接口奖励组别
      insert into ad_interf_group
        (adid,
         event,
         atype,
         awardgroup,
         param,
         itime,
         preparam,
         prevaule,
         pretype)
      values
        (I_ADID,
         V_Event,
         V_AType,
         V_AwardGroup,
         V_Param,
         sysdate,
         V_PreParam,
         V_PreValue,
         V_PreType);
    
      EXIT WHEN V_AType_List IS NULL;
    END LOOP;
  
    commit;
  
    -------------------------------------------------------------------
    --报错误处理，回滚
    -------------------------------------------------------------------
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '修改组别失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
    
  end PW_InterfConfig_AwardGroupSet;

  procedure PW_InterfConfig_OldUser
  /*****************************************************************
    Procedure Name: PW_InterfConfig_OldUser
    Purpose: 广告老用户激活接口配置
    Edit: 2018-06-7 add by 小胡
    Comment:
    ****************************************************************/
  (I_AdmInId  In Varchar2, ---管理员ID
   I_ADID     In Number, --广告ID
   I_Adidlist In Varchar2, --老用户广告id列表
   I_Fid      In Varchar2, --渠道编号
   I_IsAuto   In Varchar2, --自动同步上期账号
   I_Url      In Varchar2, --接口地址
   I_Params   In Varchar2, --接口参数
   I_Keycode  In Varchar2, --加密字符串
   I_Isupper  In Number, --加密后字符串是否大写
   I_Jsont    In Number, -- 返回参数格式
   I_Jsons    In Varchar2, --状态判断参数名
   I_Jsonv    In Varchar2, --状态判断参数值
   I_Method   In Varchar2, -- 请求类型（GET、POST）
   I_Htype    In Number, --请求类型（1为GET，3为POST）
   I_Islog    In Number, --是否记录日志
   I_Status   In Number, --接口状态值，（0正常，1停止）
   I_Type     In Number, -- 激活类型（1激活接口激活，2数据库自动激活，3卸载重装后激活）
   I_Ismer    In Number, -- 以商家返回信息为主（1：是，0，不是）
   I_Note     In Varchar2, -- 接口备注
   O_Result   Out Number,
   O_Message  Out Varchar2) is
    v_n  number;
    V_QX number;
  
  begin
    O_RESULT  := 0;
    O_MESSAGE := '保存成功！';
  
    --管理员输入是否正确
    if I_AdminID is null then
      O_RESULT  := 101;
      O_MESSAGE := '请重新登录后在操作！';
      RETURN;
    end if;
  
    --有下列权限的管理员有本模块的设置权限
    V_QX := 371; --配置接口权限
  
    --管理员是否有操作此模块的权限
    if p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    select count(1) into v_n from ad_adinfo where adid = I_ADID;
    if v_n <= 0 then
      O_RESULT  := 1;
      O_MESSAGE := '广告不存在';
      return;
    end if;
  
    select count(1) into v_n from ad_interf_olduser where adid = I_ADID;
  
    -------------------------------------------------------------------
    --添加激活接口
    -------------------------------------------------------------------
  
    if I_Adidlist IS NULL then
      O_RESULT  := -5;
      O_MESSAGE := '老用户广告id不能为空，请检查';
      ROLLBACK;
      RETURN;
    end if;
  
    if I_Type = 1 and I_Ismer = 1 and I_IsAuto = 1 then
      O_RESULT  := -5;
      O_MESSAGE := '有激活接口时不能自动同步老账号！';
      ROLLBACK;
      RETURN;
    end if;
  
    if I_Fid IS NULL then
      O_RESULT  := -5;
      O_MESSAGE := '渠道编号不能为空，请检查';
      ROLLBACK;
      RETURN;
    end if;
  
    if I_Jsons IS NULL then
      O_RESULT  := -5;
      O_MESSAGE := '状态判断参数不能为空，请检查';
      ROLLBACK;
      RETURN;
    end if;
  
    if I_Jsonv IS NULL then
      O_RESULT  := -5;
      O_MESSAGE := '状态判断值不能为空，请检查';
      ROLLBACK;
      RETURN;
    end if;
    if v_n <= 0 then
    
      --添加激活接口
      insert into ad_interf_olduser
        (adid,
         adid_list,
         fid,
         isauto,
         url,
         params,
         keycode,
         isupper,
         jsont,
         jsons,
         jsonv,
         method,
         code,
         htype,
         islog,
         status,
         itime,
         type,
         ismer,
         note)
      values
        (I_ADID,
         I_Adidlist,
         I_Fid,
         I_IsAuto,
         I_Url,
         I_Params,
         I_Keycode,
         I_Isupper,
         I_Jsont,
         I_Jsons,
         I_Jsonv,
         I_Method,
         'UTF-8',
         I_Htype,
         I_Islog,
         I_Status,
         sysdate,
         I_Type,
         I_Ismer,
         I_Note);
    else
      update ad_interf_olduser
         set adid_list = I_Adidlist,
             fid       = I_Fid,
             isauto    = I_IsAuto,
             url       = I_Url,
             params    = I_Params,
             keycode   = I_Keycode,
             isupper   = I_Isupper,
             jsont     = I_Jsont,
             jsons     = I_Jsons,
             jsonv     = I_Jsonv,
             method    = I_Method,
             htype     = I_Htype,
             islog     = I_Islog,
             status    = I_Status,
             type      = I_Type,
             ismer     = I_Ismer,
             note      = I_Note
       where adid = I_ADID;
    end if;
  
    commit;
    -------------------------------------------------------------------
    --错误处理，回滚
    -------------------------------------------------------------------
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '保存老用户激活接口失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
    
  end PW_InterfConfig_OldUser;

  procedure PW_InterfConfig_IOSInform
  /*****************************************************************
    Procedure Name: p_iosinformInter_config
    Purpose: IOS通知接口
    Edit: 2018-06-7 add by 小胡
    ****************************************************************/
  (I_AdmInId In Varchar2, ---管理员ID
   I_ADID    In Number, --广告ID
   I_Url     In Varchar2, --接口地址
   I_Params  In Varchar2, --接口参数
   I_Keycode In Varchar2, --加密字符串
   I_Isupper In Number, --加密后字符串是否大写
   I_Jsont   In Number, -- 返回参数格式
   I_Jsons   In Varchar2, --状态判断参数名
   I_Jsonv   In Varchar2, --状态判断参数值
   I_Method  In Varchar2, -- 请求类型（GET、POST）
   I_Htype   In Number, --请求类型（1为GET，3为POST）
   I_Islog   In Number, --是否记录日志
   I_Status  In Number, --接口状态值，（0正常，1停止）
   
   O_Result  Out Number,
   O_Message Out Varchar2) is
    v_n  number;
    V_QX number;
  
  begin
    O_RESULT  := 0;
    O_MESSAGE := '保存成功！';
  
    --管理员输入是否正确
    if I_AdminID is null then
      O_RESULT  := 101;
      O_MESSAGE := '请重新登录后在操作！';
      RETURN;
    end if;
  
    --有下列权限的管理员有本模块的设置权限
    V_QX := 371; --配置接口权限
  
    --管理员是否有操作此模块的权限
    if p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    select count(1) into v_n from ad_adinfo where adid = I_ADID;
    if v_n <= 0 then
      O_RESULT  := 1;
      O_MESSAGE := '广告不存在';
      return;
    end if;
  
    select count(1) into v_n from ad_interf_inform where adid = I_ADID;
  
    -------------------------------------------------------------------
    --添加激活接口
    -------------------------------------------------------------------
    if I_Url IS NULL then
      O_RESULT  := -5;
      O_MESSAGE := '接口地址不能为空，请检查';
      ROLLBACK;
      RETURN;
    end if;
  
    if I_Params IS NULL then
      O_RESULT  := -5;
      O_MESSAGE := '接口参数不能为空，请检查';
      ROLLBACK;
      RETURN;
    end if;
  
    if I_Jsons IS NULL then
      O_RESULT  := -5;
      O_MESSAGE := '状态判断参数不能为空，请检查';
      ROLLBACK;
      RETURN;
    end if;
  
    if I_Jsonv IS NULL then
      O_RESULT  := -5;
      O_MESSAGE := '状态判断值不能为空，请检查';
      ROLLBACK;
      RETURN;
    end if;
  
    -------------------------------IOS通知接口------------------------------------
    if v_n <= 0 then
      --添加IOS通知接口（商家记录IDFA）
      insert into ad_interf_inform
        (adid,
         url,
         params,
         keycode,
         isupper,
         jsont,
         jsons,
         jsonv,
         method,
         code,
         htype,
         islog,
         status,
         itime)
      values
        (I_ADID,
         I_Url,
         I_Params,
         I_Keycode,
         I_Isupper,
         I_Jsont,
         I_Jsons,
         I_Jsonv,
         I_Method,
         'UTF-8',
         I_Htype,
         I_Islog,
         I_Status,
         sysdate);
    else
      update ad_interf_inform
         set url     = I_Url,
             params  = I_Params,
             keycode = I_Keycode,
             isupper = I_Isupper,
             jsont   = I_Jsont,
             jsons   = I_Jsons,
             jsonv   = I_Jsonv,
             method  = I_Method,
             htype   = I_Htype,
             islog   = I_Islog,
             status  = I_Status
       where adid = I_ADID;
    end if;
  
    commit;
    -------------------------------------------------------------------
    --错误处理，回滚
    -------------------------------------------------------------------
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '保存IOS通知接口失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
    
  end PW_InterfConfig_IOSInform;

  procedure PW_InterfConfig_Reg
  /*****************************************************************
    Procedure Name: PW_InterfConfig_Reg
    Purpose: 注册查询接口配置
    Edit: 2018-06-7 add by 小胡
    ****************************************************************/
  (I_AdmInId  In Varchar2, ---管理员ID
   I_ADID     In Number, --广告ID
   I_Url      In Varchar2, --接口地址
   I_Params   In Varchar2, --接口参数
   I_Keycode  In Varchar2, --加密字符串
   I_Isupper  In Number, --加密后字符串是否大写
   I_Jsont    In Number, -- 返回参数格式
   I_Jsons    In Varchar2, --状态判断参数名
   I_Jsonv    In Varchar2, --状态判断参数值
   I_Jsonitem In Varchar2, --返回参数数组参数名
   I_Fid      In Varchar2, --渠道编号
   I_Merid    In Varchar2, --用户ID参数
   I_Mername  In Varchar2, --用户账号参数
   I_Method   In Varchar2, -- 请求类型（GET、POST）
   I_Htype    In Number, --请求类型（1为GET，3为POST）
   I_Islog    In Number, --是否记录日志
   I_Status   In Number, --接口状态值，（0正常，1停止）
   O_Result   Out Number,
   O_Message  Out Varchar2) is
    v_n  number;
    V_QX number;
  
  begin
    O_RESULT  := 0;
    O_MESSAGE := '保存成功！';
  
    --管理员输入是否正确
    if I_AdminID is null then
      O_RESULT  := 101;
      O_MESSAGE := '请重新登录后在操作！';
      RETURN;
    end if;
  
    --有下列权限的管理员有本模块的设置权限
    V_QX := 371; --配置接口权限
  
    --管理员是否有操作此模块的权限
    if p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    select count(1) into v_n from ad_adinfo where adid = I_ADID;
    if v_n <= 0 then
      O_RESULT  := 1;
      O_MESSAGE := '广告不存在';
      return;
    end if;
  
    select count(1) into v_n from ad_interf_reg where adid = I_ADID;
  
    -------------------------------------------------------------------
    --添加注册查询接口
    -------------------------------------------------------------------
  
    if I_Url IS NULL then
      O_RESULT  := -5;
      O_MESSAGE := '接口地址不能为空，请检查';
      ROLLBACK;
      RETURN;
    end if;
  
    if I_Params IS NULL then
      O_RESULT  := -5;
      O_MESSAGE := '接口参数不能为空，请检查';
      ROLLBACK;
      RETURN;
    end if;
  
    if I_Jsons IS NULL then
      O_RESULT  := -5;
      O_MESSAGE := '状态判断参数不能为空，请检查';
      ROLLBACK;
      RETURN;
    end if;
  
    if I_Jsonv IS NULL then
      O_RESULT  := -5;
      O_MESSAGE := '状态判断值不能为空，请检查';
      ROLLBACK;
      RETURN;
    end if;
    ---------------------------------注册查询接口----------------------------------
    if v_n <= 0 then
      --添加注册查询接口
      insert into ad_interf_reg
        (adid,
         url,
         params,
         keycode,
         isupper,
         jsont,
         jsons,
         jsonv,
         jsonitem,
         fid,
         merid,
         mername,
         method,
         code,
         htype,
         islog,
         status,
         itime)
      values
        (I_ADID,
         I_Url,
         I_Params,
         I_Keycode,
         I_Isupper,
         I_Jsont,
         I_Jsons,
         I_Jsonv,
         I_Jsonitem,
         I_Fid,
         I_Merid,
         I_Mername,
         I_Method,
         'UTF-8',
         I_Htype,
         I_Islog,
         I_Status,
         sysdate);
    else
      update ad_interf_reg
         set url      = I_Url,
             params   = I_Params,
             keycode  = I_Keycode,
             isupper  = I_Isupper,
             jsont    = I_Jsont,
             jsons    = I_Jsons,
             jsonv    = I_Jsonv,
             jsonitem = I_Jsonitem,
             fid      = I_Fid,
             merid    = I_Merid,
             mername  = I_Mername,
             method   = I_Method,
             htype    = I_Htype,
             islog    = I_Islog,
             status   = I_Status
       where adid = I_ADID;
    end if;
  
    commit;
    -------------------------------------------------------------------
    --错误处理，回滚
    -------------------------------------------------------------------
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '保存用户注册接口失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
    
  end PW_InterfConfig_Reg;

  procedure PW_InterfConfig_Level
  /*****************************************************************
    Procedure Name: PW_InterfConfig_Level
    Purpose: 游戏信息查询接口配置
    Edit: 2018-06-7 add by 小胡
    ****************************************************************/
  (I_AdmInId  In Varchar2, ---管理员ID
   I_ADID     In Number, --广告ID
   I_Url      In Varchar2, --接口地址
   I_Params   In Varchar2, --接口参数
   I_Keycode  In Varchar2, --加密字符串
   I_Isupper  In Number, --加密后字符串是否大写
   I_Jsont    In Number, -- 返回参数格式
   I_Jsons    In Varchar2, --状态判断参数名
   I_Jsonv    In Varchar2, --状态判断参数值
   I_Jsonitem In Varchar2, --返回参数数组参数名
   I_Method   In Varchar2, -- 请求类型（GET、POST）
   I_Htype    In Number, --请求类型（1为GET，3为POST）
   I_Islog    In Number, --是否记录日志
   I_Status   In Number, --接口状态值，（0正常，1停止）
   O_Result   Out Number,
   O_Message  Out Varchar2) is
    v_n  number;
    V_QX number;
  
  begin
    O_RESULT  := 0;
    O_MESSAGE := '保存成功！';
  
    --管理员输入是否正确
    if I_AdminID is null then
      O_RESULT  := 101;
      O_MESSAGE := '请重新登录后在操作！';
      RETURN;
    end if;
  
    --有下列权限的管理员有本模块的设置权限
    V_QX := 371; --配置接口权限
  
    --管理员是否有操作此模块的权限
    if p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    select count(1) into v_n from ad_adinfo where adid = I_ADID;
    if v_n <= 0 then
      O_RESULT  := 1;
      O_MESSAGE := '广告不存在';
      return;
    end if;
  
    select count(1) into v_n from ad_interf_levle where adid = I_ADID;
  
    -------------------------------------------------------------------
    --添加等级查询接口
    -------------------------------------------------------------------
  
    if I_Url IS NULL then
      O_RESULT  := -5;
      O_MESSAGE := '接口地址不能为空，请检查';
      ROLLBACK;
      RETURN;
    end if;
  
    if I_Params IS NULL then
      O_RESULT  := -5;
      O_MESSAGE := '接口参数不能为空，请检查';
      ROLLBACK;
      RETURN;
    end if;
  
    if I_Jsons IS NULL then
      O_RESULT  := -5;
      O_MESSAGE := '状态判断参数不能为空，请检查';
      ROLLBACK;
      RETURN;
    end if;
  
    if I_Jsonv IS NULL then
      O_RESULT  := -5;
      O_MESSAGE := '状态判断值不能为空，请检查';
      ROLLBACK;
      RETURN;
    end if;
  
    ------------------------------等级查询接口-------------------------------------
    if v_n <= 0 then
      --添加等级查询接口
      insert into ad_interf_levle
        (adid,
         url,
         params,
         keycode,
         isupper,
         jsont,
         jsons,
         jsonv,
         jsonitem,
         method,
         code,
         htype,
         islog,
         status,
         itime)
      values
        (I_ADID,
         I_Url,
         I_Params,
         I_Keycode,
         I_Isupper,
         I_Jsont,
         I_Jsons,
         I_Jsonv,
         I_Jsonitem,
         I_Method,
         'UTF-8',
         I_Htype,
         I_Islog,
         I_Status,
         sysdate);
    else
      update ad_interf_levle
         set url      = I_Url,
             params   = I_Params,
             keycode  = I_Keycode,
             isupper  = I_Isupper,
             jsont    = I_Jsont,
             jsons    = I_Jsons,
             jsonv    = I_Jsonv,
             jsonitem = I_Jsonitem,
             method   = I_Method,
             htype    = I_Htype,
             islog    = I_Islog,
             status   = I_Status
       where adid = I_ADID;
    end if;
  
    commit;
    -------------------------------------------------------------------
    --错误处理，回滚
    -------------------------------------------------------------------
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '保存等级查询接口失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
    
  end PW_InterfConfig_Level;

  procedure PQ_QueryChannel_OrderInterf
  /*****************************************************************
    Procedure Name: PQ_QueryChannel_OrderInterf
    Purpose: 注册查询接口配置
    Edit: 2018-06-13 add by 小胡
    ****************************************************************/
  (I_AdmInId   In Varchar2, ---管理员ID
   I_APPID     In Number, --渠道标识编号
   O_OUTCURSOR Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    v_n      number;
    V_QX     number;
    v_SQLStr varchar2(1000);
  
  begin
    O_RESULT  := 0;
    O_MESSAGE := '查询成功！';
  
    --管理员输入是否正确
    if I_AdminID is null then
      O_RESULT  := 101;
      O_MESSAGE := '请重新登录后在操作！';
      RETURN;
    end if;
  
    --有下列权限的管理员有本模块的设置权限
    V_QX := 381; --配置接口权限
  
    --管理员是否有操作此模块的权限
    if p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    select count(1) into v_n from ad_channel where appid = I_APPID;
    if v_n <= 0 then
      O_RESULT  := 1;
      O_MESSAGE := '渠道不存在';
      return;
    end if;
    -------------------------------------------------------------------
    --查询订单推送接口
    -------------------------------------------------------------------
    v_SQLStr := 'select * from ';
    select count(1) into v_n from ad_interf_order where appid = I_APPID;
    --检查接口是否存在
    if v_n <= 0 THEN
      O_RESULT  := 2;
      O_MESSAGE := '接口未配置';
      return;
    else
      v_SQLStr := 'select appid,url,key,method,code,otime,htype,islog,status,ktype  from ad_interf_order where appid=' ||
                  I_APPID;
    end if;
    open O_OUTCURSOR for v_SQLStr;
    -------------------------------------------------------------------
    --错误处理，回滚
    -------------------------------------------------------------------
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '查询订单推送接口失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
    
  end PQ_QueryChannel_OrderInterf;

  procedure PW_Channel_OrderInterf
  /*****************************************************************
    Procedure Name: PW_Channel_OrderInterf
    Purpose: 订单接口接口配置
    Edit: 2018-06-13 add by 小胡
    ****************************************************************/
  (I_AdmInId In Varchar2, ---管理员ID
   I_APPID   In Number, --渠道ID
   I_Url     In Varchar2, --接口地址
   I_Key     In Varchar2, --签名密钥
   I_Method  In Varchar2, -- 请求类型（GET、POST）
   I_Code    In Varchar2, --请求类型（UTF-8,GB2312）
   I_OTIME   In Number, --超时时间
   I_HTYPE   In Number, --请求方式
   I_Islog   In Number, --是否记录日志
   I_Status  In Number, --接口状态值，（0正常，1停止）
   I_KTYPE   In Number,--加密类型 1：adid+appid+ordernum+deviceid+key 2：adid+appid+ordernum+dlevel+deviceid+appsign+price+money+key
   O_Result  Out Number,
   O_Message Out Varchar2) is
    v_n   number;
    V_QX  number;
    v_key varchar2(100);
  begin
    O_RESULT  := 0;
    O_MESSAGE := '保存成功！';
    v_key     := I_Key;
  
    --管理员输入是否正确
    if I_AdminID is null then
      O_RESULT  := 101;
      O_MESSAGE := '请重新登录后在操作！';
      RETURN;
    end if;
  
    --有下列权限的管理员有本模块的设置权限
    V_QX := 381; --配置接口权限
  
    --管理员是否有操作此模块的权限
    if p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    select count(1) into v_n from ad_channel where appid = I_APPID;
    if v_n <= 0 then
      O_RESULT  := 1;
      O_MESSAGE := '渠道不存在';
      return;
    end if;
  
    --------------------------保存修改------------------------
    if I_Url IS NULL then
      O_RESULT  := -5;
      O_MESSAGE := '接口地址不能为空，请检查';
      ROLLBACK;
      RETURN;
    end if;
  
    select count(1) into v_n from ad_interf_order where appid = I_APPID;
  
    if v_n <= 0 then
      --获取渠道密钥
      select APPSECRET into v_key from ad_channel where appid = I_APPID;
    
      --设置订单推送接口
      insert into ad_interf_order
        (appid, url, key, method, code, otime, htype, islog, status, itime,ktype )
      values
        (I_APPID,
         I_Url,
         v_key,
         I_Method,
         I_Code,
         I_OTIME,
         I_HTYPE,
         I_Islog,
         I_Status,
         sysdate,
         I_KTYPE);
    else
      update ad_interf_order
         set url    = I_Url,
             method = I_Method,
             code   = I_Code,
             otime  = I_OTIME,
             htype  = I_HTYPE,
             islog  = I_Islog,
             status = I_Status,
             ktype=I_KTYPE
       where appid = I_APPID;
    end if;
    commit;
    -------------------------------------------------------------------
    --错误处理，回滚
    -------------------------------------------------------------------
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '保存订单推送接口失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
    
  end PW_Channel_OrderInterf;
end P_AD_InterfaceConfig;
/


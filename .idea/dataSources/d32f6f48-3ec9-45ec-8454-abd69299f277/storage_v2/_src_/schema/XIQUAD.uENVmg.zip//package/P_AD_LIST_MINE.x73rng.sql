create PACKAGE P_AD_List_Mine AS
  TYPE T_CURSOR IS REF CURSOR;

  /*我的广告列表*/

  procedure PQ_List
  /*****************************************************************
        Procedure Name :PQ_List
        Purpose: 获取列表
        Edit: 2017-02-13 add by 小沈
    ****************************************************************/
  (I_APPId          In Number, --渠道应用ID
   I_Deviceid       In Varchar2, --设备号ID
   I_SIMID          In Varchar2, --sim卡编号
   I_PType          In Number, --1、ios  2、安卓
   I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始
   O_Outrecordcount Out Number, --返回总记录数
   O_Outcursor      Out t_cursor, --返回游标
   O_Result         Out Number, --判断 0：查询成功，其他：出错
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  procedure PQ_ListH5
  /*****************************************************************
        Procedure Name :PQ_ListH5
        Purpose: H5获取广告列表
        Edit: 2017-06-07 add by 小沈
    ****************************************************************/
  (I_APPId          In Number, --渠道应用ID
   I_Deviceid       In Varchar2, --设备号ID
   I_SIMID          In Varchar2, --sim卡编号
   I_PType          In Number, --1、ios  2、安卓
   I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始
   O_Outrecordcount Out Number, --返回总记录数
   O_Outcursor      Out t_cursor, --返回游标
   O_Result         Out Number, --判断 0：查询成功，其他：出错
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  

end P_AD_List_Mine;


/


create PACKAGE P_AD_OldUser_V2 AS

  TYPE T_CURSOR IS REF CURSOR;
  /* 老用户激活*/

  procedure PQ_OldUser
  /*****************************************************************
        Procedure Name :PQ_Interf_OldUser
        Purpose: 查询老用户信息【只处理接口激活和自动激活的广告】
                 第一优先：老用户激活根据设备号激活，当前广告当前设备号在哪个渠道优先激活新一期就归该渠道
                 第二优先：根据闲玩用户ID去查找上期帐号避免用户更换手机后无法激活
                 如果又换手机又更换帐号只能人工处理
        Edit: 2018-04-10 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   I_PType     In Number, --1、ios  2、安卓
   I_DeviceId  In Varchar2, --用户设备号
   I_Userid    In Number, --闲玩用户编号
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure PW_OldUser_Click
  /*****************************************************************
        Procedure Name :PW_OldUser_Click
        Purpose: 广告接口_用户点击下载后激活老帐号
        Edit: 2018-04-11 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_PType    In Number, --1、ios  2、安卓
   I_DeviceId In Varchar2, --用户设备号 
   I_Userid   In Number, --闲玩用户编号
   O_Result   Out Number,
   O_Message  Out Varchar2);

  procedure PW_Activate_OldUser
  /*****************************************************************
        Procedure Name :PW_Activate_OldUser
        Purpose: 激活老帐号
        Edit: 2018-04-10 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_Fid      In Varchar2, --本期广告主统计的来源id[apk渠道编号] 
   I_UrlId    In Number, --广告下载编号
   I_LastAdid In Number, --上一期广告ID
   I_LastFid  In Varchar2, --上一期广告主渠道编号 
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID[传的为老设备号，如果做老用户，传老设备可以用新设备和老设备都查]
   I_SIMID    In Varchar2, --sim卡编号
   I_Userid   In Number, --闲玩用户编号
   I_APPSign  In Varchar2, --渠道应用标识符号、渠道用户id 
   I_PType    In Number, --1、ios  2、安卓
   I_IP       In Varchar2, --
   O_Result   Out Number,
   O_Message  Out Varchar2);

end P_AD_OldUser_V2;


/


create PACKAGE P_AD_WebInfo AS
  TYPE T_CURSOR IS REF CURSOR;

  /*广告页面详情_2.0 版本 */

  procedure PQ_ADInfo
  /*****************************************************************
        Procedure Name :PQ_ADInfo
        Purpose: 获取广告详细信息
        Edit: 2018-04-09 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   I_APPId     In Number, --渠道应用ID
   I_Deviceid  In Varchar2, --设备号ID
   I_SIMID     In Varchar2, --sim卡编号
   I_Userid    In Number, --闲玩用户编号
   I_PType     In Number, --1、ios  2、安卓
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number, --判断 0：查询成功，其他：出错
   O_Message   Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  procedure PQ_UserClick
  /*****************************************************************
        Procedure Name :PQ_UserClick
        Purpose: 用户点击操作
        Edit: 2018-04-11 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   I_APPId     In Number, --渠道应用ID
   I_Deviceid  In Varchar2, --设备号ID
   I_SIMID     In Varchar2, --sim卡编号
   I_Userid    In Number, --闲玩用户编号
   I_APPSign   In Varchar2, --渠道应用标识符号、渠道用户id
   I_PType     In Number, --1、ios  2、安卓
   I_IP        In Varchar2, --
   I_CType     In Number, --用户操作类型 1：下载  2：打开
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number, --判断 0：查询成功，其他：出错
   O_Message   Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  procedure PQ_AwardList
  /*****************************************************************
        Procedure Name :PQ_AwardList
        Purpose: 获取广告奖励列表
        Edit: 2018-04-11 add by 小沈
    ****************************************************************/
  (I_ADID           In Number, --广告ID
   I_APPId          In Number, --渠道应用ID
   I_Deviceid       In Varchar2, --设备号ID
   I_SIMID          In Varchar2, --sim卡编号
   I_Userid         In Number, --闲玩用户编号
   I_PType          In Number, --1、ios  2、安卓
   I_ATYPE          In Number, -- 奖励类型 1 普通 2充值和VIP
   O_Outrecordcount out number, --返回总记录数
   O_Outcursor      out t_cursor, --返回游标
   O_Result         out number, --判断 0：查询成功，其他：出错
   O_Message        out varchar2 --返回信息（操作结果，成功或者错误信息）
   );

end P_AD_WebInfo;


/


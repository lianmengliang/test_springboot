create package body p_activity_manage is

  procedure pq_AD_ActivityList
  /*****************************************************************
        Procedure Name :pq_AD_List
        Purpose: 广告活动列表
        Edit: 2018-8-22 add by 小胡
    ****************************************************************/
  (I_AdmInId        In Varchar2, --管理员id
   I_ADID           In Number, --广告id
   I_ADName         In Varchar2, --广告名称
   I_PageSize       In Number,
   I_PageNO         In Number,
   O_OutRecordCount Out Number,
   O_OutCursor      Out t_cursor, --返回游标
   O_Result         Out Number,
   O_Message        Out Varchar2) is
    v_sql       varchar2(2000);
    v_selectsql varchar2(1000);
    V_HEIROWNUM NUMBER;
    V_LOWROWNUM NUMBER;
    V_QX        NUMBER; --本模块的权限代码
    v_n         Number;
  begin
    o_result  := 0;
    o_message := '查询成功';
    ---初始化游标
    open O_OutCursor for
      select 1 from dual where 1 = 2;
    V_QX := 104; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    select count(1) into v_n from ad_adinfo where adid = I_ADID;
    if v_n <= 0 then
      O_Result  := 2;
      O_Message := '广告ID输入错误！';
      return;
    end if;
  
    v_sql := 'select adid,actid,aname,intro,dlevel,pcount,to_char(etime ,''yyyy-mm-dd'') etime,arank,status,to_char(itime ,''yyyy-mm-dd'') itime  from ad_activity where 1=1 ';
  
    v_selectsql := '';
  
    if I_ADID is not null then
      v_selectsql := v_selectsql || ' and adid = ' || I_ADID;
    end if;
    if I_ADName is not null then
      v_selectsql := v_selectsql ||
                     ' and adid in (select adid from ad_adinfo where  title like ''%' ||
                     I_ADName || '%'' or adname like ''%' || I_ADName ||
                     '%'')';
    end if;
  
    execute immediate 'select count(1) from ad_activity where 1 = 1' ||
                      v_selectsql
      into O_OUTRECORDCOUNT;
  
    v_sql := v_sql || v_selectsql || '  order by arank';
  
    ----执行分页查询
    V_HEIROWNUM := I_PAGENO * I_PAGESIZE;
    V_LOWROWNUM := V_HEIROWNUM - I_PAGESIZE + 1;
    V_SQL       := 'select adid,actid,aname,intro,dlevel,pcount,etime,arank,status,itime,rn 
                    FROM (
                    select adid,actid,aname,intro,dlevel,pcount,etime,arank,status,itime,rownum rn  
                    FROM (' || v_sql || ') A
                    WHERE rownum <= ' ||
                   TO_CHAR(V_HEIROWNUM) || '
                    ) B
                    WHERE rn >= ' || TO_CHAR(V_LOWROWNUM);
    open O_OUTCURSOR for v_sql;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '查询失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pq_AD_ActivityList;

  procedure pq_AD_ActivityInfo
  /*****************************************************************
        Procedure Name :pq_AD_ActivityInfo
        Purpose: 广告活动信息
        Edit: 2018-8-22 add by 小胡
    ****************************************************************/
  (I_AdmInId   In Varchar2, --管理员id
   I_ACTID     In Number, --活动id
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    v_sql varchar2(2000);
  
    V_QX NUMBER; --本模块的权限代码
    v_n  Number;
  begin
    o_result  := 0;
    o_message := '显示成功';
    V_QX      := 104; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    select count(1) into v_n from ad_activity where actid = I_ACTID;
    if v_n <= 0 then
      O_Result  := 2;
      O_Message := '该活动不存在！';
      return;
    end if;
  
    v_sql := 'select adid,actid,aname,intro,dlevel,pcount,arank,status  from ad_activity  where actid= ' ||
             I_ACTID;
  
    open O_OUTCURSOR for v_sql;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '查询失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pq_AD_ActivityInfo;

  procedure pw_AD_ActivityModSave
  /*****************************************************************
        Procedure Name :pw_AD_ActivityModSave
        Purpose: 活动修改保存
        Edit: 2018-8-22 add by 小胡
    ****************************************************************/
  (I_AdmInId In Varchar2, --管理员id
   I_ACTID   In Number, --活动id
   I_INTRO   In Varchar2, --活动介绍
   I_STATUS  In Number, --活动状态
   I_ARANK   In Number, --活动排序 
   I_PCOUNT  In Number, --活动奖励人数 
   I_DLEVEL  In Number, --奖励对应等级 
   I_ANAME   In Varchar2, --活动名称
   O_Result  Out Number,
   O_Message Out Varchar2) is
    V_QX NUMBER; --本模块的权限代码
    v_n  Number;
  begin
    o_result  := 0;
    o_message := '保存成功';
    V_QX      := 104; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    select count(1) into v_n from ad_activity where actid = I_ACTID;
    if v_n <= 0 then
      O_Result  := 2;
      O_Message := '该活动不存在！';
      return;
    end if;
  
    update ad_activity
       set aname  = I_ANAME,
           intro  = I_INTRO,
           dlevel = I_DLEVEL,
           pcount = I_PCOUNT,
           arank  = I_ARANK,
           status = I_STATUS
     where actid = I_ACTID;
    commit;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '保存失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pw_AD_ActivityModSave;

  procedure pw_AD_ActivityAddSave
  /*****************************************************************
        Procedure Name :pw_AD_ActivityAddSave
        Purpose: 添加活动-保存
        Edit: 2018-8-23 add by 小胡
    ****************************************************************/
  (I_AdmInId In Varchar2, --管理员id
   I_ADID    In Number, --广告id
   I_INTRO   In Varchar2, --活动介绍
   I_STATUS  In Number, --活动状态
   I_ARANK   In Number, --活动排序 
   I_PCOUNT  In Number, --活动奖励人数 
   I_DLEVEL  In Number, --奖励对应等级 
   I_ANAME   In Varchar2, --活动名称
   O_Result  Out Number,
   O_Message Out Varchar2) is
    V_QX NUMBER; --本模块的权限代码
    v_n  Number;
  begin
    o_result  := 0;
    o_message := '保存成功';
    V_QX      := 104; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    select count(1) into v_n from ad_adinfo where adid = I_ADID;
    if v_n <= 0 then
      O_Result  := 2;
      O_Message := '该广告不存在！';
      return;
    end if;
  
    insert into ad_activity
      (actid,
       aname,
       intro,
       adid,
       dlevel,
       pcount,
       etime,
       arank,
       itime,
       status)
    values
      (sq_ad_activity.nextval,
       I_ANAME,
       I_INTRO,
       I_ADID,
       I_DLEVEL,
       I_PCOUNT,
       (select STOPTIME from ad_adinfo where adid = I_ADID),
       I_ARANK,
       sysdate,
       I_STATUS);
  
    commit;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '保存失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pw_AD_ActivityAddSave;

  procedure pw_AD_activityDelete
  /*****************************************************************
        Procedure Name :pw_AD_activityDelete
        Purpose: 删除活动
        Edit: 2018-8-23 add by 小胡
    ****************************************************************/
  (I_AdmInId In Varchar2, --管理员id
   I_ACTID   In Number, --广告id
   O_Result  Out Number,
   O_Message Out Varchar2) is
    V_QX NUMBER; --本模块的权限代码
    v_n  Number;
  begin
    o_result  := 0;
    o_message := '删除成功';
    V_QX      := 104; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    select count(1) into v_n from ad_activity where actid = I_ACTID;
    if v_n <= 0 then
      O_Result  := 2;
      O_Message := '该活动不存在！';
      return;
    end if;
    ---删除活动
    delete from ad_activity where actid = I_ACTID;
    --删除活动下的奖励
    delete from ad_activity_award where actid = I_ACTID;
  
    commit;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '删除失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pw_AD_activityDelete;

  procedure pq_AD_ActAwardList
  /*****************************************************************
        Procedure Name :pq_AD_ActAwardList
        Purpose: 查询活动奖励列表
        Edit: 2018-8-24 add by 小胡
    ****************************************************************/
  (I_AdmInId   In Varchar2, --管理员id
   I_ADID      In Number, --广告id
   I_ACTID     In Number, --活动ID
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    V_QX number; --本模块的权限代码
    v_n  number;
  begin
    o_result  := 0;
    o_message := '显示成功';
    V_QX      := 104; --初始化权限代码
    --初始化游标
    open O_OutCursor for
      select 1 from dual where 1 = 2;
  
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    select count(1)
      into v_n
      from ad_activity
     where adid = I_ADID
       and actid = I_ACTID;
    if v_n <= 0 then
      O_Result  := -2;
      O_Message := '不存在此活动';
      return;
    end if;
  
    select count(1) into v_n from ad_adinfo where adid = I_ADID;
    if v_n <= 0 then
      O_Result  := -2;
      O_Message := '不存在出广告！';
      return;
    end if;
  
    open O_OUTCURSOR for
      select adid, actid, srank, erank, money, price, status
        from ad_activity_award
       where adid = I_ADID
         and actid = I_ACTID
       order by srank;
    return;
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '获取失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pq_AD_ActAwardList;

  procedure pw_AD_ActAwardSave
  /*****************************************************************
        Procedure Name :pw_AD_ActAwardSave
        Purpose: 活动奖励-保存
        Edit: 2018-8-24 add by 小胡
    ****************************************************************/
  (I_AdmInId    In Varchar2, --管理员id
   I_ADID       In Number, --广告id
   I_ACTID      In Number, --活动介绍
   I_SrankList  In Varchar2, --起始排名列表
   I_ErankList  In Varchar2, --结束排名列表 
   I_MoneyList  In Varchar2, --奖励金额列表 
   I_PriceList  In Varchar2, --结算金额列表 
   I_StatusList In Varchar2, --奖励状态列表
   O_Result     Out Number,
   O_Message    Out Varchar2) is
    V_QX NUMBER; --本模块的权限代码
    v_n  Number;
  
    V_SrankList  Varchar2(3000); --起始排名列表
    V_ErankList  Varchar2(3000); --结束排名列表 
    V_MoneyList  Varchar2(3000); --奖励金额列表 
    V_PriceList  Varchar2(3000); --结算金额列表 
    V_StatusList Varchar2(3000); --奖励状态列表
  
    V_Srank  Number; --起始排名列表
    V_Erank  Number; --结束排名列表 
    V_Money  Number(18, 2); --奖励金额列表 
    V_Price  Number(18, 2); --结算金额列表 
    V_Status Number; --奖励状态列表
  
  begin
    o_result  := 0;
    o_message := '保存成功';
    V_QX      := 104; --初始化权限代码
  
    V_SrankList  := I_SrankList; --起始排名列表
    V_ErankList  := I_ErankList; --结束排名列表 
    V_MoneyList  := I_MoneyList; --奖励金额列表 
    V_PriceList  := I_PriceList; --结算金额列表 
    V_StatusList := I_StatusList; --奖励状态列表
  
    --管理员输入是否正确
    if I_ADMINID is null then
      O_RESULT  := 101;
      O_MESSAGE := '请重新登录后在操作！';
      RETURN;
    end if;
  
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    select count(1) into v_n from ad_adinfo where adid = I_ADID;
    if v_n <= 0 then
      O_Result  := 2;
      O_Message := '该广告不存在！';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_activity
     where adid = I_ADID
       and actid = I_ACTID;
    if v_n <= 0 then
      O_Result  := 2;
      O_Message := '活动不存在！';
      return;
    end if;
  
    --删除原有奖励
    select count(1)
      into v_n
      from ad_activity_award
     where adid = I_ADID
       and actid = I_ACTID;
    if v_n > 0 then
      delete ad_activity_award
       where adid = I_ADID
         and actid = I_ACTID;
      commit;
    end if;
  
    if V_SrankList is null then
      return;
    end if;
    Loop
      --拆分  起始排名列表
      if INSTR(V_SrankList, '$#@') <= 0 then
        --如果没有“$#@”符号，则直接取值，不拆分
        V_Srank     := V_SrankList;
        V_SrankList := '';
      else
        V_Srank     := substr(V_SrankList, 0, instr(V_SrankList, '$#@') - 1); --从字符串0开始复制，到第一个"$#@"退一位结束
        V_SrankList := substr(V_SrankList, instr(V_SrankList, '$#@') + 3); --从第一组分隔符开始取 到结束
      end if;
    
      --拆分  结束排名列表
      if INSTR(V_ErankList, '$#@') <= 0 then
        --如果没有“$#@”符号，则直接取值，不拆分
        V_Erank     := V_ErankList;
        V_ErankList := '';
      else
        V_Erank     := substr(V_ErankList, 0, instr(V_ErankList, '$#@') - 1); --从字符串0开始复制，到第一个"$#@"退一位结束
        V_ErankList := substr(V_ErankList, instr(V_ErankList, '$#@') + 3); --从第一组分隔符开始取 到结束
      end if;
    
      --拆分  奖励金额列表
      if INSTR(V_MoneyList, '$#@') <= 0 then
        --如果没有“$#@”符号，则直接取值，不拆分
        V_Money     := V_MoneyList;
        V_MoneyList := '';
      else
        V_Money     := substr(V_MoneyList, 0, instr(V_MoneyList, '$#@') - 1); --从字符串0开始复制，到第一个"$#@"退一位结束
        V_MoneyList := substr(V_MoneyList, instr(V_MoneyList, '$#@') + 3); --从第一组分隔符开始取 到结束
      end if;
    
      --拆分  结算金额列表
      if INSTR(V_PriceList, '$#@') <= 0 then
        --如果没有“$#@”符号，则直接取值，不拆分
        V_Price     := V_PriceList;
        V_PriceList := '';
      else
        V_Price     := substr(V_PriceList, 0, instr(V_PriceList, '$#@') - 1); --从字符串0开始复制，到第一个"$#@"退一位结束
        V_PriceList := substr(V_PriceList, instr(V_PriceList, '$#@') + 3); --从第一组分隔符开始取 到结束
      end if;
    
      --拆分  奖励状态列表
      if INSTR(V_StatusList, '$#@') <= 0 then
        --如果没有“$#@”符号，则直接取值，不拆分
        V_Status     := V_StatusList;
        V_StatusList := '';
      else
        V_Status     := substr(V_StatusList,
                               0,
                               instr(V_StatusList, '$#@') - 1); --从字符串0开始复制，到第一个"$#@"退一位结束
        V_StatusList := substr(V_StatusList, instr(V_StatusList, '$#@') + 3); --从第一组分隔符开始取 到结束
      end if;
    
      if V_Money < 0 then
        O_RESULT  := -5;
        O_MESSAGE := '奖励金额不能小于0，请检查';
        ROLLBACK;
        RETURN;
      end if;
      if V_Price < 0 then
        O_RESULT  := -5;
        O_MESSAGE := '奖励金额不能小于0，请检查';
        ROLLBACK;
        RETURN;
      end if;
      if V_Money > V_Price then
        O_RESULT  := -5;
        O_MESSAGE := '奖励金额不能大于结算金额';
        ROLLBACK;
        RETURN;
      end if;
    
      insert into ad_activity_award
        (adid, actid, srank, erank, money, price, status, itime)
      values
        (I_ADID,
         I_ACTID,
         V_Srank,
         V_Erank,
         V_Money,
         V_Price,
         V_Status,
         sysdate);
      EXIT WHEN V_SrankList IS NULL;
    end Loop;
  
    commit;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '保存失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pw_AD_ActAwardSave;

  procedure pq_AD_ActRecordList
  /*****************************************************************
        Procedure Name :pq_AD_ActAwardList
        Purpose: 冲级赛名单
        Edit: 2018-8-22 add by 小胡
    ****************************************************************/
  (I_AdmInId        In Varchar2, --管理员id
   I_ADID           In Number, --广告id
   I_ACTID          In Number, --活动ID
   I_PageSize       In Number,
   I_PageNO         In Number,
   O_OutRecordCount Out Number,
   O_OutCursor      Out t_cursor, --返回游标
   O_Result         Out Number,
   O_Message        Out Varchar2) is
    v_sql       varchar2(2000);
    V_HEIROWNUM NUMBER;
    V_LOWROWNUM NUMBER;
    V_QX        NUMBER; --本模块的权限代码
    v_n         Number;
  begin
    o_result  := 0;
    o_message := '查询成功';
    ---初始化游标
    open O_OutCursor for
      select 1 from dual where 1 = 2;
    V_QX := 104; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    select count(1) into v_n from ad_adinfo where adid = I_ADID;
    if v_n <= 0 then
      O_Result  := 2;
      O_Message := '广告ID输入错误！';
      return;
    end if;
  
    select count(1) into v_n from ad_activity where actid = I_ACTID;
    if v_n <= 0 then
      O_Result  := 2;
      O_Message := '活动不存在';
      return;
    end if;
  
    v_sql := 'select  c.adid ,c.title ,c.merid ,c.dlevel ,d.money,d.price,c.itime ,c.rn as RANK,c.actid ,e.aname  from (
 select adid,title,merid,dlevel,itime,rownum rn,actid from ( select b.adid,b.title,a.merid,a.dlevel,to_char(a.itime ,''yyyy-mm-dd hh24:mi:ss'') itime,' ||
             I_ACTID ||
             ' as actid from ad_app_flux a,ad_adinfo b
  where a.adid=b.adid and a.dlevel = (select dlevel from ad_activity where  adid=' ||
             I_ADID || ' and actid=' || I_ACTID || ' ) and b.adid=' ||
             I_ADID ||
             ' order by dlevel,a.itime) 
   where  rownum <=(select pcount from ad_activity where actid=' ||
             I_ACTID ||
             ' ))c,ad_activity_award d,ad_activity e where e.actid=d.actid and c.adid=d.adid and c.actid=d.actid and rn >=d.srank and rn<=d.erank';
  
    execute immediate 'select count(1) from (select adid,deviceid,merid from ad_app_flux where adid=' ||
                      I_ADID ||
                      ' and dlevel = (select dlevel from ad_activity where  adid=' ||
                      I_ADID || ' and actid=' || I_ACTID ||
                      ' ) and rownum<=(select pcount from ad_activity where actid=' ||
                      I_ACTID || ' ) )'
      into O_OUTRECORDCOUNT;
  
    ----执行分页查询
    V_HEIROWNUM := I_PAGENO * I_PAGESIZE;
    V_LOWROWNUM := V_HEIROWNUM - I_PAGESIZE + 1;
    V_SQL       := 'select adid,title,merid,dlevel,price,money,itime,RANK,actid,aname,rn 
                    FROM (
                    select adid,title,merid,dlevel,price,money,itime,RANK,actid,aname,rownum rn  
                    FROM (' || v_sql || ') 
                    WHERE rownum <= ' ||
                   TO_CHAR(V_HEIROWNUM) || '
                    ) 
                    WHERE rn >= ' || TO_CHAR(V_LOWROWNUM);
    open O_OUTCURSOR for v_sql;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '查询失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pq_AD_ActRecordList;

  procedure PW_AD_ActivityCopy
  /*****************************************************************
        Procedure Name :PW_AD_ActivityCopy
        Purpose: 复制活动
        Edit: 2018-10-30 add by 小胡
    ****************************************************************/
  (I_AdmInId In Varchar2, --管理员id
   I_ADID    In Number, --广告id
   I_ACTID   In Number, --活动id
   O_Result  Out Number,
   O_Message Out Varchar2) is
    V_QX        NUMBER; --本模块的权限代码
    v_n         Number;
    v_NextActid number;
  begin
    o_result    := 0;
    o_message   := '复制成功';
    v_NextActid := 0;
    V_QX        := 104; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    select count(1) into v_n from ad_activity where actid = I_ACTID;
    if v_n <= 0 then
      O_Result  := 2;
      O_Message := '该活动不存在！';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_activity
     where adid = I_ADID
       and actid = I_ACTID;
  
    if v_n > 0 then
      v_NextActid := sq_ad_activity.nextval;
      insert into ad_activity
        (actid, aname, intro, adid, dlevel, pcount, etime, arank, status)
        select v_NextActid,
               aname,
               intro,
               adid,
               dlevel,
               pcount,
               etime,
               arank,
               status
          from ad_activity
         where adid = I_ADID
           and actid = I_ACTID;
      commit;
    
      select count(1)
        into v_n
        from ad_activity_award
       where adid = I_ADID
         and actid = I_ACTID;
      if v_n > 0 then
        insert into ad_activity_award
          (adid, actid, srank, erank, money, price, status)
          select adid, v_NextActid, srank, erank, money, price, status
            from ad_activity_award
           where adid = I_ADID
             and actid = I_ACTID;
        commit;
      end if;
    
    end if;
    commit;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '删除失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_AD_ActivityCopy;
  procedure PW_AD_ActivityCopyAll
  /*****************************************************************
        Procedure Name :PW_AD_ActivityCopyAll
        Purpose: 复制活动
        Edit: 2018-11-01 add by 小胡
    ****************************************************************/
  (I_AdmInId  In Varchar2, --管理员id
   I_ADID     In Number, --广告id
   I_COPYADID In Number, --复制的广告id
   O_Result   Out Number,
   O_Message  Out Varchar2) is
    V_QX        NUMBER; --本模块的权限代码
    v_n         Number;
    v_NextActid number;
  
  begin
    o_result    := 0;
    o_message   := '复制成功';
    v_NextActid := 0;
    V_QX        := 104; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    select count(1) into v_n from ad_adinfo where adid = I_ADID;
    if v_n <= 0 then
      O_Result  := 2;
      O_Message := '该广告不存在！';
      return;
    end if;
  
    select count(1) into v_n from ad_activity where adid = I_COPYADID;
    if v_n <= 0 then
      O_Result  := 2;
      O_Message := '此复制广告没有设置过活动！';
      return;
    end if;
    DECLARE
      CURSOR ActList IS
        select actid from ad_activity where adid = I_COPYADID;
    begin
      for cur in ActList loop
        v_NextActid := sq_ad_activity.nextval;
        insert into ad_activity
          (actid, aname, intro, adid, dlevel, pcount, etime, arank, status)
          select v_NextActid,
                 aname,
                 intro,
                 I_ADID,
                 dlevel,
                 pcount,
                 etime,
                 arank,
                 status
            from ad_activity
           where actid = cur.actid;
        commit;
      
        select count(1)
          into v_n
          from ad_activity_award
         where actid = cur.actid;
        if v_n > 0 then
          insert into ad_activity_award
            (adid, actid, srank, erank, money, price, status)
            select I_ADID, v_NextActid, srank, erank, money, price, status
              from ad_activity_award
             where actid = cur.actid;
          commit;
        end if;
      end loop;
    end;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '复制失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_AD_ActivityCopyAll;

end p_activity_manage;
/


create PACKAGE BODY P_AD_Users AS

  /*
    根据广告渠道用户生成闲玩用户ID 
  */

  procedure PQ_User
  /*****************************************************************
        Procedure Name :PQ_User
        Purpose: 查找闲玩用户编号
        Edit: 2018-03-27 add by 小沈
    ****************************************************************/
  (I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_SIMID    In Varchar2, --sim卡编号
   I_AppSign  In Varchar2, --渠道用户标识
   I_PType    In Number, --1、ios  2、安卓  
   O_Userid   Out Number, --返回闲玩用户ID
   O_Deviceid Out Varchar2, --返回处理后的设备号
   O_Result   Out Number, --判断 0：查询成功，其他：出错
   O_Message  Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n          number;
    v_userid     number := 0; --闲玩用户编号
    v_DeviceId   varchar2(100);
    v_DeviceId_O varchar2(100); --之前设备号
    v_SimId_O    varchar2(100); --之前sim卡编号 
  begin
    O_Userid   := 0;
    O_Deviceid := I_Deviceid;
    O_Result   := 0;
    O_Message  := '查询成功';
    --去空格处理
    v_DeviceId := fq_str_delspace(i_str => I_Deviceid);
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
  
   /* if I_PType not in (1, 2) then
      O_Result  := 1;
      O_Message := '请重新登录APP';
      return;
    end if;
  
    --设备号校验是否合法 0否 1是
    if p_base_fun.fq_deviceid_check(v_DeviceId, I_PType) = 0 then
      O_Result  := 1;
      O_Message := '请先对APP进行授权';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_channel
     where appid = I_APPId
       and status != 2;
  
    if v_n <= 0 then
      O_Result  := 1;
      O_Message := '渠道信息不存在';
      return;
    end if;*/
  
    ----------------------------------------------------
    --步骤二：处理
    ----------------------------------------------------
  
    select count(1)
      into v_n
      from ad_app_users
     where appid = I_APPId
       and ptype = I_PType
       and appsign = I_AppSign;
    --如果用户编号已存在 则返回
    if v_n =1 then
      select userid, deviceid, simid
        into v_userid, v_DeviceId_O, v_SimId_O
        from ad_app_users
       where appid = I_APPId
         and appsign = I_AppSign
         and ptype = I_PType;
      --如果用户变更了设备号则需要更新
      if v_DeviceId_O != v_DeviceId or v_SimId_O != I_SIMID then
        update ad_app_users
           set deviceid = v_DeviceId, simid = I_SIMID
         where userid = v_userid;
        commit;
      end if;
    else
      v_userid := SQ_AD_USERS.NEXTVAL;
      insert into ad_app_users
        (userid, appid, deviceid, simid, appsign, ptype)
      values
        (v_userid, I_APPId, v_DeviceId, I_SIMID, I_AppSign, I_PType);
      commit;
    end if;
  
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    O_Userid   := v_userid;
    O_Deviceid := v_DeviceId;
    commit;
    return;
  
  exception
    --失败
    when others then
      rollback;
      O_Userid   := 0;
      O_Deviceid := '';
      O_Result   := -9;
      O_Message  := '查询失败';
      return;
  end PQ_User;

end P_AD_Users;
/


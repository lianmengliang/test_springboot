create package body P_WXAD_Manage is

  procedure PW_AD_Add
  /*****************************************************************
        Procedure Name :pw_AD_Add
        Purpose: 微信广告增加
        Edit: 2017-10-14 add by 小沈
    ****************************************************************/
  (I_AdminID   In Varchar2,
   I_Title     In Varchar2, --广告名称[内部使用] 
   I_ADName    In Varchar2, --前台显示广告名称 
   I_Status    In Number, --投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放） 
   I_ShowType  In Number, --0不显示，1显示 
   I_ADType    In Number, --广告类型（1转发，2关注） 
   I_Intro     In Varchar2, --广告简介 
   I_Money     In Varchar2, --奖励总金额 
   I_StartTime In Varchar2, --广告投放时间 
   I_StopTime  In Varchar2, --停止投放时间 
   I_PhoneType In Number, --1、ios，  2、安卓， 3、ios和安卓都显示 
   I_Wechat    In Varchar2, --微信号 
   I_Imgurl    In Varchar2, --广告小图片地址
   I_ADLink    In Varchar2, --广告地址
   I_AMoney    In Number, --到款金额 
   I_ShowOrder In Number, --排序号 
   O_Result    Out number,
   O_Message   Out varchar2) is
    V_ADID   Number; --广告ID
    V_ADLink Varchar2(500); --   安卓广告地址
  
    V_QX Number; --本模块的权限代码
  
  begin
    o_result  := 0;
    o_message := '保存成功';
  
    V_QX := 104; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX)=0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    V_ADID   := sq_wx_adinfo.nextval;
    V_ADLink := replace(I_ADLink, '[adid]', V_ADID);
  
    insert into wx_adinfo
      (adid,
       title,
       adname,
       status,
       showtype,
       adtype,
       intro,
       money,
       starttime,
       stoptime,
       phonetype,
       wechat,
       imgurl,
       adlink,
       amoney,
       showorder)
    values
      (V_ADID,
       I_title,
       I_adname,
       I_status,
       I_showtype,
       I_adtype,
       I_intro,
       I_money,
       to_date(I_starttime, 'yyyy-mm-dd hh24:mi:ss'),
       to_date(I_stoptime, 'yyyy-mm-dd hh24:mi:ss'),
       I_phonetype,
       I_wechat,
       I_imgurl,
       V_ADLink,
       I_amoney,
       I_showorder);
  
    commit;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_MESSAGE := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_AD_Add;

end P_WXAD_Manage;
/


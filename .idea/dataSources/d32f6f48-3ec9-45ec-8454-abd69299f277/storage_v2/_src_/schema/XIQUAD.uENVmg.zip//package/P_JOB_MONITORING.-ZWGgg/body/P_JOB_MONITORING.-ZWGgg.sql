create PACKAGE BODY P_Job_Monitoring AS

  /*监控jobs*/

  procedure Job_AD
  /*****************************************************************
        procedure name: Job_AD
        purpose: 广告监控
       edit: 2017-07-30 add by 小沈
    ****************************************************************/
   is
    v_n               number;
    v_appid           number;
    v_adid            number;
    v_adname          varchar2(500);
    v_admin           varchar2(100); --广告负责人
    v_adminPhone      varchar2(18); ---负责人手机号码
    v_msg             varchar2(100); --需要发送内容
    v_result          number;
    v_message         varchar2(100);
    v_PhoneList_Super varchar2(500) := '15395719310,18768124010'; --超级管理员号码
    v_PhoneList       varchar2(500);
    v_Phone           varchar2(18);
  
  begin
    --查看是否有广告30分钟无下载
    declare
      cursor myCur is
        select adid
          from (select adid, max(itime) itime
                  from ad_app_bind
                 where adid in (select adid
                                  from ad_adinfo
                                 where status = 1
                                   and showtype = 1
                                   and phonetype = 2)
                 group by adid)
         where itime <= sysdate - (180 / (24 * 60));
    begin
      for cur in myCur loop
        v_adid       := cur.adid;
        v_msg        := '';
        v_adminPhone := '';
        select adname into v_adname from ad_adinfo where adid = v_adid;
        select trim(marketer)
          into v_admin
          from ad_downurl
         where adid = v_adid;
      
        select count(1) into v_n from t_admin where name = v_admin;
        if v_n > 0 then
        
          select phone into v_adminPhone from t_admin where name = v_admin;
          v_msg := '广告ID:' || v_adid || '-' || v_adname || '绑定可能异常';
          p_sms.pw_alarm_add(i_phone     => v_adminPhone,
                             i_message   => v_msg,
                             i_sendlevel => 1,
                             i_sendtype  => 1,
                             o_result    => v_result,
                             o_message   => v_message);
        end if;
      
        --抄送超级管理员
        v_PhoneList := v_PhoneList_Super;
        loop
        
          if instr(v_PhoneList, ',') <= 0 then
            v_Phone     := v_PhoneList;
            v_PhoneList := '';
          else
            v_Phone     := substr(v_PhoneList,
                                  0,
                                  instr(v_PhoneList, ',') - 1);
            v_PhoneList := substr(v_PhoneList, instr(v_PhoneList, ',') + 1);
          end if;
          exit when(v_PhoneList is null);
        
          if v_adminPhone != v_Phone and v_Phone is not null then
            p_sms.pw_alarm_add(i_phone     => v_Phone,
                               i_message   => v_msg,
                               i_sendlevel => 1,
                               i_sendtype  => 1,
                               o_result    => v_result,
                               o_message   => v_message);
          end if;
        end loop;
      
      end loop;
      commit;
    end;
  
    v_adid := 0;
    v_msg  := '';
  
    ---查看是否有广告半小时没有注册信息 
    declare
      cursor myCur is
        select adid
          from (select adid, max(lasttime) itime
                  from ad_app_bind
                 where adid in (select adid
                                  from ad_adinfo
                                 where status = 1
                                   and showtype = 1
                                   and phonetype = 2)
                   and ustatus in (2, 3)
                
                 group by adid)
         where itime <= sysdate - (180 / (24 * 60));
    begin
      for cur in myCur loop
        v_adid       := cur.adid;
        v_msg        := '';
        v_adminPhone := '';
        select adname into v_adname from ad_adinfo where adid = v_adid;
        select trim(marketer)
          into v_admin
          from ad_downurl
         where adid = v_adid;
        select count(1) into v_n from t_admin where name = v_admin;
        if v_n > 0 then
          select phone into v_adminPhone from t_admin where name = v_admin;
          v_msg := '广告ID:' || v_adid || '-' || v_adname || '注册可能异常';
          p_sms.pw_alarm_add(i_phone     => v_adminPhone,
                             i_message   => v_msg,
                             i_sendlevel => 1,
                             i_sendtype  => 1,
                             o_result    => v_result,
                             o_message   => v_message);
        end if;
      
        --抄送超级管理员
        v_PhoneList := v_PhoneList_Super;
        loop
        
          if instr(v_PhoneList, ',') <= 0 then
            v_Phone     := v_PhoneList;
            v_PhoneList := '';
          else
            v_Phone     := substr(v_PhoneList,
                                  0,
                                  instr(v_PhoneList, ',') - 1);
            v_PhoneList := substr(v_PhoneList, instr(v_PhoneList, ',') + 1);
          end if;
          exit when(v_PhoneList is null);
        
          if v_adminPhone != v_Phone and v_Phone is not null then
            p_sms.pw_alarm_add(i_phone     => v_Phone,
                               i_message   => v_msg,
                               i_sendlevel => 1,
                               i_sendtype  => 1,
                               o_result    => v_result,
                               o_message   => v_message);
          end if;
        end loop;
      
      end loop;
      commit;
    end;
  
    --查看是否有广告30分钟无奖励
    declare
      cursor myCur is
        select adid
          from (select adid, max(itime) itime
                  from ad_app_flux
                 where adid in (select adid
                                  from ad_adinfo
                                 where status in (1)
                                   and showtype = 1
                                   and phonetype = 2)
                 group by adid)
         where itime <= sysdate - (180 / (24 * 60));
    begin
      for cur in myCur loop
        v_adid       := cur.adid;
        v_msg        := '';
        v_adminPhone := '';
        select adname into v_adname from ad_adinfo where adid = v_adid;
        select trim(marketer)
          into v_admin
          from ad_downurl
         where adid = v_adid;
      
        select count(1) into v_n from t_admin where name = v_admin;
        if v_n > 0 then
          select phone into v_adminPhone from t_admin where name = v_admin;
          v_msg := '广告ID:' || v_adid || '-' || v_adname || '奖励可能异常';
          p_sms.pw_alarm_add(i_phone     => v_adminPhone,
                             i_message   => v_msg,
                             i_sendlevel => 1,
                             i_sendtype  => 1,
                             o_result    => v_result,
                             o_message   => v_message);
        end if;
      
        --抄送超级管理员
        v_PhoneList := v_PhoneList_Super;
        loop
        
          if instr(v_PhoneList, ',') <= 0 then
            v_Phone     := v_PhoneList;
            v_PhoneList := '';
          else
            v_Phone     := substr(v_PhoneList,
                                  0,
                                  instr(v_PhoneList, ',') - 1);
            v_PhoneList := substr(v_PhoneList, instr(v_PhoneList, ',') + 1);
          end if;
          exit when(v_PhoneList is null);
        
          if v_adminPhone != v_Phone and v_Phone is not null then
            p_sms.pw_alarm_add(i_phone     => v_Phone,
                               i_message   => v_msg,
                               i_sendlevel => 1,
                               i_sendtype  => 1,
                               o_result    => v_result,
                               o_message   => v_message);
          end if;
        end loop;
      
      end loop;
      commit;
    end;
  
    ---查看是否有渠道半小时没有推送成功消息
    declare
      cursor myCur is
        select appid
          from (select appid, max(p_time) p_time
                  from ad_channel_order
                 where p_time >= sysdate - (180 / (24 * 60))
                   and appid in
                       (select appid from ad_interf_order where status = 0)
                 group by appid)
         where p_time <= sysdate - (180 / (24 * 60))
            or p_time is null;
    
    begin
      for cur in myCur loop
        v_appid      := cur.appid;
        v_adminPhone := '';
      
        v_msg := '渠道ID:' || v_appid || '推送异常';
        p_sms.pw_alarm_add(i_phone     => '15755173251',
                           i_message   => v_msg,
                           i_sendlevel => 1,
                           i_sendtype  => 3,
                           o_result    => v_result,
                           o_message   => v_message);
      
      end loop;
      commit;
    end;
  
    ---查看半小时广告奖励金额 超过5000报警
    declare
      cursor myCur is
        select adid
          from (select adid, sum(price) price
                  from ad_app_flux
                 where itime >= sysdate - 30 / (24 * 60)
                 group by adid)
         where price > 5000
         order by price desc;
    begin
      for cur in myCur loop
        v_adid := cur.adid;
        select adname into v_adname from ad_adinfo where adid = v_adid;
        v_msg        := '广告ID:' || v_adid || '-' || v_adname ||
                        '；30分钟领奖超5000';
        v_adminPhone := '';
        select trim(marketer)
          into v_admin
          from ad_downurl
         where adid = v_adid;
      
        select count(1) into v_n from t_admin where name = v_admin;
        if v_n > 0 then
          select phone into v_adminPhone from t_admin where name = v_admin;
        
          p_sms.pw_alarm_add(i_phone     => v_adminPhone,
                             i_message   => v_msg,
                             i_sendlevel => 1,
                             i_sendtype  => 1,
                             o_result    => v_result,
                             o_message   => v_message);
        end if;
      
        --抄送超级管理员
        v_PhoneList := v_PhoneList_Super;
        loop
        
          if instr(v_PhoneList, ',') <= 0 then
            v_Phone     := v_PhoneList;
            v_PhoneList := '';
          else
            v_Phone     := substr(v_PhoneList,
                                  0,
                                  instr(v_PhoneList, ',') - 1);
            v_PhoneList := substr(v_PhoneList, instr(v_PhoneList, ',') + 1);
          end if;
          exit when(v_PhoneList is null);
        
          if v_adminPhone != v_Phone and v_Phone is not null then
            p_sms.pw_alarm_add(i_phone     => v_Phone,
                               i_message   => v_msg,
                               i_sendlevel => 1,
                               i_sendtype  => 1,
                               o_result    => v_result,
                               o_message   => v_message);
          end if;
        end loop;
      
      end loop;
      commit;
    end;
  
    ---查看半小时跑数据金额 超过5000报警
    declare
      cursor myCur is
        select adid, money
          from (select adid, sum(amount) money
                  from (select a.adid,
                               b.dlevel,
                               a.price,
                               b.ct,
                               a.price * b.ct Amount
                          from fin_ad_set_l a,
                               (
                                
                                select adid, dlevel, count(1) ct
                                  from fin_ad_flux
                                 where itime >= sysdate - 30 / (24 * 60)
                                 group by adid, dlevel
                                
                                ) b
                         where a.adid = b.adid
                           and a.dlevel = b.dlevel)
                 group by adid)
         where money > 5000
         order by money desc;
    begin
      for cur in myCur loop
        v_adid := cur.adid;
        select adname into v_adname from ad_adinfo where adid = v_adid;
        v_msg        := '广告ID:' || v_adid || '-' || v_adname ||
                        '；30分钟系统跑超5000';
        v_adminPhone := '';
        select trim(marketer)
          into v_admin
          from ad_downurl
         where adid = v_adid;
      
        select count(1) into v_n from t_admin where name = v_admin;
        if v_n > 0 then
        
          select phone into v_adminPhone from t_admin where name = v_admin;
        
          p_sms.pw_alarm_add(i_phone     => v_adminPhone,
                             i_message   => v_msg,
                             i_sendlevel => 1,
                             i_sendtype  => 1,
                             o_result    => v_result,
                             o_message   => v_message);
        end if;
      
        --抄送超级管理员
        v_PhoneList := v_PhoneList_Super;
        loop
        
          if instr(v_PhoneList, ',') <= 0 then
            v_Phone     := v_PhoneList;
            v_PhoneList := '';
          else
            v_Phone     := substr(v_PhoneList,
                                  0,
                                  instr(v_PhoneList, ',') - 1);
            v_PhoneList := substr(v_PhoneList, instr(v_PhoneList, ',') + 1);
          end if;
          exit when(v_PhoneList is null);
        
          if v_adminPhone != v_Phone and v_Phone is not null then
            p_sms.pw_alarm_add(i_phone     => v_Phone,
                               i_message   => v_msg,
                               i_sendlevel => 1,
                               i_sendtype  => 1,
                               o_result    => v_result,
                               o_message   => v_message);
          end if;
        end loop;
      
      end loop;
      commit;
    end;
  
    ---查看是否有广告奖励未设置
    declare
      cursor myCur is
        select adid, title, showtype
          from ad_adinfo
         where adid not in (2055, 2067)
           and status in (1, 2, 3)
           and showtype = 1
           and adid not in (select adid from fin_ad_set);
    begin
      for cur in myCur loop
        v_adid := cur.adid;
        v_msg  := '广告:' || cur.title || '；结算尚未设置';
      
        --抄送超级管理员
        v_PhoneList := v_PhoneList_Super;
        loop
        
          if instr(v_PhoneList, ',') <= 0 then
            v_Phone     := v_PhoneList;
            v_PhoneList := '';
          else
            v_Phone     := substr(v_PhoneList,
                                  0,
                                  instr(v_PhoneList, ',') - 1);
            v_PhoneList := substr(v_PhoneList, instr(v_PhoneList, ',') + 1);
          end if;
          exit when(v_PhoneList is null);
        
          if v_adminPhone != v_Phone and v_Phone is not null then
            p_sms.pw_alarm_add(i_phone     => v_Phone,
                               i_message   => v_msg,
                               i_sendlevel => 1,
                               i_sendtype  => 1,
                               o_result    => v_result,
                               o_message   => v_message);
          end if;
        end loop;
      
      end loop;
      commit;
    end;
  
    --渠道推送监测
    select count(1)
      into v_n
      from ad_channel_order
     where p_ntime <= sysdate
       and p_status in (0, 2)
       and appid in (select appid from ad_interf_order where status = 0);
  
    if v_n > 100 then
      v_msg := '嘻趣渠道待推送订单超100条';
      p_sms.pw_alarm_add(i_phone     => '18758009397',
                         i_message   => v_msg,
                         i_sendlevel => 1,
                         i_sendtype  => 1,
                         o_result    => v_result,
                         o_message   => v_message);
      --亚飞
      p_sms.pw_alarm_add(i_phone     => '15755173251',
                         i_message   => v_msg,
                         i_sendlevel => 1,
                         i_sendtype  => 1,
                         o_result    => v_result,
                         o_message   => v_message);
    end if;
  
    ---访问连接数
  
    /*    grand
          select count(1)
            into v_n
            from v$session to 'ADWall'
           where status = 'ACTIVE';
        if v_n > 40 then
          v_msg := '连接等待数数达到' || v_n || '检查';
          p_sms.pw_alarm_add(i_phone     => v_adminPhone_s,
                             i_message   => v_msg,
                             i_sendlevel => 1,
                             i_sendtype  => 3,
                             o_result    => v_result,
                             o_message   => v_message);
        end if;
    */
  exception
    when others then
      rollback;
      return;
  end Job_AD;

end P_Job_Monitoring;
/


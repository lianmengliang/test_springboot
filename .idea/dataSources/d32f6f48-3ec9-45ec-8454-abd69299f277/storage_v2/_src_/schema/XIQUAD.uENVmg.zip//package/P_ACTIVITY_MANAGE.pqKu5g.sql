create package p_activity_manage is

  TYPE T_CURSOR IS REF CURSOR;

  procedure pq_AD_ActivityList
  /*****************************************************************
        Procedure Name :pq_AD_List
        Purpose: 广告活动列表
        Edit: 2018-8-22 add by 小胡
    ****************************************************************/
  (I_AdmInId        In Varchar2, --管理员id
   I_ADID           In Number, --广告id
   I_ADName         In Varchar2, --广告名称
   I_PageSize       In Number,
   I_PageNO         In Number,
   O_OutRecordCount Out Number,
   O_OutCursor      Out t_cursor, --返回游标
   O_Result         Out Number,
   O_Message        Out Varchar2);
  procedure pq_AD_ActivityInfo
  /*****************************************************************
        Procedure Name :pq_AD_ActivityInfo
        Purpose: 广告活动信息
        Edit: 2018-8-22 add by 小胡
    ****************************************************************/
  (I_AdmInId   In Varchar2, --管理员id
   I_ACTID     In Number, --活动id
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure pw_AD_ActivityModSave
  /*****************************************************************
        Procedure Name :pw_AD_ActivityModSave
        Purpose: 广告活动信息
        Edit: 2018-8-22 add by 小胡
    ****************************************************************/
  (I_AdmInId In Varchar2, --管理员id
   I_ACTID   In Number, --活动id
   I_INTRO   In Varchar2, --活动介绍
   I_STATUS  In Number, --活动状态
   I_ARANK   In Number, --活动排序 
   I_PCOUNT  In Number, --活动奖励人数 
   I_DLEVEL  In Number, --奖励对应等级 
   I_ANAME   In Varchar2, --活动名称
   O_Result  Out Number,
   O_Message Out Varchar2);

  procedure pw_AD_ActivityAddSave
  /*****************************************************************
        Procedure Name :pw_AD_ActivityAddSave
        Purpose: 添加活动-保存
        Edit: 2018-8-23 add by 小胡
    ****************************************************************/
  (I_AdmInId In Varchar2, --管理员id
   I_ADID    In Number, --广告id
   I_INTRO   In Varchar2, --活动介绍
   I_STATUS  In Number, --活动状态
   I_ARANK   In Number, --活动排序 
   I_PCOUNT  In Number, --活动奖励人数 
   I_DLEVEL  In Number, --奖励对应等级 
   I_ANAME   In Varchar2, --活动名称
   O_Result  Out Number,
   O_Message Out Varchar2);

  procedure pw_AD_activityDelete
  /*****************************************************************
        Procedure Name :pw_AD_activityDelete
        Purpose: 删除活动
        Edit: 2018-8-23 add by 小胡
    ****************************************************************/
  (I_AdmInId In Varchar2, --管理员id
   I_ACTID   In Number, --广告id
   O_Result  Out Number,
   O_Message Out Varchar2);

  procedure pq_AD_ActAwardList
  /*****************************************************************
        Procedure Name :pq_AD_ActAwardList
        Purpose: 查询活动奖励列表
        Edit: 2018-8-24 add by 小胡
    ****************************************************************/
  (I_AdmInId   In Varchar2, --管理员id
   I_ADID      In Number, --广告id
   I_ACTID     In Number, --活动ID
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);
  procedure pw_AD_ActAwardSave
  /*****************************************************************
        Procedure Name :pw_AD_ActAwardSave
        Purpose: 活动奖励-保存
        Edit: 2018-8-24 add by 小胡
    ****************************************************************/
  (I_AdmInId    In Varchar2, --管理员id
   I_ADID       In Number, --广告id
   I_ACTID      In Number, --活动介绍
   I_SrankList  In Varchar2, --起始排名列表
   I_ErankList  In Varchar2, --结束排名列表 
   I_MoneyList  In Varchar2, --奖励金额列表 
   I_PriceList  In Varchar2, --结算金额列表 
   I_StatusList In Varchar2, --奖励状态列表
   O_Result     Out Number,
   O_Message    Out Varchar2);

  procedure pq_AD_ActRecordList
  /*****************************************************************
        Procedure Name :pq_AD_ActAwardList
        Purpose: 冲级赛名单
        Edit: 2018-8-22 add by 小胡
    ****************************************************************/
  (I_AdmInId        In Varchar2, --管理员id
   I_ADID           In Number, --广告id
   I_ACTID          In Number, --活动ID
   I_PageSize       In Number,
   I_PageNO         In Number,
   O_OutRecordCount Out Number,
   O_OutCursor      Out t_cursor, --返回游标
   O_Result         Out Number,
   O_Message        Out Varchar2);
  procedure PW_AD_ActivityCopy
  /*****************************************************************
        Procedure Name :PW_AD_ActivityCopy
        Purpose: 复制活动
        Edit: 2018-10-30 add by 小胡
    ****************************************************************/
  (I_AdmInId In Varchar2, --管理员id
   I_ADID    In Number, --广告id
   I_ACTID   In Number, --活动id
   O_Result  Out Number,
   O_Message Out Varchar2);
  procedure PW_AD_ActivityCopyAll
  /*****************************************************************
        Procedure Name :PW_AD_ActivityCopyAll
        Purpose: 复制活动
        Edit: 2018-11-01 add by 小胡
    ****************************************************************/
  (I_AdmInId  In Varchar2, --管理员id
   I_ADID     In Number, --广告id
   I_COPYADID In Number, --复制的广告id
   O_Result   Out Number,
   O_Message  Out Varchar2);
end p_activity_manage;


/


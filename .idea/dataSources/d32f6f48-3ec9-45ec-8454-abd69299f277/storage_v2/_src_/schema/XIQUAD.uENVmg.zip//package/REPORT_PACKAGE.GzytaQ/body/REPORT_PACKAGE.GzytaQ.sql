create package body report_package as

  procedure addreport
  /*****************************************************************
    procedure name: titlelist
    purpose: 插入报表
    comment: 建立日期 20071218
    author：wangcheng
            modify by yxh 2008-01-18 增加了设置每页显示记录数参数
    ****************************************************************/
  (i_title         in varchar2, -- 查询区
   i_sql           in long, --sql语句
   i_parameter     in varchar2, --当前页码,从 1 开始
   i_reportname    in varchar2, --报表名称
   i_reportwidth   in varchar2, --报表列宽
   i_reportalign   in varchar2, --报表列对齐方式
   i_reportcontrol in varchar2, --报表控件
   i_pagesize      in number, --每页显示的记录数
   o_result        out number) -- 返回结果  1:成功 0:失败 2：报表名称已经存在
   is
    v_count number;
  
  begin
    --检查报表名称是否已经存在
    select count(*)
      into v_count
      from t_report
     where reportname = i_reportname;
    if v_count > 0 then
      o_result := 2;
      return;
    end if;
    --判断sql语句中是否有不合法的关键字
    if freport_checksql(i_sql => i_sql) > 0 then
      o_result := 0;
      return;
    end if;
    --插入数据
    insert into t_report
      (title,
       querysql,
       parameter,
       reportname,
       reportid,
       reportwidth,
       reportalign,
       recordtime,
       reportcontrol,
       state,
       pagesize)
    values
      (i_title,
       i_sql,
       i_parameter,
       i_reportname,
       sq_t_report.nextval,
       i_reportwidth,
       i_reportalign,
       sysdate,
       i_reportcontrol,
       0,
       i_pagesize);
    commit;
    o_result := 1;
    return;
  exception
    when others then
      rollback;
      o_result := 0;
      return;
  end addreport;

  procedure viewreport
  /*******************************************************************
    procedure name:reportlist
    prupose :报表查询
    comment:建立日期20071218
    author:wangcheng
    ********************************************************************/
  (i_sql            in long, --查询报表的sql
   i_pagesize       in number, --每页记录数
   i_pageno         in number, --当前页码,从 1 开始
   o_outrecordcount out number, --返回总记录数
   o_outcursor      out t_cursor --返回记录
   ) is
    v_sql       long;
    v_tmp       long;
    v_count     number;
    v_heirownum number;
    v_lowrownum number;
  begin
    --判断sql语句中是否有不合法的关键字
    if freport_checksql(i_sql => i_sql) > 0 then
      o_outrecordcount := 0;
      return;
    end if;
    --报表总数
    v_sql := i_sql;
    v_tmp := 'select count(*)
             from (' || v_sql || ') a';
    execute immediate v_tmp
      into v_count;
    o_outrecordcount := v_count;
    --分页查询
    v_heirownum := i_pageno * i_pagesize;
    v_lowrownum := v_heirownum - i_pagesize + 1;
  
    v_sql := 'select *
               from (
                  select a.*, rownum rn
                  from  (' || v_sql || ') a
                  where rownum <= ' || to_char(v_heirownum) || '
                 ) b
            where rn >= ' || to_char(v_lowrownum);
    open o_outcursor for v_sql;
  end viewreport;

  procedure queryreport
  /*******************************************************************
    procedure name:reportlist
    prupose :查询报表
    comment:建立日期20071218
    author:wangcheng
    ********************************************************************/
  (i_adminid   in varchar2, --管理员id
   i_id        in number, --报表id
   o_result    out number, --返回结果，0：无权限，1：有权限
   o_outcursor out t_cursor --返回记录
   ) is
    v_qx  number;
    v_sql long;
  begin
    v_qx := 0;
  
    --查询出该用户该报表的权限id
    select count(1) into v_qx from t_qx where reportid = i_id;
    if v_qx = 0 then
      v_qx := 102;
    else
      select qxid into v_qx from t_qx where reportid = i_id;
    end if;
  
    --判断用户是否有权限查看
    if p_admin.fq_isqx(i_adminid => i_adminid, i_qxid => v_qx) = 0 then
      o_result := 0;
      return;
    end if;
    --返回记录集
    /*    v_sql := 'select  reportid, reportname, reportwidth, state,
    replace(title,''onbeforepaste=filterpaste() onkeypress=number() onpaste="return false"'',null) as  title, parameter, reportalign, recordtime, reportcontrol, pagesize, querysql from t_report where reportid=' ||
               to_char(i_id);*/
    v_sql := 'select  reportid, reportname, reportwidth, state,
    replace(replace(replace(title,''onbeforepaste="filterpaste()"'',null),''onkeypress="number()"'',null),''onpaste="return false"'',null) as  title,  parameter, reportalign, recordtime, reportcontrol, pagesize, querysql from t_report where reportid=' ||
             to_char(i_id);
  
    open o_outcursor for v_sql;
    o_result := 1;
    return;
  exception
    when others then
      o_result := 0;
      return;
  end queryreport;

  procedure reportlist
  /*******************************************************************
    procedure name:reportlist
    prupose :返回定制的报表list
    comment:建立日期20071218
    author:wangcheng
    ********************************************************************/
  (o_outcursor out t_cursor --返回报表记录
   ) is
    v_sql long;
  begin
    v_sql := 'select * from t_report where state=0 order by reportid';
    open o_outcursor for v_sql;
  end reportlist;

  procedure delreport
  /*******************************************************************
    procedure name:delreport
    prupose :删除报表
    comment:建立日期20071218
    author:wangcheng
    ********************************************************************/
  (i_id     in varchar2, --报表id
   o_result out number -- 返回结果  1:成功 0:失败
   ) is
    v_sql long;
  begin
    --删除报表
    v_sql := 'delete from t_report where reportid in (' || to_char(i_id) || ' )';
    execute immediate v_sql;
    --删除报表对应的权限
    v_sql := 'delete from t_qx where reportid in (' || to_char(i_id) || ' )';
    execute immediate v_sql;
    commit;
    o_result := 1;
    return;
  exception
    when others then
      rollback;
      o_result := 0;
      return;
  end delreport;

  procedure modifyreport
  /*****************************************************************
    procedure name: titlelist
    purpose: 修改报表
    comment: 建立日期 20071218
    author：wangcheng
    ****************************************************************/
  (i_id            in number, --报表id
   i_title         in varchar2, -- 查询区
   i_sql           in long, --sql语句
   i_parameter     in varchar2, --当前页码,从 1 开始
   i_reportname    in varchar2, --报表名称
   i_reportwidth   in varchar2, --报表列宽
   i_reportalign   in varchar2, --报表列对齐方式
   i_reportcontrol in varchar2, --报表控件
   i_pagesize      in number, --每页显示的记录数
   o_result        out number) -- 返回结果  1:成功 0:失败  2:报表名称已经存在
   is
    v_count number;
  begin
    --检查报表名称是否存在
    select count(*)
      into v_count
      from t_report
     where reportname = i_reportname
       and reportid != i_id;
    if v_count > 0 then
      o_result := 2;
      return;
    end if;
    --判断sql语句中是否有不合法的关键字
    if freport_checksql(i_sql => i_sql) > 0 then
      o_result := 0;
      return;
    end if;
    --修改
    update t_report
       set title         = i_title,
           querysql      = i_sql,
           parameter     = i_parameter,
           reportname    = i_reportname,
           reportwidth   = i_reportwidth,
           reportalign   = i_reportalign,
           recordtime    = sysdate,
           reportcontrol = i_reportcontrol,
           pagesize      = i_pagesize
     where reportid = i_id;
    commit;
    o_result := 1;
    return;
  exception
    when others then
      rollback;
      o_result := 0;
      return;
  end modifyreport;

  procedure managereport
  /*******************************************************************
    procedure name:reportlist
    prupose :报表管理查询
    comment:建立日期20071218
    author:wangcheng
    ********************************************************************/
  (i_adminid        in varchar2, --管理员id
   i_pagesize       in number, --每页记录数
   i_pageno         in number, --当前页码,从 1 开始
   o_outrecordcount out number, --返回总记录数
   o_result         out number, -- 0:无权限查询，1：有权限
   o_outcursor      out t_cursor --返回记录
   ) is
    v_qx        number;
    v_sql       long;
    v_count     number;
    v_heirownum number;
    v_lowrownum number;
  begin
  
    --约定该报表的权限代码为1007
    v_qx  := 102;
    v_sql := 'select * from t_report';
    --判断用户是否有权限查看
    if p_admin.fq_isqx(i_adminid => i_adminid, i_qxid => v_qx) = 0 then
      o_result         := 0;
      o_outrecordcount := 0;
      open o_outcursor for v_sql;
      return;
    end if;
    --报表总数
    select count(*) into v_count from t_report;
    o_outrecordcount := v_count;
    --分页查询
    v_heirownum := i_pageno * i_pagesize;
    v_lowrownum := v_heirownum - i_pagesize + 1;
  
    v_sql := 'select *
               from (
                  select a.*, rownum rn
                  from  (' || v_sql || ') a
                  where rownum <= ' || to_char(v_heirownum) || '
                 ) b
            where rn >= ' || to_char(v_lowrownum) ||
             ' order by reportid ';
    open o_outcursor for v_sql;
    o_result := 1;
  end managereport;

  procedure config
  /*******************************************************************
    procedure name:reportlist
    prupose :报表权限配置
    comment:建立日期20071218
    author:wangcheng
    ********************************************************************/
  (i_adminid        in varchar2, --管理员id
   i_status         in number, --显示查询状态1：查询已显示，0：查询不显示
   i_delstatus      in number, --显示删除状态1：未删除，0：已删除
   i_pagesize       in number, --每页记录数
   i_pageno         in number, --当前页码,从 1 开始
   o_outrecordcount out number, --返回总记录数
   o_result         out number, -- 0:无权限查询，1：有权限
   o_outcursor      out t_cursor --返回记录
   ) is
    v_qx        number;
    v_sql       long;
    v_count     number;
    v_heirownum number;
    v_lowrownum number;
  begin
    --约定该报表的权限代码为1006
    v_qx  := 102;
    v_sql := 'select 1 from dual where 1=2';
    --判断用户是否有权限查看
    if p_admin.fq_isqx(i_adminid => i_adminid, i_qxid => v_qx) = 0then
     o_result := 0 ; o_outrecordcount := 0 ; open o_outcursor for v_sql ;
     return ; end if ;
    
    --select count(*) into v_count from t_qx;
      select count(*)
          into v_count
          from t_qx
         where 1 = 1
           and status = i_delstatus
           and isshow = i_status
         order by gname asc, rank; o_outrecordcount := v_count;
        --分页查询
        v_heirownum := i_pageno * i_pagesize; v_lowrownum := v_heirownum - i_pagesize + 1; v_sql := 'select * from t_qx where 1=1 and status=' || i_delstatus || ' and isshow=' || i_status; v_sql := v_sql || '  order by groupname asc, orderbyid ';
        
        v_sql := 'select *
               from (
                  select a.*, rownum rn
                  from  (' || v_sql || ') a
                  where rownum <= ' || to_char(v_heirownum) || '
                 ) b
            where rn >= ' || to_char(v_lowrownum); open o_outcursor
           for v_sql; o_result := 1; end config;
        
        procedure delqx
        /*******************************************************************
        procedure name:delqx
        prupose :删除权限（报表）
        comment:建立日期20071218
        author:wangcheng
        ********************************************************************/
        (i_adminid in varchar2, --管理员id
        i_id in number, --报表id
        o_result out number -- 返回结果  1:成功 0:失败,2:无权限
        ) is v_status number; v_qx number; begin
        --初始化
        --v_reportid := 0;
        --约定该报表的权限代码为102
        v_qx := 102;
        --判断用户是否有权限
        if p_admin.fq_isqx(i_adminid => i_adminid, i_qxid => v_qx) = 0
     then
      o_result := 2;
      return;
    end if;
    --如果该权限是来自定制的报表则修改该报表的状态
    select status into v_status from t_qx where qxid = i_id;
    -- if v_reportid > 0 then
    -- update t_report set state = 0 where reportid = v_reportid;
    if v_status = 0 then
      update t_qx set status = 1 where qxid = i_id;
    end if;
    if v_status = 1 then
      update t_qx set status = 0 where qxid = i_id;
    end if;
  
    -- end if;
  
    --删除该权限
    --delete from t_qx where qxid = i_id;
    commit;
    o_result := 1;
    return;
  exception
    when others then
      rollback;
      o_result := 0;
      return;
  end delqx;

  procedure readqx
  /*******************************************************************
    procedure name:readqx
    prupose :查询某条权限
    comment:建立日期20071218
    author:wangcheng
    ********************************************************************/
  (i_adminid   in varchar2, --管理员id
   i_qxid      in number, --权限id
   o_result    out number, --0：无权限操作，1：有权限
   o_outcursor out t_cursor --返回记录
   ) is
    v_sql long;
    v_qx  number;
  begin
    --约定该报表的权限代码为102
    v_qx := 102;
    --判断用户是否有权限查看
    if p_admin.fq_isqx(i_adminid => i_adminid, i_qxid => v_qx) = 0 then
      o_result := 0;
      return;
    end if;
    v_sql := 'select * from t_qx where qxid=' || to_char(i_qxid);
  
    open o_outcursor for v_sql;
    o_result := 1;
  end readqx;

  procedure reportqx
  /*******************************************************************
    procedure name:reportqx
    prupose :判断该用户是否有定制报表的权限
    comment:建立日期20071218
    author:wangcheng
    ********************************************************************/
  (i_adminid in varchar2, --管理员id
   o_result  out number --0：无权限操作，1：有权限
   ) is
    v_qx number;
  begin
    --约定该报表的权限代码为1007
    v_qx := 102;
    --判断用户是否有权限查看
    if p_admin.fq_isqx(i_adminid => i_adminid, i_qxid => v_qx) = 0 then
      o_result := 0;
      return;
    end if;
    o_result := 1;
  end reportqx;

  procedure eportinfor
  /*******************************************************************
    procedure name:eportinfor
    prupose :查询报表
    comment:建立日期20071218
    author:wangcheng
    ********************************************************************/
  (i_id        in number, --报表id
   o_outcursor out t_cursor --返回记录
   ) is
    v_sql long;
  begin
  
    --返回记录集
    v_sql := 'select * from t_report where reportid=' || to_char(i_id);
  
    open o_outcursor for v_sql;
    return;
  exception
    when others then
      return;
  end eportinfor;

  procedure viewrconfigeport
  /*******************************************************************
    procedure name:viewrconfigeport
    prupose :在添加定制报表的时候，预览报表，
            验证sql语句的正确性，返回空记录集
    comment:建立日期20071218
    author:wangcheng
    ********************************************************************/
  (i_sql       in long, --查询报表的sql
   o_result    out number, --返回结果 0：sql包含关键字  1：不包含
   o_outcursor out t_cursor --返回记录
   ) is
    v_sql long;
  
  begin
    --初始化
    v_sql := i_sql;
    --判断sql语句中是否有不合法的关键字
    if freport_checksql(i_sql => v_sql) > 0 then
      o_result := 0;
      return;
    end if;
    --查询
  
    v_sql := 'select a.*, rownum rn
                  from  (' || v_sql || ') a
                  where  1=2 ';
    open o_outcursor for v_sql;
    o_result := 1;
  end viewrconfigeport;

  function freport_checksql
  /*****************************************************************
    过程名称：freport_checksql
    创建日期：20071228
    功能说明：检查报表的sql语句是否包含非法的关键字
    输入：sql语句
    返回：0：不包含  1：包含
    ****************************************************************/
  (i_sql in long) return number is
    v_sql long;
  begin
    if i_sql is null then
      return 1;
    end if;
    v_sql := upper(i_sql);
    if instr(v_sql, 'insert') > 0 then
      return 1;
    end if;
    if instr(v_sql, 'update') > 0 then
      return 1;
    end if;
    if instr(v_sql, 'delete') > 0 then
      return 1;
    end if;
  
    return 0;
  exception
    when others then
      return 1;
  end freport_checksql;

  function monthactcount
  /*****************************************************************
    过程名称：monthactcount
    创建日期：20110301
    功能说明：获取当月活跃数
    输入：sql语句
    返回：0：不包含  1：包含
    ****************************************************************/
  (in_time in varchar2, in_placeid in varchar2) return number is
    v_sql   long;
    r_value number;
  begin
    r_value := 0;
    if in_placeid is null then
      return 0;
    end if;
    v_sql := 'select  sum(actnum)    from  ts_report_placeid_active  where placeid=' ||
             in_placeid || ' and itime<=to_date(''' || in_time ||
             ''',''yyyy-mm-dd'') and itime>to_date(''' || in_time ||
             ''',''yyyy-mm-dd'')-30';
  
    execute immediate v_sql
      into r_value;
  
    return r_value;
  exception
    when others then
      return 0;
  end monthactcount;

  function monthactrate
  /*****************************************************************
    过程名称：monthactcount
    创建日期：20110301
    功能说明：获取当月活跃率
    输入：sql语句
    返回：0：不包含  1：包含
    ****************************************************************/
  (in_time in varchar2, in_placeid in varchar2) return number is
    v_sql   long;
    r_value number;
  begin
    r_value := 0;
    if in_placeid is null then
      return 0;
    end if;
    v_sql := 'select  round(sum(actnum)/sum(regnum)*100,2)   from  ts_report_placeid_active  where placeid=' ||
             in_placeid || ' and itime<=to_date(''' || in_time ||
             ''',''yyyy-mm-dd'') and itime>to_date(''' || in_time ||
             ''',''yyyy-mm-dd'')-30';
  
    execute immediate v_sql
      into r_value;
  
    return r_value;
  exception
    when others then
      return 0;
  end monthactrate;

end report_package;
/


create package P_APP_Version is

  /* APP 版本信息  */

  TYPE T_CURSOR IS REF CURSOR;

  procedure PQ_Version
  /*****************************************************************
        Procedure Name :PQ_Version
        Purpose: 版本校验
        Edit: 2018-09-14 add by 小沈
    ****************************************************************/
  (I_Phone_Type     In Varchar2, --手机类型 1：苹果 2：安卓
   I_App_Version_ID In Number, --趣识货app版本号id
   I_App_Version    In Varchar2, --趣识货app版本号
   I_Deviceid       In Varchar2, --手机设备号
   O_Outcursor      Out T_CURSOR,
   O_Result         Out Number, --判断 0：查询成功，其他：出错  1000:直接退出APP
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  procedure PQ_DownUrl
  /*****************************************************************
        Procedure Name :PQ_DownUrl
        Purpose: 获取最新版本下载地址
        Edit: 2018-09-14 add by 小沈
    ****************************************************************/
  (I_Phone_Type In Varchar2, --手机类型 1：苹果 2：安卓 
   O_Outcursor  Out T_CURSOR,
   O_Result     Out Number, --判断 0：查询成功，其他：出错  1000:直接退出APP
   O_Message    Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

end P_APP_Version;


/


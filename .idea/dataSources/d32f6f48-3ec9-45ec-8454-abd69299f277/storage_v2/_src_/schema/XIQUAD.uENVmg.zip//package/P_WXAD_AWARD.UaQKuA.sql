create package P_WXAD_Award is

  TYPE T_CURSOR IS REF CURSOR;

  /*微信广告奖励主入口*/

  procedure Job_Wait;
  /***************************************************************
    procedure name :Job_Wait
   purpose：
        对在待奖区的用户进行奖励
    edit: 2017-10-23 add by 小沈
  ****************************************************************/

end P_WXAD_Award;


/


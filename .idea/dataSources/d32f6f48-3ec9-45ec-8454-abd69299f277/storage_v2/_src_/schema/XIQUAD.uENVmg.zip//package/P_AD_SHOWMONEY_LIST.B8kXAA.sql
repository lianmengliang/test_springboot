create PACKAGE P_AD_ShowMoney_List AS

   /*判断 用户还可获得奖励金额--广告列表使用 使用表缓存 */

  Function FQ_Userid
  /*****************************************************************
        Procedure Name :FQ_Userid
        Purpose:  根据闲玩用户 判断用户还可获得奖励金额
        Edit: 2018-11-17 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_ADStatus In Number, --广告投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放）
   I_Deviceid In Varchar2, --设备号ID
   I_Userid   In Number, --闲玩用户编号
   I_PType    In Number --1、ios  2、安卓
   ) Return varchar2;


end P_AD_ShowMoney_List;


/


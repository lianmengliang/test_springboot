create package body P_APP_Version is

  /* APP 版本信息  */

  procedure PQ_Version
  /*****************************************************************
        Procedure Name :PQ_Version
        Purpose: 版本校验
        Edit: 2018-09-14 add by 小沈
    ****************************************************************/
  (I_Phone_Type     In Varchar2, --手机类型 1：苹果 2：安卓
   I_App_Version_ID In Number, --闲玩盒子app版本号id
   I_App_Version    In Varchar2, --趣识货app版本号
   I_Deviceid       In Varchar2, --手机设备号
   O_Outcursor      Out T_CURSOR,
   O_Result         Out Number, --判断 0：查询成功，其他：出错  1000:直接退出APP
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) IS
    v_n           number;
    v_version_id  number;
    v_version     varchar2(20);
    v_intro       varchar2(500);
    v_url         varchar2(200);
    v_UpVersion   number(1); --更新状态（0无需更新，1有更新不强制，2强制更新）
    v_packageSize varchar2(50); --包大小（字节）
  begin
    o_result  := 0;
    o_message := '成功';
    open O_Outcursor for
      select 1 from dual where 1 = 2;
  
    --获取最新版本
    select version_id, version, intro, url, package_size
      into v_version_id, v_version, v_intro, v_url, v_packageSize
      from (select version_id, version, intro, url, package_size
              from app_version
             where status = 1
               and phone_type = I_Phone_Type
             order by version_id desc)
     where rownum = 1;
  
    --如果是最新版本，直接返回不用更新
    if v_version_id = I_App_Version_ID then
      v_UpVersion := 0;
    else
      --判断当前用户版本是否存在
      select count(1)
        into v_n
        from app_version
       where version_id = I_App_Version_ID
         and phone_type = I_Phone_Type;
      if v_n = 0 then
        --否：强制更新
        v_UpVersion := 2;
      else
        --获取用户当前版本更新状态
      
        select up_version
          into v_UpVersion
          from app_version
         where version_id = I_App_Version_ID
           and phone_type = I_Phone_Type;
      end if;
    end if;
  
    open o_outcursor for
      select v_version_id  as v_version_id,
             v_version     as version,
             v_intro       as note,
             v_url         as url,
             v_UpVersion   as UpVersion,
             v_packageSize as packagesize
        from dual;
  
  exception
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '查询失败';
      return;
  End PQ_Version;

  procedure PQ_DownUrl
  /*****************************************************************
        Procedure Name :PQ_DownUrl
        Purpose: 获取最新版本下载地址
        Edit: 2018-09-14 add by 小沈
    ****************************************************************/
  (I_Phone_Type In Varchar2, --手机类型 1：苹果 2：安卓 
   O_Outcursor  Out T_CURSOR,
   O_Result     Out Number, --判断 0：查询成功，其他：出错  1000:直接退出APP
   O_Message    Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) IS 
  
  begin
    o_result  := 0;
    o_message := '成功';
    open O_Outcursor for
      select 1 from dual where 1 = 2;
  
    open o_outcursor for
      select version_id, version, intro, url, package_size
        from (select version_id, version, intro, url, package_size
                from app_version
               where status = 1
                 and phone_type = I_Phone_Type
               order by version_id desc)
       where rownum = 1;
  
  exception
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '查询失败';
      return;
  End PQ_DownUrl;

end P_APP_Version;
/


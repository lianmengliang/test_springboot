create package P_AD_Windows_Older is

  TYPE T_CURSOR IS REF CURSOR;

  /*windows 服务 老用户激活 信息获取与处理 */

  Procedure Job_CheckOldUser;
  /*****************************************************************
      Procedure Name :Job_CheckOldUser
      Purpose: 校验当天下载是否为老用户体验
       Edit: 2019-01-24 add by 小沈
  ****************************************************************/
  
    Procedure Job_Auto;
  /*****************************************************************
      Procedure Name :Job_Auto
      Purpose: 自动添加激活老用户人数
       Edit: 2019-02-01 add by 小沈
  ****************************************************************/

  Procedure Job_EntryUser;
  /*****************************************************************
      Procedure Name :Job_EntryUser
      Purpose: 录入需要新增的老用户名单
       Edit: 2019-01-20 add by 小沈
  ****************************************************************/

  procedure PQ_UserList
  /*****************************************************************
        Procedure Name :PQ_UserList
        Purpose: 获取老用户列表
        Edit: 2019-01-20 add by 小沈
    ****************************************************************/
  (I_Sign      In Number, --标记符号 1，2，3……
   I_PageSize  In Number, --每页记录数
   I_PageNO    In Number, --当前页码,从 1 开始
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure PW_UPOlderUser
  /*****************************************************************
        Procedure Name :PW_UPOlderUser
        Purpose: 修改需要激活老用户状态
        Edit: 2019-01-20 add by 小沈
    ****************************************************************/
  (I_ID     In Number, --处理ID 
   I_ADID   In Number, --广告ID
   I_Status In Number, --状态 2：闲玩数据库自动激活 3：闲玩激活失败 4：商家激活失败 9正在处理中
   I_Msg    In Varchar2, --商家返回消息
   O_Result Out Number --返回状态
   );

  procedure PW_AddUserBind
  /*****************************************************************
        Procedure Name :PW_UPOlderUser
        Purpose: 添加用户绑定记录
        Edit: 2019-01-21 add by 小沈
    ****************************************************************/
  (I_ID       In Number, --处理ID 
   I_ADID     In Number, --广告ID
   I_Userid   In Number, --闲玩用户ID
   I_Deviceid In Varchar2, --被激活设备号ID
   O_Result   Out Number, --返回状态 
   O_Message  Out Varchar2 --返回信息
   );

  procedure PW_Activate_OldUser
  /*****************************************************************
        Procedure Name :PW_Activate_OldUser
        Purpose: 广告接口_激活老用户
        Edit: 2019-01-20 add by 小沈
    ****************************************************************/
  (I_ID       In Number, --处理ID 
   I_ADID     In Number, --广告ID
   I_Fid      In Varchar2, --本期广告主统计的来源id[apk渠道编号] 
   I_UrlId    In Number, --广告下载编号
   I_LastAdid In Number, --上一期广告ID
   I_LastFid  In Varchar2, --上一期广告主渠道编号 
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_SIMID    In Varchar2, --sim卡编号
   I_Userid   In Number, --闲玩用户编号
   I_APPSign  In Varchar2, --渠道应用标识符号、渠道用户id 
   I_PType    In Number, --1、ios  2、安卓
   I_IP       In Varchar2, --
   O_Result   Out Number,
   O_Message  Out Varchar2);

  Procedure Job_CheckUserReg;
  /*****************************************************************
      Procedure Name :Job_CheckUserReg
      Purpose: 之前商家注册信息查询失败的用户，进行二次校验检查是否注册已完成
       Edit: 2019-01-26 add by 小沈
  ****************************************************************/

  Procedure Job_UserMoney;
  /*****************************************************************
      Procedure Name :Job_UserMoney
      Purpose: 获取已经激活的用户，跑出了多少奖励，和用户领取奖励
       Edit: 2019-01-26 add by 小沈
  ****************************************************************/
  Procedure Job_UpdateRunOlderSet;
  /*****************************************************************
        Procedure Name :Job_UpdateRunOlderSet
        Purpose: 更新跑老用户设置表
         Edit: 2019-01-26 add by 小胡
    ****************************************************************/
end P_AD_Windows_Older;
/


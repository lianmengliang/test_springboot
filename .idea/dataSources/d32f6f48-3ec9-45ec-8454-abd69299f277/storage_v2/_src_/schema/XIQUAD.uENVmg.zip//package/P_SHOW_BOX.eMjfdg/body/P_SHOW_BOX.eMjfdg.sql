create PACKAGE BODY P_Show_Box AS

  /* 闲玩盒子 */

  procedure FQ_IsShow
  /*****************************************************************
        Procedure Name :FQ_IsShow
        Purpose: 判断是否显示 0 不显示 1 显示
        Edit: 2018-09-27 add by 小沈
    ****************************************************************/
  (I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_Userid   In Number, --闲玩用户编号
   I_PType    In Number, --1、ios  2、安卓 
   I_IP       In Varchar2, --用户当前IP
   I_IP_Num   In Number, --用户当前IP 数字化
   O_IsShow   Out Number, --是否显示闲玩盒子  0 不显示 1 显示 
   O_Result   Out Number, --判断 0：查询成功，其他：出错
   O_Message  Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
  
    v_n             number;
    v_ip_short      varchar2(20); --短IP
    v_province_user varchar2(100); -- 用户所在省份
    v_city_user     varchar2(100); -- 用户所在城市
  
  begin
  
    O_IsShow  := 0;
    O_Result  := 0;
    O_Message := '查询成功';
  
    if I_Userid is null or I_Userid = 0 then
      O_IsShow := 0; --不显示
      return;
    end if;
  
    if I_PType not in (1, 2) then
      O_IsShow := 0; --不显示
      return;
    end if;
  
    --渠道如果不存在或已下架则不显示
    select count(1)
      into v_n
      from ad_channel
     where appid = appid
       and status in (0, 1);
  
    if v_n <= 0 then
      O_IsShow := 0; --不显示
      return;
    end if;
  
    --渠道是否显示闲玩盒子
    select count(1)
      into v_n
      from ad_channel_box
     where appid = I_APPId
       and is_show = 0;
    if v_n > 0 then 
      O_IsShow := 0; --不显示
      return;
    end if;
  
    ---IP限制体验 
  
    v_ip_short := fq_ip_cutout(I_IP);
  
    --渠道限制下载闲玩盒子
    select count(1) into v_n from limit_box where appid = I_APPId;
    if v_n > 0 then
    
      --获取用户ID 所在城市 与省份 
      select province, city
        into v_province_user, v_city_user
        from ip_library
       where ip_start_short = v_ip_short
         and ip_start_num <= I_IP_Num
         and I_IP_Num <= ip_end_num;
    
      --判断用户所在的城市是否为限制城市
      select count(1)
        into v_n
        from limit_box
       where appid = I_APPId
         and (instr(province, v_province_user) > 0 or
             instr(city, v_city_user) > 0);
      if v_n > 0 then
        O_IsShow := 0;
        return;
      end if;
    
    end if;
  
    O_IsShow := 1; --显示
    return;
  exception
    --失败
    when others then
      O_IsShow  := 0;
      O_Result  := 0;
      O_Message := '查询异常！';
      --v_msg := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm; 
      return;
  end FQ_IsShow;

end P_Show_Box;
/


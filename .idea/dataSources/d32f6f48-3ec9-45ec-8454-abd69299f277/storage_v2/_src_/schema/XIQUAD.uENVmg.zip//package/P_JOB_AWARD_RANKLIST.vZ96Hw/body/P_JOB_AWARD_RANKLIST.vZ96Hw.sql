create package body P_JOB_AWARD_RANKLIST is

  /*****************************************************************
   Procedure Name :P_JOB_AWARD_DAILYLIST
   Purpose: 每5分钟更新一次日榜榜单。
            在每天凌晨0点05分之后需要最后结算一次昨天的统计数据，才是最准的日榜
   Edit: 2019/7/1 20:18:35 add by 旭东
   Edit 2019/8/23 10:19:35 revise by 文浩
  ****************************************************************/
  procedure P_JOB_DAILYLIST_TASK(I_TASKTYPE NUMBER --任务类型 0：统计今天的   1：统计昨天的
                                 ) is
  
    v_n number := 0;
    --榜单类型 日榜
    v_ranktype number := 0;
    --榜单统计多少名以内的
    v_count number := 100;
    --榜单统计的日期（当天日期）
    v_date_start date := trunc(sysdate - I_TASKTYPE);
  
    v_date_end date := trunc(sysdate + 1 - I_TASKTYPE);
    --排名
    v_ranking number := 1;
    --奖励金额
    v_awardmoney number := 0;
  
     --当前多少名以内的榜单列表
    cursor v_ranklist is
      select *
        from (
             --限制广告根据金额
             /*select appid, appsign, userid, sum(money) as trail_money
                from ad_app_flux
               where itime >= v_date_start
                 and itime < v_date_end
                 and adid in(
                       select distinct regexp_substr(LIMIT_ADIDS, '[^,]+', 1, level) as limit_adids
                       from ad_activity_config
                       where actcode = 'actDailyRank' 
                       connect by regexp_substr(LIMIT_ADIDS, '[^,]+', 1, level) is not null)
               group by appid, appsign, userid
               order by 4 desc*/
               
               --根据领奖次数
               select appid, appsign, userid, count(1) as trail_money
                from ad_app_flux
                where itime >= v_date_start
                and itime < v_date_end
               group by appid, appsign, userid
               order by 4 desc
               )
       where rownum <= v_count;
  
  begin
    --循环多少名以内的榜单列表
    select nvl(count(1), 0)
     into v_n from ad_activity_config where actid = 1002 and to_date('2019-09-12','yyyy-MM-dd') <= trunc(sysdate - I_TASKTYPE)  and to_date('2019-09-21','yyyy-MM-dd') >= trunc(sysdate - I_TASKTYPE);
    if v_n <= 0 then
       return;
    end if;
    for c_rank in v_ranklist loop
      begin
        --查询日期下的排名是否已经存在，存在则更新
        select nvl(count(1), 0)
          into v_n
          from ad_award_ranklist
         where RANK_DATE = to_number(to_char(v_date_start, 'yyyymmdd'))
           and ranking = v_ranking;
        --判断用户多少名，设置多少奖励金额
        if v_ranking = 1 then
          v_awardmoney := 150;
        end if;
        if v_ranking = 2 then
          v_awardmoney := 75;
        end if;
        if v_ranking = 3 then
          v_awardmoney := 35;
        end if;
        if v_ranking >= 4 and v_ranking <= 10 then
          v_awardmoney := 15;
        end if;
        if v_ranking >= 11 and v_ranking <= 50 then
          v_awardmoney := 5;
        end if;
        if v_ranking >= 51 and v_ranking <= 100 then
          v_awardmoney := 2;
        end if;
        if v_ranking < 1 or v_ranking > 100 then
          v_awardmoney := 0;
        end if;
        
        --只为了测试才打开
        --v_awardmoney:=0.1;
      
        if v_n > 0 then
          --榜单已经存在该用户，则更新排名的用户信息
          update ad_award_ranklist
             set appid       = c_rank.appid,
                 appsign     = c_rank.appsign,
                 userid      = c_rank.userid,
                 ranktype    = v_ranktype,
                 trail_money = c_rank.trail_money,
                 AWARD_MONeY = v_awardmoney,
                 lasttime    = sysdate
           where RANK_DATE = to_number(to_char(v_date_start, 'yyyymmdd'))
             and ranking = v_ranking;
        
        else
          --榜单不存在该用户，则插入该用户  
          insert into ad_award_ranklist
            (id,
             appid,
             appsign,
             userid,
             ranktype,
             ranking,
             rank_date,
             trail_money,
             award_money)
          values
            (SQ_AD_AWARDRANKLIST.NEXTVAL,
             c_rank.appid,
             c_rank.appsign,
             c_rank.userid,
             v_ranktype,
             v_ranking,
             to_number(to_char(v_date_start, 'yyyymmdd')),
             c_rank.trail_money,
             v_awardmoney);
        
        end if;
      
        v_ranking := v_ranking + 1;
      
      end;
    
    end loop;
    commit;
    return;
  exception
    when others then
      rollback;
    
      return;
    
  end P_JOB_DAILYLIST_TASK;

  /*****************************************************************
   Procedure Name :P_JOB_SETTLE_DAILLYLIST_TASK
   Purpose: 每天10点直接修改为可领奖状态
   Edit: 2019/7/1 20:18:35 add by 旭东
   Edit 2019/8/23 10:19:35 revise by 文浩
  ****************************************************************/
  procedure P_JOB_SETTLE_DAILLYLIST_TASK is
    v_n       number := 0;
    v_result  number := 0;
    v_message varchar2(500) := '';
    --榜单类型 日榜
    v_ranktype number := 0;
    --榜单统计多少名以内的
    v_count number := 100;
    --今日结算昨日的日榜
    v_date date := trunc(sysdate - 1);
    --要结算的昨日的榜单
    cursor v_ranklist is
      select id,
             appid,
             appsign,
             userid,
             ranking,
             rank_date,
             trail_money,
             award_money
        from ad_award_ranklist
       where RANK_DATE = to_number(to_char(v_date, 'yyyymmdd'))
         and ranktype = v_ranktype
         and award_status = -1;
    --当前渠道的类型，有积分还是无积分
    v_integral number := 1;
    --用户当前设备号
    v_deviceid varchar2(100) := '';
    --手机类型
    v_ptype number := 2;
  
  begin
    --结算状态  0 待结算  1待确认(已结算，不能提现)    2确认正常（可以提现）  3结算异常 
  
    select nvl(count(1), 0)
      into v_n
      from ad_award_ranklist
     where RANK_DATE = to_number(to_char(v_date, 'yyyymmdd'))
       and ranktype = v_ranktype
       and award_status = -1;
  
    --查询昨日未结算的排名如果不等于 v_count  则全部认为异常
    if v_n != v_count then
      --要结算的条数与预期不符合，直接异常标志
      update ad_award_ranklist
         set award_status = 3,
             NOTE          = '榜单个数异常,请联系客服',
             settle_time   = sysdate
      
       where RANK_DATE = to_number(to_char(v_date, 'yyyymmdd'))
         and ranktype = v_ranktype
         and award_status = 0;
      commit;
      return;
    end if;
    --循环结算的榜单并且进行用户信息同步到主库（DBLIKN）
    for c_rank in v_ranklist loop
      begin
        --查询渠道
        select integral
          into v_integral
          from ad_channel
         where appid = c_rank.appid;
      
        if v_integral is null then
          --更新该条记录为异常
          update ad_award_ranklist
             set award_status = 3,
                 NOTE          = '渠道异常,请联系客服',
                 settle_time   = sysdate
           where id = c_rank.id;
          goto CONTINUE_LOOP;
        end if;
        --查询用户手机类型
        select deviceid, PTYPE
          into v_deviceid, v_ptype
          from ad_app_users
         where userid = c_rank.userid;
        if v_deviceid is null or v_ptype is null then
          --更新该条记录为异常
          update ad_award_ranklist
             set award_status = 3,
                 NOTE          = '设备号异常,请联系客服',
                 settle_time   = sysdate
           where id = c_rank.id;
          goto CONTINUE_LOOP;
        end if;
 
        update ad_award_ranklist
           set award_status = 0,
               NOTE          = '结算正常,可领取',
               settle_time   = sysdate
         where id = c_rank.id;
      
        <<CONTINUE_LOOP>>
        commit;
      exception
        when others then
          rollback;
          --更新结算标志为失败
          update ad_award_ranklist
             set award_status = 3,
                 NOTE          = '结算异常,请联系客服',
                 settle_time   = sysdate
           where id = c_rank.id;
        
          commit;
      end;
    
    end loop;
  
  end P_JOB_SETTLE_DAILLYLIST_TASK;

  /*****************************************************************
   Procedure Name :P_JOB_HANDLE_SETTLE__TASK
   Purpose: 每天10点执行，将已经结算的榜单并且是用户状态待审核的奖励信息审核将该奖励改为可让用户提现，并给盒子主库用户加钱和流水
   Edit: 2019/7/1 20:18:35 add by 旭东
  ****************************************************************/
  procedure P_JOB_HANDLE_SETTLE__TASK is
    v_n       number := 0;
    v_result  number := -1;
    v_message varchar2(500) := '';
    --榜单类型 日榜
    v_ranktype number := 0;
  
    --今日审核昨日的日榜
    v_date date := trunc(sysdate - 1);
    --要审核的昨日的榜单
    cursor v_ranklist is
      select id,
             appid,
             appsign,
             userid,
             ranking,
             rank_date,
             trail_money,
             award_money
        from ad_award_ranklist
       where RANK_DATE = to_number(to_char(v_date, 'yyyymmdd'))
         and ranktype = v_ranktype
         and settle_status = 1
         and award_status = -1;
    --当前渠道的类型，有积分还是无积分
    v_integral number := 1;
    --用户当前设备号
    v_deviceid varchar2(100) := '';
    --手机类型
    v_ptype number := 2;
    --昨日用户奖励总额
    v_sum_flux number := 0;
  
  begin
    --结算状态  0 待结算  1待确认(已结算，不能提现)    2确认正常（可以提现）  3结算异常 
  
    --并新增用户金额和流水
    for c_rank in v_ranklist loop
      begin
        --查询渠道
        select integral
          into v_integral
          from ad_channel
         where appid = c_rank.appid;
      
        if v_integral is null then
          --更新该条记录为异常
          update ad_award_ranklist
             set SETTLE_STATUS = 3,
                 NOTE          = '渠道异常,请联系客服',
                 settle_time   = sysdate
           where id = c_rank.id;
          goto CONTINUE_LOOP;
        end if;
        --查询用户手机类型
        select deviceid, PTYPE
          into v_deviceid, v_ptype
          from ad_app_users
         where userid = c_rank.userid;
        if v_deviceid is null or v_ptype is null then
          --更新该条记录为异常
          update ad_award_ranklist
             set SETTLE_STATUS = 3,
                 NOTE          = '设备号异常,请联系客服',
                 settle_time   = sysdate
           where id = c_rank.id;
          goto CONTINUE_LOOP;
        end if;
        --比较昨日ad_app_flux的金额与结算的金额是否一致
        select nvl(sum(money), 0)
          into v_sum_flux
          from ad_app_flux
         where appid = c_rank.appid
           and userid = c_rank.userid
           and itime >= trunc(v_date)
           and itime < trunc(sysdate);
      
        if c_rank.trail_money != v_sum_flux then
          update ad_award_ranklist
             set SETTLE_STATUS = 3,
                 NOTE          = '审核不通过,请联系客服',
                 settle_time   = sysdate
           where id = c_rank.id;
          goto CONTINUE_LOOP;
        end if;
      
        --这个是同步信息加发送奖励到盒子
      
       xiquad_box.p_ad_award.pw_reward(i_userid   => c_rank.userid,
                                        i_money    => c_rank.award_money,
                                        i_type     => 1,
                                        i_remark   => c_rank.rank_date ||
                                                      '日榜活动第' ||
                                                      c_rank.ranking ||
                                                      '名奖励',
                                        i_deviceid => v_deviceid,
                                        i_appid    => c_rank.appid,
                                        i_appsign  => c_rank.appsign,
                                        I_Internal => v_integral,
                                        I_Ptype    => v_ptype,
                                        I_Owner    => 1,
                                        o_result   => v_result,
                                        o_message  => v_message);
      
        --判断状态   
        if v_result = 0 then
          --领取成功
          --更新用户结算标志为结算成功，领奖状态为待奖励（能提现）
          update ad_award_ranklist
             set SETTLE_STATUS = 2,
                 award_status  = 0, --奖励状态改成可提现
                 --NOTE          = 'trail_money:'||c_rank.trail_money||'v_sum_flux:'||v_sum_flux|| '审核通过,可以提现',
                 NOTE        = '审核通过,可以提现',
                 settle_time = sysdate
           where id = c_rank.id;
        else
          --领取失败  
          update ad_award_ranklist
             set SETTLE_STATUS = 3,
                 NOTE          = '审核异常,请联系客服' || v_message,
                 settle_time   = sysdate
           where id = c_rank.id;
        
        end if;
      
        <<CONTINUE_LOOP>>
        commit;
      exception
        when others then
          rollback;
        
          update ad_award_ranklist
             set SETTLE_STATUS = 3,
                 NOTE          = '审核异常,请联系客服',
                 settle_time   = sysdate
           where id = c_rank.id;
        
          commit;
      end;
    
    end loop;
  
  end P_JOB_HANDLE_SETTLE__TASK;

  /*****************************************************************
   Procedure Name :P_JOB_HANDLE_DRAW_TASK
   Purpose: 每小时执行一次将七天内的提现状态是已申请处理中的奖励状态去盒子主库查询最终的发奖状态，并更新回来
   Edit: 2019/7/1 20:18:35 add by 旭东
  ****************************************************************/
  procedure P_JOB_HANDLE_DRAW_TASK is
    v_n       number := 0;
    v_result  number := -1;
    v_message varchar2(500) := '';
  
    --榜单类型 日榜
    v_ranktype number := 0;
  
    --起始日期
    v_start_date date := trunc(sysdate - 7);
    --结束日期
    v_end_date date := trunc(sysdate);
  
    --要审核的昨日的榜单
    cursor v_ranklist is
      select id,
             appid,
             appsign,
             userid,
             ranking,
             rank_date,
             trail_money,
             award_money,
             xw_order_id
        from ad_award_ranklist
       where RANK_DATE >= to_number(to_char(v_start_date, 'yyyymmdd'))
         and rank_date <= to_number(to_char(v_end_date, 'yyyymmdd'))
         and ranktype = v_ranktype
         and settle_status = 2
         and award_status = 1;
  
    --当前盒子主库提现订单状态
    v_box_draw_status number := 0;
    --盒子主库提现到的账号
    v_box_draw_account varchar2(100) := '';
  begin
    --结算状态  0 待结算  1待确认(已结算，不能提现)    2确认正常（可以提现）  3结算异常 
  
    --并新增用户金额和流水
    for c_rank in v_ranklist loop
      begin
        --查询盒子状态
        select status, account
          into v_box_draw_status, v_box_draw_account
          from xiquad_box.t_withdraw_wait
         where userid = c_rank.userid
           and xw_order_id = c_rank.xw_order_id;
        if v_box_draw_status is null then
          goto CONTINUE_LOOP;
        end if;
        --盒子提现成功状态
        if v_box_draw_status = 3 then
          update ad_award_ranklist
             set award_status = 2,
                 note         = '已打款至支付宝,' || v_box_draw_account
           where userid = c_rank.userid
             and xw_order_id = c_rank.xw_order_id;
        end if;
      
        --盒子提现失败状态
      
        if v_box_draw_status = 9 then
            update ad_award_ranklist
             set award_status = 3,
                 note         = '提现失败请确认账号,' || v_box_draw_account
           where userid = c_rank.userid
             and xw_order_id = c_rank.xw_order_id;
        end if;
      
        <<CONTINUE_LOOP>>
        commit;
      exception
        when others then
          rollback;
        
          update ad_award_ranklist
             set SETTLE_STATUS = 3,
                 NOTE          = '审核异常,请联系客服',
                 settle_time   = sysdate
           where id = c_rank.id;
        
          commit;
      end;
    
    end loop;
  
  end P_JOB_HANDLE_DRAW_TASK;

end P_JOB_AWARD_RANKLIST;
/


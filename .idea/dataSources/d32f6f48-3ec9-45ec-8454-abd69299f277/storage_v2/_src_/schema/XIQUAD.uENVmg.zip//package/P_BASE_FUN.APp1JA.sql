create package P_Base_Fun is

  TYPE T_CURSOR IS REF CURSOR;

  /*基础方法 集合*/

  Function FQ_StrRound
  /**保留2位小数*/
  (i_num IN number --数字
   ) return varchar2;

  Function FQ_StrRound
  /*****************************************************************
    过程名称：FQ_StrRound
    创建日期：2017-03-02
    功能说明：保留2位小数
    ****************************************************************/
  (i_num  IN number, --数字
   i_type in number --1显示位数，如1.00元或者2.30元 ；2不显示位数，如1元，2.3元，
   ) return varchar2;

  Function FQ_Deviceid_Check
  /*****************************************************************
        Procedure Name :FQ_Deviceid_Check
        Purpose: 设备号校验是否合法 0否 1是
        Edit: 2017-07-12 add by 小沈
    ****************************************************************/
  (I_DeviceId In Varchar2, --设备号
   I_PType    In Varchar2 --1.iphone，2.android
   ) Return Number;

  function FQ_Str_Round
  /*****************************************************************
        Procedure Name :FQ_Str_Round
        Purpose: 金额千分位
        Edit: 2017-07-12 add by 小沈
    ****************************************************************/
  (I_Num In Number --数字
   ) return varchar2;

  Function FQ_PhoneNum
  /*****************************************************************
        Procedure Name :FQ_PhoneNum
        Purpose: 是否为手机号码 0否 ；1是
        Edit: 2017-07-12 add by 小沈
    ****************************************************************/
  (I_PhoneNum In Varchar2) Return Number;

  Function FQ_Random_Str
  /*****************************************************************
        Procedure Name :FQ_Random_Str
        Purpose: 生成指定长度随机数
        Edit: 2017-07-12 add by 小沈
    ****************************************************************/
  (I_len In Number --长度
   ) return Varchar2;

  function FQ_Str_Unit_Old
  /*****************************************************************
        Procedure Name :fq_str_Unit
        Purpose: 转化以万为单位的金额
        Edit: 2007-10-07 add by  小沈
    ****************************************************************/
  (I_Money In Varchar2 --数字
   ) return varchar2;

  function FQ_Str_Unit
  /*****************************************************************
        Procedure Name :fq_str_Unit
        Purpose: 转化以万为单位的金额
        Edit: 2007-12-10 add by  小沈
    ****************************************************************/
  (I_Money In Varchar2 --数字
   ) return varchar2;

  function FQ_Is_Number
  /*****************************************************************
        Procedure Name :FQ_Is_Number
        Purpose: 是否为数字 0:否 1：是
        Edit: 2007-10-07 add by  小沈
    ****************************************************************/
  (I_Str Varchar2) return Number;

  function FQ_MonetaryUnit
  /*****************************************************************
    过程名称：显示货币单位
    创建日期：2018-03-21 add by 小沈
    返回：
    ****************************************************************/
  (I_Money In Number, --传入金额
   I_Type  In Number --显示类型 0 :普通显示小数位2位补0 1：已万亿单位显示  2:没有小数点
   ) return varchar2;

  function FQ_MonetaryUnit
  /*****************************************************************
    过程名称：显示货币单位
    创建日期：2018-03-21 add by 小沈
    返回：
    ****************************************************************/
  (I_Money In Number, --传入金额
   I_Type  In Number, --显示类型 0 :普通显示小数位2位补0 1：已万亿单位显示  2:没有小数点
   I_From  In Number --1:列表 2：详情
   ) return varchar2;

end P_Base_Fun;


/


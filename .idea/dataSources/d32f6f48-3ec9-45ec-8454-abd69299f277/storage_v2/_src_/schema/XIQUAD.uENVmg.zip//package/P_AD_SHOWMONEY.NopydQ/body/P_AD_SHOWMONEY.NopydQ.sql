create PACKAGE BODY P_AD_ShowMoney AS

  /*判断 设备号还可获得奖励金额 */

  Function FQ_Deviceid
  /*****************************************************************
        Procedure Name :FQ_Deviceid
        Purpose:  根据设备号 判断用户还可获得奖励金额
        Edit: 2017-02-16 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_ADStatus In Number, --广告状态  0 正常 1、广告尚未投放 2、日流量到量 3、总流量到量 4、已停止投放
   I_Deviceid In Varchar2, --设备号ID
   I_PType    In Number --1、ios  2、安卓
   ) Return varchar2 As
    -- 0_金额 【0 表示未绑定 1表示用户已绑定但是无追加奖励 2表示为用户已绑定并有追加奖励  3表示为用户仅绑定】
    v_bind      number; --绑定数
    v_n         number;
    v_msg       varchar2(500); ---返回信息
    v_money     Number; --奖励总金额 
    v_AMoney    number; --还可以获得奖励金额
    v_AllMoney  number; --还可以获取总 
    v_Awarding  number; --是否有奖励正在进行中
    v_MaxDlevel number; --99 同组最大奖励
    v_unit      varchar2(50); --货币单位描述 默认元 
    v_rate      number; --货币与人名币比率 1：1 
    v_random    number; --随机 
    cursor myCur is
    
      select dlevel, times, amoney, atype, needlevel, awardgroup
        from ad_awardset
       where adid = I_ADID
         and appid = I_APPId
         and atype != 3
         and isshow = 1
       order by dlevel asc;
  
  begin
    v_AMoney   := 0;
    v_AllMoney := 0;
    v_Awarding := 0;
    select money into v_money from ad_adinfo where adid = i_adid;
  
    if I_ADStatus in (0, 4) then
      v_msg := '0_' || v_money;
      return v_msg;
    end if;
  
    --判断奖励是否已设置
    select count(1)
      into v_n
      from ad_awardset
     where adid = i_adid
       and appid = I_APPId;
  
    if v_n <= 0 then
      v_msg := '0_' || v_money;
      return v_msg;
    end if;
  
    --没绑定则直接显示后台所写奖励金蛋数
    select count(1)
      into v_bind
      from ad_app_bind
     where adid = i_adid
       and deviceid = I_Deviceid;
  
    --如果同个广告同设备绑定多次 则说明有问题不奖励
    if v_bind > 1 then
      v_msg := '0_0';
      return v_msg;
    end if;
  
    for cur in myCur loop
      v_AMoney := 0;
    
      v_Awarding := 0;
    
      --- 返回  状态 0 未完成 1已完成 2 已过期 3 正在完成中 4 不予奖励
      v_Awarding := p_ad_isreward.fq_deviceid(i_adid     => i_adid,
                                              i_appid    => i_appid,
                                              i_dlevel   => cur.dlevel,
                                              i_deviceid => i_deviceid,
                                              i_ptype    => I_PType);
    
      --如果为不予奖励则直接推出并不予奖励
      if v_Awarding = 4 then
        v_AllMoney := 0;
        exit;
      end if;
    
      if v_Awarding in (0, 3) then
      
        select count(1)
          into v_n
          from ad_app_flux
         where adid = I_ADID
           and dlevel = cur.dlevel
           and deviceid = I_Deviceid;
      
        /*
        select trunc(dbms_random.value(0, 3)) into v_random from dual;
        case v_random
          when 0 then
            select \* sql a *\
             count(1)
              into v_n
              from ad_app_flux
             where adid = I_ADID
               and dlevel = cur.dlevel
               and deviceid = I_Deviceid;
          when 1 then
            select \* sql b *\
             count(1)
              into v_n
              from ad_app_flux
             where adid = I_ADID
               and dlevel = cur.dlevel
               and deviceid = I_Deviceid;
          when 2 then
            select \* sql c *\
             count(1)
              into v_n
              from ad_app_flux
             where adid = I_ADID
               and dlevel = cur.dlevel
               and deviceid = I_Deviceid;
          else
          
            select \* sql d *\
             count(1)
              into v_n
              from ad_app_flux
             where adid = I_ADID
               and dlevel = cur.dlevel
               and deviceid = I_Deviceid;
        end case;*/
      
        -- 还可领取数=总奖励数-已获取数
        -- 如果组别大于90则说明该组别只可获取一次奖励
        if cur.awardgroup >= 90 then
        
          --如果存在同组奖励 则取同组最大级别
          select max(dlevel)
            into v_MaxDlevel
            from ad_awardset
           where adid = i_adid
             and awardgroup = cur.awardgroup;
        
          if cur.dlevel = v_MaxDlevel then
            v_AMoney := cur.times * cur.amoney - v_n * cur.amoney;
          end if;
        else
          v_AMoney := cur.times * cur.amoney - v_n * cur.amoney;
        end if;
      end if;
    
      v_AllMoney := v_AllMoney + v_AMoney;
    
    end loop;
  
    --  0_金额 【0 表示未绑定 1表示用户已绑定但是无追加奖励 2表示为用户已绑定并有追加奖励  3表示为用户仅绑定】
    if v_AllMoney = 0 then
      v_msg := '0_0';
      return v_msg;
    else
    
      --货币单位描述 默认元 
      --货币与人名币比率 1：1 
      select unit, rate
        into v_unit, v_rate
        from ad_channel
       where appid = I_APPId;
    
      --如果用户未绑定且有奖励金额
      if v_bind = 0 and v_AllMoney > 0 then
        v_msg := '0_' || p_base_fun.fq_strround(v_AllMoney * v_rate) ||
                 v_unit;
        return v_msg;
      end if;
    
      v_msg := '2_' || p_base_fun.fq_strround(v_AllMoney * v_rate) ||
               v_unit;
    
      --判断是否已领取过奖励
      select count(1)
        into v_n
        from ad_app_flux
       where adid = I_ADID
         and deviceid = I_Deviceid;
      if v_n = 0 then
        v_msg := '3_' || p_base_fun.fq_strround(v_AllMoney * v_rate) ||
                 v_unit;
      end if;
    
      return v_msg;
    end if;
  
    return v_msg;
  exception
    --失败
    when others then
      rollback;
      v_msg := '0&+0万';
      return v_msg;
  end FQ_Deviceid;

  Function FQ_Deviceid_Easy
  /*****************************************************************
        Procedure Name :FQ_Deviceid_Easy
        Purpose:  根据设备号 判断用户还可获得奖励金额-简洁版
        Edit: 2017-11-23 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_ADStatus In Number, --广告状态  0 正常 1、广告尚未投放 2、日流量到量 3、总流量到量 4、已停止投放
   I_Deviceid In Varchar2, --设备号ID
   I_PType    In Number --1、ios  2、安卓
   ) Return varchar2 As
    -- 0_金额 【0 表示未绑定 1表示用户已绑定但是无追加奖励 2表示为用户已绑定并有追加奖励  3表示为用户仅绑定】
    v_bind number; --绑定数
  
    v_AllMoney number; --金额
    v_ATimes   number; --已获得奖励次数
    v_unit     varchar2(50); --货币单位描述 默认元 
    v_rate     number; --货币与人名币比率 1：1  
    v_msg      varchar2(500) := '0_0'; ---返回信息
    v_ischange number := 0; --是否开启货币转换 0：否 1：是 
    v_isint    number := 0; --是否整数计算 0否1是 
  
  begin
    v_AllMoney := 0;
  
    --判断用户是否绑定
    select count(1)
      into v_bind
      from ad_app_bind
     where adid = I_ADID
       and deviceid = I_Deviceid;
  
    --货币单位描述 默认元 
    --货币与人名币比率 1：1 
    select unit, rate, ischange, isint
      into v_unit, v_rate, v_ischange, v_isint
      from ad_channel
     where appid = I_APPId;
  
    --用户还可获得奖励金额
    select nvl(sum(AllMoney), 0), sum(cnt)
      into v_AllMoney, v_ATimes
      from (select case
                     when v_isint = 1 then
                      trunc(((amoney * times) - (amoney * cnt)) * v_rate)
                     else
                      ((amoney * times) - (amoney * cnt)) * v_rate
                   end as AllMoney,
                   cnt
              from (select a.adid,
                           a.appid,
                           a.type,
                           a.dlevel,
                           a.awardgroup,
                           a.amoney,
                           a.times,
                           nvl(b.cnt, 0) cnt
                      from ad_awardset a
                      left join (select adid, dlevel, count(1) cnt
                                  from ad_app_flux
                                 where adid = I_ADID
                                   and deviceid = I_Deviceid
                                 group by adid, dlevel) b
                        on a.adid = b.adid
                       and a.dlevel = b.dlevel
                     where a.adid = I_ADID
                       and a.appid = I_APPId));
  
    -- 0_金额 【0 表示未绑定 1表示用户已绑定但是无追加奖励 2表示为用户已绑定并有追加奖励  3表示为用户仅绑定】
  
    if v_bind = 0 then
      --未绑定
      v_msg := '0_' || p_base_fun.fq_monetaryunit(v_AllMoney, v_ischange) ||
               v_unit;
      return v_msg;
    
    else
      --已绑定，但是无可领取奖励
      if v_AllMoney <= 0 then
        v_msg := '1_' || p_base_fun.fq_monetaryunit(v_AllMoney, v_ischange) ||
                 v_unit;
        return v_msg;
      
      else
        --如果没拿过奖励则为仅下载
        if v_ATimes = 0 then
          v_msg := '3_' ||
                   p_base_fun.fq_monetaryunit(v_AllMoney, v_ischange) ||
                   v_unit;
        else
          v_msg := '2_' ||
                   p_base_fun.fq_monetaryunit(v_AllMoney, v_ischange) ||
                   v_unit;
        end if;
      
        return v_msg;
      end if;
    
    end if;
  
    return v_msg;
  
  exception
    --失败
    when others then
      rollback;
      v_msg := '0_0';
      --v_msg := sqlerrm || sqlcode;
      return v_msg;
  end FQ_Deviceid_Easy;

end P_AD_ShowMoney;
/


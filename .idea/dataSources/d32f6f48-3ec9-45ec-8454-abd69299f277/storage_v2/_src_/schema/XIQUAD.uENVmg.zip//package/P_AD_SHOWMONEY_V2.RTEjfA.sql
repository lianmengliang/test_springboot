create PACKAGE P_AD_ShowMoney_V2 AS

  /*判断 设备号还可获得奖励金额 */

  Function FQ_Userid
  /*****************************************************************
        Procedure Name :FQ_Deviceid_Easy
        Purpose:  根据闲玩用户 判断用户还可获得奖励金额 
        Edit: 2018-04-09 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_ADStatus In Number, --广告投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放）
   I_Deviceid In Varchar2, --设备号ID
   I_Userid   In Number, --闲玩用户编号
   I_PType    In Number --1、ios  2、安卓
   ) Return varchar2;

  procedure PQ_UserMoney
  /*****************************************************************
        Procedure Name :FQ_UserMoney
        Purpose:  根据闲玩用户 返回还可获得奖励金额
        Edit: 2018-04-09 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_ADStatus In Number, --广告投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放）
   I_Deviceid In Varchar2, --设备号ID
   I_Userid   In Number, --闲玩用户编号
   I_PType    In Number, --1、ios  2、安卓
   O_AllMoney Out Number, --可获得总奖励金额
   O_AllTimes Out Number --已获得奖励次数
   );

  Function FQ_Userid_List
  /*****************************************************************
        Procedure Name :FQ_Userid_List
        Purpose:  根据闲玩用户 判断用户还可获得奖励金额  列表使用
        Edit: 2018-11-16 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_ADStatus In Number, --广告投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放）
   I_Deviceid In Varchar2, --设备号ID
   I_Userid   In Number, --闲玩用户编号
   I_PType    In Number --1、ios  2、安卓
   ) Return varchar2;

  procedure PQ_UserMoney_List
  /*****************************************************************
        Procedure Name :PQ_UserMoney_List
        Purpose:  根据闲玩用户 返回还可获得奖励金额 列表使用
        Edit: 2018-11-06 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_ADStatus In Number, --广告投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放）
   I_Deviceid In Varchar2, --设备号ID
   I_Userid   In Number, --闲玩用户编号
   I_PType    In Number, --1、ios  2、安卓
   O_AllMoney Out Number, --可获得总奖励金额
   O_AllTimes Out Number --已获得奖励次数
   );

end P_AD_ShowMoney_V2;


/


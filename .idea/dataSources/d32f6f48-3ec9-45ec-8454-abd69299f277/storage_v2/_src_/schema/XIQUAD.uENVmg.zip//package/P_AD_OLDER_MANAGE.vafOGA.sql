create package P_AD_Older_Manage is

  TYPE T_CURSOR IS REF CURSOR;

  procedure PQ_UserList
  /*****************************************************************
        Procedure Name :PQ_UserList
        Purpose: 获取老用户激活设置列表
        Edit: 2019-2-22 add by 一帆
    ****************************************************************/
  (I_AdmInId        In Varchar2, --管理员ID
   I_Adid           In Number, --广告ID
   I_AdName         In Varchar2, --广告名称
   I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始
   O_OutCursor      Out t_cursor, --返回游标
   O_Outrecordcount Out Number, --返回总记录数
   O_Result         Out Number,
   O_Message        Out Varchar2);

  procedure PQ_UserItem
  /*****************************************************************
        Procedure Name :PQ_UserItem
        Purpose: 获取老用户激活设置
        Edit: 2019-2-22 add by 一帆
    ****************************************************************/
  (I_AdmInId   In Varchar2, --管理员ID
   I_Adid      In Number, --广告ID
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure PW_UpDateOlder
  /*****************************************************************
        Procedure Name :PW_UpDateOlder
        Purpose: 修改老用户激活设置
        Edit: 2019-2-22 add by 一帆
    ****************************************************************/
  (I_AdmInId   In Varchar2, --管理员ID
   I_Adid      In Number, -- 广告ID
   I_OlderAdid In Varchar2, --老广告Id,
   I_Total     In Number, --激活总数
   I_Flux_Day  In Number, --每日带量数
   I_Flux_Time In Date, --带量时间
   I_Status    In Number, --状态
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure PW_AddOlder
  /*****************************************************************
        Procedure Name :PW_AddOlder
        Purpose: 修改老用户激活设置
        Edit: 2019-2-22 add by 一帆
    ****************************************************************/
  (I_AdmInId   In Varchar2, --管理员ID
   I_Adid      In Number, -- 广告ID
   I_OlderAdid In Varchar2, --老广告Id,
   I_Total     In Number, --激活总数
   I_Flux_Day  In Number, --每日带量数
   I_Flux_Time In Date, --带量时间
   I_Status    In Number, --状态
   O_Result    Out Number,
   O_Message   Out Varchar2);

end P_AD_Older_Manage;
/


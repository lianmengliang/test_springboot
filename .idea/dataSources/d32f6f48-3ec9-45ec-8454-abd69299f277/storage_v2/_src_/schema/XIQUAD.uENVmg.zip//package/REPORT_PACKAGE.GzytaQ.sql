create package report_package as

  type t_cursor is ref cursor;

  procedure addreport
  /*****************************************************************
    procedure name: titlelist
    purpose: 插入报表
    comment: 建立日期 20071218
    author：wangcheng
    ****************************************************************/
  (i_title         in varchar2, -- 查询区
   i_sql           in long, --sql语句
   i_parameter     in varchar2, --当前页码,从 1 开始
   i_reportname    in varchar2, --报表名称
   i_reportwidth   in varchar2, --报表列宽
   i_reportalign   in varchar2, --报表列对齐方式
   i_reportcontrol in varchar2, --报表控件
   i_pagesize      in number, --每页显示的记录数
   o_result        out number); -- 返回结果

  procedure viewreport
  /*******************************************************************
    procedure name:reportlist
    prupose :取报表
    comment:建立日期20071218
    author:wangcheng
    ********************************************************************/
  (i_sql            in long, --查询报表的sql
   i_pagesize       in number, --每页记录数
   i_pageno         in number, --当前页码,从 1 开始
   o_outrecordcount out number, --返回总记录数
   o_outcursor      out t_cursor);
  procedure queryreport
  /*******************************************************************
    procedure name:reportlist
    prupose :查询报表
    comment:建立日期20071218
    author:wangcheng
    ********************************************************************/
  (i_adminid   in varchar2, --管理员id
   i_id        in number, --报表id
   o_result    out number, --返回结果，0：无权限，1：有权限
   o_outcursor out t_cursor --返回记录
   );
  procedure reportlist
  /*******************************************************************
    procedure name:reportlist
    prupose :报表list
    comment:建立日期20071218
    author:wangcheng
    ********************************************************************/
  (o_outcursor out t_cursor --返回报表记录
   );

  procedure delreport
  /*******************************************************************
    procedure name:delreport
    prupose :删除报表
    comment:建立日期20071218
    author:wangcheng
    ********************************************************************/
  (i_id     in varchar2, --报表id
   o_result out number -- 返回结果  1:成功 0:失败
   );
  procedure modifyreport
  /*****************************************************************
    procedure name: titlelist
    purpose: 修改报表
    comment: 建立日期 20071218
    author：wangcheng
    ****************************************************************/
  (i_id            in number, --报表id
   i_title         in varchar2, -- 查询区
   i_sql           in long, --sql语句
   i_parameter     in varchar2, --当前页码,从 1 开始
   i_reportname    in varchar2, --报表名称
   i_reportwidth   in varchar2, --报表列宽
   i_reportalign   in varchar2, --报表列对齐方式
   i_reportcontrol in varchar2, --报表控件
   i_pagesize      in number, --每页显示的记录数
   o_result        out number); -- 返回结果  1:成功 0:失败

  procedure managereport
  /*******************************************************************
    procedure name:reportlist
    prupose :报表管理查询
    comment:建立日期20071218
    author:wangcheng
    ********************************************************************/
  (i_adminid        in varchar2, --管理员id
   i_pagesize       in number, --每页记录数
   i_pageno         in number, --当前页码,从 1 开始
   o_outrecordcount out number, --返回总记录数
   o_result         out number, -- 0:无权限查询，1：有权限
   o_outcursor      out t_cursor --返回记录
   );
  procedure config
  /*******************************************************************
    procedure name:reportlist
    prupose :报表权限配置
    comment:建立日期20071218
    author:wangcheng
    ********************************************************************/
  (i_adminid        in varchar2, --管理员id
   i_status         in number, --显示查询状态1：查询已显示，0：查询不显示
   i_delstatus      in number, --显示删除状态1：未删除，0：已删除
   i_pagesize       in number, --每页记录数
   i_pageno         in number, --当前页码,从 1 开始
   o_outrecordcount out number, --返回总记录数
   o_result         out number, -- 0:无权限查询，1：有权限
   o_outcursor      out t_cursor --返回记录
   );

  procedure delqx
  /*******************************************************************
    procedure name:delqx
    prupose :删除权限（报表）
    comment:建立日期20071218
    author:wangcheng
    ********************************************************************/
  (i_adminid in varchar2, --管理员id
   i_id      in number, --报表id
   o_result  out number -- 返回结果  1:成功 0:失败
   );

  procedure readqx
  /*******************************************************************
    procedure name:readqx
    prupose :查询某条权限
    comment:建立日期20071218
    author:wangcheng
    ********************************************************************/
  (i_adminid   in varchar2, --管理员id
   i_qxid      in number, --权限id
   o_result    out number,
   o_outcursor out t_cursor --返回记录
   );
  procedure reportqx
  /*******************************************************************
    procedure name:reportqx
    prupose :判断该用户是否有定制报表的权限
    comment:建立日期20071218
    author:wangcheng
    ********************************************************************/
  (i_adminid in varchar2, --管理员id
   o_result  out number --0：无权限操作，1：有权限
   );
  procedure eportinfor
  /*******************************************************************
    procedure name:eportinfor
    prupose :查询报表
    comment:建立日期20071218
    author:wangcheng
    ********************************************************************/
  (i_id        in number, --报表id
   o_outcursor out t_cursor --返回记录
   );

  procedure viewrconfigeport
  /*******************************************************************
    procedure name:viewrconfigeport
    prupose :在添加定制报表的时候，预览报表，
            验证sql语句的正确性，返回空记录集
    comment:建立日期20071218
    author:wangcheng
    ********************************************************************/
  (i_sql       in long, --查询报表的sql
   o_result    out number, --返回结果 0：sql包含关键字  1：不包含
   o_outcursor out t_cursor --返回记录
   );

  function freport_checksql
  /*****************************************************************
    过程名称：freport_checksql
    创建日期：20071228
    修改日志：add by fyj 2007-10-13
    功能说明：检查报表的sql语句是否包含非法的关键字
    输入：sql语句
    返回：0：不包含  1：包含
    
    ****************************************************************/
  (i_sql in long) return number;

  function monthactcount
  /*****************************************************************
    过程名称：monthactcount
    创建日期：20110301
    功能说明：获取当月活跃数
    输入：sql语句
    返回：0：不包含  1：包含
    ****************************************************************/
  (in_time in varchar2, in_placeid in varchar2) return number;
  function monthactrate
  /*****************************************************************
    过程名称：monthactcount
    创建日期：20110301
    功能说明：获取当月活跃率
    输入：sql语句
    返回：0：不包含  1：包含
    ****************************************************************/
  (in_time in varchar2, in_placeid in varchar2) return number;

end report_package;


/


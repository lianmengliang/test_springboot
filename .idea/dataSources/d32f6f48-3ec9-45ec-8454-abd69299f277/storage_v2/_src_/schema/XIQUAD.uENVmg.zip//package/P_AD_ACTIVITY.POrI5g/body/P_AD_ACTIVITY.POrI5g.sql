create package body P_AD_Activity is
  procedure PQ_Activity_AwardRecord
  /*****************************************************************
        Procedure Name :PQ_Activity_AwardRecord
        Purpose: 获取福利活动领奖记录
        Edit: 2018-7-2  add by 小胡
    ****************************************************************/
  (I_ADID      In Number, --广告id
   I_ACTID     In Varchar2, --活动id
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number, --判断 0：查询成功，其他：出错
   O_Message   Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n      number;
    v_SQL    varchar2(4000);
    v_pcount number;
  begin
    O_Result  := 0;
    O_Message := '查询成功';
    v_SQL     := '';
    v_pcount  := 0;
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值 
    ----------------------------------------------------
    --判断广告是否存在
    select count(1) into v_n from ad_adinfo where adid = I_ADID;
  
    if v_n <= 0 then
      O_Result  := -2;
      O_Message := '广告编号输入错误';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_activity
     where adid = I_ADID
       and actid = I_ACTID
       and status = 1;
    if v_n <= 0 then
      O_Result  := -1;
      O_Message := '未查到活动信息';
      return;
    end if;
    select pcount
      into v_pcount
      from ad_activity
     where adid = I_ADID
       and actid = I_ACTID
       and status = 1;
    ----  --WMSYS.WM_CONCAT(actid || '_' || arank)
  
    v_SQL := 'select actid,arank,merid,itime,p_ad_activity.FQ_ActMoney(i_adid=>' ||
             I_ADID ||
             ',i_actid=>actid,i_rank=>arank)  money,keycode from(select ' ||
             I_ACTID ||
             ' actid,to_number(a.rank) arank, nvl2(b.merid,''*******''||substr(b.merid,length(b.merid)-2,3),''虚位以待'') as merid, b.itime,b.money as money,b.keycode from (select lpad(level,2,0) rank from dual connect by level<=' ||
             v_pcount || ' ) a ' ||
             ' left join  (select adid,actid,merid,arank,money, to_char(itime, ''yyyy-mm-dd hh24:mi:ss'') itime,userid,keycode from ad_activity_record where adid=' ||
             I_ADID || ' and actid=' || I_ACTID ||
             ') b on a.rank=b.arank order by arank) ';
  
    OPEN O_Outcursor FOR v_SQL;
  
    return;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      ROLLBACK;
      O_Result  := -9;
      O_Message := '查询失败';
      RETURN;
  end PQ_Activity_AwardRecord;

  procedure PW_Activity_AddRecord
  /*****************************************************************
        Procedure Name :PQ_Activity_AddRecord
        Purpose: 添加领奖记录
        Edit: 2018-7-2  add by 小胡
    ****************************************************************/
   is
    v_n     number;
    v_money number(18, 2);
    v_price number(18, 2);
  begin
    -----循环 在结束内时间的所有活动，从流水表获取领奖名单，并插入领奖记录表
    DECLARE
      CURSOR myCur IS
        select actid, dlevel, pcount, adid
          from ad_activity
         where status = 1
           and etime > sysdate;
    begin
    
      for cur in myCur LOOP
      
        declare
          cursor toCur is
          
            select money, itime, merid, userid, rownum as rn
              from (select money, itime, merid, userid
                      from ad_app_flux
                     where dlevel = cur.dlevel
                       and (case
                             when adid = 5553 and merid in ('1172721') then
                              0
                             else
                              1
                           end) = 1
                       and adid = cur.adid
                     order by itime asc)
             where rownum <= cur.pcount;
        
        begin
          for cus in toCur Loop
            v_n := 0;
            select count(1)
              into v_n
              from ad_activity_record
             where adid = cur.adid
               and actid = cur.actid
               and merid = cus.merid;
            ---只有当期未领过奖才添加
            if v_n <= 0 then
              --查询奖励和结算金额
              p_ad_activity.PQ_ActAwardMoney(I_ADID  => cur.adid,
                                             I_ACTID => cur.actid,
                                             I_RANK  => cus.rn,
                                             O_MONEY => v_money,
                                             O_PRICE => v_price);
              insert into ad_activity_record
                (adid,
                 actid,
                 merid,
                 arank,
                 itime,
                 userid,
                 money,
                 price,
                 keycode)
              values
                (cur.adid,
                 cur.actid,
                 cus.merid,
                 cus.rn,
                 cus.itime,
                 cus.userid,
                 v_money,
                 v_price,
                 '#' || p_base_fun.fq_random_str(4) || '#');
              commit;
            end if;
          end loop;
        
        end;
      
      end loop;
    end;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      ROLLBACK;
      RETURN;
  end PW_Activity_AddRecord;

  procedure PQ_ActAwardMoney
  /*****************************************************************
        Procedure Name :PQ_ActAwardMoney
        Purpose: 获取福利活动 奖励金额和结算金额
        Edit: 2018-08-13 add by 小胡
    ****************************************************************/
  (I_ADID  In Number, --广告ID 
   I_ACTID In Number, --活动id
   I_RANK  In Number, --排名
   O_MONEY Out Number, --奖励金额
   O_PRICE Out Number --结算金额
   ) is
    v_n number;
  begin
    O_MONEY := 0;
    O_PRICE := 0;
    select count(1)
      into v_n
      from ad_activity
     where adid = I_ADID
       and actid = I_ACTID;
    if v_n <= 0 then
      return;
    end if;
    select count(1)
      into v_n
      from ad_activity_award
     where adid = I_ADID
       and actid = I_ACTID
       and I_RANK >= srank
       and I_RANK <= erank;
    if v_n <= 0 then
      return;
    end if;
    select money, price
      into O_MONEY, O_PRICE
      from ad_activity_award
     where adid = I_ADID
       and actid = I_ACTID
       and I_RANK >= srank
       and I_RANK <= erank;
  
    return;
  exception
    --失败
    when others then
      --v_msg := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      rollback;
      return;
  end PQ_ActAwardMoney;

  Function FQ_ActMoney
  /*****************************************************************
        Procedure Name :ActMoney
        Purpose: 查询奖励金额
        Edit: 2018-08-14 add by 小胡
    ****************************************************************/
  (I_ADID  In Number, --广告ID 
   I_ACTID In Number, --活动id
   I_RANK  In Number --排名
   ) Return number As
    v_n     number;
    v_money number(18, 2);
  begin
    v_money := 0;
    select count(1)
      into v_n
      from ad_activity
     where adid = I_ADID
       and actid = I_ACTID;
    if v_n <= 0 then
      return v_money;
    end if;
    select count(1)
      into v_n
      from ad_activity_award
     where adid = I_ADID
       and actid = I_ACTID
       and I_RANK >= srank
       and I_RANK <= erank;
    if v_n <= 0 then
      return v_money;
    end if;
    select money
      into v_money
      from ad_activity_award
     where adid = I_ADID
       and actid = I_ACTID
       and I_RANK >= srank
       and I_RANK <= erank;
  
    return v_money;
  
  exception
    --失败
    when others then
      --v_msg := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      rollback;
      return v_money;
  end FQ_ActMoney;

  procedure PQ_ACTIVITY
  /*****************************************************************
        Procedure Name :PQ_ACTIVITY
        Purpose: 获取福利活动
        Edit: 2018-08-15 add by 小胡
    ****************************************************************/
  (I_ADID      In Number, --广告ID 
   I_MerId     In Varchar2, --用户游戏账号id
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number, --判断 0：查询成功，其他：出错
   O_Message   Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
  
    pragma autonomous_transaction; -------------方法函数 被嵌套，且有表操作 必写
    v_n   number;
    v_sql varchar2(2000);
  begin
    open O_Outcursor for
      select 1 from dual where 1 = 2;
    O_Result  := 0;
    O_Message := '查询成功';
    select count(1)
      into v_n
      from ad_activity
     where adid = I_ADID
       and status = 1;
    if v_n <= 0 then
      O_Result  := -2;
      O_Message := '未查到该广告活动信息';
      return;
    end if;
  
    v_sql := 'select adid,aname,actid,pcount,intro,dlevel,etime,arank,status,(select nvl(arank,0)  from ad_activity_record where adid=' ||
             I_ADID || ' and merid=''' || I_MerId || ''' and actid=b.actid) userrank
      from ad_activity b
     where adid =' || I_ADID ||
             ' and status= 1 and (select count(1) from ad_activity_award where adid=' ||
             I_ADID ||
             ' and status=1 and actid=b.actid)>0 order  by arank ';
  
    open O_Outcursor for v_sql;
    return;
  exception
    --失败
    when others then
      --v_msg := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      O_Result  := -2;
      O_Message := '查询失败';
      rollback;
      return;
  end PQ_ACTIVITY;

end P_AD_Activity;
/


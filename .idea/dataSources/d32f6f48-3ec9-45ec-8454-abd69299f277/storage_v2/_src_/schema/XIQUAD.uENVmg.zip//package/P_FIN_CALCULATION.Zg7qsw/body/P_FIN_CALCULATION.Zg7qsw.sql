create package body P_FIN_Calculation is

  -- Purpose : 财务数据计算

  Procedure Job_Channel_Expend
  /*****************************************************************
        procedure name: Job_Channel_Expend
        purpose: 渠道消耗自动计算
        edit: 2017-06-18 add by 小沈
    ****************************************************************/
   is
  
    v_id         number; --ID
    v_amount     number; --总数，金额 
    v_price      number; --单价 
    v_expend     number; --税前消耗=数量[金额]*单价 
    v_taxrate    number; --税率 
    v_tax_income number; --税后收入=税前收入(消耗)-税前收入(消耗)*税率 
    v_price_c    number; --渠道单价 
    v_expend_c   number; --渠道消耗=数量[金额]*渠道单价 
    v_profit     number; --广告毛利=税后收入-渠道消耗 
  
    v_message varchar2(500);
  
    cursor Cur_List is
    
      select id, appid, adid, urlid, amount, price, taxrate, price_c
        from fin_channel_expend
       where cstatus = 0
       order by itime asc, appid, adid, urlid;
  
  begin
    v_message := '处理成功！';
  
    for Cur in Cur_List loop
      v_id         := cur.id;
      v_amount     := cur.amount; --总数，金额 
      v_price      := cur.price; --单价 
      v_expend     := v_amount * v_price; --税前消耗=数量[金额]*单价 
      v_taxrate    := cur.taxrate; --税率 
      v_tax_income := v_expend - (v_expend * v_taxrate); --税后收入=税前收入(消耗)-税前收入(消耗)*税率 
      v_price_c    := cur.price_c; --渠道单价 
      v_expend_c   := v_amount * v_price_c; --渠道消耗=数量[金额]*渠道单价 
      v_profit     := v_tax_income - v_expend_c; --广告毛利=税后收入-渠道消耗 
    
      update fin_channel_expend
         set expend     = v_expend,
             tax_income = v_tax_income,
             expend_c   = v_expend_c,
             profit     = v_profit,
             cstatus    = 2
       where id = v_id;
      commit;
    
    end loop;
  
  exception
    when others then
      rollback;
    
      v_message := '计算失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      --添加日志
      insert into fin_log
        (appid, adid, urlid, msg)
      values
        (0,
         0,
         0,
         'P_FIN_Calculation.Job_Channel_Expend 渠道消耗自动计算异常：' || v_message);
      commit;
      return;
  end Job_Channel_Expend;

  Procedure Job_Expend_Day
  /*****************************************************************
        procedure name: Job_Expend_Day
        purpose: 渠道消耗日报表
        edit: 2017-06-18 add by 小沈
    ****************************************************************/
   is
    v_n          number;
    v_id         number; --ID
    v_amount     number; --总数，金额 
    v_price      number; --单价 
    v_expend     number; --税前消耗=数量[金额]*单价 
    v_taxrate    number; --税率 
    v_tax_income number; --税后收入=税前收入(消耗)-税前收入(消耗)*税率 
    v_price_c    number; --渠道单价 
    v_expend_c   number; --渠道消耗=数量[金额]*渠道单价 
    v_profit     number; --广告毛利=税后收入-渠道消耗 
    v_Now_Day    date; --当期日期
    v_message    varchar2(500);
  
    v_Satrt_Day varchar2(100); --开始计算日期  如果只取一天则开始和结束日期写同一天 如 2017-06-18
    v_End_Day   varchar2(100); --结束计算日期  如果只取一天则开始和结束日期写同一天 如 2017-06-18
    v_days      number; --获取相差天数
  
    cursor Cur_List is
    --不加广告编号
      select appid,
             dtime,
             sum(expend) expend,
             sum(tax_income) tax_income,
             sum(expend_c) expend_c,
             sum(amoney_c) amoney_c,
             sum(profit) profit
        from fin_channel_expend
       where dtime >= v_Now_Day
         and dtime < v_Now_Day + 1
         and status = 0
       group by appid, dtime
       order by dtime desc, appid desc;
  
  begin
  
    v_Satrt_Day := to_char(sysdate - 1, 'yyyy-mm-dd');
    v_End_Day   := to_char(sysdate - 1, 'yyyy-mm-dd');
  
    /*    v_Satrt_Day := '2017-12-19';
    v_End_Day   := '2017-12-21';*/
    v_message := '处理成功！';
  
    v_days := to_date(v_End_Day, 'yyyy-mm-dd') -
              to_date(v_Satrt_Day, 'yyyy-mm-dd');
  
    --根据需要获取的日期进行循环获取
    for v_day in 0 .. v_days loop
    
      --当前需要获取的日期
      v_Now_Day := to_date(v_Satrt_Day, 'yyyy-mm-dd') + v_day;
    
      for Cur in Cur_List loop
      
        select count(1)
          into v_n
          from fin_expend_day
         where dtime = cur.dtime
           and appid = cur.appid;
      
        if v_n > 0 then
          update fin_expend_day
             set expend     = cur.expend,
                 tax_income = cur.tax_income,
                 expend_c   = cur.expend_c,
                 amoney_c   = cur.amoney_c,
                 profit     = cur.profit
           where appid = cur.appid
             and dtime = cur.dtime;
        else
          insert into fin_expend_day
            (appid,
             dtime,
             expend,
             tax_income,
             expend_c,
             amoney_c,
             profit,
             itime)
          values
            (cur.appid,
             cur.dtime,
             cur.expend,
             cur.tax_income,
             cur.expend_c,
             cur.amoney_c,
             cur.profit,
             sysdate);
        
        end if;
      
        commit;
        <<next_cur>>
        null;
      
      end loop;
    
    end loop;
  
  exception
    when others then
      rollback;
    
      v_message := '计算失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      --添加日志
      insert into fin_log
        (appid, adid, urlid, msg)
      values
        (0,
         0,
         0,
         'P_FIN_Calculation.Job_Channel_Expend_Day 渠道消耗日报表计算异常：' ||
         v_message);
      commit;
      return;
  end Job_Expend_Day;

  Procedure Job_Adv_Expend
  /*****************************************************************
        procedure name: Job_Adv_Expend
        purpose: 广告主消耗自动计算
        edit: 2017-08-07 add by 小沈
    ****************************************************************/
   is
  
    v_id         number; --ID
    v_amount     number; --总数，金额 
    v_price      number; --单价 
    v_expend     number; --税前消耗=数量[金额]*单价 
    v_taxrate    number; --税率 
    v_tax_income number; --税后收入=税前收入(消耗)-税前收入(消耗)*税率 
    v_amount_c   number; --渠道总数，金额 
    v_price_c    number; --渠道单价 
    v_amoney_c   number; --渠道奖励金额 
    v_expend_c   number; --渠道消耗=数量[金额]*渠道单价 
    v_profit     number; --广告毛利=税后收入-渠道消耗 
    v_profit_c   number; --渠道毛利 =渠道消耗-渠道奖励
    v_message    varchar2(500);
  
    cursor Cur_List is
    
      select id,
             adid,
             appid,
             urlid,
             amount,
             price,
             taxrate,
             amount_c,
             amoney_c,
             price_c
        from fin_adv_expend
       where cstatus = 0
       order by itime asc, appid, adid, urlid;
  
  begin
    v_message := '处理成功！';
  
    for Cur in Cur_List loop
      v_id         := cur.id;
      v_amount     := cur.amount; --总数，金额 
      v_price      := cur.price; --单价 
      v_expend     := v_amount * v_price; --税前消耗=数量[金额]*单价 
      v_taxrate    := cur.taxrate; --税率 
      v_tax_income := v_expend - (v_expend * v_taxrate); --税后收入=税前收入(消耗)-税前收入(消耗)*税率 
      v_amount_c   := cur.amount_c; --渠道总数，金额 
      v_price_c    := cur.price_c; --渠道单价 
      v_amoney_c   := cur.amoney_c; --渠道奖励总金额 
      v_expend_c   := v_amount_c * v_price_c; --渠道消耗=数量[金额]*渠道单价 
      v_profit_c   := v_expend_c - v_amoney_c; --渠道毛利=渠道消耗-渠道奖励金额 
      v_profit     := v_tax_income - v_expend_c; --广告毛利=税后收入-渠道消耗 
    
      update fin_adv_expend
         set expend     = v_expend,
             tax_income = v_tax_income,
             expend_c   = v_expend_c,
             profit_c   = v_profit_c,
             profit     = v_profit,
             cstatus    = 2
       where id = v_id;
      commit;
    
    end loop;
  
  exception
    when others then
      rollback;
    
      v_message := '计算失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      --添加日志
      insert into fin_log
        (appid, adid, urlid, msg)
      values
        (0,
         0,
         0,
         'P_FIN_Calculation.Job_Adv_Expend 广告消耗自动计算异常：' || v_message);
      commit;
      return;
  end Job_Adv_Expend;

  Procedure Job_Adv_Expend_Day
  /*****************************************************************
        procedure name: Job_Expend_Day
        purpose: 渠道消耗日报表
        edit: 2017-08-07 add by 小沈
    ****************************************************************/
   is
    v_n          number;
    v_id         number; --ID
    v_amount     number; --总数，金额 
    v_price      number; --单价 
    v_expend     number; --税前消耗=数量[金额]*单价 
    v_taxrate    number; --税率 
    v_tax_income number; --税后收入=税前收入(消耗)-税前收入(消耗)*税率 
    v_price_c    number; --渠道单价 
    v_expend_c   number; --渠道消耗=数量[金额]*渠道单价 
    v_profit     number; --广告毛利=税后收入-渠道消耗 
    v_Now_Day    date; --当期日期
    v_message    varchar2(500);
  
    v_Satrt_Day varchar2(100); --开始计算日期  如果只取一天则开始和结束日期写同一天 如 2017-06-18
    v_End_Day   varchar2(100); --结束计算日期  如果只取一天则开始和结束日期写同一天 如 2017-06-18
    v_days      number; --获取相差天数
  
    cursor Cur_List is
    --不加广告编号
      select adid,
             appid,
             dtime,
             sum(expend) expend,
             sum(tax_income) tax_income,
             sum(expend_c) expend_c,
             sum(profit) profit
        from fin_adv_expend
       where dtime >= v_Now_Day
         and dtime < v_Now_Day + 1
         and status = 0 
       group by adid, appid, dtime
       order by dtime desc, adid desc, appid desc;
  
  begin
  
    v_message := '处理成功！';
  
    v_Satrt_Day := to_char(sysdate - 1, 'yyyy-mm-dd');
    v_End_Day   := to_char(sysdate - 1, 'yyyy-mm-dd');
  
    /*    v_Satrt_Day := '2018-6-4';
    v_End_Day   := '2018-6-13';*/
  
    v_message := '处理成功！';
  
    v_days := to_date(v_End_Day, 'yyyy-mm-dd') -
              to_date(v_Satrt_Day, 'yyyy-mm-dd');
  
    --根据需要获取的日期进行循环获取
    for v_day in 0 .. v_days loop
    
      --当前需要获取的日期
      v_Now_Day := to_date(v_Satrt_Day, 'yyyy-mm-dd') + v_day;
    
      for Cur in Cur_List loop
      
        select count(1)
          into v_n
          from fin_adv_expend_day
         where dtime = cur.dtime
           and adid = cur.adid
           and appid = cur.appid;
      
        if v_n > 0 then
          update fin_adv_expend_day
             set expend     = cur.expend,
                 tax_income = cur.tax_income,
                 expend_c   = cur.expend_c,
                 profit     = cur.profit
           where dtime = cur.dtime
             and adid = cur.adid
             and appid = cur.appid;
        else
          insert into fin_adv_expend_day
            (adid,
             appid,
             dtime,
             expend,
             tax_income,
             expend_c,
             profit,
             itime)
          values
            (cur.adid,
             cur.appid,
             cur.dtime,
             cur.expend,
             cur.tax_income,
             cur.expend_c,
             cur.profit,
             sysdate);
        
        end if;
      
        commit;
        <<next_cur>>
        null;
      
      end loop;
    
    end loop;
  exception
    when others then
      rollback;
    
      v_message := '计算失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      --添加日志
      insert into fin_log
        (appid, adid, urlid, msg)
      values
        (0,
         0,
         0,
         'P_FIN_Calculation.Job_Expend_Day 广告消耗日报表计算异常：' || v_message);
      commit;
      return;
  end Job_Adv_Expend_Day;

end P_FIN_Calculation;
/


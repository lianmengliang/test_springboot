create PACKAGE P_AD_IsShow_V3 AS

  /* 判断当前广告是否为该用户显示 */

  Function FQ_IsShow
  /*****************************************************************
        Procedure Name :FQ_IsShow
        Purpose: 判断是否显示 0 不显示 1 显示
        Edit: 2018-09-17 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_Userid   In Number, --闲玩用户编号
   I_IP       In Varchar2, --用户当前IP
   I_IP_Num   In Number, --用户当前IP 数字化
   I_PType    In Number --1、ios  2、安卓
   ) Return Number;

end P_AD_IsShow_V3;


/


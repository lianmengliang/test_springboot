create function        FQ_String_limit
/*****************************************************************
  过程名称：防止注入的过滤
  创建日期：2016-7-19
  返回：
  ****************************************************************/
(i_strInput IN varchar2, --输入需要过滤的sql参数
 i_type     in number, --类型，默认1全过滤；2日期yyyy-mm-dd，3去空格（如设备号）
 i_lenght   IN varchar2, --限制长度
 i_source   IN varchar2, --日志记录：来源的存储过程
 i_getvalue IN varchar2 --日志记录：参数，如userid
 ) return varchar2 --返回
 is
  v_isLog number(1); --如果有限制字符，则记录日志（0不记录，1记录日志）
  o_str   varchar2(2000);
begin
  ----------------------------------------------------
  --步骤一：校验数据输入的合法性，以及初始化赋值
  ----------------------------------------------------
  v_isLog := 0;

  o_str := i_strInput;
  if i_strInput is null then
    return '';
  end if;

  --超长，记录日志，截取字符串
  if length(i_strInput) > i_lenght then
    v_isLog := 1;
    o_str   := substr(o_str, 1, i_lenght);
  end if;

  ----------------------------------------------------
  --步骤二：如果是日期型
  ----------------------------------------------------
  if i_type = 2 then
    --日期，直接返回
    o_str := to_char(to_date(o_str, 'yyyy-mm-dd'), 'yyyy-mm-dd');
    return o_str;
  end if;

  ----------------------------------------------------
  --步骤二：返回记录集
  ----------------------------------------------------
  if i_type = 3 then
    --去空格
    o_str := FQ_str_DelSpace(o_str);

    if lower(o_str) like '%*/%' then
      v_isLog := 1;
      loop
        select replace(lower(o_str), '*/', '') into o_str from dual;
        exit when(instr(lower(o_str), '*/') = 0);
      end loop;
    end if;

    if lower(o_str) like '%/*%' then
      v_isLog := 1;
      loop
        select replace(lower(o_str), '/*', '') into o_str from dual;
        exit when(instr(lower(o_str), '/*') = 0);
      end loop;
    end if;

    if lower(o_str) like '%--%' then
      v_isLog := 1;
      loop
        select replace(lower(o_str), '--', '- -') into o_str from dual;
        exit when(instr(lower(o_str), '--') = 0);
      end loop;
    end if;

    /* if v_isLog = 1 then
      insert into t_log_limitstr
        (str, type, itime, source, getvalue)
      values
        (i_strInput, i_type, sysdate, i_source, i_getvalue);
      commit;
    end if;*/
    return o_str;
  end if;

  ----------------------------------------------------
  --步骤二：返回记录集
  ----------------------------------------------------
  /*type=1 查询，包含特殊字符则替换，大不了查不出数据 */

  if lower(o_str) like '%--%' then
    v_isLog := 1;
    loop
      select replace(lower(o_str), '--', '- -') into o_str from dual;
      exit when(instr(lower(o_str), '--') = 0);
    end loop;
  end if;

  if lower(o_str) like '%*/%' then
    v_isLog := 1;
    loop
      select replace(lower(o_str), '*/', '') into o_str from dual;
      exit when(instr(lower(o_str), '*/') = 0);
    end loop;
  end if;

  if lower(o_str) like '%/*%' then
    v_isLog := 1;
    loop
      select replace(lower(o_str), '/*', '') into o_str from dual;
      exit when(instr(lower(o_str), '/*') = 0);
    end loop;
  end if;

  --过滤script
  if lower(o_str) like '%script%' then
    v_isLog := 1;

    loop
      select replace(lower(o_str), 'script', '') into o_str from dual;
      exit when(instr(lower(o_str), 'script') = 0);
    end loop;

  end if;

  --过滤select
  if lower(o_str) like '%select%' then
    v_isLog := 1;
    select replace(lower(o_str), 'select', 'selec t') into o_str from dual;
  end if;

  --过滤union
  if lower(o_str) like '%union%' then
    v_isLog := 1;
    select replace(lower(o_str), 'union', 'unio n') into o_str from dual;
  end if;

  --过滤or
  if lower(o_str) like '% or %' then
    v_isLog := 1;
    select replace(lower(o_str), ' or ', ' o r ') into o_str from dual;
  end if;

  --过滤'
  if lower(o_str) like '%''%' then
    v_isLog := 1;
    select replace(lower(o_str), '''', '‘') into o_str from dual;
  end if;

  --过滤'
  if lower(o_str) like '%"%' then
    v_isLog := 1;
    select replace(lower(o_str), '"', '“') into o_str from dual;
  end if;

  --过滤
  if lower(o_str) like '%delete%' then
    v_isLog := 1;
    select replace(lower(o_str), 'delete', 'delet e') into o_str from dual;
  end if;

  --过滤
  if lower(o_str) like '%update%' then
    v_isLog := 1;
    select replace(lower(o_str), 'update', 'updat e') into o_str from dual;
  end if;

  --过滤
  if lower(o_str) like '%insert%' then
    v_isLog := 1;
    select replace(lower(o_str), 'insert', 'inser t') into o_str from dual;
  end if;

  --过滤
  if lower(o_str) like '%truncate%' then
    v_isLog := 1;
    select replace(lower(o_str), 'truncate', 'truncat e')
      into o_str
      from dual;
  end if;

  --过滤
  if lower(o_str) like '% exec%' then
    v_isLog := 1;
    select replace(lower(o_str), ' exec', '  exe c') into o_str from dual;
  end if;

  --过滤
  if lower(o_str) like '%;%' then
    v_isLog := 1;
    select replace(lower(o_str), ';', '；') into o_str from dual;
  end if;

  --过滤
  if lower(o_str) like '%.request%' then
    v_isLog := 1;
    select replace(lower(o_str), '.request', '.reques t')
      into o_str
      from dual;
  end if;

  --过滤
  if lower(o_str) like '%.adduser%' then
    v_isLog := 1;
    select replace(lower(o_str), '.adduser', '.adduse r')
      into o_str
      from dual;
  end if;

  --过滤
  if lower(o_str) like '%dbms_%' then
    v_isLog := 1;
    select replace(lower(o_str), 'dbms_', 'dbms-') into o_str from dual;
  end if;

  --过滤
  if lower(o_str) like '%commit%' then
    v_isLog := 1;
    select replace(lower(o_str), 'commit', 'commi t') into o_str from dual;
  end if;

  --过滤
  if lower(o_str) like '%url_%' then
    v_isLog := 1;
    select replace(lower(o_str), 'url_', 'url-') into o_str from dual;
  end if;

  --过滤
  if lower(o_str) like '% truncate %' then
    v_isLog := 1;
    select replace(lower(o_str), ' truncate ', ' truncat e ')
      into o_str
      from dual;
  end if;

  /* if v_isLog = 1 then
    insert into t_log_limitstr
      (str, type, itime, source, getvalue)
    values
      (i_strInput, i_type, sysdate, i_source, i_getvalue);
    commit;
  end if;*/
  return o_str;
EXCEPTION
  WHEN OTHERS THEN
    --错误时，返回sql参数错误
    if i_type = 1 then
      o_str := 'wrong code参数错误 ';
    else
      o_str := o_str || '!';
    end if;

    /*  insert into t_log_limitstr
      (str, type, itime, source, getvalue)
    values
      (i_strInput, 9, sysdate, i_source, i_getvalue);
    commit;*/
    return o_str;
end FQ_String_limit;


/


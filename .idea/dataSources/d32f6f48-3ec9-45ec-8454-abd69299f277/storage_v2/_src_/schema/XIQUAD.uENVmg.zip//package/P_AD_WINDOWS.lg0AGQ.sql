create package P_AD_Windows is

  TYPE T_CURSOR IS REF CURSOR;

  /*windows 服务 信息获取与处理 */

  procedure PQ_RegUserList
  /*****************************************************************
        Procedure Name :PQ_UserList
        Purpose: 获取已注册用户列表
        Edit: 2016-12-08 add by 小沈
    ****************************************************************/
  (I_Sign      In Number, --标记符号 1，2，3……
   I_PageSize  In Number, --每页记录数
   I_PageNO    In Number, --当前页码,从 1 开始
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure PQ_AwardUserList
  /*****************************************************************
        Procedure Name :PQ_AwardUserList
        Purpose: 获取已获得奖励用户列表
        Edit: 2018-01-13 add by 小沈
    ****************************************************************/
  (I_Sign      In Number, --标记符号 1，2，3……
   I_PageSize  In Number, --每页记录数
   I_PageNO    In Number, --当前页码,从 1 开始
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure PQ_AllMain
  /*****************************************************************
        Procedure Name :PQ_AllMain
        Purpose: Windows服务奖励判断全部入口
         Edit: 2017-08-05 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_Urlid    In Number, --下载地址id 
   I_MerId    In Varchar2, --用户注册帐号id
   I_Levle    In Number, --用户等级、金额等
   I_AType    In Number, --  发奖类型 1 按固定值发放 
   I_AGroup   In Number, --组别
   O_Result   Out Number,
   O_Message  Out Varchar2);

  procedure PQ_Common
  /*****************************************************************
        Procedure Name :PQ_Common
        Purpose: 普通固定奖励发放 
         Edit: 2017-08-05 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_Urlid    In Number, --下载地址id 
   I_MerId    In Varchar2, --用户注册帐号id
   I_Levle    In Number, --用户等级、金额等
   I_AGroup   In Number, --组别
   O_Result   Out Number,
   O_Message  Out Varchar2);

  procedure PQ_DownUserList
  /*****************************************************************
        Procedure Name :PQ_DownUserList
        Purpose: 获取已下载用户列表
        Edit: 2017-11-26 add by 小沈
    ****************************************************************/
  (I_Sign      In Number, --标记符号 1，2，3……
   I_PageSize  In Number, --每页记录数
   I_PageNO    In Number, --当前页码,从 1 开始
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure PW_Get_Reg
  /*****************************************************************
        Procedure Name :PW_Get_Reg
        Purpose: Windows抓取注册信息
        Edit: 2017-11-26 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告id 
   I_APPID    In Number, --渠道ID
   I_UserId   In Number, --闲玩用户ID 
   I_FID      In Varchar2, --广告主统计的来源id[apk渠道编号] 
   I_DeviceId In Varchar2, --返回设备号imei idfa
   I_SIMID    In Varchar2, --返回sim卡id
   I_Merid    In Varchar2, --用户注册帐号id
   I_MerName  In Varchar2, --用户注册帐号 
   I_APPSign  In Varchar2, --用户注册帐号 
   O_Result   Out Number,
   O_Message  Out Varchar2);

  procedure PW_UpRunUser
  /*****************************************************************
        Procedure Name :FQ_UpRunUser
        Purpose: 修改跑数据用户信息
        Edit: 2018-07-20 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID 
   I_APPId    In Number, --渠道应用ID 
   I_Deviceid In Varchar2, --设备号ID 
   I_MerId    In Varchar2, --商家帐号id  
   I_Urlid    In Number --下载地址id 
   );

  Procedure Job_RegisterUser;
  /*****************************************************************
      Procedure Name :PW_RegisterUser
      Purpose: 获取注册用户信息
       Edit: 2017-07-21 add by 小沈
  ****************************************************************/

  Procedure Job_AwardUser;
  /*****************************************************************
      Procedure Name :Job_AwardUser
      Purpose: 获取那过奖励用户信息
       Edit: 2017-07-22 add by 小沈
  ****************************************************************/

  procedure PW_UpRunAwardUser
  /*****************************************************************
        Procedure Name :PW_UpRunAwardUser
        Purpose: 修改领奖跑数据用户信息
        Edit: 2018-07-21 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID 
   I_APPId    In Number, --渠道应用ID 
   I_Deviceid In Varchar2, --设备号ID 
   I_MerId    In Varchar2, --商家帐号id  
   I_Urlid    In Number --下载地址id 
   );

  Procedure Job_DownUser;
  /*****************************************************************
      Procedure Name :Job_DownUser
      Purpose: 获取仅下载用户信息
       Edit: 2017-07-22 add by 小沈
  ****************************************************************/

  procedure PW_UpRunDownUser
  /*****************************************************************
        Procedure Name :PW_UpRunDownUser
        Purpose: 修改跑数据用户信息
        Edit: 2018-07-20 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID 
   I_APPId    In Number, --渠道应用ID 
   I_UserId   In Number, --闲玩用户ID 
   I_Deviceid In Varchar2, --设备号ID  
   I_Urlid    In Number --下载地址id 
   );

  Procedure Job_DownUser_Fast;
  /*****************************************************************
      Procedure Name :Job_DownUser
      Purpose: 获取仅下载用户信息 10分钟到-小时内未注册用户
       Edit: 2017-07-22 add by 小沈
  ****************************************************************/

  procedure PW_UpRunDownUser_Fast
  /*****************************************************************
        Procedure Name :PW_UpRunDownUser_Fast
        Purpose: 修改跑数据用户信息--快速版
        Edit: 2018-07-22 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID 
   I_APPId    In Number, --渠道应用ID 
   I_UserId   In Number, --闲玩用户ID 
   I_Deviceid In Varchar2, --设备号ID  
   I_Urlid    In Number --下载地址id 
   );

  procedure PQ_DownUserFast_List
  /*****************************************************************
        Procedure Name :PQ_DownUserFast_List
        Purpose: 获取已下载用户列表
        Edit: 2018-07-22 add by 小沈
    ****************************************************************/
  (I_Sign      In Number, --标记符号 1，2，3……
   I_PageSize  In Number, --每页记录数
   I_PageNO    In Number, --当前页码,从 1 开始
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure PW_Get_Reg_Fast
  /*****************************************************************
        Procedure Name :PW_Get_Reg_Fast
        Purpose: Windows抓取注册信息
        Edit: 2018-12-09 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告id 
   I_APPID    In Number, --渠道ID
   I_UserId   In Number, --闲玩用户ID 
   I_FID      In Varchar2, --广告主统计的来源id[apk渠道编号] 
   I_DeviceId In Varchar2, --返回设备号imei idfa
   I_SIMID    In Varchar2, --返回sim卡id
   I_Merid    In Varchar2, --用户注册帐号id
   I_MerName  In Varchar2, --用户注册帐号 
   I_APPSign  In Varchar2, --用户注册帐号 
   O_Result   Out Number,
   O_Message  Out Varchar2);

  Procedure Job_Del_TempData;
  /*****************************************************************
      Procedure Name :Job_DelTempData
      Purpose: 删除已停止广告数据
       Edit: 2017-08-26 add by 小沈
  ****************************************************************/

  procedure PQ_TestList
  /*****************************************************************
        Procedure Name :PQ_TestList
        Purpose: 获取已注册用户列表
        Edit: 2017-08-05 add by 小沈
    ****************************************************************/
  (I_Sign      In Number, --标记符号 1，2，3……
   I_PageSize  In Number, --每页记录数
   I_PageNO    In Number, --当前页码,从 1 开始
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);
  procedure PW_CheckIsNewUser
  /*****************************************************************
        Procedure Name :p_Run_CheckIsNewUser
        Purpose: 更改用户是老用户还是新用户
        Edit: 2018-8-25 add by 小胡
    ****************************************************************/
  (I_ADID     In Number, --广告id
   I_APPID    In Number, --渠道编号
   I_DEVICEID In Varchar2, --设备号
   I_MERID    In Varchar2, --广告用户唯一标识 
   I_ISOLD    In Number, --是否是老用户 0：新用户； 1：老用户
   O_Result   Out Number,
   O_Message  Out Varchar2);
  procedure PQ_AwardUserList_v2
  /*****************************************************************
        Procedure Name :PQ_AwardUserList
        Purpose: 获取已获得奖励用户列表
        Edit: 2018-08-25 add by 小胡
    ****************************************************************/
  (I_Sign      In Number, --标记符号 1，2，3……
   I_PageSize  In Number, --每页记录数
   I_PageNO    In Number, --当前页码,从 1 开始
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);
  procedure PQ_RegUserList_V2
  /*****************************************************************
        Procedure Name :PQ_UserList
        Purpose: 获取已注册用户列表
        Edit: 2018-09-06 add by 小胡
    ****************************************************************/
  (I_Sign      In Number, --标记符号 1，2，3……
   I_PageSize  In Number, --每页记录数
   I_PageNO    In Number, --当前页码,从 1 开始
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);
end P_AD_Windows;
/


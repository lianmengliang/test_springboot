create PACKAGE P_WXAD_Info AS
  TYPE T_CURSOR IS REF CURSOR;

  /*分享广告页*/

  procedure PQ_ADInfo
  /*****************************************************************
        Procedure Name :PQ_ADInfo
        Purpose: 获取微信广告页面信息
        Edit: 2017-10-14 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   I_APPId     In Number, --渠道应用ID
   I_Deviceid  In Varchar2, --设备号ID
   I_SIMID     In Varchar2, --sim卡编号
   I_AppSign   In Varchar2, ---渠道标识
   I_PType     In Number, --1、ios  2、安卓
   O_Outcursor out t_cursor, --返回游标
   O_Result    out number, --判断 0：查询成功，其他：出错
   O_Message   out varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  PROCEDURE PQ_ADLimit
  /*****************************************************************
        Procedure Name :PQ_ADLimit
        Purpose: 获取微信广告用户限制信息 只有未参与的用户才回进入
        Edit: 2017-04-23 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_SIMID    In Varchar2, --sim卡编号
   I_PType    In Number, --1、ios  2、安卓
   O_Status   out number, -- 限制状态 0 正常 1、广告尚未投放 2、日流量到量 3、总流量到量 4、已停止投放 5、用户被限制  6、广告被限制 7、SIMID被限制  8、设备号限制
   O_Msg      out varchar2 --描述信息
   );

  procedure PW_CreateWechatKL
  /*****************************************************************
        Procedure Name :PW_CreateWechatKL
        Purpose: 创建微信口令
        Edit: 2017-10-14 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_SIMID    In Varchar2, --sim卡编号
   I_AppSign  In Varchar2, ---渠道标识
   I_PType    In Number, --1、ios  2、安卓 
   I_IP       In Varchar2, ---IP
   O_WechatKL Out Varchar2, --微信关注口令
   O_Result   Out Number, --判断 0：查询成功，其他：出错
   O_Message  Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  procedure PQ_GZ_List
  /*****************************************************************
        Procedure Name :PQ_List
        Purpose: 获取关注广告列表
        Edit: 2017-10-16 add by 小沈
    ****************************************************************/
  (I_APPId          In Number, --渠道应用ID
   I_Deviceid       In Varchar2, --设备号ID
   I_SIMID          In Varchar2, --sim卡编号
   I_AppSign        In Varchar2, ---渠道标识
   I_PType          In Number, --1、ios  2、安卓
   I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始 
   O_Outrecordcount Out Number, --返回总记录数
   O_Outcursor      Out t_cursor, --返回游标
   O_Result         Out Number, --判断 0：查询成功，其他：出错
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  Function FQ_GZ_IsShow
  /*****************************************************************
        Procedure Name :FQ_IsShow
        Purpose: 根据用户ID判断是否显示   -- 是否显示 0 不显示 1 显示关注
        Edit:  2017-01-17 by 小沈  
    ****************************************************************/
  (I_APPId    In Number, --渠道应用ID
   I_ADID     In Number, --广告ID 
   I_Deviceid In Varchar2, --设备号ID 
   I_PType    In Number --1、ios  2、安卓
   ) Return Number;
end P_WXAD_Info;


/


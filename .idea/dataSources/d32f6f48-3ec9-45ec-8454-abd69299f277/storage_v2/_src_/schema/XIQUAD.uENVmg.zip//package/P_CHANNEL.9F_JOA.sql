create package P_Channel is

  TYPE T_CURSOR IS REF CURSOR;

  /*渠道信息*/

  procedure pw_CheckSecret
  /*****************************************************************
        Procedure Name :pw_CheckSecret
        Purpose: 校验渠道密钥是否正确
        Edit: 2017-02-19 add by 小沈
    ****************************************************************/
  (I_APPId     In Number, --渠道应用ID
   I_APPSecret In Varchar2, --  密钥 --随机字母字符串组成 16位
   O_Result    Out number,
   O_Message   Out varchar2);

  procedure PQ_GetSecret
  /*****************************************************************
        Procedure Name :PQ_GetSecret
        Purpose: 获取渠道密钥是否正确
        Edit: 2017-03-16 add by 小沈
    ****************************************************************/
  (I_APPId      In Number, --渠道应用ID
   O_RAPPSecret Out Varchar2, -- 返回 密钥  
   O_Result     Out number,
   O_Message    Out varchar2);

  procedure PQ_GetInfo
  /*****************************************************************
        Procedure Name :PQ_GetInfo
        Purpose: 获取渠道信息
        Edit: 2017-06-7 add by 小沈
    ****************************************************************/
  (I_APPId     In Number, --渠道应用ID
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out number,
   O_Message   Out varchar2);

end P_Channel;


/


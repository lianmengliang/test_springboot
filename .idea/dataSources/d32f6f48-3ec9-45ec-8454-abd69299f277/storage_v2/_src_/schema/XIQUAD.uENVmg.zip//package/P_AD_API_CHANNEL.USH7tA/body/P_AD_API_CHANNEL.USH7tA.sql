create PACKAGE BODY P_AD_API_Channel AS

  /*
  渠道广告API接口查询
  2018-06-20
  */

  procedure PQ_List
  /*****************************************************************
        Procedure Name :PQ_List
        Purpose: 获取广告列表
        Edit: 2018-06-20 add by 小沈
    ****************************************************************/
  (I_APPId          In Number, --渠道应用ID 
   I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始
   O_Outrecordcount Out Number, --返回总记录数
   O_Outcursor      Out t_cursor, --返回游标
   O_Result         Out Number, --判断 0：查询成功，其他：出错
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n number;
  
    v_atype     number; --应用类型 1苹果 2安卓 
    V_SQL       varchar2(3000);
    v_Sql_Where varchar2(200);
  
    V_HeiRowNUM number; --小于第几行 分页用
    V_LowRowNUM number; --大于第几行 分页用
    v_PageSize  number;
    v_PageNO    number;
  
  begin
    v_PageSize := I_PageSize;
    v_PageNO   := I_PageNO;
  
    O_Result  := 0;
    O_Message := '查询成功';
  
    select count(1)
      into v_n
      from ad_channel
     where appid = I_APPId
       and status != 2;
  
    if v_n <= 0 then
      O_Result  := 1;
      O_Message := '渠道信息不存在';
      return;
    end if;
  
    ----------------------------------------------------
    --步骤二：返回记录集
  
    select atype into v_atype from ad_channel where appid = I_APPId;
    if v_atype = 1 then
      v_Sql_Where := ' and phonetype in (1,3 ) ';
    else
      v_Sql_Where := ' and phonetype in (2,3 ) ';
    end if;
  
    V_SQL := 'select adid,adname,to_char(starttime ,''yyyy-mm-dd hh24:mi:ss'') starttime ,to_char(stoptime,''yyyy-mm-dd hh24:mi:ss'') stoptime from ad_adinfo 
    where status =1 and showtype=1 ' || v_Sql_Where ||
             '  and  p_ad_api_channel.fq_isshow(adid) =1  order by starttime desc';
  
    ----执行分页查询
    V_HeiRowNUM := v_PageNO * v_PageSize;
    V_LowROWNUM := V_HeiRowNUM - v_PageSize + 1;
  
    execute immediate 'select count(1) from (' || V_SQL || ')'
      into O_Outrecordcount;
  
    V_SQL := ' select    adid,adname,starttime ,stoptime, (select count(1) from ad_awardset where appid='||I_APPId||' and adid=b.adid )  isset  from (
     select   adid,adname,starttime ,stoptime,rownum rn from (  ' ||
             V_SQL || ') a where rownum <=' || to_char(V_HeiRowNUM) ||
             ') b where  rn >= ' || to_char(V_LowROWNUM) || ' ';
    --注意对rownum别名的使用,第一次直接用rownum,第二次一定要用别名rn
    --- order by 放里面会影响速度
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    OPEN O_OUTCURSOR FOR V_SQL;
    commit;
    return;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '查询失败';
      return;
  end PQ_List;

  procedure PQ_InterfaceIntro
  /*****************************************************************
        Procedure Name :PQ_InterfaceIntro
        Purpose: 获取广告接口介绍
        Edit: 2018-07-04 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   I_APPId     In Number, --渠道应用ID 
   O_Intro     Out varchar2, --返回接口简介
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out number, --判断 0：查询成功，其他：出错
   O_Message   Out varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n         number;
    v_phonetype number; --1、ios，  2、安卓， 3、ios和安卓都显示 
    v_appid     number; --查看结算appid
    v_jsont     number; --json 返回格式类型  1、含子对象  2、数组对象 3、对象 4、多数组对象 
    v_jsons     varchar(100);
    v_jsonv     varchar(100);
    v_jsonitem  varchar(100);
    v_jsonmsg   varchar(100);
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
  
    if I_Adid is null then
      O_Result  := 1;
      O_Message := '广告ID不能为空';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_channel
     where appid = I_APPId
       and status != 2;
  
    if v_n <= 0 then
      O_Result  := 2;
      O_Message := '渠道信息不存在';
      return;
    end if;
  
    select count(1) into v_n from ad_adinfo where adid = I_ADID;
    if v_n <= 0 then
      O_Result  := 3;
      O_Message := '广告不存在';
      return;
    end if;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
  
    select jsont, jsons, jsonv, jsonitem, jsonmsg
      into v_jsont, v_jsons, v_jsonv, v_jsonitem, v_jsonmsg
      from ad_interf_levle
     where adid = I_ADID;
  
    -- 1、含子对象  2、数组对象 3、对象 4、多数组对象 
    case v_jsont
      when 1 then
        O_Intro := 'Json类型：含子对象;';
      when 2 then
        O_Intro := 'Json类型：数组对象;';
      when 3 then
        O_Intro := 'Json类型：对象;';
      when 4 then
        O_Intro := 'Json类型：多数组对象;';
      else
        O_Intro := 'Json类型：其他;';
    end case;
  
    O_Intro := O_Intro || '   状态判断字段：' || v_jsons || '   值为：' || v_jsonv ||
               '表示正确 ';
  
    if v_jsonitem is not null then
      O_Intro := O_Intro || '; 子对象为：' || v_jsonitem;
    end if;
    O_Intro := O_Intro || ' ; 消息值字段：' || v_jsonmsg;
  
    OPEN O_OUTCURSOR FOR
      select adid, event, param, preparam, prevaule
        from ad_interf_group
       where adid = I_ADID;
  
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    commit;
    return;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      ROLLBACK;
      O_Result  := -9;
      O_Message := '查询失败';
      RETURN;
  end PQ_InterfaceIntro;

  procedure PQ_AwardList
  /*****************************************************************
        Procedure Name :PQ_AwardList
        Purpose: 获取广告奖励结算
        Edit: 2018-06-20 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   I_APPId     In Number, --渠道应用ID 
   O_Outcursor out t_cursor, --返回游标
   O_Result    out number, --判断 0：查询成功，其他：出错
   O_Message   out varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n         number;
    v_phonetype number; --1、ios，  2、安卓， 3、ios和安卓都显示 
    v_appid     number; --查看结算appid
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
  
    if I_Adid is null then
      O_Result  := 1;
      O_Message := '广告ID不能为空';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_channel
     where appid = I_APPId
       and status != 2;
  
    if v_n <= 0 then
      O_Result  := 2;
      O_Message := '渠道信息不存在';
      return;
    end if;
  
    select count(1) into v_n from ad_adinfo where adid = I_ADID;
    if v_n <= 0 then
      O_Result  := 3;
      O_Message := '广告不存在';
      return;
    end if;
  
    select phonetype into v_phonetype from ad_adinfo where adid = I_ADID;
    if v_phonetype = 1 then
      v_appid := 1011;
    else
      v_appid := 1010;
    end if;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
  
    OPEN O_OUTCURSOR FOR
      select adid, dlevel, event, price, amoney
        from ad_awardset
       where appid = v_appid
         and adid = i_adid order by dlevel asc;
 
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    commit;
    return;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      ROLLBACK;
      O_Result  := -9;
      O_Message := '查询失败';
      RETURN;
  end PQ_AwardList;

  procedure PQ_DownUrl
  /*****************************************************************
        Procedure Name :PQ_DownUrl
        Purpose: 获取广告下载地址
        Edit: 2017-06-27 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   I_APPId     In Number, --渠道应用ID 
   O_Outcursor out t_cursor, --返回游标
   O_Result    out number, --判断 0：查询成功，其他：出错
   O_Message   out varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n         number;
    v_phonetype number; --1、ios，  2、安卓， 3、ios和安卓都显示 
    v_appid     number; --查看结算appid
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
  
    if I_Adid is null then
      O_Result  := 1;
      O_Message := '广告ID不能为空';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_channel
     where appid = I_APPId
       and status != 2;
  
    if v_n <= 0 then
      O_Result  := 2;
      O_Message := '渠道信息不存在';
      return;
    end if;
  
    select count(1) into v_n from ad_adinfo where adid = I_ADID;
    if v_n <= 0 then
      O_Result  := 3;
      O_Message := '广告不存在';
      return;
    end if;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
  
    OPEN O_OUTCURSOR FOR
      select adid,
             phonetype,
             dayflux,
             allflux,
             downtype,
             appurl,
             to_char(fluxtime, 'hh24:mi:ss') fluxtime
        from ad_downurl
       where adid = i_adid;
  
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    commit;
    return;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      ROLLBACK;
      O_Result  := -9;
      O_Message := '查询失败';
      RETURN;
  end PQ_DownUrl;

  Function FQ_IsShow
  /*****************************************************************
        Procedure Name :FQ_IsShow
        Purpose: 判断是否显示 0 不显示 1 显示
        Edit: 2018-06-27 add by 小沈
    ****************************************************************/
  (I_ADID In Number --广告ID
   ) Return Number As
    PRAGMA AUTONOMOUS_TRANSACTION; -------------方法函数 被嵌套，且有表操作 必写
    -- 是否显示 0 不显示 1 显示 
    v_n number;
  begin
  
    --如果有需要符号替换的则不显示
    select count(1)
      into v_n
      from (select *
              from ad_downurl
             where adid = I_ADID
               and instr(appurl, '[') > 0);
    if v_n > 0 then
      return 0;
    end if;
  
    --如果没有注册查询接口则不显示
    select count(1) into v_n from ad_interf_reg where adid = I_ADID;
  
    if v_n <= 0 then
      return 0;
    end if;
  
    return 1;
  exception
    --失败
    when others then
      --v_msg := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      rollback;
      return 0;
  end FQ_IsShow;

end P_AD_API_Channel;
/


create package body P_Job_ACAward is

  Procedure Job_AcAwardWaitCheck
    /*****************************************************************
          procedure name: Job_AcAwardWaitCheck
          purpose: 盒子奖励等待表处理
          edit: 2019-08-19 add by ReveeWu
      ****************************************************************/
  is
    v_n             number;
    v_awardTimes    number; -- 单步奖励的奖励次数
    v_Event         varchar2(500); -- 奖励描述
    v_OwnUser       number; --是否是自由用户 0：不是  1：是
    v_batchid       varchar2(50);
    v_Remark        varchar2(2000);
    v_result        number;
    v_result_vip    number;
    v_message       varchar2(200);
    v_integral      number; --是否是有积分   1有积分   0无积分
    v_ptype         number;
    v_vipGoodsValue number; --vip金额
    v_userId        number := 0;
  begin
    --默认为有积分
    v_integral := 1;
    --默认vip发奖结果为成功
    v_result_vip :=0;
    ----------------------------------------------------
    --步骤一：初始化
    ----------------------------------------------------
    select count(1)
           into v_n
    from ta_award_wait
    where itime > sysdate - 1 / 12
      and status = 1;
    --如果有数据还正在处理则此次job不做处理
    if v_n > 0 then
      return;
    end if;
    declare
      cursor AwardWait_List is
        select id,
               adid,
               appid,
               deviceid,
               userid,
               ptype,
               simid,
               appsign,
               merid,
               mername,
               ulevel,
               amoney,
               dlevel,
               needlevel,
               awardgroup,
               batchid,
               status,
               remark
        from ta_award_wait
        where batchid = v_batchid
          and status = 1
        order by itime asc;

    begin
      --使用随机数和日期组合批次号
      select dbms_random.string('a', 5) into v_batchid from dual;
      v_batchid := to_char(sysdate, 'yyyymmddhh24miss') || v_batchid;

      --每次处理100条
      update ta_award_wait
      set batchid = v_batchid, status = 1, utime = sysdate
      where status = 0
        and id in (select id
                   from (select id
                         from ta_award_wait
                         where status = 0
                           and itime >= sysdate - 0.5
                         order by itime asc)
                   where rownum <= 100);
      commit;

      for C_AwardWait in AwardWait_List loop
        v_awardTimes := 0;
        v_Event      := '';
        v_message    := '';
        begin
          if C_AwardWait.Userid=0 then
            select MG_USERID into v_userId from T_ADWALL_LOCAL_USER_REL where APPID=C_AwardWait.appid and APPSIGN = C_AwardWait.appsign;
          end if;
          if v_userId =0 then
            v_result :=20;
            v_result_vip :=20;
            v_message :='用户目前不存在，奖励失败';
          else
            --由闲玩发奖，则增加主库的用户余额
            v_Remark := '完成奖励【' || C_AwardWait.remark || '】';
            p_ad_award.PW_ReWard(i_userid   => v_userId,
                                 i_money    => C_AwardWait.amoney,
                                 i_type     => 0,
                                 i_remark   => v_Remark,
                                 i_deviceid => C_AwardWait.deviceid,
                                 i_appid    => C_AwardWait.appid,
                                 i_appsign  => C_AwardWait.appsign,
                                 I_Internal => v_integral,
                                 I_Ptype    => v_ptype,
                                 I_Owner    => v_OwnUser,
                                 o_result   => v_result,
                                 o_message  => v_message);
            --VIP卡券额外奖励
            select nvl(goods_value, 0) into v_vipGoodsValue
            from (select goods_value
                  from TA_MANOR_USER_COUPON
                  where USER_ID = v_userId and GOODS_TYPE = 0 and EFFECT_STATUS = 1 and DEAD_TIME >= sysdate
                  union
                  select null from dual)
            where rownum = 1;
            if v_vipGoodsValue != 0 then
              v_Remark := 'VIP加成奖励【' || C_AwardWait.remark || '】';
              p_ad_award.PW_ReWard(i_userid   => v_userId,
                                   i_money    => v_vipGoodsValue * C_AwardWait.amoney,
                                   i_type     => 4,
                                   i_remark   => v_Remark,
                                   i_deviceid => C_AwardWait.deviceid,
                                   i_appid    => C_AwardWait.appid,
                                   i_appsign  => C_AwardWait.appsign,
                                   I_Internal => v_integral,
                                   I_Ptype    => v_ptype,
                                   I_Owner    => v_OwnUser,
                                   o_result   => v_result_vip,
                                   o_message  => v_message);
            end if;
          end if;


          if v_result = 0 and v_result_vip = 0 then
            update ta_award_wait
            set status = 2, utime = sysdate, msg = '闲玩奖励成功'
            where id = C_AwardWait.id
              and status = 1;
          else
            v_message := '奖励失败 v_result：' || v_result || 'v_result_vip ：' || v_result_vip;
            update ta_award_wait
            set status = 3, utime = sysdate, msg = v_message
            where id = C_AwardWait.id
              and status = 1;
          end if;

          <<CONTINUE_LOOP>>
          commit;
          --单条异常处理
        exception
          when others then
            rollback;
            v_message := '奖励异常 编码：' || SQLCODE || '信息 ：' || sqlerrm;
            update ta_award_wait
            set status = 3, utime = sysdate, msg = v_message
            where id = C_AwardWait.id;
            commit;
        end;
      end loop;
    end;
  exception
    when others then
      rollback;
      return;
  end Job_AcAwardWaitCheck;

end P_Job_ACAward;
/


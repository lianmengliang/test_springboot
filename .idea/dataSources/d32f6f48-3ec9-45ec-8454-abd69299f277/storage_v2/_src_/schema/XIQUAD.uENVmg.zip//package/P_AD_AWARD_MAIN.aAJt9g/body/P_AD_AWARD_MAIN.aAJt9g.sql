create package body P_AD_Award_Main is

  /*奖励主入口 2.0 */

  procedure PQ_AllMain
  /*****************************************************************
        Procedure Name :PQ_AllMain
        Purpose: 奖励判断全部入口
        Edit: 2018-04-12 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_SIMID    In Varchar2, --返回sim卡id
   I_Userid   In Number, --闲玩用户编号
   I_PType    In Number, --1、ios  2、安卓
   I_MerId    In Varchar2, --用户注册帐号id
   I_MerName  In Varchar2, --用户注册帐号
   I_Levle    In Number, --用户等级、金额等
   I_AType    In Number, --  发奖类型 1 按固定值发放
   I_AGroup   In Number, --组别
   O_AMoney   Out Number, --奖励金额
   O_Result   Out Number,
   O_Message  Out Varchar2) is
    V_Money number;
  begin
    o_result  := 0;
    o_message := '奖励成功';
    O_AMoney  := 0;
  
    if I_APPId = 1502 then
      o_result  := 0;
      o_message := '暂停奖励';
      return;
    end if;
  
    p_ad_award_main.pq_common(i_adid     => i_adid,
                              i_appid    => i_appid,
                              i_deviceid => i_deviceid,
                              i_simid    => i_simid,
                              i_userid   => i_userid,
                              i_ptype    => i_ptype,
                              i_merid    => i_merid,
                              i_mername  => i_mername,
                              i_levle    => i_levle,
                              i_agroup   => i_agroup,
                              o_amoney   => V_Money,
                              o_result   => O_Result,
                              o_message  => O_Message);
  
    O_AMoney := O_AMoney + V_Money;
  
    commit;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      o_result  := 1001;
      o_message := '接收异常！';
      RETURN;
  end PQ_AllMain;

  procedure PQ_Common
  /*****************************************************************
        Procedure Name :PQ_Common
        Purpose: 普通固定奖励发放
        Edit: 2018-04-11 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_SIMID    In Varchar2, --返回sim卡id
   I_Userid   In Number, --闲玩用户编号
   I_PType    In Number, --1、ios  2、安卓
   I_MerId    In Varchar2, --用户注册帐号id
   I_MerName  In Varchar2, --用户注册帐号
   I_Levle    In Number, --用户等级、金额等
   I_AGroup   In Number, --组别
   O_AMoney   Out Number, --奖励金额
   O_Result   Out Number,
   O_Message  Out Varchar2) is
    v_n            Number;
    v_ptype        Number; -- 下载时手机类型 1苹果  2安卓
    v_Deviceid     varchar2(100); --设备号
    v_ADStatus     Number; --投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放） 
    v_adname       Varchar2(100); --广告名称--对外
    v_adtype       Number; --广告类型（1游戏，2应用，3其他） 
    V_IsShow       Number; --是否显示 0 否  1是  判断用户是否可以体验
    v_ordernum     Varchar2(100); --订单编号
    v_pagename     Varchar2(100); --包名
    v_pagename_and Varchar2(100); --安卓包名
    v_pagename_ios Varchar2(100); --苹果包名
    v_appsign      Varchar2(200); --渠道应用标识符号、渠道用户id
    v_urlid        Number; --下载编号
    v_dlevel       number; --奖励级别
    v_event        Varchar2(500); --奖励说明
    v_AGroup       number; --奖励组别
    cursor myCur_award is
      select dlevel,
             event,
             needlevel,
             times,
             atype,
             awardgroup,
             price,
             amoney,
             isshow
        from ad_awardset
       where adid = I_ADID
         and appid = I_APPId
         and awardgroup = I_AGroup
       order by dlevel desc;
  
  begin
    O_Result  := 0;
    O_Message := '奖励成功！';
    O_AMoney  := 0; --奖励金额
  
    if I_ADID is null then
      O_Result  := 10;
      O_Message := '请返回后刷新，再重新点击进入';
      return;
    end if;
  
    --去空格处理
    v_DeviceId := fq_str_delspace(i_str => I_Deviceid);
    --设备号校验是否合法 0否 1是
    if p_base_fun.fq_deviceid_check(v_DeviceId, I_PType) = 0 then
      O_Result  := 10;
      O_Message := '请先对APP进行授权';
      return;
    end if;
  
    if v_DeviceId is null then
      O_Result  := 10;
      O_Message := '需要先对APP进行授权';
      return;
    end if;
  
    --获取广告名称和包名
    select status, adname, pagename, iospagename, adtype
      into v_ADStatus, v_adname, v_pagename_and, v_pagename_ios, v_adtype
      from ad_adinfo
     where adid = I_ADID;
  
    if v_ADStatus in (0, 4) then
      O_Result  := 10;
      O_Message := '广告未投放或已停止！';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_awardset
     where adid = i_adid
       and appid = I_APPId
       and awardgroup = I_AGroup;
    if v_n = 0 then
      O_RESULT  := 10;
      O_MESSAGE := '奖励参数尚未设置';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_app_bind
     where adid = I_ADID
       and merid = I_MerId;
    --如果1个账号ID存在2个以上 则说明有问题，直接不显示
    if v_n >= 2 then
      O_RESULT  := 15;
      O_MESSAGE := '您的应用账号存在异常，不予奖励！请联系管理员';
      return;
    end if;
  
    --判断用户是否被限制
    --设备号限制表判断
    select count(1)
      into v_n
      from ad_limit_deviceid
     where adid = i_adid
       and deviceid = v_DeviceId;
    if v_n > 0 then
      O_RESULT  := 18;
      O_MESSAGE := '您暂时无法体验该任务，不予奖励！请联系管理员';
      return;
    end if;
  
    --用户限制表判断
    select count(1)
      into v_n
      from ad_limit_user
     where adid = i_adid
       and userid = i_userid;
    if v_n > 0 then
      O_RESULT  := 20;
      O_MESSAGE := '您暂时无法体验该任务，不予奖励！请联系管理员';
      return;
    end if;
  
    ---判断用户是否可以参与该广告
    -- 是否显示 0 不显示 1 显示 
  
    v_IsShow := p_ad_isshow_v2.fq_isshow(i_adid     => i_adid,
                                         i_appid    => i_appid,
                                         i_deviceid => v_DeviceId,
                                         i_userid   => i_userid,
                                         i_ptype    => i_ptype);
  
    if v_IsShow = 0 then
      O_Result  := 10;
      O_Message := '您无法参与该广告，请返回后体验其他广告！';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_app_bind
     where adid = I_ADID
       and appid = I_APPId
       and userid = I_Userid
       and upper(merid) = upper(I_MerId); --用帐号匹配更恰当，判断帐号是否一致
  
    if v_n <= 0 then
      O_RESULT  := 11;
      O_MESSAGE := '您还未下载或注册该任务';
      return;
    end if;
  
    --判断是否有注册奖励，如果有的话，需要先完成
    select count(1)
      into v_n
      from ad_awardset
     where adid = i_adid
       and appid = I_APPId
       and atype = 1;
  
    if v_n > 0 then
      select dlevel, event, awardgroup
        into v_dlevel, v_event, v_AGroup
        from ad_awardset
       where adid = i_adid
         and appid = I_APPId
         and atype = 1;
    
      if v_AGroup != I_AGroup then
        select count(1)
          into v_n
          from ad_app_flux
         where adid = I_ADID
           and userid = I_Userid
           and dlevel = v_dlevel;
      
        if v_n <= 0 then
          O_RESULT  := 11;
          O_MESSAGE := '请先完成' || v_event;
          return;
        end if;
      end if;
    end if;
  
    --判断同组奖励该设备号是否已存在有则不奖励  t_ad_channel_order
    if I_AGroup >= 90 then
      --如果为同组奖励 表示该组别中的奖励 用户只能领取其中一个 ，领取过其中一个则该组别其他奖励均为过期
      --不加 appid 放宽 查询条件
      select count(1)
        into v_n
        from ad_app_flux
       where adid = I_ADID
         and (userid = I_Userid or deviceid = upper(v_DeviceId))
         and dlevel in (select dlevel
                          from ad_awardset
                         where adid = I_ADID
                           and appid = I_APPId
                           and awardgroup = I_AGroup);
    
      if v_n > 0 then
        O_RESULT  := 12;
        O_MESSAGE := '已经有过该奖励了';
        return;
      end if;
    
    end if;
  
    --获取当时用户下载时的设备 为苹果还是安卓，和渠道标识
    select ptype, appsign, urlid
      into v_ptype, v_appsign, v_urlid
      from ad_app_bind
     where adid = I_ADID
       and appid = I_APPId
       and userid = I_Userid;
  
    ---- 下载时手机类型 1苹果  2安卓
    if v_ptype = 1 then
      v_pagename := v_pagename_ios;
    else
    
      v_pagename := v_pagename_and;
    end if;
  
    for cur in myCur_award loop
    
      --内部循环奖励也需要判断 
      --判断同组奖励该设备号是否已存在有则不奖励  t_ad_channel_order
      if I_AGroup >= 90 then
        --如果为同组奖励 表示该组别中的奖励 用户只能领取其中一个 ，领取过其中一个则该组别其他奖励均为过期
        select count(1)
          into v_n
          from ad_app_flux
         where adid = I_ADID
           and (userid = I_Userid or deviceid = upper(v_DeviceId))
           and dlevel in (select dlevel
                            from ad_awardset
                           where adid = I_ADID
                             and appid = I_APPId
                             and awardgroup = I_AGroup);
      
        if v_n > 0 then
          O_RESULT  := 12;
          O_MESSAGE := '已经获得过该奖励了';
          return;
        end if;
      
      end if;
    
      select count(1)
        into v_n
        from ad_app_flux
       where adid = I_ADID
         and (userid = I_Userid or deviceid = upper(v_DeviceId))
         and dlevel = cur.dlevel;
    
      --如果该设备已经获取过该奖励则跳过
      if v_n >= cur.times then
        GOTO CONTINUE_LOOP;
      end if;
    
      --游戏级别不够，不奖励
      if cur.needlevel > I_Levle then
        GOTO CONTINUE_LOOP;
      end if;
    
      insert into ad_app_flux
        (id,
         adid,
         appid,
         deviceid,
         appsign,
         dlevel,
         merid,
         money,
         event,
         adtype,
         atype,
         simid,
         urlid,
         price,
         userid,
         ptype)
        select SQ_AD_FLUX.NEXTVAL,
               I_ADID,
               I_APPId,
               upper(v_DeviceId),
               v_appsign,
               cur.dlevel,
               I_MerId,
               cur.amoney,
               cur.event,
               v_adtype,
               cur.atype,
               I_simid,
               v_urlid,
               cur.price,
               i_userid,
               i_ptype
          from dual
         where (select count(1)
                  from ad_app_flux
                 where adid = I_ADID
                   and (userid = I_Userid or deviceid = upper(v_DeviceId))
                   and dlevel = cur.dlevel) < cur.times;
    
      if cur.isshow = 1 then
      
        --累加奖励
        O_AMoney := O_AMoney + cur.amoney;
      
        v_ordernum := I_APPId || to_char(sysdate, 'yyyymmddhh24miss') ||
                      I_ADID || dbms_random.string('x', 5) ||
                      trunc(dbms_random.value(0, 10));
      
        insert into ad_channel_order
          (adid,
           adname,
           appid,
           ordernum,
           dlevel,
           awardgroup,
           pagename,
           deviceid,
           simid,
           appsign,
           merid,
           mername,
           event,
           price,
           money)
        values
          (I_ADID,
           v_adname,
           I_APPId,
           v_ordernum,
           cur.dlevel,
           cur.awardgroup,
           v_pagename,
           I_Deviceid,
           I_SIMID,
           v_appsign,
           I_MerId,
           I_MerName,
           v_adname || cur.event,
           cur.price,
           cur.amoney);
      
      end if;
      commit;
          select count(1)
        into v_n
        from ad_app_users
       where userid = I_Userid
         and getedmoney = 0;
      if v_n > 0 then
        update ad_app_users set getedmoney = 1 where userid = I_Userid;
        commit;
      end if;
    
      <<CONTINUE_LOOP>>
      null;
    
    end loop;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 1001;
      O_Message := '领取奖励异常！';
      -- o_message := '领取奖励异常 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PQ_Common;
  procedure PQ_AllMain_windows
  /*****************************************************************
        Procedure Name :PQ_AllMain
        Purpose: 奖励判断全部入口
        Edit: 2018-11-21 add by 小胡
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_SIMID    In Varchar2, --返回sim卡id
   I_MerId    In Varchar2, --用户注册帐号id
   I_MerName  In Varchar2, --用户注册帐号
   I_Levle    In Number, --用户等级、金额等
   I_AType    In Number, --  发奖类型 1 按固定值发放 
   I_AGroup   In Number, --组别
   O_AMoney   Out Number, --奖励金额
   O_Result   Out Number,
   O_Message  Out Varchar2) is
    V_Money number;
  begin
    o_result  := 0;
    o_message := '接收成功';
    O_AMoney  := 0;
  
    P_AD_Award_Main.PQ_Common_Windows(i_adid     => I_ADID,
                                      i_appid    => I_APPId,
                                      i_deviceid => I_Deviceid,
                                      i_simid    => I_SIMID,
                                      i_merid    => I_MerId,
                                      i_mername  => I_MerName,
                                      i_levle    => I_Levle,
                                      i_agroup   => I_AGroup,
                                      o_amoney   => V_Money,
                                      o_result   => O_Result,
                                      o_message  => O_Message);
    O_AMoney := O_AMoney + V_Money;
  
    commit;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      o_result  := 1001;
      o_message := '接收异常！';
      RETURN;
  end PQ_AllMain_windows;

  procedure PQ_Common_Windows
  /*****************************************************************
        Procedure Name :PQ_Common
        Purpose: 普通固定奖励发放 
        Edit: 2018-11-21 add by 小胡
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_SIMID    In Varchar2, --返回sim卡id
   I_MerId    In Varchar2, --用户注册帐号id
   I_MerName  In Varchar2, --用户注册帐号
   I_Levle    In Number, --用户等级、金额等
   I_AGroup   In Number, --组别
   O_AMoney   Out Number, --奖励金额
   O_Result   Out Number,
   O_Message  Out Varchar2) is
    v_n            Number;
    v_ptype        Number; -- 下载时手机类型 1苹果  2安卓
    v_adname       Varchar2(100); --广告名称--对外
    v_adtype       Number; --广告类型（1游戏，2应用，3其他） 
    v_ordernum     Varchar2(100); --订单编号
    v_pagename     Varchar2(100); --包名
    v_pagename_and Varchar2(100); --安卓包名
    v_pagename_ios Varchar2(100); --苹果包名
    v_appsign      Varchar2(200); --渠道应用标识符号、渠道用户id 
    v_urlid        Number; --下载编号  
    v_dlevel       number; --奖励级别 
    v_event        Varchar2(500); --奖励说明 
    v_AGroup       number; --奖励组别
    cursor myCur_award is
      select dlevel,
             event,
             needlevel,
             times,
             atype,
             awardgroup,
             price,
             amoney,
             isshow
        from ad_awardset
       where adid = I_ADID
         and appid = I_APPId
         and awardgroup = I_AGroup
       order by dlevel desc;
  
  begin
    O_Result  := 0;
    O_Message := '奖励成功！';
    O_AMoney  := 0; --奖励金额 
  
    select count(1)
      into v_n
      from ad_awardset
     where adid = i_adid
       and appid = I_APPId
       and awardgroup = I_AGroup;
    if v_n = 0 then
      O_RESULT  := 10;
      O_MESSAGE := '奖励参数尚未设置';
      return;
    end if;
  
    --1899棋牌2期 VIP4级不给奖励
    if I_ADID = 2479 and I_Levle >= 5 and I_AGroup = 1 then
      O_RESULT  := 10;
      O_MESSAGE := 'VIP5暂时不予奖励！';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_app_bind
     where adid = I_ADID
       and appid = I_APPId
       and upper(deviceid) = upper(I_Deviceid)
       and upper(merid) = upper(I_MerId);
  
    if v_n <= 0 then
      O_RESULT  := 11;
      O_MESSAGE := '您还未下载或注册该任务';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_app_bind
     where adid = I_ADID
       and merid = I_MerId;
    --如果1个账号ID存在2个以上 则说明有问题，直接不显示
    if v_n >= 2 then
      O_RESULT  := 15;
      O_MESSAGE := '您的应用账号存在异常，不予奖励！请联系管理员';
      return;
    end if;
  
    --判断是否有注册奖励，如果有的话，需要先完成
    select count(1)
      into v_n
      from ad_awardset
     where adid = i_adid
       and appid = I_APPId
       and atype = 1;
  
    if v_n > 0 then
      select dlevel, event, awardgroup
        into v_dlevel, v_event, v_AGroup
        from ad_awardset
       where adid = i_adid
         and appid = I_APPId
         and atype = 1;
    
      if v_AGroup != I_AGroup then
        select count(1)
          into v_n
          from ad_app_flux
         where adid = I_ADID
           and deviceid = upper(I_Deviceid)
           and dlevel = v_dlevel;
      
        if v_n <= 0 then
          O_RESULT  := 11;
          O_MESSAGE := '请先完成' || v_event;
          return;
        end if;
      end if;
    end if;
  
    --判断同组奖励该设备号是否已存在有则不奖励  t_ad_channel_order
    if I_AGroup >= 90 then
      --如果为同组奖励 表示该组别中的奖励 用户只能领取其中一个 ，领取过其中一个则该组别其他奖励均为过期
      --不加 appid 放宽 查询条件 
      select count(1)
        into v_n
        from ad_app_flux
       where adid = I_ADID
         and upper(deviceid) = upper(I_Deviceid)
         and dlevel in (select dlevel
                          from ad_awardset
                         where adid = I_ADID
                           and appid = I_APPId
                           and awardgroup = I_AGroup);
    
      if v_n > 0 then
        O_RESULT  := 12;
        O_MESSAGE := '已经有过该奖励了';
        return;
      end if;
    
    end if;
  
    --获取当时用户下载时的设备 为苹果还是安卓，和渠道标识
    select ptype, appsign, urlid
      into v_ptype, v_appsign, v_urlid
      from ad_app_bind
     where adid = I_ADID
       and appid = I_APPId
       and upper(deviceid) = upper(I_Deviceid);
  
    --获取广告名称和包名
    select adname, pagename, iospagename, adtype
      into v_adname, v_pagename_and, v_pagename_ios, v_adtype
      from ad_adinfo
     where adid = I_ADID;
  
    ---- 下载时手机类型 1苹果  2安卓
    if v_ptype = 1 then
      v_pagename := v_pagename_ios;
    else
    
      v_pagename := v_pagename_and;
    end if;
  
    for cur in myCur_award loop
    
      --判断同组奖励该设备号是否已存在有则不奖励  t_ad_channel_order
      if I_AGroup >= 90 then
        --如果为同组奖励 表示该组别中的奖励 用户只能领取其中一个 ，领取过其中一个则该组别其他奖励均为过期
        select count(1)
          into v_n
          from ad_app_flux
         where adid = I_ADID
           and upper(deviceid) = upper(I_Deviceid)
           and dlevel in (select dlevel
                            from ad_awardset
                           where adid = I_ADID
                             and appid = I_APPId
                             and awardgroup = I_AGroup);
      
        if v_n > 0 then
          O_RESULT  := 12;
          O_MESSAGE := '已经获得过该奖励了';
          return;
        end if;
      
      end if;
    
      select count(1)
        into v_n
        from ad_app_flux
       where adid = I_ADID
         and upper(deviceid) = upper(I_Deviceid)
         and dlevel = cur.dlevel;
    
      --如果该设备已经获取过该奖励则跳过
      if v_n >= cur.times then
        GOTO CONTINUE_LOOP;
      end if;
    
      --游戏级别不够，不奖励
      if cur.needlevel > I_Levle then
        GOTO CONTINUE_LOOP;
      end if;
    
      insert into ad_app_flux
        (id,
         adid,
         appid,
         deviceid,
         appsign,
         dlevel,
         merid,
         money,
         event,
         adtype,
         atype,
         simid,
         urlid,
         price)
      values
        (SQ_AD_FLUX.NEXTVAL,
         I_ADID,
         I_APPId,
         upper(I_Deviceid),
         v_appsign,
         cur.dlevel,
         I_MerId,
         cur.amoney,
         cur.event,
         v_adtype,
         cur.atype,
         I_simid,
         v_urlid,
         cur.price);
    
      commit;
    
      if cur.isshow = 1 then
      
        --累加奖励
        O_AMoney := O_AMoney + cur.amoney;
      
        v_ordernum := I_APPId || to_char(sysdate, 'yyyymmddhh24miss') ||
                      I_ADID || dbms_random.string('x', 5) ||
                      trunc(dbms_random.value(0, 10));
      
        insert into ad_channel_order
          (adid,
           adname,
           appid,
           ordernum,
           dlevel,
           awardgroup,
           pagename,
           deviceid,
           simid,
           appsign,
           merid,
           mername,
           event,
           price,
           money)
        values
          (I_ADID,
           v_adname,
           I_APPId,
           v_ordernum,
           cur.dlevel,
           cur.awardgroup,
           v_pagename,
           I_Deviceid,
           I_SIMID,
           v_appsign,
           I_MerId,
           I_MerName,
           v_adname || cur.event,
           cur.price,
           cur.amoney);
      
        commit;
      end if;
   
    
      <<CONTINUE_LOOP>>
      null;
    
    end loop;
  
  exception
    --失败 
    when others then
      rollback;
      O_Result  := 1001;
      O_Message := '领取奖励异常！';
      -- o_message := '领取奖励异常 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PQ_Common_Windows;

end P_AD_Award_Main;
/


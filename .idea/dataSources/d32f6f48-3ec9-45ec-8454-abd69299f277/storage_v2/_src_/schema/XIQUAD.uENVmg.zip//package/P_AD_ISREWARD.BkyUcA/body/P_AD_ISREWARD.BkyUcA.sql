create PACKAGE BODY P_AD_IsReward AS

  /*判断该广告该设备号是否可以继续获得奖励*/

  Function FQ_Deviceid
  /*****************************************************************
        Procedure Name :FQ_Deviceid
        Purpose: 根据设备号 判断用户是否还有奖励可以获取
        note: 返回  状态 0 未完成 1已完成 2 已过期 3 正在完成中 4 不予奖励
        Edit: 2017-02-16 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Dlevel   Number, --奖励级别
   I_Deviceid In varchar2, --设备号ID
   I_PType    In number --1、ios  2、安卓
   ) Return Number As
    PRAGMA AUTONOMOUS_TRANSACTION; -------------方法函数 被嵌套，且有表操作 必写
    v_status     number; --状态 0 未完成 1已完成 2 已过期 3 正在完成中 4 不予奖励
    v_n          number;
    v_times      number; --任务可奖励次数
    v_atype      number; --  奖励类型：1-注册 2-等级/首冲固定奖励  3-充值理财百分比奖励 4-安装奖励 5-当天签到奖励
    v_needlevel  number; --要求游戏等级（时间、天数 、积分)；充值奖励时为充值的返蛋比例值 （如 充值返20% 则写20）
    v_awardgroup number; --奖励组别，根据不同广告有自己的组别【注意：签到奖励每个签到需为一个组别】（99表是同组中只能获得其中1个奖励）
    v_BTime      date; --用户注册时间
  
    v_UpStep    number; ---上一步
    v_UpFulfill number; --上一步是否已完成 0 否 1 是
    v_UpPast    number; --上一步是否已过期 0 否 1 是 
    v_IAward    number; --是否拿过第一步奖励
    v_rdm       number; --随机 
  Begin
    v_status    := 0;
    v_UpFulfill := 0;
    v_UpPast    := 0;
    v_IAward    := 0;
  
    if I_Deviceid is null then
      v_status := 4;
      return v_status;
    end if;
  
    if I_ADID is null then
      v_status := 4;
      return v_status;
    end if;
  
    v_status := 3;
    return v_status;
  
    /* insert into aaa_ad_request_log
      (adid, appid, deviceid, itime, type)
    values
      (I_ADID, i_appid, i_deviceid, sysdate, 4);
    
    commit;*/
  
    /*
    select trunc(dbms_random.value(0, 3)) into v_rdm from dual;
    case v_rdm
      when 0 then
        select \* sql a *\
         times, atype, needlevel, awardgroup
          into v_times, v_atype, v_needlevel, v_awardgroup
          from ad_awardset
         where adid = I_ADID
           and dlevel = I_Dlevel
           and appid = I_APPId;
      when 1 then
        select \* sql b *\
         times, atype, needlevel, awardgroup
          into v_times, v_atype, v_needlevel, v_awardgroup
          from ad_awardset
         where adid = I_ADID
           and dlevel = I_Dlevel
           and appid = I_APPId;
      when 2 then
        select \* sql c *\
         times, atype, needlevel, awardgroup
          into v_times, v_atype, v_needlevel, v_awardgroup
          from ad_awardset
         where adid = I_ADID
           and dlevel = I_Dlevel
           and appid = I_APPId;
      else
      
        select \* sql d *\
         times, atype, needlevel, awardgroup
          into v_times, v_atype, v_needlevel, v_awardgroup
          from ad_awardset
         where adid = I_ADID
           and dlevel = I_Dlevel
           and appid = I_APPId;
    end case;*/
  
    select count(1)
      into v_n
      from ad_app_flux
     where adid = I_ADID
       and dlevel = I_Dlevel
       and deviceid = I_Deviceid;
  
    if v_n > 1 then
      v_status := 1;
      return v_status;
    end if;
  
    -- atype  奖励类型：1-注册 2-等级/首冲固定奖励  3-充值理财百分比奖励 4-安装奖励 5-当天签到奖励
  
    select times, atype, needlevel, awardgroup
      into v_times, v_atype, v_needlevel, v_awardgroup
      from ad_awardset
     where adid = I_ADID
       and dlevel = I_Dlevel
       and appid = I_APPId;
  
    --用户奖励次数大于等于 可获取次数则直接完成
    /*  if v_n >= v_times then
      v_status := 1;
      return v_status;
    else*/
    --用户是否绑定过
    select count(1)
      into v_n
      from ad_app_bind
     where adid = I_ADID
       and deviceid = I_Deviceid;
  
    --如果同一个设备号同个 广告 存在多个 说明是问题用户 不予奖励
    if v_n > 1 then
      v_status := 4;
      return v_status;
    end if;
  
    --没绑定并且不是第一步则直接没完成
    if v_n <= 0 and I_Dlevel != 1 then
      v_status := 0;
      return v_status;
    end if;
  
    -- 如果为 第一步 则 正在完成中
    if I_Dlevel = 1 then
      v_status := 3;
      return v_status;
    end if;
  
    if v_awardgroup >= 90 then
      --如果为同组奖励 表示该组别中的奖励 用户只能领取其中一个 ，领取过其中一个则该组别其他奖励均为过期
      select count(1)
        into v_n
        from ad_app_flux
       where adid = I_ADID
         and deviceid = I_Deviceid
         and dlevel in (select dlevel
                          from ad_awardset
                         where adid = I_ADID
                           and appid = I_APPId
                           and awardgroup = v_awardgroup);
    
      ---如果是同个 dlevel 已获得过  前面已经判断了
      if v_n > 0 then
        v_status := 2;
        return v_status;
      end if;
    
    end if;
  
    --用户是否领取过奖励，如果领取过则使用第一次的安装奖励时间来判断【仅限快速赚钱】
    select count(1)
      into v_n
      from ad_app_flux
     where adid = I_ADID
       and deviceid = I_Deviceid
       and atype in (1, 4); --奖励类型：1-注册 2-等级/首冲固定奖励  3-充值理财百分比奖励 4-安装奖励 5-当天签到奖励
  
    if v_n > 0 then
      select min(trunc(itime))
        into v_BTime
        from ad_app_flux
       where adid = I_ADID
         and deviceid = I_Deviceid
         and atype in (1, 4);
      v_IAward := 1;
    end if;
  
    --如果广告没有安装奖励则判断是否有完成记录
    if v_IAward = 0 then
      select count(1)
        into v_n
        from ad_app_flux
       where adid = I_ADID
         and deviceid = I_Deviceid;
      if v_n > 0 then
        select min(trunc(itime))
          into v_BTime
          from ad_app_flux
         where adid = I_ADID
           and deviceid = I_Deviceid;
        v_IAward := 1;
      end if;
    end if;
  
    ------------------------------------------------过期判断------------------------------
    --如果绑定过 则需要判断该奖励是否为签到类型的，是则需要判断 是否已过期
  
    -- 5-当天签到奖励
    if v_atype = 5 then
      --如果绑定天数+需要完成的天数内 仍然小于当前时间 则表示用户该级别已过期
      if v_BTime + v_needlevel < trunc(sysdate) then
        v_status := 2;
        return v_status;
      end if;
    end if;
  
    -- 如果拿过第一步奖励  且为 等级 奖励 或 充值奖励 则 都在完成中 
    if v_IAward > 0 and v_atype in (2, 3, 9) then
      v_status := 3;
      return v_status;
    end if;
  
    --如果第一步奖励 未领取 则 未完成
    if v_IAward = 0 then
      v_status := 0;
      return v_status;
    end if;
  
    -----------------------------------------------是否为 正在完成中 判断--------------------------------
  
    if v_awardgroup >= 90 then
      --如果为同组奖励 并且用户都没领取过该组奖励 则该组旗下的所有奖励均为 正在进行中
      v_status := 3;
      return v_status;
    end if;
  
    /* 如果上一步已完成 或者  已过期  则 该步骤为正在进行中 */
  
    --获取上一步级别 不为充值奖励  并且为显示
    select nvl(max(dlevel), 0)
      into v_UpStep
      from ad_awardset
     where adid = I_ADID
       and dlevel < I_Dlevel
       and appid = I_APPId
       and atype != 3;
  
    --判断上一步是否完成
    select count(1)
      into v_n
      from ad_app_flux
     where adid = I_ADID
       and dlevel = v_UpStep
       and deviceid = I_Deviceid;
  
    select times, atype, needlevel
      into v_times, v_atype, v_needlevel
      from ad_awardset
     where adid = I_ADID
       and appid = I_APPId
       and dlevel = v_UpStep;
  
    if v_n >= v_times then
      v_UpFulfill := 1; --已完成
    end if;
  
    --如果不为签到奖励则不会过期
    if v_atype != 5 then
      v_UpPast := 0; --未过期
    end if;
  
    --如果为签到奖励则且上一步未完成判断是否过期  
    if v_atype = 5 and v_UpFulfill != 1 then
    
      --如果绑定天数+需要完成的天数内 仍然小于当前时间 则表示用户该级别已过期
      if v_BTime + v_needlevel < trunc(sysdate) then
        v_UpPast := 1; --过期
      else
        v_UpPast := 0; --未过期
      end if;
    end if;
  
    --如果上已经完成或者已经过期
    if v_UpFulfill = 1 or v_UpPast = 1 then
      v_status := 3; --正在完成
      return v_status;
    else
      v_status := 0; --未完成
      return v_status;
    end if;
  
    v_status := 0;
    --end if;
  
    return v_status;
  
  End FQ_Deviceid;

end P_AD_IsReward;
/


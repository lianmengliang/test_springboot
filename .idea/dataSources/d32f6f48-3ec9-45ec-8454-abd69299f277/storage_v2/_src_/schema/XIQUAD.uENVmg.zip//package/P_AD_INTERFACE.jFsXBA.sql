create package P_AD_InterFace is

  TYPE T_CURSOR IS REF CURSOR;

  /*渠道信息*/

  procedure PQ_Interf_Group
  /*****************************************************************
        Procedure Name :PQ_Interf_Group
        Purpose: 广告接口_组别等级对应参数
        Edit: 2017-03-07 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure PQ_Interf_Group
  /*****************************************************************
        Procedure Name :PQ_Interf_Group
        Purpose: 广告接口_组别等级对应参数  
        Edit: 2017-07-23 add by 小沈  新增获取接口普通信息 显示用
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   I_Deviceid  In Varchar2, --设备号ID
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure PQ_Interf_Level
  /*****************************************************************
        Procedure Name :PQ_Interf_Level
        Purpose: 广告接口_等级查询
        Edit: 2017-03-07 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure PQ_Interf_Repetition
  /*****************************************************************
        Procedure Name :PQ_Interf_Repetition
        Purpose: 广告接口_设备号排重查询
        Edit: 2017-03-21 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure PW_Interf_Log
  /*****************************************************************
        Procedure Name :PQ_Interf_Log
        Purpose: 广告接口_日志记录
        Edit: 2017-03-07 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_Url      In Varchar2, --接口地址
   I_BackJson In Varchar2, --返回Json信息
   I_Type     In Number, --记录类型 1、排重接口 2、等级接口 3、订单推送接口 4、注册信息查询
   O_Result   Out Number,
   O_Message  Out Varchar2);

  procedure PW_Interf_Limit
  /*****************************************************************
        Procedure Name :PW_Interf_Limit
        Purpose: 广告接口_设备号被限制
        Edit: 2017-03-21 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID  
   O_Result   Out Number,
   O_Message  Out Varchar2);

  procedure PQ_Interf_Reg
  /*****************************************************************
        Procedure Name :PQ_Interf_Reg
        Purpose: 广告接口_注册查询
        Edit: 2017-04-26 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure PQ_Interf_Inform
  /*****************************************************************
        Procedure Name :PQ_Interf_Inform
        Purpose: 广告接口_通知接口查询，广告主记录该设备号成功才可体验
        Edit: 2018-04-15 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   I_APPId     In Number, --渠道应用ID
   I_Deviceid  In Varchar2, --设备号ID
   I_SIMID     In Varchar2, --sim卡编号 
   I_APPSign   In Varchar2, --渠道应用标识符号、渠道用户id 
   I_Userid    In Number, --闲玩用户编号
   I_PType     In Number, --1、ios  2、安卓
   O_UStatus   Out Number, --用户体验状态 0：否【用户不可体验】 1：是【用户可体验】 -1需通知广告主
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure PW_Interf_Inform_Back
  /*****************************************************************
        Procedure Name :PW_Interf_Inform_Back
        Purpose: 广告接口_通知接口返回记录
        Edit: 2018-04-15 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_SIMID    In Varchar2, --sim卡编号 
   I_APPSign  In Varchar2, --渠道应用标识符号、渠道用户id 
   I_Userid   In Number, --闲玩用户编号
   I_PType    In Number, --1、ios  2、安卓
   I_IP       In Varchar2, --IP
   I_UStatus  In Number, --用户体验状态 0：否【用户不可体验】 1：是【用户可体验】  
   O_Result   Out Number,
   O_Message  Out Varchar2);

  procedure PQ_Interf_OldUser
  /*****************************************************************
        Procedure Name :PQ_Interf_OldUser
        Purpose: 广告接口_老用户查询接口
        Edit: 2017-06-09 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   I_PType     In Number, --1、ios  2、安卓
   I_DeviceId  In Varchar2, --用户设备号
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure PQ_Interf_OldUser_Click
  /*****************************************************************
        Procedure Name :PQ_Interf_OldUser_Click
        Purpose: 广告接口_老用户查询接口
        Edit: 2017-06-09 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_PType    In Number, --1、ios  2、安卓
   I_DeviceId In Varchar2, --用户设备号 
   O_Result   Out Number,
   O_Message  Out Varchar2);

  procedure PQ_Activate_OldUser
  /*****************************************************************
        Procedure Name :PQ_Activate_OldUser
        Purpose: 广告接口_激活老用户
        Edit: 2017-06-09 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_Fid      In Varchar2, --本期广告主统计的来源id[apk渠道编号] 
   I_UrlId    In Number, --广告下载编号
   I_LastAdid In Number, --上一期广告ID
   I_LastFid  In Varchar2, --上一期广告主渠道编号 
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_SIMID    In Varchar2, --sim卡编号
   I_APPSign  In Varchar2, --渠道应用标识符号、渠道用户id 
   I_PType    In Number, --1、ios  2、安卓
   I_IP       In Varchar2, --
   O_Result   Out Number,
   O_Message  Out Varchar2);

end P_AD_InterFace;
/


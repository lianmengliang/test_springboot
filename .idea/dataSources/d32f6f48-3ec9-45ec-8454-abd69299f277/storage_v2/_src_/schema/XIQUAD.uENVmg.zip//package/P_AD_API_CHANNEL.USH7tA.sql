create PACKAGE P_AD_API_Channel AS

  TYPE T_CURSOR IS REF CURSOR;

  /*
  渠道广告API接口查询
  2018-06-20
  */

  procedure PQ_List
  /*****************************************************************
        Procedure Name :PQ_List
        Purpose: 获取广告列表
        Edit: 2018-06-20 add by 小沈
    ****************************************************************/
  (I_APPId          In Number, --渠道应用ID 
   I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始
   O_Outrecordcount Out Number, --返回总记录数
   O_Outcursor      Out t_cursor, --返回游标
   O_Result         Out Number, --判断 0：查询成功，其他：出错
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  procedure PQ_InterfaceIntro
  /*****************************************************************
        Procedure Name :PQ_InterfaceIntro
        Purpose: 获取广告接口介绍
        Edit: 2018-07-04 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   I_APPId     In Number, --渠道应用ID 
   O_Intro     Out varchar2, --返回接口简介
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out number, --判断 0：查询成功，其他：出错
   O_Message   Out varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  procedure PQ_AwardList
  /*****************************************************************
        Procedure Name :PQ_AwardList
        Purpose: 获取广告奖励结算
        Edit: 2018-06-20 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   I_APPId     In Number, --渠道应用ID 
   O_Outcursor out t_cursor, --返回游标
   O_Result    out number, --判断 0：查询成功，其他：出错
   O_Message   out varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  procedure PQ_DownUrl
  /*****************************************************************
        Procedure Name :PQ_DownUrl
        Purpose: 获取广告下载地址
        Edit: 2017-06-27 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   I_APPId     In Number, --渠道应用ID 
   O_Outcursor out t_cursor, --返回游标
   O_Result    out number, --判断 0：查询成功，其他：出错
   O_Message   out varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  Function FQ_IsShow
  /*****************************************************************
        Procedure Name :FQ_IsShow
        Purpose: 判断是否显示 0 不显示 1 显示
        Edit: 2018-06-27 add by 小沈
    ****************************************************************/
  (I_ADID In Number --广告ID
   ) Return Number;

end P_AD_API_Channel;


/


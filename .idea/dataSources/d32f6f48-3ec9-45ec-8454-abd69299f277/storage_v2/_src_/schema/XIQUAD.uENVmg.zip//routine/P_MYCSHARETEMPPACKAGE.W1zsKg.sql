create PROCEDURE P_MyCShareTempPackage
/*****************************************************************
  Procedure Name: .net 调用存储过程，模板
  ****************************************************************/
(I_ProName in varchar2, i_package_name in varchar2, O_Str out varchar2) IS
  --游标：
  cursor myCur is
    select t.*
      from all_arguments t
     where object_name = upper(I_ProName)
       and package_name = upper(i_package_name)
    --and owner = 'PCEGGS'
    --and package_name='pg_app_base'
     order by position;

  v_title         varchar2(3000);
  v_ParameterList varchar2(3000);
  v_body          varchar2(3000);
  v_foot          varchar2(3000);
BEGIN
  v_title         := '';
  v_ParameterList := '';
  v_body          := '';
  v_foot          := '';

  v_title := v_title || 'DataSet ds = null;' || chr(13);
  v_title := v_title || 'DataRow row = null;' || chr(13);
  v_title := v_title || 'OracleParameter ';

  for cur in myCur loop
    --输入输出参数列表
    v_ParameterList := v_ParameterList || cur.argument_name || ',';

    if cur.in_out = 'IN' then
      --输入参数
      v_body := v_body || cur.argument_name || ' = new OracleParameter("' ||
                cur.argument_name || '",  ' || cur.argument_name || '  );' ||
                chr(13);
    end if;

    if cur.in_out = 'OUT' then
      --输出参数
      select v_body || cur.argument_name || ' = new OracleParameter("' ||
             cur.argument_name || '",OracleType.' ||
             decode(cur.data_type,
                    'REF CURSOR',
                    'Cursor',
                    'NUMBER',
                    'Number',
                    'VARCHAR2',
                    'VarChar,500',
                    'VARCHAR',
                    'VarChar,500',
                    'DATE',
                    'DateTime',
                    '字段类型') || ');' || chr(13)
        into v_body
        from dual;
      v_body := v_body || cur.argument_name ||
                '.Direction = ParameterDirection.Output;' || chr(13);
    end if;

  end loop;

  v_body := v_body || 'Parameters = new OracleParameter[] { ';

  v_foot := v_foot || 'try' || chr(13) || '{' || chr(13);
  v_foot := v_foot || 'ds = ExecuteDataSet("' ||i_package_name || '.' || I_ProName ||
            '", Parameters);' || chr(13);
  v_foot := v_foot || 'if (ds != null)' || chr(13) || '{' || chr(13);
  v_foot := v_foot || 'row = ds.Tables[0].Rows[0];' || chr(13);
  v_foot := v_foot || '}' || chr(13) || '}' || chr(13) || 'catch' || '{' ||
            chr(13) || '}' || chr(13);

  v_ParameterList := substr(v_ParameterList, 1, length(v_ParameterList) - 1);

  --返回参数
  O_Str := v_title || v_ParameterList || ';' || chr(13) ||
           'OracleParameter[] Parameters;' || chr(13) || v_body ||
           v_ParameterList || ' };' || chr(13) || v_foot;

END P_MyCShareTempPackage;


/


create package body P_SMS is

  /*短信处理*/

  procedure PW_Alarm_Add
  /*****************************************************************
        Procedure Name :PW_Aalarm_Add
        Purpose: 报警短信添加 
        Edit: 2017-07-29 add by 小沈
    ****************************************************************/
  (I_Phone     In Varchar2, --手机号码
   I_Message   In Varchar2, --消息内容 
   I_SendLevel In Number, --发送优先级,99为手工插入，最高优先级 
   I_SendType  In Number, --发送类型 1：渠道推送失败
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    v_n       Number;
    v_message varchar2(200);
  
  begin
    o_result  := 0;
    o_message := '添加成功';
  
    if I_Message is null or I_Phone is null then
    
      o_result  := 1;
      o_message := '信息错误';
      return;
    end if;
  
    v_message := '嘻趣_' || i_message;
  
    --除最高权限外
    if I_SendLevel != 99 then
      --凌晨 0点到7点 不记录报警信息 
      if sysdate >= to_date(to_char(sysdate, 'yyyy-mm-dd') || ' 00:00',
                            'yyyy-mm-dd hh24:mi') and
         sysdate <= to_date(to_char(sysdate, 'yyyy-mm-dd') || ' 07:00',
                            'yyyy-mm-dd hh24:mi') then
        o_result  := 1;
        o_message := '凌晨不接收报警';
        return;
      end if;
    end if;
  
    --半小时内是否有同样的短信存在
    select count(1)
      into v_n
      from sms_send_alarm
     where Itime >= sysdate - (120 / (24 * 60))
       and phone = I_Phone
       and message = v_message;
  
    if v_n > 0 then
      o_result  := 2;
      o_message := '2小时内不接收同样的报警！';
      return;
    end if;
  
    insert into sms_send_alarm
      (id, phone, message, sendlevel, sendtype, channel, template)
    values
      (SQ_SMS_SEND_ALARM.Nextval,
       i_phone,
       v_message,
       i_sendlevel,
       i_sendtype,
       1,
       'SMS_80040010');
    commit;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 1001;
      O_Message := '添加异常！';
      o_message := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_Alarm_Add;

  procedure PQ_Alarm_List
  /*****************************************************************
        Procedure Name :PQ_Alarm_List
        Purpose: 获取报警短信列表
        Edit: 2017-07-30 add by 小沈
    ****************************************************************/
  (I_PageSize       In Number,
   I_PageNO         In Number,
   O_OutRecordCount Out Number,
   O_OutCursor      Out t_cursor, --返回游标
   O_Result         Out Number,
   O_Message        Out Varchar2) is
    v_sql       varchar2(2000);
    V_HeiRownum Number;
    V_LowRownum Number;
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    v_sql := ' select id, phone,message , status , to_char(itime,''mm-dd hh24:mi'') itime ,channel ,template    from sms_send_alarm where channel =1 and status=0  ';
  
    execute immediate ' select count(1) from (' || v_sql || ')'
      into O_OUTRECORDCOUNT;
  
    v_sql := v_sql || ' order by sendlevel desc,itime asc   ';
  
    ----执行分页查询
    V_HeiRownum := I_PageNO * I_PageSize;
    V_LowRownum := V_HeiRownum - I_PageSize + 1;
    V_SQL       := 'select id, phone,message ,itime ,channel ,template,rn
                    from  (
                    select id,  phone,message ,itime ,channel ,template,rownum rn
                    from (' || v_sql || ') A
                    where rownum <= ' ||
                   to_char(V_HeiRownum) || '
                    ) B
                    where rn >= ' || to_char(V_LowRownum);
    open O_OutCursor for v_sql;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 110;
      O_Message := '获取失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PQ_Alarm_List;

  procedure PW_UpStatus
  /*****************************************************************
        Procedure Name :PW_UpStatus
        Purpose: 修改短信状态为正在发送中 
        Edit: 2017-07-29 add by 小沈
    ****************************************************************/
  (I_SmsId   In Number, --短信ID 
   O_Result  Out Number,
   O_Message Out Varchar2) is
    v_n Number;
  
  begin
    o_result  := 0;
    o_message := '修改成功';
  
    select count(1)
      into v_n
      from sms_send_alarm
     where id = I_SmsId
       and status = 0;
    if v_n <= 0 then
      o_result  := 1;
      o_message := '短信已再发送中';
      return;
    end if;
  
    update sms_send_alarm
       set status = 1, sendtime = sysdate
     where id = I_SmsId
       and status = 0;
  
    commit;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 1001;
      O_Message := '处理异常！';
      O_Message := '处理异常 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_UpStatus;

  procedure PW_Result
  /*****************************************************************
        Procedure Name :PW_Result
        Purpose: 短信发送结果返回 
        Edit: 2017-07-29 add by 小沈
    ****************************************************************/
  (I_SmsId   In Number, --短信ID 
   I_Status  In Number, -- 返回状态 0：失败  1：成功
   I_Result  In Varchar2, --返回信息
   O_Result  Out Number,
   O_Message Out Varchar2) is
    v_n Number;
  
  begin
    o_result  := 0;
    o_message := '处理成功';
  
    select count(1)
      into v_n
      from sms_send_alarm
     where id = I_SmsId
       and status = 1;
  
    if v_n <= 0 then
      o_result  := 1;
      o_message := '短信已处理或未处理';
      return;
    end if;
  
    if I_Status = 0 then
      update sms_send_alarm
         set status = 3, sendtime = sysdate, result = I_Result
       where id = I_SmsId
         and status = 1;
    end if;
  
    if I_Status = 1 then
      update sms_send_alarm
         set status = 2, sendtime = sysdate, result = I_Result
       where id = I_SmsId
         and status = 1;
    end if;
  
    commit;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 1001;
      O_Message := '处理异常！';
      O_Message := '处理异常 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_Result;

end P_SMS;
/


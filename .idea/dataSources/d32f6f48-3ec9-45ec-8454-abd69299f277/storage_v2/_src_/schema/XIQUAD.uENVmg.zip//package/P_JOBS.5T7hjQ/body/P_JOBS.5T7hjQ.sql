create PACKAGE BODY P_Jobs AS

  /*定时 Jobs */

  procedure Job_5ss
  /*****************************************************************
        procedure name: Job_5ss
        purpose: 5秒高频JOB  --慎用
       edit: 2018-08-23 add by 小沈
    ****************************************************************/
   is
    v_n number;
  
  begin
  
    --发奖审核校验
    p_ad_award_check.job_autocheck;
  
  exception
    when others then
      rollback;
      return;
  end Job_5ss;

  procedure Job_1mi
  /*****************************************************************
        procedure name: Job_1mi
        purpose: 1分钟JOB
       edit: 2017-06-18 add by 小沈
    ****************************************************************/
   is
    v_n number;
  
  begin
  
    v_n := 1;
     --校验当天下载是否为老用户体验
    p_ad_windows_older.job_checkolduser;
  exception
    when others then
      rollback;
      return;
  end Job_1mi;

  procedure Job_5mi
  /*****************************************************************
        procedure name: Job_5mi
        purpose: 5分钟JOB
        edit: 2017-06-18 add by 小沈
    ****************************************************************/
   is
    v_n       number;
    v_result  number;
    v_message varchar2(100);
  
  begin
    -- 渠道消耗自动计算
    p_fin_calculation.job_channel_expend;
  
    --广告主消耗自动计算
    p_fin_calculation.job_adv_expend;
  
    --广告检测短信发送
    p_job_monitoring.job_ad;
  
    ---关注广告奖励发放
    p_wxad_award.job_wait;
  
    --临时 需删除 给绑定用户添加闲玩用户编号
    aaa_initializeuser(i_sign    => 0,
                       o_result  => v_result,
                       o_message => v_message);
    --临时 需删除 对一小时前的奖励的数据初始化闲玩用户编号
    aaa_initializeadflux(o_result => v_result, o_message => v_message);
  
  exception
    when others then
      rollback;
      return;
  end Job_5mi;
  procedure Job_10mi
  /*****************************************************************
        procedure name: Job_10mi
        purpose: 10分钟JOB
       edit: 2019-02-01 add by 小胡
    ****************************************************************/
   is
    v_n number;
  
  begin
  
    ----老用户自动激活 winds服务 录入需要新增的老用户名单
    p_ad_windows_older.job_entryuser;
  
  exception
    when others then
      rollback;
      return;
  end Job_10mi;

  procedure Job_30mi
  /*****************************************************************
        procedure name: Job_30mi
        purpose: 30分钟JOB
       edit: 2019-2-1 add by 小胡
    ****************************************************************/
   is
    v_n number;
  
  begin
    v_n := 1;
  
    --老用户自动激活 winds服务 之前商家注册信息查询失败的用户，进行二次校验检查是否注册已完成
    p_ad_windows_older.job_checkuserreg;
  
  exception
    when others then
      rollback;
      return;
  end Job_30mi;

  procedure Job_60mi
  /*****************************************************************
        procedure name: Job_60mi
        purpose: 60分钟JOB
          edit: 2019-2-1 add by 小胡
    ****************************************************************/
   is
    v_n number;
  
  begin
    v_n := 1;
  
    --老用户自动激活 winds服务 自动添加激活老用户人数
    p_ad_windows_older.job_auto;
    --老用户自动激活 winds服务 获取已经激活的用户，跑出了多少奖励，和用户领取奖励
    p_ad_windows_older.job_usermoney;
  
  exception
    when others then
      rollback;
      return;
  end Job_60mi;
  procedure Job_1AM
  /*****************************************************************
        procedure name: Job_1AM
        purpose: 凌晨1点 处理事物
        edit: 2017-06-18 add by 小沈
    ****************************************************************/
   is
  
  begin
  
    --数据自动录入
    p_fin_entry.job_autoentry;
  
    --广告实际消耗录入
    p_fin_entry_real.job_autoentry;
  
    --注册绑定数录入
    p_report_entry.Job_DayClick;
    
    --更新跑老用户激活数据设置表
    P_AD_Windows_Older.Job_UpdateRunOlderSet;
  
  exception
    when others then
      rollback;
      return;
  end Job_1AM;

  procedure Job_2AM
  /*****************************************************************
        procedure name: Job_1AM
        purpose: 凌晨2点 处理事物
        edit: 2017-06-18 add by 小沈
    ****************************************************************/
   is
    v_sql varchar(200);
    v_day varchar(50);
  begin
  
    --渠道消耗日报表
    p_fin_calculation.job_expend_day;
    --广告消耗日报表
    p_fin_calculation.job_adv_expend_day;
    --是否显示记录表清除
    v_sql := 'truncate table ad_limit_show';
    execute immediate v_sql;
  
    --删除广告列表缓存表
    v_sql := 'truncate table cache_ad_list';
    execute immediate v_sql;
    commit;
  
    v_sql := 'truncate table cache_ad_money';
    execute immediate v_sql;
    commit;
  
    v_sql := 'truncate table cache_ad_show';
    execute immediate v_sql;
    commit;
  
    --UV,PV 统计日报表
    --p_ad_statistics.job_statsday;
    p_ad_statistics_v2.job_statsday;
  
    --获取当前星期几
    v_day := to_char(sysdate, 'day');
  
    if v_day = '星期日' or v_day = '星期三' then
      --清除广告日志表
      v_sql := 'truncate table ad_interf_log';
      execute immediate v_sql;
    end if;
    commit;
  
  exception
    when others then
      rollback;
      return;
  end Job_2AM;

  Procedure Job_Maintain
  /******************************************************************
        procedure name: Job_Maintain
        purpose: 维护
        edit: 2018-04-26 add by 小沈
    ****************************************************************/
   is
    v_per number; --百分比
    v_sql varchar2(4000);
  begin
    --round((d.tot_grootte_mb - f.total_bytes) / d.tot_grootte_mb * 100, 2)
    /*  v_sql := ' select count(1)
     from (select tablespace_name,
                  round(sum(bytes) / (1024 * 1024), 2) total_bytes,
                  round(max(bytes) / (1024 * 1024), 2) max_bytes
             from sys.dba_free_space
            group by tablespace_name) f,
          (select dd.tablespace_name,
                  round(sum(dd.bytes) / (1024 * 1024), 2) tot_grootte_mb
             from sys.dba_data_files dd
            group by dd.tablespace_name) d
    where d.tablespace_name = f.tablespace_name
      and d.tablespace_name = ''ADTEMP''
    order by 1';*/
  
    v_sql := 'select 
                   round(max(bytes) / (1024 * 1024), 2) max_bytes
              from sys.dba_free_space
             group by tablespace_name ';
  
    execute immediate v_sql
      into v_per;
  
  exception
    when others then
      rollback;
      return;
  end Job_Maintain;

  procedure Job_Temp
  /*****************************************************************
        procedure name: Job_Temp
        purpose: 测试用
       edit: 2018-08-23 add by 小沈
    ****************************************************************/
   is
    v_n number;
  
    v_sql     varchar(200);
    v_day     varchar(50);
    v_message varchar2(500);
  begin
    v_n := 1;
  
    --获取当前星期几
    v_day := to_char(sysdate, 'day');
  
    if v_day = '星期日' or v_day = '星期三' then
    
      /*    v_sql := 'create table aa_ad_interf_log tablespace  ADTEMP as
      select * from ad_interf_log where itime>=trunc(sysdate)-1 ';
            execute immediate v_sql;*/
    
      --清除广告日志表
      v_sql := 'truncate table ad_interf_log';
      execute immediate v_sql;
    end if;
  
  exception
    when others then
      v_message := '错误码：' || sqlcode || ' 消息：' || sqlerrm;
      rollback;
      return;
  end Job_Temp;

end P_Jobs;
/


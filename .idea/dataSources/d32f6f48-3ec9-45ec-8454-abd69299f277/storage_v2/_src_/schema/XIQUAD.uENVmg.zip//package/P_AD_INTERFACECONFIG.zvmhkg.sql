create package P_AD_InterfaceConfig is
  TYPE T_CURSOR IS REF CURSOR;

  procedure PQ_QueryInterface
  /*****************************************************************
        Procedure Name :PQ_QueryInterface
        Purpose: 查询数据接口
        Edit: 2018-5-29 add by 小胡
    ****************************************************************/
  (I_AdminId    in varchar2, --管理员id
   I_ADID       in number, --广告ID
   I_INTERFTYPE in number, --接口类型（1、老用户激活 2、IOS通知 3、注册查询 4、等级查询 5、组别接口）
   O_OutCursor  Out t_cursor, --返回游标
   O_Result     out number, --返回（0正确，其他为提示或错误）
   O_Message    out varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  procedure PW_InterfConfig_AwardGroupSet
  /*****************************************************************
    Procedure Name: PW_InterfConfig_AwardGroupSet
    Purpose: 广告奖励组别设置录入
    Edit: 2018-06-6 add by 小胡
    ****************************************************************/
  (I_AdmInId     In Varchar2, --管理员ID
   I_ADID        In Number, --广告ID
   I_Events      In Varchar2, --组别名称
   I_ATypes      In Varchar2, --奖励组别类型 （0：显示用的组别，1 普通奖励）
   I_AwardGroups In Varchar2, --奖励组别（0为显示用的组别，从1开始）
   I_Params      In Varchar2, --组别奖励对应的接口参数名称
   I_PreParams   In Varchar2, --前提参数，获得该奖励的前提参数名，一般用于判断新用户
   I_PreValues   In Varchar2, --前提参数值
   I_PreTypes    In Varchar2, --前提参数判断类型 （0：不判断，1：与前提参数值相同，2：大于或等于，3：小于或等于）
   O_Result      Out Number,
   O_Message     Out Varchar2);

  procedure PW_InterfConfig_OldUser
  /*****************************************************************
    Procedure Name: PW_InterfConfig_OldUser
    Purpose: 广告老用户激活接口配置
    Edit: 2018-06-7 add by 小胡
    Comment:
    ****************************************************************/
  (I_AdmInId  In Varchar2, ---管理员ID
   I_ADID     In Number, --广告ID
   I_Adidlist In Varchar2, --老用户广告id列表
   I_Fid      In Varchar2, --渠道编号
   I_IsAuto   In Varchar2, --自动同步上期账号
   I_Url      In Varchar2, --接口地址
   I_Params   In Varchar2, --接口参数
   I_Keycode  In Varchar2, --加密字符串
   I_Isupper  In Number, --加密后字符串是否大写
   I_Jsont    In Number, -- 返回参数格式
   I_Jsons    In Varchar2, --状态判断参数名
   I_Jsonv    In Varchar2, --状态判断参数值
   I_Method   In Varchar2, -- 请求类型（GET、POST）
   I_Htype    In Number, --请求类型（1为GET，3为POST）
   I_Islog    In Number, --是否记录日志
   I_Status   In Number, --接口状态值，（0正常，1停止）
   I_Type     In Number, -- 激活类型（1激活接口激活，2数据库自动激活，3卸载重装后激活）
   I_Ismer    In Number, -- 以商家返回信息为主（1：是，0，不是）
   I_Note     In Varchar2, -- 接口备注
   O_Result   Out Number,
   O_Message  Out Varchar2);

  procedure PW_InterfConfig_IOSInform
  /*****************************************************************
    Procedure Name: p_iosinformInter_config
    Purpose: IOS通知接口
    Edit: 2018-06-7 add by 小胡
    ****************************************************************/
  (I_AdmInId In Varchar2, ---管理员ID
   I_ADID    In Number, --广告ID
   I_Url     In Varchar2, --接口地址
   I_Params  In Varchar2, --接口参数
   I_Keycode In Varchar2, --加密字符串
   I_Isupper In Number, --加密后字符串是否大写
   I_Jsont   In Number, -- 返回参数格式
   I_Jsons   In Varchar2, --状态判断参数名
   I_Jsonv   In Varchar2, --状态判断参数值
   I_Method  In Varchar2, -- 请求类型（GET、POST）
   I_Htype   In Number, --请求类型（1为GET，3为POST）
   I_Islog   In Number, --是否记录日志
   I_Status  In Number, --接口状态值，（0正常，1停止）
   O_Result  Out Number,
   O_Message Out Varchar2);

  procedure PW_InterfConfig_Reg
  /*****************************************************************
    Procedure Name: PW_InterfConfig_Reg
    Purpose: 注册查询接口配置
    Edit: 2018-06-7 add by 小胡
    ****************************************************************/
  (I_AdmInId  In Varchar2, ---管理员ID
   I_ADID     In Number, --广告ID
   I_Url      In Varchar2, --接口地址
   I_Params   In Varchar2, --接口参数
   I_Keycode  In Varchar2, --加密字符串
   I_Isupper  In Number, --加密后字符串是否大写
   I_Jsont    In Number, -- 返回参数格式
   I_Jsons    In Varchar2, --状态判断参数名
   I_Jsonv    In Varchar2, --状态判断参数值
   I_Jsonitem In Varchar2, --返回参数数组参数名
   I_Fid      In Varchar2, --渠道编号
   I_Merid    In Varchar2, --用户ID参数
   I_Mername  In Varchar2, --用户账号参数
   I_Method   In Varchar2, -- 请求类型（GET、POST）
   I_Htype    In Number, --请求类型（1为GET，3为POST）
   I_Islog    In Number, --是否记录日志
   I_Status   In Number, --接口状态值，（0正常，1停止）
   O_Result   Out Number,
   O_Message  Out Varchar2);

  procedure PW_InterfConfig_Level
  /*****************************************************************
    Procedure Name: PW_InterfConfig_Level
    Purpose: 游戏信息查询接口配置
    Edit: 2018-06-7 add by 小胡
    ****************************************************************/
  (I_AdmInId  In Varchar2, ---管理员ID
   I_ADID     In Number, --广告ID
   I_Url      In Varchar2, --接口地址
   I_Params   In Varchar2, --接口参数
   I_Keycode  In Varchar2, --加密字符串
   I_Isupper  In Number, --加密后字符串是否大写
   I_Jsont    In Number, -- 返回参数格式
   I_Jsons    In Varchar2, --状态判断参数名
   I_Jsonv    In Varchar2, --状态判断参数值
   I_Jsonitem In Varchar2, --返回参数数组参数名
   I_Method   In Varchar2, -- 请求类型（GET、POST）
   I_Htype    In Number, --请求类型（1为GET，3为POST）
   I_Islog    In Number, --是否记录日志
   I_Status   In Number, --接口状态值，（0正常，1停止）
   O_Result   Out Number,
   O_Message  Out Varchar2);

  procedure PQ_QueryChannel_OrderInterf
  /*****************************************************************
    Procedure Name: PQ_QueryChannel_OrderInterf
    Purpose: 注册查询接口配置
    Edit: 2018-06-13 add by 小胡
    ****************************************************************/
  (I_AdmInId   In Varchar2, ---管理员ID
   I_APPID     In Number, --渠道标识编号
   O_OUTCURSOR Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure PW_Channel_OrderInterf
  /*****************************************************************
    Procedure Name: PW_Channel_OrderInterf
    Purpose: 订单接口接口配置
    Edit: 2018-06-13 add by 小胡
    ****************************************************************/
  (I_AdmInId In Varchar2, ---管理员ID
   I_APPID   In Number, --渠道ID
   I_Url     In Varchar2, --接口地址
   I_Key     In Varchar2, --签名密钥
   I_Method  In Varchar2, -- 请求类型（GET、POST）
   I_Code    In Varchar2, --请求类型（UTF-8,GB2312）
   I_OTIME   In Number, --超时时间
   I_HTYPE   In Number, --请求方式
   I_Islog   In Number, --是否记录日志
   I_Status  In Number, --接口状态值，（0正常，1停止）
   I_KTYPE   In Number,--加密类型 1：adid+appid+ordernum+deviceid+key 2：adid+appid+ordernum+dlevel+deviceid+appsign+price+money+key
   O_Result  Out Number,
   O_Message Out Varchar2) ;

end P_AD_InterfaceConfig;


/


create package body P_FIN_Entry_Real is

  -- Purpose : 财务实际数据录入

  Procedure PW_DayExpend
  /*****************************************************************
        Procedure Name :PW_DayExpend
        Purpose: 每日消耗
      edit: 2017-08-07 add by 小沈
    ****************************************************************/
  (I_APPId   In Number, --渠道应用ID
   I_Adid    In Number, --广告编号
   I_UrlId   In Number, --广告编号
   I_DTime   In Varchar2, --数据日期
   O_Result  Out Number,
   O_Message Out Varchar2) is
    v_n        Number;
    v_amount   number; ---人数合计
    v_amount_c number; ---渠道人数合计
    v_date     date; --结算日期
    v_price_c  number; --渠道结算单价
    v_amoney_c number; --渠道奖励金额
    v_taxrate  number; --税率
    v_customer varchar2(200); --商家名称
    v_marketer varchar2(200); --市场人员
  
    v_appid     number; --结算金额使用
    v_phonetype number; --1、ios，  2、安卓， 3、ios和安卓都显示 
    cursor Set_List is
      select adid, urlid, dlevel, event, price, isauto
        from fin_ad_set_l
       where adid = I_Adid
         and urlid = I_UrlId
       order by dlevel asc;
  
  begin
    O_Result  := 0;
    O_Message := '记录成功';
    v_date    := to_date(I_DTime, 'yyyy-mm-dd');
    v_appid   := I_APPId;
  
    select count(1)
      into v_n
      from ad_awardset
     where appid = I_APPId
       and adid = I_Adid;
  
    if v_n <= 0 then
      select phonetype into v_phonetype from ad_adinfo where adid = I_Adid;
      if v_phonetype = 1 then
        v_appid := 1011;
      else
        v_appid := 1010;
      end if;
    end if;
  
    select taxrate, customer, marketer
      into v_taxrate, v_customer, v_marketer
      from fin_ad_set
     where adid = I_Adid
       and urlid = I_UrlId;
  
    for C_Set in Set_List loop
    
      --获取人数、
      select count(1)
        into v_amount
        from fin_ad_flux
       where adid = c_set.adid
         and appid = I_APPId
         and dlevel = c_set.dlevel
         and urlid = c_set.urlid
         and itime >= v_date
         and itime < v_date + 1;
    
      --获取渠道人数   
      select count(1)
        into v_amount_c
        from ad_app_flux
       where adid = c_set.adid
         and appid = I_APPId
         and dlevel = c_set.dlevel
         and urlid = c_set.urlid
         and itime >= v_date
         and itime < v_date + 1;
    
      --渠道奖励金额
      select nvl(sum(money), 0)
        into v_amoney_c
        from ad_app_flux
       where adid = c_set.adid
         and appid = I_APPId
         and dlevel = c_set.dlevel
         and urlid = c_set.urlid
         and itime >= v_date
         and itime < v_date + 1;
    
      if v_amount >= 0 then
        --获取该渠道的结算金额和奖励金额
        select count(1)
          into v_n
          from ad_awardset
         where appid = v_appid
           and adid = c_set.adid
           and dlevel = c_set.dlevel;
      
        if v_n <= 0 then
          v_price_c := 0;
        else
        
          select price
            into v_price_c
            from ad_awardset
           where appid = v_appid
             and adid = c_set.adid
             and dlevel = c_set.dlevel;
        
        end if;
      
        --判断该记录是否已经存在
        select count(1)
          into v_n
          from fin_adv_expend
         where appid = I_APPId
           and adid = c_set.adid
           and urlid = c_set.urlid
           and dlevel = c_set.dlevel
           and dtime = v_date;
      
        if v_n > 0 then
        
          update fin_adv_expend
             set amount   = v_amount, --总数，金额 
                 price    = c_set.price, --单价 
                 taxrate  = v_taxrate, --税率 
                 amount_c = v_amount_c, --渠道总数，金额  
                 price_c  = v_price_c, ---渠道单价 
                 amoney_c = v_amoney_c, --渠道总奖励金额 
                 cstatus  = 0, --计算状态 0待计算 1正在计算中 2已计算 3计算失败 
                 l_time   = sysdate
           where appid = I_APPId
             and adid = c_set.adid
             and urlid = c_set.urlid
             and dlevel = c_set.dlevel
             and dtime = v_date;
        else
        
          insert into fin_adv_expend
            (id,
             adid,
             appid,
             urlid,
             dtime,
             dlevel,
             amount,
             price,
             taxrate,
             amount_c, --渠道总数，金额 
             price_c, --渠道单价 
             amoney_c, --渠道奖励金额 
             marketer,
             customer)
          values
            (sq_fin_adv_expend.nextval,
             i_adid,
             i_appid,
             i_urlid,
             v_date, --日期 
             c_set.dlevel,
             v_amount, --总数，金额  
             c_set.price, --单价 
             v_taxrate,
             v_amount_c, --渠道总数，金额 
             v_price_c, --渠道单价 
             v_amoney_c, --渠道奖励金额 =单次奖励金额*合计
             v_marketer,
             v_customer);
        
        end if;
      
      else
        --判断该记录是否已经存在
        select count(1)
          into v_n
          from fin_adv_expend
         where appid = I_APPId
           and adid = c_set.adid
           and urlid = c_set.urlid
           and dlevel = c_set.dlevel
           and dtime = v_date;
      
        if v_n > 0 then
          update fin_adv_expend
             set amount   = 0, --总数，金额 
                 price    = c_set.price, --单价 
                 taxrate  = 0, --税率 
                 amount_c = v_amount_c, --渠道总数，金额  
                 price_c  = 0, ---渠道单价 
                 amoney_c = 0, --渠道总奖励金额 
                 cstatus  = 0, --计算状态 0待计算 1正在计算中 2已计算 3计算失败 
                 status   = 1,
                 l_time   = sysdate
           where appid = I_APPId
             and adid = c_set.adid
             and urlid = c_set.urlid
             and dlevel = c_set.dlevel
             and dtime = v_date;
        end if;
      end if;
    
      <<next_dlevel>>
      null;
    end loop;
  
    commit;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 110;
      O_Message := '记录失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      --添加日志
      insert into fin_log
        (appid, adid, urlid, msg)
      values
        (I_APPId,
         I_Adid,
         I_UrlId,
         'p_fin_entry_real.pw_dayexpend 数据录入异常：' || O_Message);
      commit;
      return;
  end PW_DayExpend;

  Procedure Job_AutoEntry
  /*****************************************************************
        procedure name: Job_AutoEntry
        purpose: 数据自动录入
      edit: 2017-08-07 add by 小沈
    ****************************************************************/
   is
  
    v_adid      number; --广告ID
    v_appid     number; --渠道编号
    v_urlid     number; --下载id
    v_Satrt_Day varchar2(100); --开始获取日期  如果只取一天则开始和结束日期写同一天 如 2017-06-18
    v_End_Day   varchar2(100); --结束获取日期  如果只取一天则开始和结束日期写同一天 如 2017-06-18
    v_Now_Day   date; --当期日期
    v_days      number; --获取相差天数
    v_n         number;
    v_result    number;
    v_message   varchar2(500);
  
    cursor Adid_List is
    
      select appid, adid, urlid
        from (select appid, adid, urlid
                from (select appid, adid, nvl(urlid, 0) urlid, count(1)
                        from fin_ad_flux
                       where itime >= v_Now_Day
                         and itime < v_Now_Day + 1
                      --and adid in (2689)
                      -- and appid = 1441
                       group by appid, adid, urlid
                       order by appid, adid)
              union
              select appid, adid, urlid
                from (select appid, adid, nvl(urlid, 0) urlid, count(1)
                        from ad_app_flux
                       where itime >= v_Now_Day
                         and itime < v_Now_Day + 1
                      --and adid in (2689)
                      --and appid = 1441
                       group by appid, adid, urlid
                       order by appid, adid));
  
  begin
    v_n       := 0;
    v_adid    := 0;
    v_result  := 0;
    v_message := '处理成功！';
  
    v_Satrt_Day := to_char(sysdate - 1, 'yyyy-mm-dd');
    v_End_Day   := to_char(sysdate - 1, 'yyyy-mm-dd');
    /*    
    v_Satrt_Day := '2018-6-4';
    v_End_Day   := '2018-6-13';*/
  
    v_days := to_date(v_End_Day, 'yyyy-mm-dd') -
              to_date(v_Satrt_Day, 'yyyy-mm-dd');
  
    --根据需要获取的日期进行循环获取
    for v_day in 0 .. v_days loop
    
      --当前需要获取的日期
      v_Now_Day := to_date(v_Satrt_Day, 'yyyy-mm-dd') + v_day;
    
      for C_Adid in Adid_List loop
        v_appid := C_Adid.appid;
        v_adid  := C_Adid.adid;
        v_urlid := C_Adid.urlid;
      
        --查看 财务广告信息设置表 是否设置过
        select count(1)
          into v_n
          from fin_ad_set
         where adid = v_adid
           and urlid = v_urlid;
      
        --如果未设置过 则不记录
        if v_n <= 0 then
          goto Next_C_Adid;
        end if;
      
        --查看 财务广告等级信息设置表 是否设置过
        select count(1)
          into v_n
          from fin_ad_set_l
         where adid = v_adid
           and urlid = v_urlid;
      
        --如果未设置过 则不记录
        if v_n <= 0 then
          goto Next_C_Adid;
        end if;
      
        p_fin_entry_real.pw_dayexpend(i_appid   => v_appid,
                                      i_adid    => v_adid,
                                      i_urlid   => v_urlid,
                                      i_dtime   => to_char(v_Now_Day,
                                                           'yyyy-mm-dd'),
                                      o_result  => v_result,
                                      o_message => v_message);
      
        --单个广告结束 提交
        commit;
      
        <<Next_C_Adid>>
        null;
      
      end loop;
    
    end loop;
  
  exception
    when others then
      rollback;
      v_message := '错误编码：' || sqlcode || '  错误信息 ：' || sqlerrm;
      --添加日志
      insert into fin_log
        (appid, adid, urlid, msg)
      values
        (0,
         0,
         0,
         'p_fin_entry_real.Job_AutoEntry 数据录入异常：' || v_message);
      commit;
    
      return;
  end Job_AutoEntry;

end P_FIN_Entry_Real;
/


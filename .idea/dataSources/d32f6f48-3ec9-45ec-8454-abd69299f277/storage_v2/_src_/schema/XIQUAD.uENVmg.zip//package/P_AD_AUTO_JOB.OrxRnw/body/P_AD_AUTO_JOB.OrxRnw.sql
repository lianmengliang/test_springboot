create package body P_AD_Auto_Job is

  /*广告自动作业*/

  PROCEDURE AD_ControlSet
  /*****************************************************************
        procedure name: AD_ControlSet
        purpose: 广告控量
        edit: 2017-05-23 add by 小沈 
    ****************************************************************/
   is
    v_n          NUMBER;
    v_AllCount   number; --下载地址总绑定数
    v_TodayCount number; --下载地址日绑定数
    v_adid       number; --广告编号
    v_status_a   number; --下载地址个数
    status0      number; --下载地址 未投放 个数
    status1      number; --下载地址 正常投放 个数
    status2      number; --下载地址 日到量 个数
    status3      number; --下载地址 总到量 个数
    status4      number; --下载地址 停止投放 个数
    v_message    varchar2(500);
  
    cursor CAdid_List is
      select adid from ad_adinfo where status in (1, 2, 3);
  
    cursor CUrl_List is
      select urlid, allflux, dayflux, status, fluxtime, stoptime
        from ad_downurl
       where adid = v_adid
         and status in (1, 2, 3);
  
  begin
  
    --到达投放终止时间
    select count(1)
      into v_n
      from ad_adinfo
     where stoptime <= sysdate
       and status != 4;
  
    if v_n > 0 then
      update ad_adinfo
         set status = 4, lastupdate = sysdate
       where stoptime <= sysdate
         and status != 4;
      commit;
    end if;
  
    -- 循环取广告ID
    for C_Adid in CAdid_List loop
    
      v_status_a := 0; --下载地址个数
      status0    := 0; --下载地址 未投放 个数
      status1    := 0; --下载地址 正常投放 个数
      status2    := 0; --下载地址 日到量 个数
      status3    := 0; --下载地址 总到量 个数
      status4    := 0; --下载地址 停止投放 个数
      v_adid     := C_Adid.adid;
    
      --循环遍历广告ID下所有的下载地址
      for C_Url in CUrl_List loop
      
        v_n          := 0;
        v_AllCount   := 0; --下载地址总绑定数
        v_TodayCount := 0; --下载地址日绑定数
      
        --判断下载地址是否已到停止时间
        if c_url.stoptime <= sysdate and c_url.stoptime is not null and
           c_url.status != 4 then
          update ad_downurl
             set status = 4, lastupdate = sysdate
           where urlid = c_url.urlid;
          commit;
          --结束该下载地址判断
          goto Next_Urlid;
        end if;
      
        --判断下载地址是否总到量
        --只有总到量有限制并且在投放或日到量的情况下才判断
        if c_url.allflux > -1 and c_url.status in (1, 2) then
        
          select count(1)
            into v_AllCount
            from ad_app_bind
           where adid = v_adid
             and urlid = c_url.urlid;
        
          if v_AllCount >= c_url.allflux then
            update ad_downurl
               set status = 3, fulltime = sysdate, lastupdate = sysdate
             where adid = v_adid
               and urlid = c_url.urlid;
            commit;
            --结束该下载地址判断
            goto Next_Urlid;
          end if;
        
        end if;
      
        --判断下载地址是否日到量
        --只有日到量有限制并且在投放的情况下才判断
        if c_url.dayflux > -1 and c_url.status = 1 then
        
          select count(1)
            into v_TodayCount
            from ad_app_bind
           where adid = v_adid
             and urlid = c_url.urlid
             and itime >= trunc(sysdate);
        
          if v_TodayCount >= c_url.dayflux then
            update ad_downurl
               set status = 2, fulltime = sysdate, lastupdate = sysdate
             where adid = v_adid
               and urlid = c_url.urlid;
            commit;
            --结束该下载地址判断
            goto Next_Urlid;
          end if;
        
        end if;
      
        -----正常情况下不判断 略过
        --==============================我是略过线===================-----
      
        ----第二天正常开启判断
        --如果广告为日到量  
        if c_url.status = 2 then
        
          select count(1)
            into v_TodayCount
            from ad_app_bind
           where adid = v_adid
             and urlid = c_url.urlid
             and itime >= trunc(sysdate);
        
          -- 如果 广告日控量不限  或者 日控量未满  则判断开启日期 判断是否需要开启  
          if c_url.dayflux < 0 or v_TodayCount < c_url.dayflux then
          
            --必须超过第二天到量时间
            if to_char(c_url.fluxtime, 'hh24:mi') <=
               to_char(sysdate, 'hh24:mi') then
              update ad_downurl
                 set status = 1, lastupdate = sysdate
               where adid = v_adid
                 and urlid = c_url.urlid;
              commit;
            end if;
          
          end if;
        
        end if;
      
        <<Next_Urlid>>
        null;
      
      end loop;
    
      --获取广告下载地址个数 与各状态个数
      select sum(status_a),
             sum(status0),
             sum(status1),
             sum(status2),
             sum(status3),
             sum(status4)
        into v_status_a, status0, status1, status2, status3, status4
        from (select decode(status, -1, 0, 1) status_a,
                     decode(status, 0, 1, 0) status0,
                     decode(status, 1, 1, 0) status1,
                     decode(status, 2, 1, 0) status2,
                     decode(status, 3, 1, 0) status3,
                     decode(status, 4, 1, 0) status4
                from ad_downurl
               where adid = v_adid);
    
      --投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放）
    
      --如果未投放数等于 总下载地址数 则广告改为 未投放
      if status0 = v_status_a then
        update ad_adinfo
           set status = 0, lastupdate = sysdate
         where adid = v_adid
           and status != 0;
        goto Next_Adid;
      end if;
    
      --如果下载地址中有1个为正常投放则 广告改为正常投放
      if status1 > 0 then
        update ad_adinfo
           set status = 1, lastupdate = sysdate
         where adid = v_adid
           and status != 1;
      
        goto Next_Adid;
      end if;
    
      --如果下载地址中有1个为 日到量 则 广告改为 日到量 【 but 无下载地址正在投放 】
      if status2 > 0 then
        update ad_adinfo
           set status = 2, lastupdate = sysdate
         where adid = v_adid
           and status != 2;
      
        goto Next_Adid;
      end if;
    
      --如果下载地址中有1个为 总到量 则 广告改为 总到量 【 but 无下载地址正在投放 与 日到量 】
      if status3 > 0 then
        update ad_adinfo
           set status = 3, lastupdate = sysdate
         where adid = v_adid
           and status != 3;
      
        goto Next_Adid;
      end if;
    
      --如果停止投放数等于 总下载地址数 则广告改为 停止投放
      if status4 = v_status_a then
        update ad_adinfo
           set status = 4, lastupdate = sysdate
         where adid = v_adid
           and status != 4;
        goto Next_Adid;
      end if;
    
      <<Next_Adid>>
      null;
      commit;
    end loop;
  
  EXCEPTION
    --失败
    when others then
      rollback;
      v_message := '错误编码：' || sqlcode || '  错误信息 ：' || sqlerrm;
      return;
  end AD_ControlSet;

end P_AD_Auto_Job;
/


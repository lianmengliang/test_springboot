create package P_AD_Auto_Job is

  TYPE T_Cursor IS REF CURSOR;

  /*广告自动作业*/

  PROCEDURE AD_ControlSet;
  /*****************************************************************
      procedure name: AD_ControlSet
      purpose: 广告控量
      edit: 2017-05-23 add by 小沈 
  ****************************************************************/

end P_AD_Auto_Job;


/


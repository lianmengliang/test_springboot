create package P_Report_Entry is
  Procedure Job_DayClick;
  /*****************************************************************
        procedure name: Job_DayClick
        purpose: 每日点击下载信息记录
        edit: 2019-02-20 add by 小沈
    ****************************************************************/
  Procedure Job_DayReg;
  /*****************************************************************
      procedure name: Job_DayReg
      purpose: 每日注册信息记录
      edit: 2017-07-23 add by 小沈
  ****************************************************************/
  -- Purpose : 报表信息录入


end P_Report_Entry;


/


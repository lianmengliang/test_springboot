create package P_FIN_Calculation is

  -- Purpose : 财务数据计算

  Procedure Job_Channel_Expend;
  /*****************************************************************
      procedure name: Job_Channel_Expend
      purpose: 渠道消耗自动计算
      edit: 2017-06-18 add by 小沈
  ****************************************************************/

  Procedure Job_Expend_Day;
  /*****************************************************************
      procedure name: Job_Expend_Day
      purpose: 渠道消耗日报表
      edit: 2017-06-18 add by 小沈
  ****************************************************************/

  Procedure Job_Adv_Expend;
  /*****************************************************************
      procedure name: Job_Adv_Expend
      purpose: 广告主消耗自动计算
      edit: 2017-08-07 add by 小沈
  ****************************************************************/

  Procedure Job_Adv_Expend_Day;
  /*****************************************************************
      procedure name: Job_Expend_Day
      purpose: 渠道消耗日报表
      edit: 2017-08-07 add by 小沈
  ****************************************************************/

end P_FIN_Calculation;


/


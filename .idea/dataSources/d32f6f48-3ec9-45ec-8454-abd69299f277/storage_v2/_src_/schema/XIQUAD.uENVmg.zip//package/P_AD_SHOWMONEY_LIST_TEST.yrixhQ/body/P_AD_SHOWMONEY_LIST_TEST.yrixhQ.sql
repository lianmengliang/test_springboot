create PACKAGE BODY P_AD_ShowMoney_List_Test AS

  /*判断 用户还可获得奖励金额--广告列表使用 使用表缓存 */

  Function FQ_Userid
  /*****************************************************************
        Procedure Name :FQ_Userid
        Purpose:  根据闲玩用户 判断用户还可获得奖励金额
        Edit: 2018-11-17 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_ADStatus In Number, --广告投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放）
   I_Deviceid In Varchar2, --设备号ID
   I_Userid   In Number, --闲玩用户编号
   I_PType    In Number --1、ios  2、安卓
   ) Return varchar2 As
    PRAGMA AUTONOMOUS_TRANSACTION; -------------方法函数 被嵌套，且有表操作 必写
    -- 0_金额 【0 表示未绑定 1表示用户已绑定但是无追加奖励 2表示为用户已绑定并有追加奖励  3表示为用户仅绑定】
    v_bind number; --绑定数
  
    v_AllMoney number; --用户可获得金额
    v_AllTimes number; --已获得总奖励次数
    v_unit     varchar2(50); --货币单位描述 默认元
    v_rate     number; --货币与人名币比率 1：1
    v_msg      varchar2(500) := '0_0'; ---返回信息
    v_ischange number := 0; --是否开启货币转换 0：否 1：是
  
    v_isCache number := 0; -- 可用缓存记录数
  
  begin
  
    v_AllMoney := 0;
    v_AllTimes := 0;
  
    
  
    --判断用户是否绑定
    select count(1)
      into v_bind
      from ad_app_bind
     where adid = I_ADID
       and userid = I_Userid;
  
    select count(1)
      into v_isCache
      from cache_ad_money
     where adid = i_adid
       and userid = i_userid
       and status = 1;
  
    if v_isCache = 1 then
      select reward, reward_times
        into v_AllMoney, v_AllTimes
        from cache_ad_money
       where adid = i_adid
         and userid = i_userid
         and status = 1;
    else
      v_isCache := 0;
    end if;
  
    --如果金额为空则重新查询 JOB会跑 金额和显示状态
    if v_isCache = 0 then
    
      -- 根据闲玩用户 获得还可获得奖励金额
      p_ad_showmoney_v2.pq_usermoney(i_adid     => i_adid,
                                     i_appid    => i_appid,
                                     i_adstatus => i_adstatus,
                                     i_deviceid => i_deviceid,
                                     i_userid   => i_userid,
                                     i_ptype    => i_ptype,
                                     o_allmoney => v_AllMoney,
                                     o_alltimes => v_AllTimes);
    
      --前面对广告的基础判断已判断，所以可以记录缓存，广告未投放等状态，再前面直接判断了
      insert into cache_ad_money
        (id,
         adid,
         appid,
         deviceid,
         userid,
         ptype,
         reward,
         reward_times,
         status)
        select sq_cache_ad_money.nextval,
               i_adid,
               i_appid,
               i_deviceid,
               i_userid,
               i_ptype,
               v_AllMoney,
               v_AllTimes,
               1
          from dual
         where not exists (select *
                  from cache_ad_money
                 where adid = i_adid
                   and userid = i_userid);
      commit;
    
    end if;
  
    --货币单位描述 默认元
    --货币与人名币比率 1：1
    select unit, rate, ischange
      into v_unit, v_rate, v_ischange
      from ad_channel
     where appid = I_APPId;
  
    -- 0_金额 【0 表示未绑定 1表示用户已绑定但是无追加奖励 2表示为用户已绑定并有追加奖励  3表示为用户仅绑定】
  
    if v_bind = 0 then
      --未绑定
      v_msg := '0_' || P_Base_Fun.fq_monetaryunit(v_AllMoney, v_ischange) ||
               v_unit;
      return v_msg;
    
    else
      --已绑定，但是无可领取奖励
      if v_AllMoney <= 0 then
        v_msg := '1_' || P_Base_Fun.fq_monetaryunit(v_AllMoney, v_ischange) ||
                 v_unit;
        return v_msg;
      
      else
        --如果没拿过奖励则为仅下载
        if v_AllTimes = 0 then
          v_msg := '3_' ||
                   P_Base_Fun.fq_monetaryunit(v_AllMoney, v_ischange) ||
                   v_unit;
        else
          v_msg := '2_' ||
                   P_Base_Fun.fq_monetaryunit(v_AllMoney, v_ischange) ||
                   v_unit;
        end if;
      
        return v_msg;
      end if;
    
    end if;
    commit;
    return v_msg;
  
  exception
    --失败
    when others then
      rollback;
      v_msg := '0_0';
      --v_msg := sqlerrm || sqlcode;
      return v_msg;
  end FQ_Userid;

end P_AD_ShowMoney_List_Test;
/


create procedure AAA_Users
/*****************************************************************
      Procedure Name :AAA_Users
      Purpose: 对已有用户标号的绑定表初始化
      Edit: 2016-10-31 add by 小沈
  ****************************************************************/
(I_Sign    in number, --标签
 O_Result  out number, --返回（0正确，其他为提示或错误）
 O_Message out varchar2 --返回信息（操作结果，成功或者错误信息）
 ) is
  v_n        number;
  v_userid   number;
  v_deviceid varchar2(100);
  v_result   number;
  v_message  varchar2(100);
  v_s_date   date;
  v_e_date   date;
  cursor Cur_Users is
    select appid, appsign, ptype, userid
      from ad_app_users
     where appsign != '0'
       and appsign != 'null'
     order by userid asc;

begin

  ----------------------------------------------------
  --步骤一：校验数据输入的合法性，以及初始化赋值
  ----------------------------------------------------
  O_Result  := 0;
  O_Message := '初始化完成';

  for cur in Cur_Users loop
    update ad_app_bind
       set userid = cur.userid
     where appid = cur.appid
       and appsign = cur.appsign
       and ptype = cur.ptype
       and userid is null;
    commit;
  end loop;

  ----------------------------------------------------
  --步骤三：完成
  ----------------------------------------------------

  return;
exception
  when others then
    rollback;
    O_Result  := -9;
    O_Message := '初始化异常！错误消息：' || sqlerrm || '错误ID:' || sqlcode;
    return;
  
end AAA_Users;


/


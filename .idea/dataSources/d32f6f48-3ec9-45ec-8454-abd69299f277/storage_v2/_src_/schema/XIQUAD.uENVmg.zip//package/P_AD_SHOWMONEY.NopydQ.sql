create PACKAGE P_AD_ShowMoney AS

  /*判断 设备号还可获得奖励金额 */

  Function FQ_Deviceid
  /*****************************************************************
        Procedure Name :FQ_Deviceid
        Purpose:  根据设备号 判断用户还可获得奖励金额
        Edit: 2017-02-16 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_ADStatus In Number, --广告状态  0 正常 1、广告尚未投放 2、日流量到量 3、总流量到量 4、已停止投放
   I_Deviceid In Varchar2, --设备号ID
   I_PType    In Number --1、ios  2、安卓
   ) Return varchar2;

  Function FQ_Deviceid_Easy
  /*****************************************************************
        Procedure Name :FQ_Deviceid_Easy
        Purpose:  根据设备号 判断用户还可获得奖励金额-简洁版
        Edit: 2017-11-23 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_ADStatus In Number, --广告状态  0 正常 1、广告尚未投放 2、日流量到量 3、总流量到量 4、已停止投放
   I_Deviceid In Varchar2, --设备号ID
   I_PType    In Number --1、ios  2、安卓
   ) Return varchar2;

end P_AD_ShowMoney;


/


create package P_Finance_Manage is

  TYPE T_CURSOR IS REF CURSOR;

  -- Purpose : 财务管理

  procedure PQ_AwardLevel_List
  /*****************************************************************
        Procedure Name :PQ_AwardLevel_List
        Purpose: 奖励级别列表
        Edit: 2018-11-27 add by 小沈
    ****************************************************************/
  (I_AdminID       In Varchar2,
   I_ADID          In Number,
   I_URLID         IN Number,
   O_AdTitle       Out Varchar2,
   O_CUSTOMER      out Varchar2,
   O_Marketer      out varchar2,
   O_OutCursor     Out t_cursor, --返回游标
   O_OutInfoCursor out t_cursor, --返回信息游标
   O_Result        Out Number,
   O_Message       Out Varchar2);

  procedure PW_Set
  /*****************************************************************
    Procedure Name: PW_Set
    Purpose: 广告结算设置
    Edit: 2018-11-27 add by 小沈 
    Comment:
    ****************************************************************/
  (I_AdminID     In Varchar2, --管理员ID
   I_ADID        In Number, --   广告ID   
   I_UrlID       In Number, --下载地址id 
   I_PutTime     In Varchar2, --投放时间 
   I_IsHand      In Number, --  是否需要手工录入  0:否 ;1:是 
   I_Interface   In Number, --  是否有做接口 0:否 ;1:是 
   I_Customer    In Varchar2, --   商家名称 
   I_Marketer    In Varchar2, --   市场人员 
   I_Taxrate     In Number, --  税率 6% 传 0.06 
   I_PayType     In Number, --  付款方式 预付 1； 后付 2； 
   I_MaxDebt     In Number, --  最大允许欠款金额
   I_Ad_Manage   In Varchar2, --   广告负责人   
   I_Dlevel_List In Varchar2, --   奖励级别  
   I_Eventl_List In Varchar2, --   奖励说明
   I_IsAuto_List In Varchar2, --  是否自动获取奖励数据  
   I_Price_List  In Varchar2, --  单价
   O_Result      Out Number,
   O_Message     Out Varchar2);

end P_Finance_Manage;
/


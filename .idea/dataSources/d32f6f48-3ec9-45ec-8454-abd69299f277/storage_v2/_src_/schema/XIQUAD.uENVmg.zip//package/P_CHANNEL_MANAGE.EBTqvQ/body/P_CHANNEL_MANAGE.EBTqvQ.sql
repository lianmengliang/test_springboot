create package body P_Channel_Manage is

  /*渠道信息*/

  procedure pw_Add
  /*****************************************************************
        Procedure Name :pw_Add
        Purpose: 渠道信息增加
        Edit: 2017-02-15 add by 小沈
    ****************************************************************/
  (I_AdminID      In Varchar2,
   I_Name         In Varchar2, --  渠道应用名称
   I_Status       In Number, --  状态 0 测试 1开启 2停止
   I_APPSecret    In Varchar2, --  密钥 --随机字母字符串组成 16位
   I_AType        In Number, -- 应用类型 1苹果 2安卓
   I_Unit         In Varchar2, --  货币单位描述
   I_Rate         In Number, --  货币与人名币比率
   I_Downapp      In Varchar2, --  App下载方法
   I_Openurl      In Varchar2, -- 打开页面地址方法
   I_Ischange     In number, --  是否开启货币转换
   I_Arate        In number, --  渠道奖励设置比率
   I_Marketer     In Varchar2, --  市场人员
   I_Note         In Varchar2, --备注信息
   I_IsInt        In number, --是否以整数计算
   I_SHOWLOGO     In number, --显示闲玩Logo等相关信息
   I_ISCONVERSION In number, --是否转换为蘑菇星球
   I_INTEGRAL     In number, --是否是有积分渠道
   I_SHOWNAME     In Varchar2, --渠道名称（显示用）
   I_PRICERATE    In number, --渠道结算金额
   O_Result       Out number,
   O_Message      Out varchar2) is
    v_n  number;
    V_QX number; --本模块的权限代码
  begin
    O_Result  := 0;
    O_Message := '保存成功';
  
    V_QX := 103; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      return;
    END IF;
  
    if I_Name is null then
      O_RESULT  := 1;
      O_MESSAGE := '渠道应用名称不能为空，请检查！';
      return;
    end if;
  
    select count(1) into v_n from ad_channel where name = I_Name;
  
    if v_n > 0 then
      O_RESULT  := 2;
      O_MESSAGE := '该渠道应用已存在，请检查！';
      return;
    end if;
  
    if I_Status not in (0, 1, 2) then
      O_RESULT  := 3;
      O_MESSAGE := '该渠道应用状态不正常，请检查！';
      return;
    end if;
  
    if I_APPSecret is null or length(I_APPSecret) < 16 then
      O_RESULT  := 4;
      O_MESSAGE := '该渠道应用密钥不正常，请检查！';
      return;
    end if;
  
    --  货币单位描述
    if I_Unit is null then
      O_RESULT  := 5;
      O_MESSAGE := '货币单位描述不能为空，请检查！';
      return;
    end if;
  
    --  货币单位描述
    if I_Rate is null then
      O_RESULT  := 5;
      O_MESSAGE := '货币与人名币比率不能为空， 默认为1，表示1：1 ，请检查！';
      return;
    end if;
  
    if I_IsInt is null then
      O_RESULT  := 5;
      O_MESSAGE := '请选择是否以整数计算！';
      return;
    end if;
  
    insert into ad_channel
      (appid,
       name,
       status,
       appsecret,
       atype,
       unit,
       rate,
       downapp,
       openurl,
       ischange,
       a_rate,
       marketer,
       note,
       isint,
       is_showlogo,
       isconversion,
       integral,
       show_name,
       price_rate)
    values
      (sq_ad_channel.Nextval,
       I_name,
       I_status,
       I_appsecret,
       I_atype,
       I_unit,
       I_rate,
       I_Downapp,
       I_Openurl,
       I_Ischange,
       I_Arate,
       I_Marketer,
       I_Note,
       I_IsInt,
       I_SHOWLOGO,
       I_ISCONVERSION,
       I_INTEGRAL,
       I_name,
       I_PRICERATE);
  
    commit;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pw_Add;

  procedure pw_Edit
  /*****************************************************************
        Procedure Name :pw_Edit
        Purpose: 渠道应用信息修改
        Edit: 2017-2-15 add by 小沈
    ****************************************************************/
  (I_AdminID      In Varchar2,
   I_APPId        In Number, --渠道应用ID
   I_Name         In Varchar2, --  渠道应用名称
   I_Status       In Number, --  状态 0 测试 1开启 2停止
   I_APPSecret    In Varchar2, --  密钥 --随机字母字符串组成 16位
   I_AType        In Number, -- 应用类型 1苹果 2安卓
   I_Unit         In Varchar2, --  货币单位描述
   I_Rate         In Number, --  货币与人名币比率
   I_Downapp      In Varchar2, --  App下载方法
   I_Openurl      In Varchar2, -- 打开页面地址方法
   I_Ischange     In number, --  是否开启货币转换
   I_Arate        In number, --  渠道奖励设置比率
   I_Marketer     In Varchar2, --  市场人员
   I_Note         In Varchar2, --备注信息
   I_IsInt        In number, --是否以整数计算
   I_SHOWLOGO     In number, --显示闲玩Logo等相关信息
   I_ISCONVERSION In number, --是否转换为蘑菇星球
   I_INTEGRAL     In number, --是否是有积分渠道
   I_SHOWNAME     In Varchar2, --渠道名称（显示用）
   I_PRICERATE    In number, --渠道结算金额
   O_Result       Out number,
   O_Message      Out varchar2) is
    V_QX NUMBER; --本模块的权限代码、
    v_n  number;
  begin
    o_result  := 0;
    o_message := '保存成功';
  
    V_QX := 103; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    --输入参数是否正确
    if I_APPId is null then
      o_result  := 1;
      o_message := '输入参数有误，请检查！';
      return;
    end if;
  
    select count(1) into v_n from ad_channel where appid = I_APPId;
  
    if v_n = 0 then
      o_result  := 2;
      o_message := '未找到指定渠道应用，不能修改！';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_channel
     where name = I_Name
       and appid != I_APPId;
  
    if v_n > 0 then
      O_RESULT  := 3;
      O_MESSAGE := '该渠道应用已存在，请检查！';
      return;
    end if;
  
    if I_Status not in (0, 1, 2) then
      O_RESULT  := 4;
      O_MESSAGE := '该渠道应用状态不正常，请检查！';
      return;
    end if;
  
    if I_APPSecret is null or length(I_APPSecret) < 16 then
      O_RESULT  := 5;
      O_MESSAGE := '该渠道应用密钥不正常，请检查！';
      return;
    end if;
  
    --  货币单位描述
    if I_Unit is null then
      O_RESULT  := 6;
      O_MESSAGE := '货币单位描述不能为空，请检查！';
      return;
    end if;
  
    --  货币单位描述
    if I_Rate is null then
      O_RESULT  := 7;
      O_MESSAGE := '货币与人名币比率不能为空， 默认为1，表示1：1 ，请检查！';
      return;
    end if;
  
    if I_IsInt is null then
      O_RESULT  := 5;
      O_MESSAGE := '请选择是否以整数计算！';
      return;
    end if;
  
    --  状态 0 测试 1开启 2停止
    if I_Status = 1 then
      update ad_channel
         set name         = I_Name,
             status       = I_Status,
             appsecret    = I_APPSecret,
             atype        = I_AType,
             unit         = I_Unit,
             rate         = I_Rate,
             downapp      = I_Downapp,
             openurl      = I_Openurl,
             ischange     = I_Ischange,
             a_rate       = I_Arate,
             otime        = sysdate,
             marketer     = I_Marketer,
             note         = I_note,
             isint        = I_IsInt,
             is_showlogo  = I_SHOWLOGO,
             isconversion = I_ISCONVERSION,
             integral     = I_INTEGRAL,
             show_name    = I_SHOWNAME,
             price_rate   = I_PRICERATE
       where appid = I_APPId;
    else
    
      update ad_channel
         set name         = I_Name,
             status       = I_Status,
             appsecret    = I_APPSecret,
             atype        = I_AType,
             unit         = I_Unit,
             rate         = I_Rate,
             downapp      = I_Downapp,
             openurl      = I_Openurl,
             ischange     = I_Ischange,
             a_rate       = I_Arate,
             marketer     = I_Marketer,
             note         = I_note,
             isint        = I_IsInt,
             is_showlogo  = I_SHOWLOGO,
             isconversion = I_ISCONVERSION,
             integral     = I_INTEGRAL,
             show_name    = I_SHOWNAME,
             price_rate   = I_PRICERATE
       where appid = I_APPId;
    end if;
  
    commit;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '修改失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pw_Edit;

  procedure pq_Info
  /*****************************************************************
        Procedure Name :pq_Info
        Purpose: 获取单个渠道信息
        Edit: 2017-2-15 add by 小沈
    ****************************************************************/
  (I_AdminID   In varchar2,
   I_APPId     In Number, --渠道应用ID
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out number,
   O_Message   Out varchar2) is
    v_sql varchar2(1000);
    V_QX  NUMBER; --本模块的权限代码
  begin
    o_result  := 0;
    o_message := '显示成功';
    V_QX      := 103; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    if I_APPId is null then
      o_result  := 101;
      o_message := '参数有误！';
      return;
    end if;
  
    v_sql := 'select a.appid, a.name, a.status, a.appsecret, a.atype, a.unit, a.rate,a.downapp,a.openurl,a.ischange,a.a_rate,a.marketer,a.note,a.isint,a.is_showlogo,a.isconversion ,a.integral ,a.show_name,b.account,a.price_rate 
from ad_channel a left join  ch_admin b on  a.ch_account_id  =b.account_id where  a.appid =' ||
             I_APPId;
  
    open O_OutCURSOR for v_sql;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '获取失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pq_INFO;

  procedure pq_List
  /*****************************************************************
        Procedure Name :pq_List
        Purpose: 广告列表
        Edit: 2017-02-15 add by 小沈
    ****************************************************************/
  (I_AdmInId        In Varchar2,
   I_APPId          In Number, --渠道应用ID
   I_Name           In Varchar2, --渠道应用名称
   I_Status         In Number, --状态 0 测试 1开启 2 停止
   I_AType          In Number, --应用类型 1苹果 2安卓
   I_PageSize       In Number,
   I_PageNO         In Number,
   O_OutRecordCount Out Number,
   O_OutCursor      Out t_cursor, --返回游标
   O_Result         Out Number,
   O_Message        Out Varchar2) is
    v_sql       varchar2(2000);
    v_selectsql varchar2(1000);
    V_HEIROWNUM NUMBER;
    V_LOWROWNUM NUMBER;
    V_QX        NUMBER; --本模块的权限代码
  begin
    o_result  := 0;
    o_message := '显示成功';
    V_QX      := 103; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
    v_sql := 'select a.appid ,a.name 
             ,decode(a.status,0,''测试'',1,''开启'',2,''停止'',''其他'') status,decode(a.atype ,1,''苹果'',2,''安卓'',''其他'') atype ,a.unit ,a.rate 
             ,to_char(a.otime ,''yyyy-mm-dd'') otime,a.marketer ,decode(a.isconversion ,0,''未转换'',1,''已转换'',''其他'') isconversion ,b.account,b.account_id   from ad_channel a left join ch_admin b on a.CH_ACCOUNT_ID=b.account_id where 1=1   ';
  
    v_selectsql := '';
  
    if I_APPId is not null then
      v_selectsql := v_selectsql || ' and a.appid  = ' || I_APPId;
    end if;
  
    if I_Name is not null then
      v_selectsql := v_selectsql || ' and a.name   like ''%' || I_Name ||
                     '%''';
    end if;
  
    if I_Status > -1 then
      v_selectsql := v_selectsql || ' and a.status =''' || I_Status || '''';
    end if;
  
    if I_Status = -1 then
      v_selectsql := v_selectsql || ' and  a.status =1 ';
    end if;
  
    if I_AType is not null then
      v_selectsql := v_selectsql || ' and a.atype  =''' || I_AType || '''';
    end if;
  
    execute immediate 'select count(1) from ad_channel a where 1 = 1 ' ||
                      v_selectsql
      into O_OutRECORDCOUNT;
  
    v_sql := v_sql || v_selectsql;
  
    ----执行分页查询
    V_HEIROWNUM := I_PAGENO * I_PAGESIZE;
    V_LOWROWNUM := V_HEIROWNUM - I_PAGESIZE + 1;
    V_SQL       := 'select  appid ,name ,status,atype,unit,rate,otime,marketer ,isconversion,account,account_id rn
                    FROM (
                    select  appid ,name ,status,atype,unit,rate,otime,marketer,isconversion, account,account_id,rownum rn
                    FROM (' || v_sql || ') c
                    WHERE rownum <= ' ||
                   TO_CHAR(V_HEIROWNUM) || '
                    ) d
                    WHERE rn >= ' || TO_CHAR(V_LOWROWNUM);
    open O_OutCURSOR for v_sql;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '查询失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pq_List;
  procedure pw_AccountSet
  /*****************************************************************
        Procedure Name :pw_Edit
        Purpose: 渠道账号设置
        Edit: 2018-11-01 add by 小胡
    ****************************************************************/
  (I_AdminID In Varchar2,
   I_APPId   In Number, --渠道应用ID
   I_Account In Varchar2, --  渠道账号
   O_Result  Out number,
   O_Message Out varchar2) is
    V_QX        NUMBER; --本模块的权限代码、
    v_n         number;
    v_accountid number;
  begin
    o_result  := 0;
    o_message := '保存成功';
  
    V_QX := 103; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    --输入参数是否正确
    if I_APPId is null then
      o_result  := 1;
      o_message := '输入参数有误，请检查！';
      return;
    end if;
  
    select count(1) into v_n from ad_channel where appid = I_APPId;
  
    if v_n = 0 then
      o_result  := 2;
      o_message := '未找到指定渠道应用，不能保存！';
      return;
    end if;
  
    select count(1) into v_n from ch_admin where account = I_Account;
  
    if v_n <= 0 then
      o_result  := 1;
      o_message := '此账号未注册，请输入正确的渠道账号！';
      return;
    end if;
  
    select account_id
      into v_accountid
      from ch_admin
     where account = I_Account;
    update ad_channel
       set ch_account_id = v_accountid
     where appid = I_APPId;
    commit;
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '修改失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pw_AccountSet;
end P_Channel_Manage;
/


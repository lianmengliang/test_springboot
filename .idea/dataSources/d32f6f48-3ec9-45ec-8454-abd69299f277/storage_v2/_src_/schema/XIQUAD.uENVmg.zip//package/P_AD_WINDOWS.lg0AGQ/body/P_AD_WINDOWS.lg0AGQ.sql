create package body P_AD_Windows is

  /*windows 服务 信息获取与处理 */

  procedure PQ_RegUserList
  /*****************************************************************
        Procedure Name :PQ_UserList
        Purpose: 获取已注册用户列表
        Edit: 2017-08-05 add by 小沈
    ****************************************************************/
  (I_Sign      In Number, --标记符号 1，2，3……
   I_PageSize  In Number, --每页记录数
   I_PageNO    In Number, --当前页码,从 1 开始
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    V_SQL         varchar2(3000);
    v_PageSize    number;
    v_PageNO      number;
    V_HeiRowNUM   number; --小于第几行 分页用
    V_LowROWNUM   number; --大于第几行 分页用
    V_ServerNum   number := 17; --跑等级信息的服务数量
    v_OrderServer number := 7; --跑10天前注册信息的服务供多少台
    v_NewServer   number := 10; --跑10天内注册信息的服务供多少台
    v_Sign        number := 0; --当前服务标识
    v_IsNew       number := 1; --是否跑新用户 0否 1是
  
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    v_PageSize := I_PageSize;
    v_PageNO   := I_PageNO;
  
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
    -- return;
  
    if I_PageNO = 1 then
      insert into win_ad_logs
        (sign, note, pageno, type)
      values
        (I_Sign,
         'I_PageSize' || I_PageSize || ' I_PageNO:' || I_PageNO,
         I_PageNO,
         2);
      commit;
    end if;
  
    /* return;*/
    --and itime>=trunc(sysdate)-10   and adid  not in (2759 ) 
  
    V_SQL := ' select  adid,appid ,deviceid,merid, mername ,urlid,userid,e_time   from ( 
       select  adid,appid ,deviceid,merid, mername ,urlid,userid ,e_time from ad_win_run where adid in
                   (select adid
                      from (select adid, rownum rn
                              from ad_adinfo
                             where status in (1, 2, 3) 
                               and showtype = 1 
                                or (status = 4 and
                                   trunc(stoptime)= trunc(sysdate)  and
                                   stoptime !=
                                   to_date(''2099-01-01'', ''yyyy-mm-dd'')
                                   )
                              ) where adid not in (3175)
                      )  and  userid>10 and  sysdate-(2/24)>= e_time    and  mod(userid,' ||
             V_ServerNum || ')=' || I_Sign || ' 
                       ) order by e_time asc';
  
    ----执行分页查询
    V_HeiRowNUM := v_PageNO * v_PageSize;
    V_LowROWNUM := V_HeiRowNUM - v_PageSize + 1;
  
    V_SQL := 'select  adid,appid ,deviceid,merid, mername ,urlid,userid,e_time,rn
    from  ( select  adid,appid ,deviceid,merid, mername ,urlid,userid,e_time,rownum rn
    from (' || V_SQL || ') a
    where rownum <= ' || TO_CHAR(V_HeiRowNUM) || '
    ) b
    where rn >= ' || TO_CHAR(V_LowROWNUM);
  
    --注意对rownum别名的使用,第一次直接用rownum,第二次一定要用别名rn
    --- order by 放里面会影响速度
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    OPEN O_OUTCURSOR FOR V_SQL;
    return;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 1001;
      O_Message := '查询异常！';
      -- o_message := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PQ_RegUserList;

  procedure PQ_AwardUserList
  /*****************************************************************
        Procedure Name :PQ_AwardUserList
        Purpose: 获取已获得奖励用户列表
        Edit: 2018-01-13 add by 小沈
    ****************************************************************/
  (I_Sign      In Number, --标记符号 1，2，3……
   I_PageSize  In Number, --每页记录数
   I_PageNO    In Number, --当前页码,从 1 开始
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    V_SQL       varchar2(3000);
    v_PageSize  number;
    v_PageNO    number;
    V_HeiRowNUM number; --小于第几行 分页用
    V_LowROWNUM number; --大于第几行 分页用
  
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    v_PageSize := I_PageSize;
    v_PageNO   := I_PageNO;
  
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
    -- return;
    if I_PageNO = 1 then
      insert into win_ad_logs
        (sign, note, pageno, type)
      values
        (I_Sign,
         'I_PageSize' || I_PageSize || ' I_PageNO:' || I_PageNO,
         I_PageNO,
         3);
      commit;
    end if;
  
    /* return;*/
    --and itime>=trunc(sysdate)-10  and a.adid!=2554   itime>=sysdate-3 and a.adid not in (3175,3216)
  
    V_SQL := '   select  a.adid,a.appid,a.deviceid,a.merid,a.mername,a.urlid,a.userid from  ad_win_run_award  a  where    a.userid>10 and   a.status=0  order by e_time asc ';
  
    ----执行分页查询
    V_HeiRowNUM := v_PageNO * v_PageSize;
    V_LowROWNUM := V_HeiRowNUM - v_PageSize + 1;
  
    V_SQL := 'select  adid,appid ,deviceid,merid, mername ,urlid,userid,rn
    from  ( select  adid,appid ,deviceid,merid, mername ,urlid,userid,rownum rn
    from (' || V_SQL || ') a
    where rownum <= ' || TO_CHAR(V_HeiRowNUM) || '
    ) b
    where rn >= ' || TO_CHAR(V_LowROWNUM);
  
    --注意对rownum别名的使用,第一次直接用rownum,第二次一定要用别名rn
    --- order by 放里面会影响速度
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    OPEN O_OUTCURSOR FOR V_SQL;
    return;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 1001;
      O_Message := '查询异常！';
      -- o_message := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PQ_AwardUserList;

  procedure PQ_AllMain
  /*****************************************************************
        Procedure Name :PQ_AllMain
        Purpose: Windows服务奖励判断全部入口
         Edit: 2017-08-05 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_Urlid    In Number, --下载地址id 
   I_MerId    In Varchar2, --用户注册帐号id
   I_Levle    In Number, --用户等级、金额等
   I_AType    In Number, --  发奖类型 1 按固定值发放 
   I_AGroup   In Number, --组别
   O_Result   Out Number,
   O_Message  Out Varchar2) is
    v_n       number;
    v_u_level number := 0; --用户等级 
  begin
    o_result  := 0;
    o_message := '接收成功';
  
    select count(1)
      into v_n
      from ad_win_run_level
     where adid = i_adid
       and awardgroup = I_AGroup
       and merid = I_MerId;
    if v_n <= 0 then
      insert into ad_win_run_level
        (adid, deviceid, u_level, awardgroup, merid)
      values
        (I_ADID, I_Deviceid, I_Levle, I_AGroup, I_MerId);
      commit;
    
    else
      --如果传入等级小于之前等级则 return;
      select u_level
        into v_u_level
        from ad_win_run_level
       where adid = i_adid
         and awardgroup = I_AGroup
         and merid = I_MerId;
    
      if I_Levle <= v_u_level then
        return;
      end if;
    
      update ad_win_run_level
         set u_level = I_Levle, ltime = sysdate
       where adid = i_adid
         and awardgroup = I_AGroup
         and merid = I_MerId;
      commit;
    
    end if;
  
    P_AD_Windows.PQ_Common(i_adid     => I_ADID,
                           i_appid    => I_APPId,
                           i_deviceid => I_Deviceid,
                           i_urlid    => I_Urlid,
                           i_merid    => I_MerId,
                           i_levle    => I_Levle,
                           i_agroup   => I_AGroup,
                           o_result   => O_Result,
                           o_message  => O_Message);
  
    commit;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      o_result  := 1001;
      o_message := '接收异常！';
      RETURN;
  end PQ_AllMain;

  procedure PQ_Common
  /*****************************************************************
        Procedure Name :PQ_Common
        Purpose: 普通固定奖励发放 
         Edit: 2017-08-05 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_Urlid    In Number, --下载地址id 
   I_MerId    In Varchar2, --用户注册帐号id
   I_Levle    In Number, --用户等级、金额等
   I_AGroup   In Number, --组别
   O_Result   Out Number,
   O_Message  Out Varchar2) is
    v_n Number;
  
    cursor myCur_award is
      select dlevel,
             event,
             needlevel,
             times,
             atype,
             awardgroup,
             price,
             amoney,
             isshow
        from ad_awardset
       where adid = I_ADID
         and appid = I_APPId
         and awardgroup = I_AGroup
       order by dlevel desc;
  
  begin
    O_Result  := 0;
    O_Message := '奖励成功！';
  
    select count(1)
      into v_n
      from ad_awardset
     where adid = i_adid
       and appid = I_APPId
       and awardgroup = I_AGroup;
    if v_n = 0 then
      O_RESULT  := 10;
      O_MESSAGE := '奖励参数尚未设置';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_app_bind
     where adid = I_ADID
       and appid = I_APPId
       and upper(deviceid) = upper(I_Deviceid)
       and upper(merid) = upper(I_MerId);
  
    if v_n <= 0 then
      O_RESULT  := 11;
      O_MESSAGE := '您还未下载或注册该任务';
      return;
    end if;
  
    --判断同组奖励该设备号是否已存在有则不奖励  t_ad_channel_order
    if I_AGroup >= 90 then
      --如果为同组奖励 表示该组别中的奖励 用户只能领取其中一个 ，领取过其中一个则该组别其他奖励均为过期
      --不加 appid 放宽 查询条件 
      select count(1)
        into v_n
        from fin_ad_flux
       where adid = I_ADID
         and upper(deviceid) = upper(I_Deviceid)
         and dlevel in (select dlevel
                          from ad_awardset
                         where adid = I_ADID
                           and appid = I_APPId
                           and awardgroup = I_AGroup);
    
      if v_n > 0 then
        O_RESULT  := 12;
        O_MESSAGE := '已经有过该奖励了';
        return;
      end if;
    
    end if;
  
    for cur in myCur_award loop
    
      --判断同组奖励该设备号是否已存在有则不奖励  t_ad_channel_order
      if I_AGroup >= 90 then
        --如果为同组奖励 表示该组别中的奖励 用户只能领取其中一个 ，领取过其中一个则该组别其他奖励均为过期
        select count(1)
          into v_n
          from fin_ad_flux
         where adid = I_ADID
           and upper(deviceid) = upper(I_Deviceid)
           and dlevel in (select dlevel
                            from ad_awardset
                           where adid = I_ADID
                             and appid = I_APPId
                             and awardgroup = I_AGroup);
      
        if v_n > 0 then
          O_RESULT  := 12;
          O_MESSAGE := '已经获得过该奖励了';
          return;
        end if;
      
      end if;
    
      select count(1)
        into v_n
        from fin_ad_flux
       where adid = I_ADID
         and upper(deviceid) = upper(I_Deviceid)
         and dlevel = cur.dlevel;
    
      --如果该设备已经获取过该奖励则跳过
      if v_n >= cur.times then
        GOTO CONTINUE_LOOP;
      end if;
    
      --游戏级别不够，不奖励
      if cur.needlevel > I_Levle then
        GOTO CONTINUE_LOOP;
      end if;
    
      insert into fin_ad_flux
        (id, adid, appid, deviceid, dlevel, merid, atype, urlid, itime)
      values
        (sq_fin_ad_flux.nextval,
         i_adid,
         i_appid,
         i_deviceid,
         cur.dlevel,
         i_merid,
         cur.atype,
         I_Urlid,
         sysdate);
    
      commit;
    
      <<CONTINUE_LOOP>>
      null;
    
    end loop;
  
  exception
    --失败 
    when others then
      rollback;
      O_Result  := 1001;
      O_Message := '领取奖励异常！';
      -- o_message := '领取奖励异常 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PQ_Common;

  procedure PQ_DownUserList
  /*****************************************************************
        Procedure Name :PQ_DownUserList
        Purpose: 获取已下载用户列表
        Edit: 2017-11-26 add by 小沈
    ****************************************************************/
  (I_Sign      In Number, --标记符号 1，2，3……
   I_PageSize  In Number, --每页记录数
   I_PageNO    In Number, --当前页码,从 1 开始
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    V_SQL       varchar2(3000);
    v_PageSize  number;
    v_PageNO    number;
    V_HeiRowNUM number; --小于第几行 分页用
    V_LowROWNUM number; --大于第几行 分页用
    V_ServerNum number := 6; --跑等级信息的服务数量
  
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    v_PageSize := I_PageSize;
    v_PageNO   := I_PageNO;
  
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
    --return;
  
    if I_PageNO = 1 then
      insert into win_ad_logs
        (sign, note, pageno, type)
      values
        (I_Sign,
         'I_PageSize' || I_PageSize || ' I_PageNO:' || I_PageNO,
         I_PageNO,
         1);
      commit;
    end if;
    /*   and  sysdate-(2/24)>= e_time  */
  
    V_SQL := '  select  a.adid,a.appid,a.userid,a.appsign,a.deviceid,a.merid,a.mername,a.urlid from  ad_win_run_down  a  where    a.userid>10 
      and   a.status=0 and  sysdate-(3/24)>= e_time and  mod(userid,' ||
             V_ServerNum || ')=' || I_Sign || '  order by e_time asc ';
  
    ----执行分页查询
    V_HeiRowNUM := v_PageNO * v_PageSize;
    V_LowROWNUM := V_HeiRowNUM - v_PageSize + 1;
  
    V_SQL := 'select adid,appid ,userid,appsign,deviceid,merid, mername ,urlid, rn
    from  ( select  adid,appid ,userid,appsign,deviceid,merid, mername ,urlid,rownum rn
    from (' || V_SQL || ') a
    where rownum <= ' || TO_CHAR(V_HeiRowNUM) || '
    ) b
    where rn >= ' || TO_CHAR(V_LowROWNUM);
  
    --注意对rownum别名的使用,第一次直接用rownum,第二次一定要用别名rn
    --- order by 放里面会影响速度
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    OPEN O_OUTCURSOR FOR V_SQL;
    return;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 1001;
      O_Message := '查询异常！';
      -- o_message := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PQ_DownUserList;

  procedure PW_Get_Reg
  /*****************************************************************
        Procedure Name :PW_Get_Reg
        Purpose: Windows抓取注册信息
        Edit: 2017-11-26 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告id 
   I_APPID    In Number, --渠道ID
   I_UserId   In Number, --闲玩用户ID 
   I_FID      In Varchar2, --广告主统计的来源id[apk渠道编号] 
   I_DeviceId In Varchar2, --返回设备号imei idfa
   I_SIMID    In Varchar2, --返回sim卡id
   I_Merid    In Varchar2, --用户注册帐号id
   I_MerName  In Varchar2, --用户注册帐号 
   I_APPSign  In Varchar2, --用户注册帐号 
   O_Result   Out Number,
   O_Message  Out Varchar2) is
    v_n       Number;
    v_appid   Number; --渠道合作编号
    v_appsign Varchar2(200); --渠道合作编号
    v_status  Number; --匹配状态 0 失败 ； 1  成功  
    v_amoney  Number; --奖励金额
    v_result  Number; --
    v_message Varchar2(100); -- 
    v_Cursor  t_cursor;
    v_isRun   number := 0; --是否为跑出来的注册0：否 1：是 
  begin
    o_result  := 0;
    o_message := '接收成功';
  
    select count(1)
      into v_n
      from ad_adv_back_reg
     where adid = I_ADID
       and userid = I_Merid;
    if v_n <= 0 then
      v_isRun := 1;
    end if;
  
    --快速跑注册中的也修改
    select count(1)
      into v_n
      from ad_win_run_downfast
     where adid = I_ADID
       and userid = I_UserId
       and status = 0;
    if v_n > 0 then
      update ad_win_run_downfast
         set merid   = I_Merid,
             mername = I_MerName,
             status  = 1,
             r_time  = sysdate,
             isrun   = v_isRun
       where adid = I_ADID
         and userid = I_UserId
         and status = 0;
      commit;
    end if;
  
    select count(1)
      into v_n
      from ad_win_run_down
     where adid = I_ADID
       and userid = I_UserId
       and status = 0;
    if v_n > 0 then
      update ad_win_run_down
         set merid   = I_Merid,
             mername = I_MerName,
             status  = 1,
             r_time  = sysdate,
             isrun   = v_isRun
       where adid = I_ADID
         and userid = I_UserId
         and status = 0;
      commit;
    
      p_ad_advertiser.pw_back_reg(i_adid      => i_adid,
                                  i_fid       => i_fid,
                                  i_deviceid  => i_deviceid,
                                  i_simid     => i_simid,
                                  i_userid    => I_Merid,
                                  i_name      => I_MerName,
                                  o_outcursor => v_Cursor,
                                  o_result    => o_result,
                                  o_message   => o_message);
    end if;
  
  exception
    --失败 
    when others then
      rollback;
      O_Result := -9;
      /*  O_Message := '记录失败！';*/
      O_Message := '记录失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_Get_Reg;

  procedure PW_UpRunUser
  /*****************************************************************
        Procedure Name :FQ_UpRunUser
        Purpose: 修改跑数据用户信息
        Edit: 2018-07-20 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID 
   I_APPId    In Number, --渠道应用ID 
   I_Deviceid In Varchar2, --设备号ID 
   I_MerId    In Varchar2, --商家帐号id  
   I_Urlid    In Number --下载地址id 
   ) is
    v_n number;
  begin
    select count(1)
      into v_n
      from ad_win_run
     where adid = I_ADID
       and merid = I_MerId;
    if v_n > 0 then
      update ad_win_run
         set l_time = e_time, e_time = sysdate
       where adid = I_ADID
         and merid = I_MerId;
      commit;
    end if;
  
  exception
    --失败
    when others then
      --v_msg := '失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      rollback;
    
  end PW_UpRunUser;

  Procedure Job_RegisterUser
  /*****************************************************************
        Procedure Name :PW_RegisterUser
        Purpose: 获取注册用户信息
         Edit: 2017-07-21 add by 小沈
    ****************************************************************/
   is
    --JOB 64 20分钟1波
    v_n       number;
    v_message varchar2(300);
  
    cursor User_List is
    
      select adid, appid, userid, deviceid, merid, mername, urlid
        from ad_app_bind
       where adid in (select adid
                        from ad_adinfo
                       where status in (1, 2, 3)
                         and showtype = 1)
         and ustatus in (2, 3)
         and lasttime >= sysdate - (30 / (24 * 60));
  
  begin
    v_n := 0;
  
    for C_User in User_List loop
    
      select count(1)
        into v_n
        from ad_win_run
       where adid = C_User.Adid
         and merid = C_User.merid;
    
      --如果已存在则不记录
      if v_n > 0 then
        goto Next_C_User;
      end if;
    
      insert into ad_win_run
        (adid, appid, userid, deviceid, merid, mername, urlid)
      values
        (C_User.Adid,
         C_User.Appid,
         C_User.Userid,
         C_User.Deviceid,
         C_User.Merid,
         C_User.Mername,
         C_User.Urlid);
    
      --单个  提交
      commit;
    
      <<Next_C_User>>
      null;
    
    end loop;
  
  exception
    when others then
      rollback;
      v_message := '错误编码：' || sqlcode || '  错误信息 ：' || sqlerrm;
      --添加日志
      insert into fin_log
        (appid, adid, urlid, msg)
      values
        (0,
         0,
         0,
         ' p_ad_windows.job_registeruser; 数据录入异常：' || v_message);
      commit;
    
      return;
  end Job_RegisterUser;

  Procedure Job_AwardUser
  /*****************************************************************
        Procedure Name :Job_AwardUser
        Purpose: 获取那过奖励用户信息
         Edit: 2017-07-22 add by 小沈
    ****************************************************************/
   is
    -- --JOB 84 20分钟1波
    v_n       number;
    v_ATime   date; --用户奖励时间
    v_R_Atime date; --跑数据表记录最近领取时间
    v_N_Hour  number; --当前小时
    v_sql     varchar2(200);
    v_message varchar2(300);
  
    cursor User_List is
    ---1小时内有领取奖励记录用户
      select a.adid,
             a.appid,
             a.deviceid,
             a.merid,
             a.mername,
             a.urlid,
             a.userid
        from ad_app_bind a,
             (select adid, userid
                from ad_app_flux
               where itime >= sysdate - 1 / 24
               group by adid, userid) b
       where a.adid = b.adid
         and a.userid = b.userid;
  
  begin
    v_n := 0;
  
    --判断当前时间是否为偶数值 如果是则清空表
  
    select to_number(to_char(sysdate, 'hh24')) into v_N_Hour from dual;
  
    if mod(v_N_Hour, 2) = 0 then
      --清除记录表  --危险操作
      v_sql := 'truncate table ad_win_run_award';
      execute immediate v_sql;
    end if;
  
    for C_User in User_List loop
    
      --获取用户该广告最近领奖时间
      select max(itime)
        into v_ATime
        from ad_app_flux
       where adid = C_User.Adid
         and userid = C_User.Userid;
    
      select count(1)
        into v_n
        from ad_win_run_award
       where adid = C_User.Adid
         and merid = C_User.merid;
    
      --如果不存在则添加记录
      if v_n <= 0 then
        insert into ad_win_run_award
          (adid, appid, userid, deviceid, merid, mername, urlid, a_time)
        values
          (C_User.Adid,
           C_User.Appid,
           C_User.Userid,
           C_User.Deviceid,
           C_User.Merid,
           C_User.Mername,
           C_User.Urlid,
           v_ATime);
        commit;
      end if;
    
      if v_n > 0 then
        --获取当前用户领取奖励时间是否和跑数据中的一致
        select a_time
          into v_R_Atime
          from ad_win_run_award
         where adid = C_User.Adid
           and merid = C_User.Merid;
        --如果不一致则修改状态
        if v_ATime != v_R_Atime then
          update ad_win_run_award
             set status = 0, a_time = v_ATime
           where adid = C_User.Adid
             and merid = C_User.Merid;
          commit;
        end if;
      
      end if;
    
      commit;
    
    end loop;
  
  exception
    when others then
      rollback;
      v_message := '错误编码：' || sqlcode || '  错误信息 ：' || sqlerrm;
      --添加日志
      insert into fin_log
        (appid, adid, urlid, msg)
      values
        (0,
         0,
         0,
         ' p_ad_windows.Job_AwardUser; 数据录入异常：' || v_message);
      commit;
      return;
  end Job_AwardUser;

  procedure PW_UpRunAwardUser
  /*****************************************************************
        Procedure Name :PW_UpRunAwardUser
        Purpose: 修改领奖跑数据用户信息
        Edit: 2018-07-21 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID 
   I_APPId    In Number, --渠道应用ID 
   I_Deviceid In Varchar2, --设备号ID 
   I_MerId    In Varchar2, --商家帐号id  
   I_Urlid    In Number --下载地址id 
   ) is
    v_n number;
  begin
    --如果统一跑数据也有，则同步下
    select count(1)
      into v_n
      from ad_win_run
     where adid = I_ADID
       and merid = I_MerId;
    if v_n > 0 then
      update ad_win_run
         set l_time = e_time, e_time = sysdate
       where adid = I_ADID
         and merid = I_MerId;
      commit;
    end if;
  
    --修改状态
    select count(1)
      into v_n
      from ad_win_run_award
     where adid = I_ADID
       and merid = I_MerId;
    if v_n > 0 then
      --修改状态
      update ad_win_run_award
         set status = 1, e_time = sysdate
       where adid = I_ADID
         and merid = I_MerId;
      commit;
    end if;
  
  exception
    --失败
    when others then
      --v_msg := '失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      rollback;
    
  end PW_UpRunAwardUser;

  Procedure Job_DownUser
  /*****************************************************************
        Procedure Name :Job_DownUser
        Purpose: 获取仅下载用户信息
         Edit: 2017-07-22 add by 小沈
    ****************************************************************/
   is
    --JOB 104 40分钟1波
    v_n       number;
    v_ATime   date; --用户奖励时间
    v_R_Atime date; --跑数据表记录最近领取时间
    v_N_Hour  number; --当前小时
    v_sql     varchar2(200);
    v_message varchar2(300);
  
    cursor User_List is
    ---获取3小时到最近1小时内2个小时内没注册的用户信息
      select adid,
             appid,
             userid,
             appsign,
             deviceid,
             merid,
             mername,
             urlid,
             itime
        from ad_app_bind a
       where adid in (select adid
                        from ad_adinfo
                       where status in (1, 2, 3)
                         and showtype = 1)
         and ustatus = 1
         and itime >= sysdate - (3 / 24)
         and itime <= sysdate - (1 / 24)
         and (select count(1)
                from ad_interf_reg
               where adid = a.adid
                 and status = 0) >= 1;
  
  begin
    v_n := 0;
  
    for C_User in User_List loop
    
      select count(1)
        into v_n
        from ad_win_run_down
       where adid = C_User.Adid
         and userid = C_User.userid;
    
      --如果已存在则不记录
      if v_n > 0 then
        goto Next_C_User;
      end if;
    
      select count(1)
        into v_n
        from ad_win_run_down
       where adid = C_User.Adid
         and merid = C_User.merid;
    
      --如果已存在则不记录
      if v_n > 0 then
        goto Next_C_User;
      end if;
    
      insert into ad_win_run_down
        (adid,
         appid,
         userid,
         appsign,
         deviceid,
         merid,
         mername,
         urlid,
         d_time)
      values
        (C_User.Adid,
         C_User.Appid,
         C_User.Userid,
         C_User.Appsign,
         C_User.Deviceid,
         C_User.Merid,
         C_User.Mername,
         C_User.Urlid,
         C_User.Itime);
    
      --单个  提交
      commit;
    
      <<Next_C_User>>
      null;
    
    end loop;
  
  exception
    when others then
      rollback;
      v_message := '错误编码：' || sqlcode || '  错误信息 ：' || sqlerrm;
      --添加日志
      insert into fin_log
        (appid, adid, urlid, msg)
      values
        (0,
         0,
         0,
         ' p_ad_windows.Job_DownUser; 数据录入异常：' || v_message);
      commit;
      return;
  end Job_DownUser;

  procedure PW_UpRunDownUser
  /*****************************************************************
        Procedure Name :PW_UpRunDownUser
        Purpose: 修改跑数据用户信息
        Edit: 2018-07-20 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID 
   I_APPId    In Number, --渠道应用ID 
   I_UserId   In Number, --闲玩用户ID 
   I_Deviceid In Varchar2, --设备号ID  
   I_Urlid    In Number --下载地址id 
   ) is
    v_n number;
  begin
    select count(1)
      into v_n
      from ad_win_run_down
     where adid = I_ADID
       and userid = I_UserId;
    if v_n > 0 then
      update ad_win_run_down
         set l_time = e_time, e_time = sysdate
       where adid = I_ADID
         and userid = I_UserId;
      commit;
    end if;
  
  exception
    --失败
    when others then
      --v_msg := '失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      rollback;
    
  end PW_UpRunDownUser;

  Procedure Job_DownUser_Fast
  /*****************************************************************
        Procedure Name :Job_DownUser
        Purpose: 获取仅下载用户信息 10分钟到-小时内未注册用户
         Edit: 2017-07-22 add by 小沈
    ****************************************************************/
   is
    --JOB 124 10分钟1波
    v_n       number;
    v_ATime   date; --用户奖励时间
    v_R_Atime date; --跑数据表记录最近领取时间
    v_N_Hour  number; --当前小时
    v_sql     varchar2(200);
    v_message varchar2(300);
  
    cursor User_List is
    ---获取10分钟到-20分钟内未注册用户 信息
      select adid,
             appid,
             userid,
             appsign,
             deviceid,
             merid,
             mername,
             urlid,
             itime
        from ad_app_bind a
       where adid in (select adid
                        from ad_adinfo
                       where status in (1, 2, 3)
                         and showtype = 1)
         and ustatus = 1
         and itime >= sysdate - (20 / (24 * 60))
         and itime <= sysdate - (10 / (24 * 60))
         and (select count(1)
                from ad_interf_reg
               where adid = a.adid
                 and status = 0) >= 1;
  
  begin
    v_n := 0;
  
    --判断当前时间是否为凌晨3点 如果是则清空表
  
    select to_number(to_char(sysdate, 'hh24')) into v_N_Hour from dual;
  
    if v_N_Hour = 3 then
      --清除记录表  --危险操作  win_ad_logs
      v_sql := 'truncate table ad_win_run_downfast';
      execute immediate v_sql;
    
      /*  v_sql := 'truncate table win_ad_logs';
      execute immediate v_sql;*/
    
    end if;
  
    for C_User in User_List loop
    
      select count(1)
        into v_n
        from ad_win_run_downfast
       where adid = C_User.Adid
         and userid = C_User.userid;
    
      --如果已存在则不记录
      if v_n > 0 then
        goto Next_C_User;
      end if;
    
      select count(1)
        into v_n
        from ad_win_run_down
       where adid = C_User.Adid
         and merid = C_User.merid;
    
      --如果已存在则不记录
      if v_n > 0 then
        goto Next_C_User;
      end if;
    
      insert into ad_win_run_downfast
        (adid,
         appid,
         userid,
         appsign,
         deviceid,
         merid,
         mername,
         urlid,
         d_time,
         e_time)
      values
        (C_User.Adid,
         C_User.Appid,
         C_User.Userid,
         C_User.Appsign,
         C_User.Deviceid,
         C_User.Merid,
         C_User.Mername,
         C_User.Urlid,
         C_User.Itime,
         sysdate - 2 / 24);
    
      -- sysdate - 2/ 24 新添加的有先处理
      --单个  提交
      commit;
    
      <<Next_C_User>>
      null;
    
    end loop;
  
  exception
    when others then
      rollback;
      v_message := '错误编码：' || sqlcode || '  错误信息 ：' || sqlerrm;
      --添加日志
      insert into fin_log
        (appid, adid, urlid, msg)
      values
        (0,
         0,
         0,
         ' p_ad_windows.Job_DownUser_Fast; 数据录入异常：' || v_message);
      commit;
      return;
  end Job_DownUser_Fast;

  procedure PW_UpRunDownUser_Fast
  /*****************************************************************
        Procedure Name :PW_UpRunDownUser_Fast
        Purpose: 修改跑数据用户信息--快速版
        Edit: 2018-07-22 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID 
   I_APPId    In Number, --渠道应用ID 
   I_UserId   In Number, --闲玩用户ID 
   I_Deviceid In Varchar2, --设备号ID  
   I_Urlid    In Number --下载地址id 
   ) is
    v_n number;
  begin
  
    --统一跑版本如果存在也同时更新
    select count(1)
      into v_n
      from ad_win_run_down
     where adid = I_ADID
       and userid = I_UserId;
    if v_n > 0 then
      update ad_win_run_down
         set l_time = e_time, e_time = sysdate
       where adid = I_ADID
         and userid = I_UserId;
      commit;
    end if;
  
    select count(1)
      into v_n
      from ad_win_run_downfast
     where adid = I_ADID
       and userid = I_UserId;
    if v_n > 0 then
      update ad_win_run_downfast
         set l_time = e_time, e_time = sysdate
       where adid = I_ADID
         and userid = I_UserId;
      commit;
    end if;
  
  exception
    --失败
    when others then
      --v_msg := '失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      rollback;
    
  end PW_UpRunDownUser_Fast;

  procedure PQ_DownUserFast_List
  /*****************************************************************
        Procedure Name :PQ_DownUserFast_List
        Purpose: 获取已下载用户列表
        Edit: 2018-07-22 add by 小沈
    ****************************************************************/
  (I_Sign      In Number, --标记符号 1，2，3……
   I_PageSize  In Number, --每页记录数
   I_PageNO    In Number, --当前页码,从 1 开始
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    V_SQL       varchar2(3000);
    v_PageSize  number;
    v_PageNO    number;
    V_HeiRowNUM number; --小于第几行 分页用
    V_LowROWNUM number; --大于第几行 分页用
    V_ServerNum number := 6; --跑等级信息的服务数量
  
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    v_PageSize := I_PageSize;
    v_PageNO   := I_PageNO;
  
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
    --return;
    if I_PageNO = 1 then
      insert into win_ad_logs
        (sign, note, pageno, type)
      values
        (I_Sign,
         'I_PageSize' || I_PageSize || ' I_PageNO:' || I_PageNO,
         I_PageNO,
         4);
      commit;
    end if;
    /*   2小时内未跑过且下载时间在1小时内  and  sysdate-(2/24)>= e_time   and  d_time>  sysdate-(2/24) */
  
    V_SQL := '  select  a.adid,a.appid,a.userid,a.appsign,a.deviceid,a.merid,a.mername,a.urlid from  ad_win_run_downfast  a  where    a.userid>10 
      and   a.status=0   and  sysdate-(2/24)>= e_time  order by e_time asc ';
  
    ----执行分页查询
    V_HeiRowNUM := v_PageNO * v_PageSize;
    V_LowROWNUM := V_HeiRowNUM - v_PageSize + 1;
  
    V_SQL := 'select adid,appid ,userid,appsign,deviceid,merid, mername ,urlid, rn
    from  ( select  adid,appid ,userid,appsign,deviceid,merid, mername ,urlid,rownum rn
    from (' || V_SQL || ') a
    where rownum <= ' || TO_CHAR(V_HeiRowNUM) || '
    ) b
    where rn >= ' || TO_CHAR(V_LowROWNUM);
  
    --注意对rownum别名的使用,第一次直接用rownum,第二次一定要用别名rn
    --- order by 放里面会影响速度
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    OPEN O_OUTCURSOR FOR V_SQL;
    return;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 1001;
      O_Message := '查询异常！';
      -- o_message := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PQ_DownUserFast_List;

  procedure PW_Get_Reg_Fast
  /*****************************************************************
        Procedure Name :PW_Get_Reg_Fast
        Purpose: Windows抓取注册信息
        Edit: 2018-12-09 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告id 
   I_APPID    In Number, --渠道ID
   I_UserId   In Number, --闲玩用户ID 
   I_FID      In Varchar2, --广告主统计的来源id[apk渠道编号] 
   I_DeviceId In Varchar2, --返回设备号imei idfa
   I_SIMID    In Varchar2, --返回sim卡id
   I_Merid    In Varchar2, --用户注册帐号id
   I_MerName  In Varchar2, --用户注册帐号 
   I_APPSign  In Varchar2, --用户注册帐号 
   O_Result   Out Number,
   O_Message  Out Varchar2) is
    v_n       Number;
    v_appid   Number; --渠道合作编号
    v_appsign Varchar2(200); --渠道合作编号
    v_status  Number; --匹配状态 0 失败 ； 1  成功  
    v_amoney  Number; --奖励金额
    v_result  Number; --
    v_message Varchar2(100); -- 
    v_Cursor  t_cursor;
    v_isRun   number := 0; --是否为跑出来的注册0：否 1：是 
  begin
    o_result  := 0;
    o_message := '接收成功';
  
    select count(1)
      into v_n
      from ad_adv_back_reg
     where adid = I_ADID
       and userid = I_Merid;
    if v_n <= 0 then
      v_isRun := 1;
    end if;
  
    --整体跑数据中的状态同样修改
    select count(1)
      into v_n
      from ad_win_run_down
     where adid = I_ADID
       and userid = I_UserId
       and status = 0;
    if v_n > 0 then
      update ad_win_run_down
         set merid   = I_Merid,
             mername = I_MerName,
             status  = 1,
             r_time  = sysdate,
             isrun   = v_isRun
       where adid = I_ADID
         and userid = I_UserId
         and status = 0;
      commit;
    end if;
  
    select count(1)
      into v_n
      from ad_win_run_downfast
     where adid = I_ADID
       and userid = I_UserId
       and status = 0;
    if v_n > 0 then
      update ad_win_run_downfast
         set merid   = I_Merid,
             mername = I_MerName,
             status  = 1,
             r_time  = sysdate,
             isrun   = v_isRun
       where adid = I_ADID
         and userid = I_UserId
         and status = 0;
      commit;
    
      p_ad_advertiser.pw_back_reg(i_adid      => i_adid,
                                  i_fid       => i_fid,
                                  i_deviceid  => i_deviceid,
                                  i_simid     => i_simid,
                                  i_userid    => I_Merid,
                                  i_name      => I_MerName,
                                  o_outcursor => v_Cursor,
                                  o_result    => o_result,
                                  o_message   => o_message);
    
    end if;
  
  exception
    --失败 
    when others then
      rollback;
      O_Result := -9;
      /*  O_Message := '记录失败！';*/
      O_Message := '记录失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_Get_Reg_Fast;

  Procedure Job_Del_TempData
  /*****************************************************************
        Procedure Name :Job_Del_TempData
        Purpose: 删除已停止广告数据
         Edit: 2017-08-26 add by 小沈
    ****************************************************************/
   is
  
    v_n       number;
    v_m_date  date;
    v_sql     varchar2(800);
    v_message varchar2(800);
    cursor Adid_List is
    
      select a.adid, a.stoptime
        from ad_adinfo a
       where a.status = 4
         and stoptime <= trunc(sysdate) - 20
         and stoptime >= trunc(sysdate) - 30
      -- and adid = 4335
       order by stoptime desc;
  
  begin
    v_n := 0;
  
    for C_Adid in Adid_List loop
    
      select count(1)
        into v_n
        from ad_win_run_down
       where adid = c_adid.adid;
      if v_n <= 0 then
        goto Next_C_Adid;
      end if;
    
      select count(1) into v_n from ad_app_bind where adid = c_adid.adid;
      if v_n <= 0 then
        goto Next_C_Adid;
      end if;
    
      select max(itime)
        into v_m_date
        from ad_app_bind
       where adid = c_adid.adid;
      if v_m_date <= trunc(sysdate) - 15 then
        --清除临时表表
        v_sql := 'delete ad_win_run where adid=' || c_adid.adid;
        execute immediate v_sql;
      
        v_sql := 'delete ad_win_run_award where adid=' || c_adid.adid;
        execute immediate v_sql;
      
        v_sql := 'delete ad_win_run_down where adid=' || c_adid.adid;
        execute immediate v_sql;
      
        v_sql := 'delete ad_win_run_downfast where adid=' || c_adid.adid;
        execute immediate v_sql;
      
        v_sql := 'delete ad_win_run_level where adid=' || c_adid.adid;
        execute immediate v_sql;
      
      end if;
    
      commit;
    
      <<Next_C_Adid>>
      null;
    
    end loop;
  
  exception
    when others then
      rollback;
      v_message := '错误编码：' || sqlcode || '  错误信息 ：' || sqlerrm;
      --添加日志
      insert into fin_log
        (appid, adid, urlid, msg)
      values
        (0,
         0,
         0,
         ' p_ad_windows.Job_Del_TempData; 删除数据异常：' || v_message);
      commit;
      return;
  end Job_Del_TempData;

  procedure PQ_TestList
  /*****************************************************************
        Procedure Name :PQ_TestList
        Purpose: 获取已注册用户列表
        Edit: 2017-08-05 add by 小沈
    ****************************************************************/
  (I_Sign      In Number, --标记符号 1，2，3……
   I_PageSize  In Number, --每页记录数
   I_PageNO    In Number, --当前页码,从 1 开始
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    V_SQL         varchar2(3000);
    v_PageSize    number;
    v_PageNO      number;
    V_HeiRowNUM   number; --小于第几行 分页用
    V_LowROWNUM   number; --大于第几行 分页用
    V_ServerNum   number := 17; --跑等级信息的服务数量
    v_OrderServer number := 7; --跑10天前注册信息的服务供多少台
    v_NewServer   number := 10; --跑10天内注册信息的服务供多少台
    v_Sign        number := 0; --当前服务标识
    v_IsNew       number := 1; --是否跑新用户 0否 1是
  
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    v_PageSize := I_PageSize;
    v_PageNO   := I_PageNO;
  
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
    -- return;
  
    /* return;*/
    --and itime>=trunc(sysdate)-10   and adid  not in (2759 ) 
  
    V_SQL := '  select  adid,appid ,deviceid,merid, mername ,urlid,userid   from  ad_app_bind  where id>=  15095698  and id< 15095710  ';
  
    ----执行分页查询
    V_HeiRowNUM := v_PageNO * v_PageSize;
    V_LowROWNUM := V_HeiRowNUM - v_PageSize + 1;
  
    V_SQL := 'select  adid,appid ,deviceid,merid, mername ,urlid,userid,rn
    from  ( select  adid,appid ,deviceid,merid, mername ,urlid,userid,rownum rn
    from (' || V_SQL || ') a
    where rownum <= ' || TO_CHAR(V_HeiRowNUM) || '
    ) b
    where rn >= ' || TO_CHAR(V_LowROWNUM);
  
    --注意对rownum别名的使用,第一次直接用rownum,第二次一定要用别名rn
    --- order by 放里面会影响速度
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    OPEN O_OUTCURSOR FOR V_SQL;
    return;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 1001;
      O_Message := '查询异常！';
      -- o_message := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PQ_TestList;

  procedure PW_CheckIsNewUser
  /*****************************************************************
        Procedure Name :p_Run_CheckIsNewUser
        Purpose: 更改用户是老用户还是新用户
        Edit: 2018-8-25 add by 小胡
    ****************************************************************/
  (I_ADID     In Number, --广告id
   I_APPID    In Number, --渠道编号
   I_DEVICEID In Varchar2, --设备号
   I_MERID    In Varchar2, --广告用户唯一标识 
   I_ISOLD    In Number, --是否是老用户 0：新用户； 1：老用户
   O_Result   Out Number,
   O_Message  Out Varchar2) is
    v_n Number;
  begin
    o_result  := 0;
    o_message := '=修改成功';
  
    select count(1)
      into v_n
      from ad_app_bind
     where adid = I_ADID
       and appid = I_APPID
       and deviceid = I_DEVICEID
       and merid = I_MERID;
  
    if v_n <= 0 then
      O_Result  := 2;
      O_Message := '该用户不存在！';
      return;
    end if;
  
    update ad_app_bind
       set isold = I_ISOLD
     where adid = I_ADID
       and appid = I_APPID
       and deviceid = I_DEVICEID
       and merid = I_MERID;
    commit;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '修改失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_CheckIsNewUser;

  procedure PQ_AwardUserList_v2
  /*****************************************************************
        Procedure Name :PQ_AwardUserList
        Purpose: 获取已获得奖励用户列表
        Edit: 2018-08-25 add by 小胡
    ****************************************************************/
  (I_Sign      In Number, --标记符号 1，2，3……
   I_PageSize  In Number, --每页记录数
   I_PageNO    In Number, --当前页码,从 1 开始
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    V_SQL       varchar2(3000);
    v_PageSize  number;
    v_PageNO    number;
    V_HeiRowNUM number; --小于第几行 分页用
    V_LowROWNUM number; --大于第几行 分页用
  
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    v_PageSize := I_PageSize;
    v_PageNO   := I_PageNO;
  
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
    -- return;
    if I_PageNO = 1 then
      insert into win_ad_logs
        (sign, note, pageno, type)
      values
        (I_Sign,
         'I_PageSize' || I_PageSize || ' I_PageNO:' || I_PageNO,
         I_PageNO,
         3);
      commit;
    end if;
  
    /* return;*/
    --and itime>=trunc(sysdate)-10  and a.adid!=2554   itime>=sysdate-3 and a.adid not in (3175,3216)
  
    V_SQL := 'select  a.adid,a.appid,a.deviceid,a.merid,a.mername,a.urlid,a.userid,b.isold from  ad_win_run_award a,ad_app_bind b  where    a.userid>10  and   a.status=0 and a.adid=b.adid and a.deviceid=b.deviceid and a.merid=b.merid  order by a.e_time asc ';
  
    ----执行分页查询
    V_HeiRowNUM := v_PageNO * v_PageSize;
    V_LowROWNUM := V_HeiRowNUM - v_PageSize + 1;
  
    V_SQL := 'select  adid,appid ,deviceid,merid, mername ,urlid,userid,isold,rn
    from  ( select  adid,appid ,deviceid,merid, mername ,urlid,userid,isold,rownum rn
    from (' || V_SQL || ') a
    where rownum <= ' || TO_CHAR(V_HeiRowNUM) || '
    ) b
    where rn >= ' || TO_CHAR(V_LowROWNUM);
  
    --注意对rownum别名的使用,第一次直接用rownum,第二次一定要用别名rn
    --- order by 放里面会影响速度
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    OPEN O_OUTCURSOR FOR V_SQL;
    return;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 1001;
      O_Message := '查询异常！';
      -- o_message := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PQ_AwardUserList_v2;

  procedure PQ_RegUserList_V2
  /*****************************************************************
        Procedure Name :PQ_UserList
        Purpose: 获取已注册用户列表
        Edit: 2018-09-06 add by 小胡
    ****************************************************************/
  (I_Sign      In Number, --标记符号 1，2，3……
   I_PageSize  In Number, --每页记录数
   I_PageNO    In Number, --当前页码,从 1 开始
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    V_SQL         varchar2(3000);
    v_PageSize    number;
    v_PageNO      number;
    V_HeiRowNUM   number; --小于第几行 分页用
    V_LowROWNUM   number; --大于第几行 分页用
    V_ServerNum   number := 1; --跑等级信息的服务数量
    v_OrderServer number := 7; --跑10天前注册信息的服务供多少台
    v_NewServer   number := 10; --跑10天内注册信息的服务供多少台
    v_Sign        number := 0; --当前服务标识
    v_IsNew       number := 1; --是否跑新用户 0否 1是
  
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    v_PageSize := I_PageSize;
    v_PageNO   := I_PageNO;
  
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
    -- return;
  
    if I_PageNO = 1 then
      insert into win_ad_logs
        (sign, note, pageno, type)
      values
        (I_Sign,
         'I_PageSize' || I_PageSize || ' I_PageNO:' || I_PageNO,
         I_PageNO,
         2);
      commit;
    end if;
  
    /* return;*/
    --and itime>=trunc(sysdate)-10   and adid  not in (2759 ) 
  
    V_SQL := '    select aw.adid,aw.appid ,aw.deviceid,aw.merid, aw.mername ,aw.urlid,aw.userid,aw.e_time,ab.isold from (
 select  adid,appid ,deviceid,merid, mername ,urlid,userid,e_time   from ( 
       select  adid,appid ,deviceid,merid, mername ,urlid,userid ,e_time from ad_win_run where adid in
                   (select adid
                      from (select adid, rownum rn
                              from ad_adinfo
                             where status in (1, 2, 3) 
                               and showtype = 1  
                                or (status = 4 and
                                   trunc(stoptime)= trunc(sysdate)  and
                                   stoptime !=
                                   to_date(''2099-01-01'', ''yyyy-mm-dd'')
                                   )
                              ) 
                      )  and  userid>10 and  sysdate-(2/24)>= e_time    and  mod(userid,' ||
             V_ServerNum || ')=' || I_Sign || ' 
                       ) order by e_time asc) aw,ad_app_bind ab where aw.adid=ab.adid and aw.appid=ab.appid and aw.deviceid=ab.deviceid and aw.merid=ab.merid';
  
    ----执行分页查询
    V_HeiRowNUM := v_PageNO * v_PageSize;
    V_LowROWNUM := V_HeiRowNUM - v_PageSize + 1;
  
    V_SQL := 'select  adid,appid ,deviceid,merid, mername ,urlid,userid,isold,e_time,rn
    from  ( select  adid,appid ,deviceid,merid, mername ,urlid,userid,isold,e_time,rownum rn
    from (' || V_SQL || ') a
    where rownum <= ' || TO_CHAR(V_HeiRowNUM) || '
    ) b
    where rn >= ' || TO_CHAR(V_LowROWNUM);
  
    --注意对rownum别名的使用,第一次直接用rownum,第二次一定要用别名rn
    --- order by 放里面会影响速度
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    OPEN O_OUTCURSOR FOR V_SQL;
    return;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 1001;
      O_Message := '查询异常！';
      -- o_message := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PQ_RegUserList_V2;

end P_AD_Windows;
/


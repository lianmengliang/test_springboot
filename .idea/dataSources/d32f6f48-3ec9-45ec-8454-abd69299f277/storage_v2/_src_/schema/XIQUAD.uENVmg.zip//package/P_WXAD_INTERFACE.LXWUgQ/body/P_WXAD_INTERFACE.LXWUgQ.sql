create package body P_WXAD_Interface is

  ---微信广告接口

  procedure PQ_AdidToken
  /*****************************************************************
        Procedure Name :PQ_ADInfo
        Purpose: 微信关注广告，根据微信adid获取token 
        Edit: 2017-10-14 add by 小沈
    ****************************************************************/
  (I_Adid      In Number, --adid
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out number, --判断 0：查询成功，其他：出错
   O_Message   Out varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n Number;
  Begin
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
  
    O_Result  := 0;
    O_Message := '成功';
    open O_Outcursor for 'select 1  from dual where 1=2'; --游标初始化
  
    select count(1)
      into v_n
      from wx_ad_token
     where adid = I_Adid
       and status = 1;
    if v_n <= 0 then
      O_Result  := 101;
      O_Message := '该广告不存在';
      return;
    end if;
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
  
    open O_Outcursor for
      select token from wx_ad_token where adid = I_Adid;
  
    return;
  exception
    when others then
      O_Result  := -9;
      O_Message := '查询不成功';
      return;
  end pq_adidtoken;

  procedure PW_SaveMessage
  /*****************************************************************
        Procedure Name: PW_SaveMessage
        Purpose:用户发送信息给微信，信息保存
        Edit: 2017-10-15 add by 小沈
        Comment:
    ****************************************************************/
  (I_Adid          In Number, --adid
   I_ToUserName    In Varchar2, --公众平台 编号
   I_FromUserName  In Varchar2, --微信发送方帐号（一个OpenID）
   I_CreateTime    In Varchar2, --消息创建时间 （整型）
   I_MsgType       In Varchar2, --消息类型 text ，event
   I_Content       In Varchar2, --消息内容
   I_MsgId         In Varchar2, --消息id，64位整型
   I_Ctime         In Varchar2, --消息创建时间 (转换后)
   O_ReturnMSG     Out Varchar2, -- 返回微信信息
   O_ReturnMSGType Out Number, --返回信息类型   1、回复文本消息 2、图片消息 3、语音消息 4、视频消息 5、音乐消息 6、图文消息
   O_Result        Out Number, -- 返回（0正确， 1回答错误 其他为提示或错误）
   O_Message       Out Varchar2 -- 返回信息（操作结果，成功或者错误信息）
   ) is
    v_n  number;
    v_id number;
  
    v_appid    number; --渠道应用编号
    v_deviceid varchar2(100); --手机设备号
    v_simid    varchar2(100); --sim卡编号
    v_appsign  varchar2(200); --渠道应用标识符号、渠道用户id
    v_ptype    number; --1ios，2安卓 
    v_ip       varchar2(50);
  
    v_dlevel    number := 0; --奖励级别
    v_price     number := 0; --单价 
    v_amoney    number := 0; --奖励金额 
    v_max_times number := 0; --奖励设置中最大奖励次数
    v_atype     number := 0; --类型 1：转发奖励 2：关注奖励 
    v_times     number := 0; --用户已获得奖励次数
  
    v_accMoney   number := 0; --到账金额
    v_awardMoney number := 0; --已结算金额
    v_jumpurl    varchar2(200); --跳转地址
  
  begin
    ----------------------------------------------------
    --步骤一：初始化赋值
    ----------------------------------------------------
    O_RESULT        := 0;
    O_MESSAGE       := '成功';
    O_ReturnMSG     := 'success';
    O_ReturnMSGType := 1;
  
    ----------------------------------------------------
    --步骤二：合法性校验
    ----------------------------------------------------
  
    if i_tousername is null then
      O_Result  := 1;
      O_Message := '公众平台ID不能为空';
      return;
    end if;
    if i_fromusername is null then
      O_Result  := 2;
      O_Message := '微信用户ID不能为空';
      return;
    end if;
    if i_msgtype is null then
      O_Result  := 3;
      O_Message := '发送格式不能为空';
      return;
    end if;
    if i_content is null then
      O_Result  := 4;
      O_Message := '发送内容不能为空';
      return;
    end if;
    if i_ctime is null then
      O_Result  := 5;
      O_Message := '发送时间不能为空';
      return;
    end if;
  
    /*  if i_msgtype <> 'text' or i_msgtype <> 'click' then
      O_Result  := 7;
      O_Message := '只支持文本发送';
      return;
    end if;*/
  
    --插入临时消息记录表
    insert into wx_usermsg_temp
      (adid,
       appusername,
       openid,
       createtime,
       msgtype,
       content,
       msgid,
       ctime)
    values
      (i_adid,
       I_ToUserName,
       I_FromUserName,
       i_createtime,
       i_msgtype,
       i_content,
       i_msgid,
       to_date(i_ctime, 'yyyy-mm-dd hh24:mi:ss'));
    commit;
  
    -- 
    if I_Adid = 100 then
      v_jumpurl := 'http://m.qushihuo.com';
    else
      v_jumpurl := 'http://youquhuo.m.qushihuo.com';
    end if;
    --<a href="' || v_jumpurl || '">点此查看更多优惠</a>
  
    /* 
        if I_Content like '%红包%' or I_Content like '%双11%' then
          O_RESULT    := 0;
          O_MESSAGE   := '成功';
          O_ReturnMSG := '红包来啦，复制该条信息￥YPBP05KYyIH￥，打开【手机淘宝】即可获得小编赠送的3次抽红包机会哦。 
    明天再回复【红包】二字给小编，将继续赠送哦~！马云爸爸的千元红包就不信你中不了呐！ 
    回复【清单】二字给小编，有惊喜哦！
     <a href="' || v_jumpurl || '">点此查看更多优惠</a>';
          return;
        end if;*/
  
    --如果广告不存在则不进行回复
    select count(1) into v_n from wx_adinfo where adid = i_adid;
    if v_n = 0 then
      --广告无广告信息
      O_Result  := 100;
      O_Message := '无投放广告';
      return;
    end if;
  
    select count(1)
      into v_n
      from wx_adinfo
     where adid = i_adid
       and status = 1
    -- and showtype = 1
    ;
    if v_n = 0 then
      --广告暂停或未投放
      O_Result    := 100;
      O_Message   := '广告没有正常投放';
      O_ReturnMSG := '小编暂时无法对你的信息进行回应哦!';
      return;
    end if;
  
    ----------------------------------------------------
    --步骤三：插入一条记录
    ----------------------------------------------------
    select sq_wx_ad_usermsgs.nextval into v_id from dual;
  
    insert into wx_ad_usermsgs
      (id,
       adid,
       appusername,
       openid,
       createtime,
       msgtype,
       content,
       msgid,
       ctime)
    values
      (v_id,
       i_adid,
       I_ToUserName,
       I_FromUserName,
       i_createtime,
       i_msgtype,
       i_content,
       i_msgid,
       to_date(i_ctime, 'yyyy-mm-dd hh24:mi:ss'));
  
    commit;
  
    ----------------------------------------------------
    --步骤四：校验是否为微信广告密令并奖励
    ----------------------------------------------------
  
    --判断是否包含2个# 如果是表示为口令
    v_n := length(regexp_replace(i_content, '[^#]', null));
  
    if v_n = 2 then
      --如果为微信广告密令
      select count(1)
        into v_n
        from wx_ad_kl
       where adid = I_Adid
         and wechat_kl = trim(i_content);
    
      if v_n <= 0 then
        O_RESULT    := 0;
        O_MESSAGE   := '成功';
        O_ReturnMSG := '啧啧啧，你发的微信密令不对哦，再去核对下吧！';
        return;
      end if;
    
      --获取密令对应用户信息
      select appid, deviceid, simid, appsign, ptype, ip
        into v_appid, v_deviceid, v_simid, v_appsign, v_ptype, v_ip
        from wx_ad_kl
       where adid = I_Adid
         and wechat_kl = trim(i_content);
    
      --获取关注奖励可奖励次数
      select dlevel, price, amoney, atype, times
        into v_dlevel, v_price, v_amoney, v_atype, v_max_times
        from wx_ad_awardset
       where adid = I_Adid
         and appid = v_appid
         and atype = 2;
    
      --已获得奖励次数
      select count(1)
        into v_times
        from wx_ad_flux
       where adid = I_Adid
         and deviceid = v_deviceid
         and status in (0, 1, 9);
    
      if v_times >= v_max_times then
        O_RESULT    := 0;
        O_MESSAGE   := '成功';
        O_ReturnMSG := '啊呀，您发送的密令被用完了，感谢您的参与呐！';
        return;
      end if;
    
      --到账金额判断 看是否超量
      select amoney into v_accMoney from wx_adinfo where adid = I_Adid;
    
      select sum(price)
        into v_awardMoney
        from wx_ad_flux
       where adid = I_Adid
         and status in (0, 1, 9);
    
      --如果已奖励结算金额+本次需要结算的金额 将广告设置为到量
      if v_awardMoney + v_price > v_accMoney then
        update wx_adinfo
           set status = 3, showtype = 0
         where adid = I_Adid
           and status = 1;
        commit;
      
        O_RESULT    := 0;
        O_MESSAGE   := '成功';
        O_ReturnMSG := '不好意思你来晚啦，本次活动今天已满员啦，下次早点来呐！';
        return;
      end if;
    
      select count(1)
        into v_n
        from wx_ad_flux
       where adid = I_Adid
         and openid = I_FromUserName;
    
      if v_n <= 0 then
        --添加用户到奖励流水中，等待发奖
        insert into wx_ad_flux
          (id,
           adid,
           appid,
           deviceid,
           simid,
           openid,
           appsign,
           dlevel,
           price,
           amoney,
           atype)
        values
          (SQ_WX_AD_FLUX.Nextval,
           i_adid,
           v_appid,
           v_deviceid,
           v_simid,
           I_FromUserName, --微信openid 
           v_appsign,
           v_dlevel,
           v_price,
           v_amoney,
           v_atype --类型 1：转发奖励 2：关注奖励 
           );
      else
        O_RESULT    := 0;
        O_MESSAGE   := '成功';
        O_ReturnMSG := '你之前已参与过咯，不能重复参与哦！';
        return;
      end if;
    
      select count(1)
        into v_n
        from wx_ad_bind
       where adid = I_Adid
         and deviceid = v_deviceid;
      if v_n <= 0 then
        --如果为首次关注则添加绑定表
        insert into wx_ad_bind
          (id, adid, appid, deviceid, simid, openid, appsign, ptype, ip)
        values
          (sq_wx_ad_bind.nextval,
           i_adid,
           v_appid,
           v_deviceid,
           v_simid,
           I_FromUserName,
           v_appsign,
           v_ptype,
           v_ip);
      
      end if;
    
      O_RESULT    := 0;
      O_MESSAGE   := '成功';
      O_ReturnMSG := '恭喜你已成功开启密令！';
      return;
    
      commit;
    
    else
      O_RESULT  := 0;
      O_MESSAGE := '成功';
      select count(1)
        into v_n
        from wx_ad_autoreply
       where adid = I_Adid
         and content like '%' || I_Content || '%';
      if v_n > 0 then
        select replymsg
          into O_ReturnMSG
          from (select a.*, row_number() over(order by dbms_random.value) rn
                  from wx_ad_autoreply a
                 where adid = I_Adid
                   and content like '%' || I_Content || '%') t
         where t.rn = 1;
      else
        O_ReturnMSG := '暂时无法识别你发的信息内容!';
        return;
      end if;
    
    end if;
  
    ----------------------------------------------------
    --步骤五：完成
    ----------------------------------------------------
  
    update wx_ad_usermsgs
       set status = 1, dotime = sysdate
     where id = v_id
       and status = 0;
  
    commit;
  
    return;
  exception
    when others then
      rollback;
      O_RESULT        := 0;
      O_MESSAGE       := '成功';
      O_ReturnMSGType := 1;
      O_ReturnMSG     := '系统繁忙，请稍后再试!';
      --O_ReturnMSG     := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_SaveMessage;

  procedure PW_Subscribe
  /*****************************************************************
        Procedure Name: PW_Subscribe
        Purpose:用户订阅或取消订阅
        Edit: 2017-10-15 add by 小沈
        Comment:
    ****************************************************************/
  (I_Adid          In Number, --adid
   I_ToUserName    In Varchar2, --公众平台 APPID
   I_FromUserName  In Varchar2, --微信发送方帐号（一个OpenID）
   I_CreateTime    In Varchar2, --消息创建时间 （整型）
   I_MsgType       In Varchar2, --消息类型 text ，event
   I_Event         In Varchar2, --事件类型，subscribe(订阅)、unsubscribe(取消订阅) 
   I_Ctime         In Varchar2, --消息创建时间 (转换后)
   O_ReturnMSG     Out Varchar2, -- 返回微信信息
   O_ReturnMSGType Out Number, --返回信息类型   1、回复文本消息 2、图片消息 3、语音消息 4、视频消息 5、音乐消息 6、图文消息
   O_Result        Out Number, -- 返回（0正确， 1回答错误 其他为提示或错误）
   O_Message       Out Varchar2 -- 返回信息（操作结果，成功或者错误信息）
   ) is
    v_n       number;
    v_id      number;
    v_msgtype number; --返回信息类型 只有1可用  1、回复文本消息 2、图片消息 3、语音消息 4、视频消息 5、音乐消息 6、图文消息 
    v_content varchar2(2000); --回复的消息内容（换行：在content中能够换行，微信客户端就支持换行显示） 
  
    v_appid    number; --渠道应用编号
    v_deviceid varchar2(100); --手机设备号
  
  begin
    ----------------------------------------------------
    --步骤一：初始化赋值
    ----------------------------------------------------
    O_RESULT        := 0;
    O_MESSAGE       := '成功';
    O_ReturnMSG     := 'success';
    O_ReturnMSGType := 1;
  
    ----------------------------------------------------
    --步骤二：合法性校验
    ----------------------------------------------------
  
    if i_tousername is null then
      O_Result  := 1;
      O_Message := '公众平台ID不能为空';
      return;
    end if;
    if i_fromusername is null then
      O_Result  := 2;
      O_Message := '微信用户ID不能为空';
      return;
    end if;
    if i_msgtype is null then
      O_Result  := 3;
      O_Message := '发送格式不能为空';
      return;
    end if;
  
    if i_ctime is null then
      O_Result  := 5;
      O_Message := '发送时间不能为空';
      return;
    end if;
  
    if i_msgtype <> 'event' then
      O_Result  := 7;
      O_Message := '只支持事件';
      return;
    end if;
  
    --如果广告不存在则不进行回复
    select count(1) into v_n from wx_adinfo where adid = i_adid;
    if v_n = 0 then
      --广告无广告信息
      O_Result    := 100;
      O_Message   := '无投放广告';
      O_ReturnMSG := '欢迎小主到来，小编在此恭候多时啦！';
      return;
    end if;
  
    select count(1)
      into v_n
      from wx_adinfo
     where adid = i_adid
       and status = 1
    -- and showtype = 1
    ;
    if v_n = 0 then
      --广告暂停或未投放
      O_Result    := 100;
      O_Message   := '广告没有正常投放';
      O_ReturnMSG := '欢迎小主到来，小编在此恭候多时啦！';
      return;
    end if;
  
    ----------------------------------------------------
    --步骤三：插入一条记录
    ----------------------------------------------------
    select sq_wx_ad_usermsgs.nextval into v_id from dual;
  
    insert into wx_ad_usermsgs
      (id,
       adid,
       APPUserName,
       openid,
       createtime,
       msgtype,
       content,
       msgid,
       ctime)
    values
      (v_id,
       i_adid,
       I_ToUserName,
       I_FromUserName,
       i_createtime,
       i_msgtype,
       I_Event,
       0,
       to_date(i_ctime, 'yyyy-mm-dd hh24:mi:ss'));
  
    commit;
  
    ----------------------------------------------------
    --步骤四：根据事件进行判断
    ----------------------------------------------------
    if I_Event = 'subscribe' then
      -- subscribe(订阅)
      select count(1)
        into v_n
        from wx_ad_subscribe
       where adid = I_Adid
         and status = 1;
      if v_n = 1 then
        select msgtype, content
          into v_msgtype, v_content
          from wx_ad_subscribe
         where adid = I_Adid
           and status = 1;
        O_ReturnMSG     := v_content;
        O_ReturnMSGType := v_msgtype;
      else
        O_ReturnMSG     := '欢迎小主到来，小编在此恭候多时啦!';
        O_ReturnMSGType := 1;
      end if;
    
    elsif I_Event = 'unsubscribe' then
      -- unsubscribe(取消订阅)
    
      --查看是否有参与广告,且为待奖励状态
      select count(1)
        into v_n
        from wx_ad_flux
       where adid = I_Adid
         and openid = I_FromUserName
         and status = 0;
      if v_n > 0 then
        update wx_ad_flux
           set status = 2
         where adid = I_Adid
           and openid = I_FromUserName
           and status = 0;
        commit;
      end if;
    
    end if;
  
    ----------------------------------------------------
    --步骤五：完成
    ----------------------------------------------------
  
    update wx_ad_usermsgs
       set status = 1, dotime = sysdate
     where id = v_id
       and status = 0;
  
    commit;
  
    return;
  exception
    when others then
      rollback;
      O_RESULT        := 0;
      O_MESSAGE       := '成功';
      O_ReturnMSGType := 1;
      O_ReturnMSG     := '系统繁忙，请稍后再试!';
      return;
  end PW_Subscribe;

end P_WXAD_Interface;
/


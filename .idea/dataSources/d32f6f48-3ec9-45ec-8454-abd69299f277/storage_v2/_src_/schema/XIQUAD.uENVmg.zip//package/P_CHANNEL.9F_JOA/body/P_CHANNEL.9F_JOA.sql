create package body P_Channel is

  /*渠道信息*/

  procedure pw_CheckSecret
  /*****************************************************************
        Procedure Name :pw_CheckSecret
        Purpose: 校验渠道密钥是否正确
        Edit: 2017-02-19 add by 小沈
    ****************************************************************/
  (I_APPId     In Number, --渠道应用ID
   I_APPSecret In Varchar2, --  密钥 --随机字母字符串组成 16位
   O_Result    Out number,
   O_Message   Out varchar2) is
    v_n number;
  begin
    O_Result  := 0;
    O_Message := '渠道正确';
  
    select count(1)
      into v_n
      from ad_channel
     where appid = I_APPId
       and appsecret = I_APPSecret;
  
    if v_n <= 0 then
      O_Result  := 1;
      O_Message := '渠道校验不正确';
      return;
    end if;
  
    commit;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := -9;
      O_Message := '渠道校验异常失败';
      return;
  end pw_CheckSecret;

  procedure PQ_GetSecret
  /*****************************************************************
        Procedure Name :PQ_GetSecret
        Purpose: 获取渠道密钥是否正确
        Edit: 2017-03-16 add by 小沈
    ****************************************************************/
  (I_APPId      In Number, --渠道应用ID
   O_RAPPSecret Out Varchar2, -- 返回 密钥  
   O_Result     Out number,
   O_Message    Out varchar2) is
    v_n number;
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    select count(1)
      into v_n
      from ad_channel
     where appid = I_APPId
       and status in (0, 1);
  
    if v_n != 1 then
      O_Result  := 1;
      O_Message := '无该渠道信息';
      return;
    end if;
  
    select appsecret
      into O_RAPPSecret
      from ad_channel
     where appid = I_APPId
       and status in (0, 1);
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := -9;
      O_Message := '查询失败';
      return;
  end PQ_GetSecret;

  procedure PQ_GetInfo
  /*****************************************************************
        Procedure Name :PQ_GetInfo
        Purpose: 获取渠道信息
        Edit: 2017-06-7 add by 小沈
    ****************************************************************/
  (I_APPId     In Number, --渠道应用ID
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out number,
   O_Message   Out varchar2) is
    v_n number;
  begin
    O_Result  := 0;
    O_Message := '查询成功';
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    select count(1)
      into v_n
      from ad_channel
     where appid = I_APPId
       and status in (0, 1);
  
    if v_n != 1 then
      O_Result  := 1;
      O_Message := '无该渠道信息';
      return;
    end if;
  
    open O_Outcursor for
      select downapp, openurl, is_showlogo, show_name
        from ad_channel
       where appid = I_APPId
         and status in (0, 1);
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := -9;
      O_Message := '查询失败';
      OPEN O_Outcursor FOR 'select 1 from dual where 1=2';
      return;
  end PQ_GetInfo;

end P_Channel;
/


create package body P_AD_Windows_Older is

  /*windows 服务 老用户激活 信息获取与处理 */

  Procedure Job_CheckOldUser
  /*****************************************************************
        Procedure Name :Job_CheckOldUser
        Purpose: 校验当天下载是否为老用户体验
         Edit: 2019-01-24 add by 小沈
    ****************************************************************/
   is
    --JOB 1分钟1波
    v_n        number;
    v_adid     number := 0; --广告编号
    v_id       number := 0;
    v_newly    number := 0; --需新增人数
    v_RowCount number := 0; --添加数量
  
    v_message varchar(300);
    cursor Cur_List is
      select id, adid, userid, deviceid, pagename
        from ad_app_bind
       where
      --itime>trunc(sysdate)
       itime > sysdate - (20 / (24 * 60))
       and isold = -1;
  
  begin
    v_n := 0;
  
    for User_Cur in Cur_List loop
    
      select count(1)
        into v_n
        from ad_app_bind
       where adid != User_Cur.adid
         and userid = User_Cur.userid
         and pagename = User_Cur.pagename
         and ustatus in (2, 3);
      if v_n > 0 then
        update ad_app_bind set isold = 1 where id = User_Cur.id;
        commit;
      else
        update ad_app_bind set isold = 0 where id = User_Cur.id;
        commit;
      end if;
    
      <<Next_Cur>>
      null;
    
    end loop;
  
  exception
    when others then
      rollback;
      v_message := '错误编码：' || sqlcode || '  错误信息 ：' || sqlerrm;
      --添加日志
      insert into fin_log
        (appid, adid, urlid, msg)
      values
        (0,
         0,
         0,
         ' P_AD_Windows_Older.Job_CheckOldUser; 校验老用户失败：' || v_message);
      commit;
      return;
  end Job_CheckOldUser;

  Procedure Job_Auto
  /*****************************************************************
        Procedure Name :Job_Auto
        Purpose: 自动添加激活老用户人数
         Edit: 2019-02-01 add by 小沈
    ****************************************************************/
   is
    --JOB 60分钟1波
    v_n        number;
    v_adid     number := 0; --广告编号 
    v_flux_day number := 0; --需新增人数
    v_RowCount number := 0; --添加数量
  
    v_message varchar(300);
    cursor Cur_List is
    -- 一个广告一天只被成功处理一次
      select adid, flux_day
        from ad_win_older_set
       where status = 2
         and sysdate - to_date(to_char(sysdate, 'yyyy-mm-dd') ||
                               to_char(flux_time, 'hh24:mi'),
                               'yyyy-mm-dd hh24:mi') > 0
         and flux_day > 0
         and d_time < trunc(sysdate)
      -- and adid=5249
      ;
  
  begin
    v_n := 0;
  
    for Ad_Cur in Cur_List loop
    
      v_adid     := Ad_Cur.Adid; --广告编号
      v_flux_day := Ad_Cur.flux_day;
    
      select count(1)
        into v_n
        from ad_adinfo
       where adid = v_adid
         and status in (1, 2, 3)
         and showtype = 1
         and round(to_number(stoptime - sysdate)) > 10;
    
      if v_n <= 0 then
        update ad_win_older_set
           set status   = 0,
               flux_msg = '广告已未带量，或即将停止',
               d_time   = sysdate
         where adid = v_adid;
        commit;
        goto Next_Cur;
      end if;
    
      --是否需要跑的老用户数量已满
      select count(1)
        into v_n
        from ad_win_older_set
       where adid = v_adid
         and total >= flux_total;
    
      if v_n > 0 then
        update ad_win_older_set
           set status   = 0,
               flux_msg = '需跑老用户数量已满',
               d_time   = sysdate
         where adid = v_adid;
        commit;
        goto Next_Cur;
      end if;
    
      --修改带量数
      update ad_win_older_set
         set newly = newly + v_flux_day, status = 1, d_time = sysdate
       where adid = v_adid
         and status = 2;
    
      commit;
    
      <<Next_Cur>>
      null;
    
    end loop;
  
  exception
    when others then
      rollback;
      v_message := '错误编码：' || sqlcode || '  错误信息 ：' || sqlerrm;
      --添加日志
      insert into fin_log
        (appid, adid, urlid, msg)
      values
        (0,
         0,
         0,
         ' P_AD_Windows_Older.Job_Auto; 数据录入异常：' || v_message);
      commit;
      return;
  end Job_Auto;

  Procedure Job_EntryUser
  /*****************************************************************
        Procedure Name :Job_EntryUser
        Purpose: 录入需要新增的老用户名单
         Edit: 2019-01-20 add by 小沈
    ****************************************************************/
   is
    --JOB 10分钟1波
    v_n         number;
    v_adid      number := 0; --广告编号
    v_total     number := 0; --累计触发
    v_id        number := 0;
    v_newly     number := 0; --需新增人数
    v_RowCount  number := 0; --添加数量
    v_flux_time date := null; --每日激活时间
  
    v_message varchar(300);
    cursor Cur_List is
      select adid, total, newly, flux_time, flux_total, complete
        from ad_win_older_set
       where status = 1;
  
    cursor Cur_UserList is
      select userid, deviceid, merid, ptype, money
        from (select userid, deviceid, merid, ptype, money
                from (select a.userid,
                             a.deviceid,
                             a.merid,
                             a.ptype,
                             sum(money) money
                        from ad_app_flux a
                       where a.adid in
                             (select column_value as adid
                                from (select *
                                        from table(splitstr((select adid_list
                                                              from ad_win_older_set
                                                             where adid =
                                                                   v_adid),
                                                            ','))))
                         and userid not in (select userid
                                              from ad_app_bind
                                             where adid = v_adid
                                               and ustatus = 3)
                         and userid not in
                             (select userid
                                from ad_win_older
                               where adid = v_adid)
                       group by a.userid, a.deviceid, a.merid, a.ptype
                      
                      )
               order by money desc
              
              )
       where rownum <= v_newly;
  
  begin
    v_n := 0;
  
    for Ad_Cur in Cur_List loop
    
      v_adid      := Ad_Cur.Adid; --广告编号
      v_total     := Ad_Cur.Total; --累计触发
      v_newly     := Ad_Cur.Newly;
      v_RowCount  := 0;
      v_flux_time := Ad_Cur.flux_time; --每日带量时间 取时间部分 
    
      --如果量已带满
      if v_total > Ad_Cur.Flux_Total or Ad_Cur.Complete > Ad_Cur.Flux_Total then
        update ad_win_older_set
           set status = 0, d_time = sysdate, flux_msg = '已到量'
         where adid = v_adid;
        commit;
        goto Next_Cur;
      end if;
    
      --如果为第一次操作
      if v_newly = 0 and v_total = 0 then
        --判断操作时间是否到了
        if sysdate - to_date(to_char(sysdate, 'yyyy-mm-dd') ||
                             to_char(v_flux_time, 'hh24:mi'),
                             'yyyy-mm-dd hh24:mi') > 0 then
          update ad_win_older_set
             set newly = flux_day, d_time = sysdate - 1
           where adid = v_adid;
          commit;
        end if;
        goto Next_Cur;
      end if;
    
      update ad_win_older_set set status = 9 where adid = v_adid;
      commit;
    
      for User_Cur in Cur_UserList loop
      
        select count(1)
          into v_n
          from ad_win_older
         where adid = v_adid
           and merid = User_Cur.Merid;
        --如果已经存在则不予插入
        if v_n <= 0 then
          v_id := sq_ad_win_older.nextval;
        
          insert into ad_win_older
            (id, adid, userid, deviceid, merid, ptype, money)
          values
            (v_id,
             v_adid,
             User_Cur.Userid,
             User_Cur.Deviceid,
             User_Cur.Merid,
             User_Cur.Ptype,
             User_Cur.Money);
          commit;
        
          v_RowCount := v_RowCount + 1;
        end if;
      
      end loop;
    
      update ad_win_older_set
         set total  = total + v_RowCount,
             newly  = newly - v_RowCount,
             status = 2,
             d_time = sysdate
       where adid = v_adid;
    
      commit;
    
      <<Next_Cur>>
      null;
    
    end loop;
  
  exception
    when others then
      rollback;
      v_message := '错误编码：' || sqlcode || '  错误信息 ：' || sqlerrm;
      --添加日志
      insert into fin_log
        (appid, adid, urlid, msg)
      values
        (0,
         0,
         0,
         ' P_AD_Windows_Older.Job_EntryUser; 数据录入异常：' || v_message);
      commit;
      return;
  end Job_EntryUser;

  procedure PQ_UserList
  /*****************************************************************
        Procedure Name :PQ_UserList
        Purpose: 获取老用户列表
        Edit: 2019-01-20 add by 小沈
    ****************************************************************/
  (I_Sign      In Number, --标记符号 1，2，3……
   I_PageSize  In Number, --每页记录数
   I_PageNO    In Number, --当前页码,从 1 开始
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    V_SQL       varchar2(3000);
    v_PageSize  number;
    v_PageNO    number;
    V_HeiRowNUM number; --小于第几行 分页用
    V_LowROWNUM number; --大于第几行 分页用
    V_ServerNum number := 1; --激活老用户服务数量 
  
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    v_PageSize := I_PageSize;
    v_PageNO   := I_PageNO;
  
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
    -- return;
  
    V_SQL := ' select id, adid,userid ,deviceid ,merid,ptype  from ad_win_older where ltime>sysdate-24   and  status =1   and  mod(id,' ||
             V_ServerNum || ')=' || I_Sign || '   order by userid   ';
  
    ----执行分页查询
    V_HeiRowNUM := v_PageNO * v_PageSize;
    V_LowROWNUM := V_HeiRowNUM - v_PageSize + 1;
  
    V_SQL := 'select id, adid,userid ,deviceid ,merid,ptype,rn
    from  ( select id , adid,userid ,deviceid ,merid,ptype,rownum rn
    from (' || V_SQL || ') a
    where rownum <= ' || TO_CHAR(V_HeiRowNUM) || '
    ) b
    where rn >= ' || TO_CHAR(V_LowROWNUM);
  
    --注意对rownum别名的使用,第一次直接用rownum,第二次一定要用别名rn
    --- order by 放里面会影响速度
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    OPEN O_Outcursor FOR V_SQL;
    return;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '查询异常！';
      -- o_message := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PQ_UserList;

  procedure PW_UPOlderUser
  /*****************************************************************
        Procedure Name :PW_UPOlderUser
        Purpose: 修改需要激活老用户状态
        Edit: 2019-01-20 add by 小沈
    ****************************************************************/
  (I_ID     In Number, --处理ID 
   I_ADID   In Number, --广告ID
   I_Status In Number, --状态 2：闲玩数据库自动激活 3：闲玩激活失败 4：商家激活失败 5：商家-激活成功，注册获取失败 9正在处理中
   I_Msg    In Varchar2, --商家返回消息
   O_Result Out Number --返回状态
   ) is
    v_n        number;
    v_RowCount number; --添加数量
  begin
  
    O_Result := 0;
  
    --查看传入状态是否正确
    if I_Status not in (2, 3, 4, 5, 9) then
      O_Result := 10;
      return;
    end if;
  
    --查看订单是否需要修改
    select count(1)
      into v_n
      from ad_win_older
     where id = I_ID
       and status in (1, 9);
  
    if v_n <= 0 then
      O_Result := 15;
      return;
    end if;
  
    if v_n > 0 then
      --数据库自动激活
      if I_Status in (2, 5) then
        update ad_win_older
           set status = I_Status, msg = I_Msg, ltime = sysdate
         where id = I_ID
           and status in (1, 9);
        v_RowCount := sql%rowcount;
        if v_RowCount = 1 then
          update ad_win_older_set
             set complete = complete + 1
           where adid = I_ADID;
        end if;
        commit;
      end if;
    
      if I_Status in (3, 4, 5) then
        update ad_win_older
           set status = I_Status, msg = I_Msg, ltime = sysdate
         where id = I_ID
           and status in (1, 9);
        v_RowCount := sql%rowcount;
        if v_RowCount = 1 then
          update ad_win_older_set
             set failure = failure + 1
           where adid = I_ADID;
        end if;
        commit;
      end if;
    
      if I_Status = 9 then
        update ad_win_older
           set status = 9, ltime = sysdate
         where id = I_ID
           and status = 1;
        commit;
      end if;
    
    end if;
  
  exception
    --失败
    when others then
    
      O_Result := -9;
      --v_msg := '失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      rollback;
    
  end PW_UPOlderUser;

  procedure PW_AddUserBind
  /*****************************************************************
        Procedure Name :PW_UPOlderUser
        Purpose: 添加用户绑定记录
        Edit: 2019-01-21 add by 小沈
    ****************************************************************/
  (I_ID       In Number, --处理ID 
   I_ADID     In Number, --广告ID
   I_Userid   In Number, --闲玩用户ID
   I_Deviceid In Varchar2, --被激活设备号ID
   O_Result   Out Number, --返回状态 
   O_Message  Out Varchar2 --返回信息
   ) is
    v_n         number;
    v_RowCount  number; --添加数量
    v_adid      number;
    v_appid     number;
    v_deviceid  varchar2(150);
    v_merid     varchar2(300);
    v_rownum    number;
    v_appsign   varchar2(300);
    v_ptype     number;
    v_ip        varchar(100);
    v_outcursor t_cursor;
  begin
  
    O_Result  := 0;
    O_Message := '处理成功';
  
    --查看订单是否需要修改
    select count(1)
      into v_n
      from ad_win_older
     where id = I_ID
       and status = 9;
  
    if v_n <= 0 then
      O_Result  := 10;
      O_Message := '信息不存在';
      return;
    end if;
  
    select adid, appid, deviceid, appsign, merid, ptype, ip, rownum
      into v_adid,
           v_appid,
           v_deviceid,
           v_appsign,
           v_merid,
           v_ptype,
           v_ip,
           v_rownum
      from ad_app_bind a
     where exists (select adid
              from (select column_value as adid
                      from table(splitstr((select adid_list
                                            from ad_win_older_set
                                           where adid = I_ADID),
                                          ','))) b
             where a.adid = b.adid)
       and a.userid = I_Userid
       and rownum = 1;
  
    --查看渠道是否有投放
    select count(1)
      into v_n
      from ad_awardset
     where adid = I_ADID
       and appid = v_appid;
  
    if v_n <= 0 then
      update ad_win_older
         set status = 3,
             msg    = '闲玩-添加绑定记录失败-渠道广告未添加',
             ltime  = sysdate
       where id = I_ID
         and status = 9;
      update ad_win_older_set
         set failure = failure + 1
       where adid = I_ADID;
      commit;
    end if;
  
    p_ad_webinfo.pq_userclick(i_adid      => I_ADID,
                                 i_appid     => v_appid,
                                 i_deviceid  => I_Deviceid,
                                 i_simid     => I_Deviceid,
                                 i_userid    => I_Userid,
                                 i_appsign   => v_appsign,
                                 i_ptype     => v_ptype,
                                 i_ip        => v_ip,
                                 i_ctype     => 1,
                                 o_outcursor => v_outcursor,
                                 o_result    => o_result,
                                 o_message   => o_message);
  
    --如果处理失败则直接老用户失败
    if o_result != 0 then
      update ad_win_older
         set status = 3,
             msg    = '闲玩-添加绑定记录失败' || o_message,
             ltime  = sysdate
       where id = I_ID
         and status = 9;
      update ad_win_older_set
         set failure = failure + 1
       where adid = I_ADID;
      commit;
    end if;
  
  exception
    --失败
    when others then
    
      O_Result := -9;
      --v_msg := '失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      rollback;
    
  end PW_AddUserBind;

  procedure PW_Activate_OldUser
  /*****************************************************************
        Procedure Name :PW_Activate_OldUser
        Purpose: 广告接口_激活老用户
        Edit: 2019-01-20 add by 小沈
    ****************************************************************/
  (I_ID       In Number, --处理ID 
   I_ADID     In Number, --广告ID
   I_Fid      In Varchar2, --本期广告主统计的来源id[apk渠道编号] 
   I_UrlId    In Number, --广告下载编号
   I_LastAdid In Number, --上一期广告ID
   I_LastFid  In Varchar2, --上一期广告主渠道编号 
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_SIMID    In Varchar2, --sim卡编号
   I_Userid   In Number, --闲玩用户编号
   I_APPSign  In Varchar2, --渠道应用标识符号、渠道用户id 
   I_PType    In Number, --1、ios  2、安卓
   I_IP       In Varchar2, --
   O_Result   Out Number,
   O_Message  Out Varchar2) is
  
  begin
    O_Result  := 0;
    O_Message := '激活成功！';
  
    p_ad_olduser_v2.pw_activate_olduser(i_adid     => i_adid,
                                        i_fid      => i_fid,
                                        i_urlid    => i_urlid,
                                        i_lastadid => i_lastadid,
                                        i_lastfid  => i_lastfid,
                                        i_appid    => i_appid,
                                        i_deviceid => i_deviceid,
                                        i_simid    => i_simid,
                                        i_userid   => i_userid,
                                        i_appsign  => i_appsign,
                                        i_ptype    => i_ptype,
                                        i_ip       => i_ip,
                                        o_result   => o_result,
                                        o_message  => o_message);
  
    if o_result = 0 then
      update ad_win_older
         set status = 2, msg = '成功激活', ltime = sysdate
       where id = I_ID;
      update ad_win_older_set
         set complete = complete + 1
       where adid = I_ADID;
      commit;
    
    else
    
      update ad_win_older
         set status = 3, msg = o_message, ltime = sysdate
       where id = I_ID;
      update ad_win_older_set
         set failure = failure + 1
       where adid = I_ADID;
      commit;
    end if;
  
    commit;
  
  exception
    --失败 
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '激活失败！';
    
      --O_Message := '激活失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_Activate_OldUser;

  Procedure Job_CheckUserReg
  /*****************************************************************
        Procedure Name :Job_CheckUserReg
        Purpose: 之前商家注册信息查询失败的用户，进行二次校验检查是否注册已完成
         Edit: 2019-01-26 add by 小沈
    ****************************************************************/
   is
    --JOB 30分钟1波
    v_n        number;
    v_adid     number := 0; --广告编号
    v_id       number := 0;
    v_newly    number := 0; --需新增人数
    v_RowCount number := 0; --添加数量
  
    v_message varchar(300);
  
    cursor Cur_UserList is
    
      select id, adid, userid, merid, ltime
        from ad_win_older
       where status = 5
         and ltime > trunc(sysdate) - 4
       order by ltime asc;
  
  begin
    v_n := 0;
  
    for User_Cur in Cur_UserList loop
    
      select count(1)
        into v_n
        from ad_app_bind
       where adid = User_Cur.adid
         and userid = User_Cur.Userid
         and ustatus in (2, 3);
      --如果用户注册信息获取到了则修改状态
      if v_n > 0 then
      
        update ad_win_older
           set status = 2,
               msg    = msg || '--后续注册校验时查到已注册',
               ltime  = sysdate
         where id = User_Cur.id
           and status = 5;
      
        v_RowCount := sql%rowcount;
      
        if v_RowCount = 1 then
          update ad_win_older_set
             set complete = complete + 1, failure = failure - 1
           where adid = User_Cur.adid;
        end if;
      
        commit;
      end if;
    
    end loop;
  
  exception
    when others then
      rollback;
      v_message := '错误编码：' || sqlcode || '  错误信息 ：' || sqlerrm;
      --添加日志
      insert into fin_log
        (appid, adid, urlid, msg)
      values
        (0,
         0,
         0,
         ' P_AD_Windows_Older.Job_CheckUserReg; 数据计算异常：' || v_message);
      commit;
      return;
  end Job_CheckUserReg;

  Procedure Job_UserMoney
  /*****************************************************************
        Procedure Name :Job_UserMoney
        Purpose: 获取已经激活的用户，跑出了多少奖励，和用户领取奖励
         Edit: 2019-01-26 add by 小沈
    ****************************************************************/
   is
    --JOB 60分钟1波
    v_n          number;
    v_adid       number := 0; --广告编号
    v_run_money  number := 0; --跑数据获得总金额 
    v_user_money number := 0; --用户已领取奖励金额  
  
    v_message varchar(300);
  
    cursor Cur_ADList is
      select adid
        from ad_win_older_set a
       where exists
       (select b.adid
                from ad_adinfo b
               where b.status in (1, 2, 3)
                 and b.showtype = 1
                  or (b.status = 4 and trunc(b.stoptime) = trunc(sysdate) and
                     b.stoptime != to_date('2099-01-01', 'yyyy-mm-dd'))
                 and a.adid = b.adid)
      --and a.adid = 5409
      ;
  
    cursor Cur_UserList is
    
      select id, adid, userid, deviceid, merid, ltime
        from ad_win_older
       where status = 2
         and adid = v_adid
      --and deviceid = '862659036752228'
       order by ltime asc;
  
  begin
    v_n := 0;
  
    for Cur_AD in Cur_ADList loop
      v_adid := Cur_AD.Adid;
    
      for User_Cur in Cur_UserList loop
        v_run_money  := 0; --跑数据获得总金额 
        v_user_money := 0; --用户已领取奖励金额  
      
        --查看是否有数据跑出来
        select count(1)
          into v_n
          from fin_ad_flux
         where adid = User_Cur.Adid
           and deviceid = User_Cur.Deviceid
           and merid = User_Cur.Merid;
      
        if v_n > 0 then
        
          select sum(a.price)
            into v_run_money
            from fin_ad_set_l a, fin_ad_flux b
           where a.adid = b.adid
             and a.dlevel = b.dlevel
             and b.adid = User_Cur.Adid
             and b.deviceid = User_Cur.Deviceid
             and b.merid = User_Cur.Merid;
        end if;
      
        --查看用户是否有主动领取奖励
      
        select count(1)
          into v_n
          from ad_app_flux
         where adid = User_Cur.Adid
           and deviceid = User_Cur.Deviceid
           and merid = User_Cur.Merid;
      
        if v_n > 0 then
          select sum(price)
            into v_user_money
            from ad_app_flux
           where adid = User_Cur.Adid
             and deviceid = User_Cur.Deviceid
             and merid = User_Cur.Merid;
        end if;
      
        if v_run_money > 0 or v_user_money > 0 then
          update ad_win_older
             set run_money  = v_run_money,
                 user_money = v_user_money,
                 c_time     = sysdate
           where id = User_Cur.id;
        end if;
      
        commit;
      end loop;
    
    end loop;
  
  exception
    when others then
      rollback;
      v_message := '错误编码：' || sqlcode || '  错误信息 ：' || sqlerrm;
      --添加日志
      insert into fin_log
        (appid, adid, urlid, msg)
      values
        (0,
         0,
         0,
         ' P_AD_Windows_Older.Job_CheckUserReg; 数据计算异常：' || v_message);
      commit;
      return;
  end Job_UserMoney;



  Procedure Job_UpdateRunOlderSet
  /*****************************************************************
        Procedure Name :Job_UpdateRunOlderSet
        Purpose: 更新跑老用户设置表
         Edit: 2019-01-26 add by 小胡
    ****************************************************************/
   is
    --JOB 每天凌晨1点更新
    begin
      
    update ad_win_older_set t set newly = 150, status = 1 where adid = 5250 and exists (select 1 from ad_adinfo s where s.adid=t.adid and status in(1,2,3));
    update ad_win_older_set t set newly = 100, status = 1 where adid = 5191 and exists (select 1 from ad_adinfo s where s.adid=t.adid and status in(1,2,3));
    exception when others then rollback;
  
    --添加日志
    return;
  end Job_UpdateRunOlderSet;

end P_AD_Windows_Older;
/


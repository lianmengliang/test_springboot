create package body P_Admin is

  /*管理员操作*/

  Function FQ_IsQX
  /*****************************************************************
    function Name: FQ_IsQX
    Purpose: 判断管理员是否有权限
    Author: 沈志江
    
    ****************************************************************/
  (I_AdminID In Varchar2,
   I_QXID    In Number --权限编号
   ) Return Number --0没权限  1有权限
   is
    stauts      Number;
    v_n         number;
    v_ip        varchar2(20);
    v_ip_limit  varchar2(20);
    v_ip_limit1 varchar2(20);
  begin
  
    V_IP_Limit  := '124.160.105.98';
    V_IP_Limit1 := '115.236.175.118';
  
    select count(1)
      into v_n
      from t_admin
     where adminid = I_AdminID
       and status = 1;
    if v_n <= 0 then
      --无权限则退出
      stauts := 0;
      return stauts;
    end if;
  
    select count(1)
      into v_n
      from t_qxconfig
     where adminid = I_AdminID
       and qxid = I_QXID;
  
    if v_n = 0 then
      --无权限则退出
      stauts := 0;
      return stauts;
    end if;
  
    stauts := 1;
    return stauts;
  
  end FQ_IsQX;

  procedure PQ_Privilege_List
  /*****************************************************************
        Procedure Name :PQ_Privilege_List
        Purpose: 当前已有权限列表
        Edit: 2018-02-24 add by 小沈
    ****************************************************************/
  (I_AdminID        In Varchar2, --管理员ID 
   I_PageSize       In Number,
   I_PageNO         In Number,
   O_OutRecordCount Out Number,
   O_OutCursor      Out T_CURSOR, --返回游标
   O_Result         Out Number, --返回（0正确，其他为提示或错误）
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_sql          varchar2(3000);
    v_n            number;
    v_qx           number; --本模块的权限代码
    V_HeiRownum    number;
    V_LowRownum    number;
    v_sqlcondition varchar2(1000);
  begin
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
  
    O_Result  := 0;
    O_Message := '';
  
    v_qx := 101; --初始化权限代码
    open o_outcursor for 'select 1 from dual where 1=2'; --游标初始化
  
    --管理员帐号是否为空
    if i_adminid is null then
      O_Result  := 101;
      O_Message := '管理员帐号不能为空，请检查！';
      return;
    end if;
  
    --管理员是否存在
    select count(1) into v_n from t_admin where adminid = i_adminid;
    if v_n = 0 then
      O_Result  := 102;
      O_Message := '管理员不存在，请检查！';
      return;
    end if;
  
    --管理员是否有操作此模块的权限
    if p_admin.fq_isqx(i_adminid => i_adminid, i_qxid => v_qx) = 0 then
      O_Result  := 103;
      O_Message := '您没有权限查询该信息，请检查！';
      return;
    end if;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
    v_sql := 'select qxid, qxname, des, url, gname,grank , rank, reportid, status, isshow, opentype, isip, itime 
            from t_qx  ';
  
    execute immediate 'select count(1) from (' || v_sql || ') '
      into O_OutRecordCount;
  
    --sql语句＝主语句＋条件＋排序 
  
    v_sql := v_sql || ' order by grank  asc, rank,status desc ';
  
    ----执行分页查询
    V_HeiRownum := I_PageNO * I_PageSize;
    V_LowRownum := V_HeiRownum - I_PageSize + 1;
    V_SQL       := 'select qxid, qxname, des, rank, url, gname,grank , reportid, status, isshow, opentype, isip, 
    to_char(itime,''yyyy-mm-dd hh24:mi:ss'') itime,rn
                    from (
                    select qxid, qxname, des, url, gname,grank , rank, reportid, status, isshow, opentype, isip, itime ,rownum rn
                    from (' || v_sql || ') A
                    where rownum <= ' ||
                   to_char(V_HeiRownum) || '
                    ) B
                    where rn >= ' || to_char(V_LowRownum);
    open O_OUTCURSOR for v_sql;
  
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
  
    return;
  exception
    --失败
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '查询不成功';
      return;
    
  end PQ_Privilege_List;

  Procedure PW_AddQX
  /*****************************************************************
        Procedure Name :PW_AddQX
        Purpose: 权限的增加
        Edit: 2017-05-01 add by 小沈
    ****************************************************************/
  (I_AdminID     In Varchar2,
   I_QXName      In Varchar2, --权限名称 
   I_Description In Varchar2, -- 描述 
   I_Url         In Varchar2, -- 权限地址 
   I_Rank        In Number, -- 权限排序号
   I_GName       In Varchar2, -- 分组名称 
   I_GRank       In Varchar2, -- 分组排序号需和之前的一样
   I_ReportId    In Number, -- 报表ID  
   I_IsShow      In Number, -- 1表示显示，0表示不显示 
   I_OpenType    In Number, -- 页面打开方式 ： 0：否 ；1：_blank 新窗 
   I_IsIp        In Number, --ip限制（1限制，0默认不限制）  
   O_Result      Out Number,
   O_Message     Out Varchar2) is
    V_QX Number; --本模块的权限代码
  begin
    O_Result  := 0;
    O_Message := '添加成功';
    V_QX      := 101; --初始化权限代码
    --管理员是否有操作此模块的权限
    if p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 then
      O_Result  := 101;
      O_Message := '您没有权限进行此操作，请检查！';
      return;
    end if;
  
    insert into t_qx
      (qxid,
       qxname,
       des,
       url,
       gname,
       rank,
       reportid,
       isshow,
       opentype,
       isip,
       grank)
    values
      (SQ_T_QX.NEXTVAL,
       I_QXName,
       I_Description,
       I_Url,
       I_GName,
       I_Rank,
       I_ReportId,
       I_IsShow,
       I_OpenType,
       I_IsIp,
       I_GRank);
  
    commit;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 110;
      O_Message := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_AddQX;

  Procedure PW_EditQX
  /*****************************************************************
        Procedure Name :PW_EditQX
        Purpose: 权限的修改
        Edit: 2017-05-01 add by 小沈
    ****************************************************************/
  (I_AdminID     In Varchar2,
   I_QXID        In Number, --权限编号 
   I_QXName      In Varchar2, --权限名称 
   I_Description In Varchar2, -- 描述 
   I_Url         In Varchar2, -- 权限地址 
   I_Rank        In Number, -- 权限排序号
   I_GName       In Varchar2, -- 分组名称 
   I_GRank       In Varchar2, -- 分组排序号需和之前的一样
   I_ReportId    In Number, -- 报表ID 无报表写0 
   I_IsShow      In Number, -- 1表示显示，0表示不显示 
   I_OpenType    In Number, -- 页面打开方式 ： 0：否 ；1：_blank 新窗 
   I_IsIp        In Number, --ip限制（1限制，0默认不限制） 
   O_Result      Out Number,
   O_Message     Out Varchar2) is
    V_QX Number; --本模块的权限代码
    v_n  Number;
  begin
    O_Result  := 0;
    O_Message := '修改成功';
    V_QX      := 101; --初始化权限代码
    --管理员是否有操作此模块的权限
    if p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 then
      O_Result  := 101;
      O_Message := '您没有权限进行此操作，请检查！';
      return;
    end if;
  
    select count(1)
      into v_n
      from t_qx
     where qxid = I_QXID
       and status = 1;
  
    if v_n = 0 then
      O_Result  := 1;
      O_Message := '没有该权限，请检查！';
      return;
    end if;
  
    update t_qx
       set qxname   = I_QXName,
           des      = I_Description,
           url      = I_Url,
           gname    = I_GName,
           rank     = I_Rank,
           reportid = I_ReportId,
           isshow   = I_IsShow,
           opentype = I_OpenType,
           isip     = I_IsIp,
           grank    = I_GRank
     where qxid = I_QXID;
  
    commit;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 110;
      O_Message := '修改失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_EditQX;

  Procedure PW_DelQX
  /*****************************************************************
        Procedure Name :PW_DelQX
        Purpose: 权限的删除
        Edit: 2018-03-06 add by 小沈
    ****************************************************************/
  (I_AdminID In Varchar2,
   I_QXID    In Number, --权限编号  
   O_Result  Out Number,
   O_Message Out Varchar2) is
    V_QX Number; --本模块的权限代码
    v_n  Number;
  begin
    O_Result  := 0;
    O_Message := '修改成功';
    V_QX      := 101; --初始化权限代码
    --管理员是否有操作此模块的权限
    if p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 then
      O_Result  := 101;
      O_Message := '您没有权限进行此操作，请检查！';
      return;
    end if;
  
    select count(1)
      into v_n
      from t_qx
     where qxid = I_QXID
       and status = 1;
  
    if v_n = 0 then
      O_Result  := 1;
      O_Message := '没有该权限，请检查！';
      return;
    end if;
  
    update t_qx
       set status = 0
     where qxid = I_QXID
       and status = 1;
  
    commit;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 110;
      O_Message := '修改失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_DelQX;

  procedure PQ_AdminList
  /*****************************************************************
        Procedure Name :PQ_AdminList
        Purpose: 查询管理员列表
        Edit: 2018-02-23 add by 小沈
    ****************************************************************/
  (I_AdminID        In Varchar2, --管理员ID
   O_OutRecordCount Out Number,
   O_OutCursor      Out T_CURSOR, --返回游标
   O_Result         Out Number, --返回（0正确，其他为提示或错误）
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) Is
    V_Sql Varchar2(500);
    V_n   NUMBER;
    V_QX  NUMBER; --本模块的权限代码
  BEGIN
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
  
    O_Result  := 0;
    O_Message := '';
  
    V_QX := 100; --初始化权限代码
    open O_OutCursor for 'select 1 from dual where 1=2'; --游标初始化
  
    --管理员帐号是否为空
    if I_AdminID is null then
      O_Result  := 101;
      O_Message := '管理员帐号不能为空，请检查！';
      return;
    end if;
  
    --管理员是否存在
    select count(1) into v_n from t_admin where adminid = i_adminid;
    if v_n = 0 then
      O_Result  := 102;
      O_Message := '管理员不存在，请检查！';
      return;
    end if;
  
    --管理员是否有操作此模块的权限
    if p_admin.fq_isqx(i_adminid => i_adminid, i_qxid => v_qx) = 0 then
      O_Result  := 103;
      O_Message := '您没有权限查询该信息，请检查！';
      return;
    end if;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
  
    select count(1) into O_OutRecordCount from t_admin where status = 1;
  
    open o_outcursor for
      select adminid, name from t_admin where status = 1 order by adminid;
  
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    O_Result  := 0;
    O_Message := '';
  
    return;
  exception
    --失败
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '查询不成功';
      return;
    
  end PQ_AdminList;

  procedure PQ_Privilege_Admin
  /*****************************************************************
        Procedure Name :PQ_Privilege_Admin
        Purpose: 根据操作获取管理员权限查询
        Edit: 2018-02-23 add by 小沈
    ****************************************************************/
  (I_AdminID        In Varchar2, --管理员ID
   I_SubAdminID     In Varchar2, --被查询管理员ID
   I_Type           In Number, --要操作的方式（0：当前权限；1：待授权限） 
   I_PageSize       In Number,
   I_PageNO         In Number,
   O_OutRecordCount Out Number,
   O_OutCursor      Out T_CURSOR, --返回游标
   O_Result         Out Number, --返回（0正确，其他为提示或错误）
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_sql          varchar2(3000);
    v_n            number;
    v_qx           number; --本模块的权限代码
    V_HeiRownum    number;
    V_LowRownum    number;
    v_sqlcondition varchar2(1000);
  begin
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
  
    O_Result  := 0;
    O_Message := '';
  
    v_qx := 100; --初始化权限代码
    open o_outcursor for 'select 1 from dual where 1=2'; --游标初始化
  
    --管理员帐号是否为空
    if i_adminid is null then
      O_Result  := 101;
      O_Message := '管理员帐号不能为空，请检查！';
      return;
    end if;
  
    --管理员是否存在
    select count(1) into v_n from t_admin where adminid = i_adminid;
    if v_n = 0 then
      O_Result  := 102;
      O_Message := '管理员不存在，请检查！';
      return;
    end if;
  
    --管理员是否有操作此模块的权限
    if p_admin.fq_isqx(i_adminid => i_adminid, i_qxid => v_qx) = 0 then
      O_Result  := 103;
      O_Message := '您没有权限查询该信息，请检查！';
      return;
    end if;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
    v_sql := 'select qxid,qxname,des ,gname 
            from t_qx where status=1 ';
  
    --查询条件赋值
    if i_type is not null and i_type > 0 then
      v_sqlcondition := ' and qxid not in (select qxid from t_qxconfig where adminid= ''' ||
                        i_subadminid || ''' ) ';
    else
      v_sqlcondition := ' and qxid=any(select qxid from t_qxconfig where adminid= ''' ||
                        i_subadminid || ''' ) ';
    end if;
  
    v_sql := v_sql || v_sqlcondition;
  
    execute immediate 'select count(1) from (' || v_sql || ') '
      into O_OutRecordCount;
  
    --sql语句＝主语句＋条件＋排序 
  
    v_sql := v_sql || ' order by grank  asc, rank ';
  
    ----执行分页查询
    V_HeiRownum := I_PageNO * I_PageSize;
    V_LowRownum := V_HeiRownum - I_PageSize + 1;
    V_SQL       := 'select qxid,qxname,des ,gname,rn
                    from (
                    select qxid,qxname,des ,gname,rownum rn
                    from (' || v_sql || ') A
                    where rownum <= ' ||
                   to_char(V_HeiRownum) || '
                    ) B
                    where rn >= ' || to_char(V_LowRownum);
    open O_OUTCURSOR for v_sql;
  
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
  
    return;
  exception
    --失败
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '查询不成功';
      return;
    
  end PQ_Privilege_Admin;

  Procedure PW_ConfigQX
  /*****************************************************************
        Procedure Name :PW_ConfigQX
        Purpose: 权限配置
        Edit: 2017-05-01 add by 小沈
    ****************************************************************/
  (I_AdminID   In Varchar2, --
   I_QXID      In Number, --权限编号 
   I_ToAdminID In Varchar2, --受权管理员 
   I_Status    In Number, --状态 1添加 2去除 
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    V_QX          Number; --本模块的权限代码
    v_n           Number;
    v_operateuser varchar(100);
  begin
    O_Result := 0;
  
    if I_Status not in (1, 2) then
      O_Result  := 6;
      O_Message := '您的操作有误，请检查！';
      return;
    end if;
  
    if I_Status = 1 then
      O_Message := '授权成功';
    else
      O_Message := '收回权限成功';
    end if;
    V_QX := 100; --初始化权限代码
    --管理员是否有操作此模块的权限
    if p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 then
      O_Result  := 101;
      O_Message := '您没有权限进行此操作，请检查！';
      return;
    end if;
  
    select count(1)
      into v_n
      from t_qxconfig
     where qxid = I_QXID
       and adminid = I_ToAdminID;
  
    --如果为添加权限
    if I_Status = 1 then
      if v_n >= 1 then
        O_Result  := 1;
        O_Message := '该管理员已有该权限，请检查！';
        return;
      end if;
    else
      --如果为删减
      if v_n <= 0 then
        O_Result  := 2;
        O_Message := '该管理员不存在该权限，无法去除，请检查！';
        return;
      end if;
    
    end if;
  
    select count(1) into v_n from t_qx where qxid = I_QXID;
    if v_n <= 0 then
      O_Result  := 3;
      O_Message := '该权限不存在，请检查！';
      return;
    end if;
  
    select count(1) into v_n from t_admin where adminid = I_ToAdminID;
    if v_n <= 0 then
      O_Result  := 4;
      O_Message := '被授权帐号有误，请检查！';
      return;
    end if;
  
    select name into v_operateuser from t_admin where adminid = I_AdminID;
  
    --添加权限
    if I_Status = 1 then
      insert into t_qxconfig
        (id, adminid, qxid, operateuser)
      values
        (sq_t_qxconfig.nextval, I_ToAdminID, I_QXID, v_operateuser);
    
    else
      delete t_qxconfig
       where qxid = I_QXID
         and adminid = I_ToAdminID;
    
    end if;
  
    commit;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 110;
      O_Message := '修改失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_ConfigQX;

  Procedure PQ_MenuList
  /*****************************************************************
        Procedure Name :PQ_MenuList
        Purpose: 获取权限列表
        Edit: 2017-05-01 add by 小沈
    ****************************************************************/
  (I_AdminID   In Varchar2,
   O_Outcursor out t_cursor, --返回游标
   O_Result    out number, --判断 0：查询成功，其他：出错
   O_Message   out varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
  
    v_n    Number;
    v_name varchar2(100);
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
    select count(1) into v_n from t_admin where adminid = I_AdminID;
  
    if v_n = 0 then
      O_Result  := 1;
      O_Message := '错误查询';
      return;
    end if;
    select name into v_name from t_admin where adminid = I_AdminID;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
  
    OPEN O_OUTCURSOR FOR
      select v_name nickname,
             a.qxid,
             a.qxname,
             a.gname,
             a.des,
             a.url,
             a.opentype
        from t_qx a, t_qxconfig b
       where a.qxid = b.qxid
         and b.adminid = I_AdminID
         and a.isshow = 1
       order by grank, gname, rank asc;
  
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    commit;
    return;
  
  Exception
    --失败
    When Others Then
      rollback;
      O_Result  := -9;
      O_Message := '查询失败';
      Return;
  end PQ_MenuList;

  Procedure PW_ChangePSW
  /*****************************************************************
        Procedure Name :PW_ChangePSW
        Purpose: 管理员修改密码
        Edit: 2017-05-01 add by 小沈
    ****************************************************************/
  (I_AdminID     In Varchar2,
   I_OldPassWord IN VARCHAR2, --老密码
   I_NewPassWord IN VARCHAR2, --新密码
   O_Result      out number, --判断 0：查询成功，其他：出错
   O_Message     out varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
  
    v_n    Number;
    v_name varchar2(100);
  begin
    O_Result  := 0;
    O_Message := '密码修改成功，请重新登录！';
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
  
    --管理员帐号是否为空
    if I_AdminID is null then
      O_Result  := 1;
      O_Message := '请先登录后台';
      return;
    end if;
  
    select count(1)
      into v_n
      from t_admin
     where adminid = I_AdminID
       and status = 1;
  
    if v_n = 0 then
      O_Result  := 2;
      O_Message := '您还不是管理员';
      return;
    end if;
  
    --输入参数是否正确
    if I_OldPassWord is null then
      O_Result  := 3;
      O_Message := '输入不能为空，请检查！';
      return;
    end if;
  
    --输入参数是否正确
    if I_NewPassWord is null then
      O_Result  := 4;
      O_Message := '请输入新密码！';
      return;
    end if;
  
    --管理员旧密码是否正确
    select count(1)
      into v_n
      from t_admin
     where adminid = I_AdminID
       and password = I_OldPassWord;
  
    if V_N = 0 then
      O_Result  := 10;
      O_Message := '旧密码错误，请检查！';
      return;
    end if;
  
    --校验新密码的复杂性
    if length(I_NewPassWord) < 5 then
      O_Result  := 107;
      O_Message := '密码长度太短，请检查！';
      return;
    end if;
  
    ----------------------------------------------------
    --步骤二：修改
    ----------------------------------------------------
    update t_admin set password = I_NewPassWord where adminid = I_AdminID;
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    commit;
    return;
  
  Exception
    --失败
    When Others Then
      rollback;
      O_Result  := -9;
      O_Message := '查询失败';
      Return;
  end PW_ChangePSW;

  procedure PW_LoginSendCode
  /*****************************************************************
        Procedure Name :PW_LoginSendCode
        Purpose: 管理员登录发送验证码
        Edit: 2018-07-05 add by 小沈
    ****************************************************************/
  (I_AdminId in varchar2, --管理员id
   I_PWD     in varchar2, --用户密码
   I_IP      in varchar2, --ip
   O_Result  out number, --返回（0正确，其他为提示或错误）
   O_Message out varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n          number;
    v_code       varchar2(30); --验证码
    v_phone      varchar(20); --手机号
    v_lasttime   date; -- 最后登陆时间 
    v_send_times number; --验证码发送次数 
    v_send_time  date; ---验证码最后发送时间 
    v_result     number;
    v_message    varchar2(100);
  begin
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
    O_Result  := 0;
    O_Message := '登录成功';
  
    --管理员帐号是否为空
    if I_AdminId is null then
      O_Result  := 10;
      O_Message := '请输入你的帐号！';
      return;
    end if;
  
    --密码不允许为空
    if I_PWD is null then
      O_Result  := 11;
      O_Message := '请输入你的密码！';
      return;
    end if;
  
    --ip是否为空
    if I_IP is null then
      O_Result  := 13;
      O_Message := '请刷新页面后重试！';
      return;
    end if;
  
    ----------------------------------------------------
    --步骤二：校验
    ----------------------------------------------------
  
    select count(1)
      into v_n
      from t_admin
     where adminid = I_AdminId
       and status = 1;
    if v_n <= 0 then
      O_Result  := 14;
      O_Message := '您的帐号不正确或已注销！';
      return;
    end if;
  
    select phone, lasttime, send_times, send_time
      into v_phone, v_lasttime, v_send_times, v_send_time
      from t_admin
     where adminid = I_AdminId;
  
    if v_phone = '' then
      O_Result  := 15;
      O_Message := '请先联系系统管理员绑定手机号! ';
      return;
    end if;
  
    --10分钟内短信发送超过5次不允许登录
    if v_lasttime > sysdate - 10 / (24 * 60) and v_send_times >= 5 then
      O_Result  := 15;
      O_Message := '短时间内，请求短信次数过多，10分钟内禁止登录，请稍后重试! ';
      return;
    end if;
  
    --2分钟内短信不允许重复发送
    if v_send_time > sysdate - 2 / (24 * 60) then
      O_RESULT  := 16;
      O_MESSAGE := '请接收短信，不要频繁发送! ';
      return;
    end if;
  
    --判断用户帐号密码是否正确
    select count(1)
      into v_n
      from t_admin t
     where t.adminid = I_AdminId
       and t.password = I_PWD;
  
    --如果密码错误 则也计算为短信验证错误，避免试探密码
    if v_n <= 0 then
      update t_admin
         set send_times = send_times + 1, lasttime = sysdate
       where adminid = I_AdminId;
      O_Result  := 17;
      O_Message := '您的帐号密码错误，请重试！';
      return;
    end if;
  
    --随机生成验证码
    select to_char(trunc(dbms_random.value(1000, 9999)))
      into v_code
      from dual;
  
    p_sms_send.pw_add_code(i_phone     => v_phone,
                           i_sendtype  => 1,
                           i_sendcode  => v_code,
                           i_sendlevel => 1,
                           o_result    => v_result,
                           o_message   => v_message);
  
    update t_admin
       set send_code = v_code, send_time = sysdate
     where adminid = I_AdminId;
  
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    commit;
  
    return;
  exception
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '登录异常！';
      return;
    
  end PW_LoginSendCode;

  procedure PW_AdminLogin
  /*****************************************************************
        Procedure Name :PW_AdminLogin
        Purpose: 管理员登录
        Edit: 2016-10-31 add by 小沈
    ****************************************************************/
  (I_AdminId in varchar2, --管理员id
   I_PWD     in varchar2, --用户密码
   I_Code    in varchar2, --用户验证码
   I_IP      in varchar2, --ip
   O_Result  out number, --返回（0正确，其他为提示或错误）
   O_Message out varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n          number;
    v_lasttime   date; -- 最后登陆时间 
    v_send_time  date; ---验证码最后发送时间 
    v_send_times number; --验证码发送次数 
  begin
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
    O_Result  := 0;
    O_Message := '登录成功';
  
    --管理员帐号是否为空
    if I_AdminId is null then
      O_Result  := 10;
      O_Message := '请输入你的帐号！';
      return;
    end if;
  
    --密码不允许为空
    if I_PWD is null then
      O_Result  := 11;
      O_Message := '请输入你的密码！';
      return;
    end if;
  
    --ip是否为空
    if I_IP is null then
      O_Result  := 13;
      O_Message := '请刷新页面后重试！';
      return;
    end if;
  
    ----------------------------------------------------
    --步骤二：登录
    ----------------------------------------------------
  
    select lasttime, send_time, send_times
      into v_lasttime, v_send_time, v_send_times
      from t_admin
     where adminid = I_AdminId;
  
    --20分钟内短信发送超过5次不允许登录
    if v_lasttime > sysdate - 20 / (24 * 60) and v_send_times >= 5 then
      O_Result  := 15;
      O_Message := '登录错误次数太多，禁止登陆，如有疑问，请联系系统管理员! ';
      return;
    end if;
  
    if v_send_time < sysdate - 20 / (24 * 60) then
      O_Result  := 16;
      O_Message := '验证码已过期请重新发送! ';
      return;
    end if;
  
    --判断用户密码
    select count(1)
      into v_n
      from t_admin t
     where t.adminid = I_AdminId
       and t.password = I_PWD;
  
    if v_n <= 0 then
    
      --密码验证失败
      update t_admin
         set send_times = send_times + 1, lasttime = sysdate
       where adminid = i_adminid;
    
      insert into t_admin_login_log
        (id, adminid, ip, itime, status, msg)
      values
        (SQ_ADMIN_LOGIN.NEXTVAL,
         I_AdminId,
         I_ip,
         sysdate,
         0,
         '登录失败—密码验证错误');
      commit;
    
      O_Result  := 18;
      O_Message := '您的密码有误，请仔细核对! ';
      return;
    end if;
  
    --验证码判断
    select count(1)
      into v_n
      from t_admin t
     where t.adminid = I_AdminId
       and t.send_code = to_number(i_code)
       and t.send_time > sysdate - 20 / (24 * 60);
  
    if v_n <= 0 then
    
      --验证码失败
      update t_admin
         set send_times = send_times + 1, lasttime = sysdate
       where adminid = i_adminid;
    
      insert into t_admin_login_log
        (id, adminid, ip, itime, status, msg)
      values
        (SQ_ADMIN_LOGIN.NEXTVAL,
         I_AdminId,
         I_ip,
         sysdate,
         0,
         '登录失败—验证码错误');
      commit;
    
      O_Result  := 18;
      O_Message := '您的验证码有误，请重新发送! ';
      return;
    end if;
  
    --判断用户
    select count(1)
      into v_n
      from t_admin t
     where t.adminid = I_AdminId
       and t.password = I_PWD
       and t.send_code = to_number(i_code)
       and t.send_time > sysdate - 20 / (24 * 60);
  
    --用户名或密码是否错误
    if (v_n > 0) then
    
      --验证通过
      update t_admin
         set send_time = sysdate - 1, send_times = 1
       where adminid = i_adminid;
    
      insert into t_admin_login_log
        (id, adminid, ip, itime, status, msg)
      values
        (SQ_ADMIN_LOGIN.NEXTVAL, I_AdminId, I_ip, sysdate, 1, '登录成功');
    
      update t_admin set lasttime = sysdate where adminid = I_AdminId;
      commit;
    
    else
      --验证码失败
      update t_admin
         set send_times = send_times + 1, lasttime = sysdate
       where adminid = i_adminid;
    
      insert into t_admin_login_log
        (id, adminid, ip, itime, status, msg)
      values
        (SQ_ADMIN_LOGIN.NEXTVAL,
         I_AdminId,
         I_ip,
         sysdate,
         0,
         '登录失败—密码或验证码错误，请刷新重试');
      commit;
      O_Result  := 99;
      O_Message := '用户名或密码或验证码错误! ';
      return;
    
    end if;
  
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
  
    return;
  exception
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '登录异常！';
      return;
    
  end PW_AdminLogin;

end P_Admin;
/


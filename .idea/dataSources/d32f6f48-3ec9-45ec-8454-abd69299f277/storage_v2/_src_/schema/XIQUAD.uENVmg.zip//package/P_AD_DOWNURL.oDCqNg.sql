create PACKAGE P_AD_DownUrl AS
  TYPE T_CURSOR IS REF CURSOR;

  /*广告页面 获取下载连接  */
  procedure PQ_DownUrl
  /*****************************************************************
        Procedure Name :PQ_DownUrl
        Purpose: 因为小米手机https开头并已apk 
        结尾下载完成后不会自动安装，所以增加个跳转的口子
        Edit: 2018-08-02 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   I_Urld      In Number, --渠道应用ID 
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number, --判断 0：查询成功，其他：出错
   O_Message   Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

end P_AD_DownUrl;


/


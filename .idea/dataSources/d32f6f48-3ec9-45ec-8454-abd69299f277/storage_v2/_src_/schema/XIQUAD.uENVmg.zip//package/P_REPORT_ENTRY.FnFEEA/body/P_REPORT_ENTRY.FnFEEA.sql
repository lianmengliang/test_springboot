create package body P_Report_Entry is

  -- Purpose : 报表信息录入

  Procedure Job_DayClick
  /*****************************************************************
        procedure name: Job_DayClick
        purpose: 每日点击下载信息记录
        edit: 2019-02-20 add by 小沈
    ****************************************************************/
   is
  
    v_adid       number; --广告ID
    v_appid      number; --渠道编号
    v_urlid      number; --下载id
    v_Satrt_Day  varchar2(100); --开始获取日期  如果只取一天则开始和结束日期写同一天 如 2017-06-18
    v_End_Day    varchar2(100); --结束获取日期  如果只取一天则开始和结束日期写同一天 如 2017-06-18
    v_Now_Day    date; --当期日期
    v_days       number; --获取相差天数
    v_n          number;
    v_down       number; --下载数 
    v_down_Older number; --老用户下载数 
    v_down_Newer number; --新用户下载数 
    v_result     number;
    v_message    varchar2(500);
  
    cursor Adid_List is
    
      select appid, adid, urlid
        from (select appid, adid, nvl(urlid, 0) urlid, count(1)
                from ad_app_bind
               where itime >= v_Now_Day
                 and itime < v_Now_Day + 1
              -- and adid=2761 and appid=1120
               group by appid, adid, urlid
               order by appid, adid);
  
  begin
    v_n       := 0;
    v_adid    := 0;
    v_result  := 0;
    v_message := '处理成功！';
  
    v_Satrt_Day := to_char(sysdate - 1, 'yyyy-mm-dd');
    v_End_Day   := to_char(sysdate - 1, 'yyyy-mm-dd');
  
    /* v_Satrt_Day := '2018-03-28';
    v_End_Day   := '2018-03-30';*/
  
    v_days := to_date(v_End_Day, 'yyyy-mm-dd') -
              to_date(v_Satrt_Day, 'yyyy-mm-dd');
  
    --根据需要获取的日期进行循环获取
    for v_day in 0 .. v_days loop
    
      --当前需要获取的日期
      v_Now_Day := to_date(v_Satrt_Day, 'yyyy-mm-dd') + v_day;
    
      for C_Adid in Adid_List loop
        v_appid := C_Adid.appid;
        v_adid  := C_Adid.adid;
        v_urlid := C_Adid.urlid;
      
        --下载数
        select count(1)
          into v_down
          from ad_app_bind
         where appid = v_appid
           and adid = v_adid
           and urlid = v_urlid
           and itime >= v_Now_Day
           and itime < v_Now_Day + 1;
      
        --老用户
        select count(1)
          into v_down_Older
          from ad_app_bind
         where appid = v_appid
           and adid = v_adid
           and isold = 1
           and urlid = v_urlid
           and itime >= v_Now_Day
           and itime < v_Now_Day + 1;
        --新用户
        select count(1)
          into v_down_Newer
          from ad_app_bind
         where appid = v_appid
           and adid = v_adid
           and isold = 0
           and urlid = v_urlid
           and itime >= v_Now_Day
           and itime < v_Now_Day + 1;
      
        select count(1)
          into v_n
          from rep_ad_dayreg
         where appid = v_appid
           and adid = v_adid
           and urlid = v_urlid
           and dtime = v_Now_Day;
        if v_n > 0 then
          update rep_ad_dayreg
             set down       = v_down,
                 down_older = v_down_Older,
                 down_newer = v_down_Newer,
                 itime      = sysdate
           where appid = v_appid
             and adid = v_adid
             and urlid = v_urlid
             and dtime = v_Now_Day;
        else
          insert into rep_ad_dayreg
            (dtime,
             appid,
             adid,
             urlid,
             down,
             down_older,
             down_newer,
             itime)
          values
            (v_Now_Day,
             v_appid,
             v_adid,
             v_urlid,
             v_down,
             v_down_Older,
             v_down_Newer,
             sysdate);
        end if;
        --单个广告结束 提交
        commit;
      
        <<Next_C_Adid>>
        null;
      
      end loop;
    
    end loop;
    
    --每日注册信息记录
    p_report_entry.job_dayreg;
  
  exception
    when others then
      rollback;
      v_message := '错误编码：' || sqlcode || '  错误信息 ：' || sqlerrm;
      --添加日志
      insert into fin_log
        (appid, adid, urlid, msg)
      values
        (0,
         0,
         0,
         ' p_report_entry.Job_DayClick; 每日下载数据录入异常：' || v_message);
      commit;
      return;
  end Job_DayClick;

  Procedure Job_DayReg
  /*****************************************************************
        procedure name: Job_DayReg
        purpose: 每日注册信息记录
        edit: 2017-07-23 add by 小沈
        2019-02-20 小沈修改，注册统计不再记录点击数据，2者分开统计
    ****************************************************************/
   is
  
    v_adid      number; --广告ID
    v_appid     number; --渠道编号
    v_urlid     number; --下载id
    v_Satrt_Day varchar2(100); --开始获取日期  如果只取一天则开始和结束日期写同一天 如 2017-06-18
    v_End_Day   varchar2(100); --结束获取日期  如果只取一天则开始和结束日期写同一天 如 2017-06-18
    v_Now_Day   date; --当期日期
    v_days      number; --获取相差天数
    v_n         number;
    v_reg       number; --注册数 
    v_reg_Older number; --老用户注册数 
    v_reg_Newer number; --新用户注册数 
    v_result    number;
    v_message   varchar2(500);
  
    cursor Adid_List is
    
      select appid, adid, urlid
        from (select appid, adid, nvl(urlid, 0) urlid, count(1)
                from ad_app_bind
               where ustatus in (2, 3)
                 and lasttime >= v_Now_Day
                 and lasttime < v_Now_Day + 1
              -- and adid=2761 and appid=1120
               group by appid, adid, urlid
               order by appid, adid);
  
  begin
    v_n       := 0;
    v_adid    := 0;
    v_result  := 0;
    v_message := '处理成功！';
  
    v_Satrt_Day := to_char(sysdate - 1, 'yyyy-mm-dd');
    v_End_Day   := to_char(sysdate - 1, 'yyyy-mm-dd');
  
    /* v_Satrt_Day := '2018-03-28';
    v_End_Day   := '2018-03-30';*/
  
    v_days := to_date(v_End_Day, 'yyyy-mm-dd') -
              to_date(v_Satrt_Day, 'yyyy-mm-dd');
  
    --根据需要获取的日期进行循环获取
    for v_day in 0 .. v_days loop
    
      --当前需要获取的日期
      v_Now_Day := to_date(v_Satrt_Day, 'yyyy-mm-dd') + v_day;
    
      for C_Adid in Adid_List loop
        v_appid := C_Adid.appid;
        v_adid  := C_Adid.adid;
        v_urlid := C_Adid.urlid;
      
        --注册
        select count(1)
          into v_reg
          from ad_app_bind
         where appid = v_appid
           and adid = v_adid
           and urlid = v_urlid
           and ustatus in (2, 3)
           and lasttime >= v_Now_Day
           and lasttime < v_Now_Day + 1;
      
        --老用户
        select count(1)
          into v_reg_Older
          from ad_app_bind
         where appid = v_appid
           and adid = v_adid
           and urlid = v_urlid
           and isold = 1
           and ustatus in (2, 3)
           and lasttime >= v_Now_Day
           and lasttime < v_Now_Day + 1;
      
        --新用户
        select count(1)
          into v_reg_Newer
          from ad_app_bind
         where appid = v_appid
           and adid = v_adid
           and urlid = v_urlid
           and isold = 0
           and ustatus in (2, 3)
           and lasttime >= v_Now_Day
           and lasttime < v_Now_Day + 1;
      
        select count(1)
          into v_n
          from rep_ad_dayreg
         where appid = v_appid
           and adid = v_adid
           and urlid = v_urlid
           and dtime = v_Now_Day;
        if v_n > 0 then
          update rep_ad_dayreg
             set reg = v_reg, 
                 reg_older = v_reg_Older, 
                 reg_newer = v_reg_Newer,
                 itime     = sysdate
           where appid = v_appid
             and adid = v_adid
             and urlid = v_urlid
             and dtime = v_Now_Day;
        else
          insert into rep_ad_dayreg
            (dtime, appid, adid, urlid, reg, reg_older, reg_newer, itime)
          values
            (v_Now_Day,
             v_appid,
             v_adid,
             v_urlid,
             v_reg,
             v_reg_Older,
             v_reg_Newer,
             sysdate);
        end if;
        --单个广告结束 提交
        commit;
      
        <<Next_C_Adid>>
        null;
      
      end loop;
    
    end loop;
  
  exception
    when others then
      rollback;
      v_message := '错误编码：' || sqlcode || '  错误信息 ：' || sqlerrm;
      --添加日志
      insert into fin_log
        (appid, adid, urlid, msg)
      values
        (0,
         0,
         0,
         ' p_report_entry.job_dayreg; 数据录入异常：' || v_message);
      commit;
      return;
  end Job_DayReg;

end P_Report_Entry;
/


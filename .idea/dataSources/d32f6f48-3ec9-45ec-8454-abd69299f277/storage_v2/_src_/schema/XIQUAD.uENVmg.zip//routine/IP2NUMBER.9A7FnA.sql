create function ip2number(ip varchar2)
return number
is
  ip_num_hex varchar2(80);
begin
  if (regexp_like(ip, '^(/d{1,3})/.(/d{1,3})/.(/d{1,3})/.(/d{1,3})$')) then
     ip_num_hex := lpad(trim(to_char(regexp_replace(ip, '^(/d{1,3})/.(/d{1,3})/.(/d{1,3})/.(/d{1,3})$', '/1'), 'XX')),2,'0') ||
                   lpad(trim(to_char(regexp_replace(ip, '^(/d{1,3})/.(/d{1,3})/.(/d{1,3})/.(/d{1,3})$', '/2'), 'XX')),2,'0') ||
                   lpad(trim(to_char(regexp_replace(ip, '^(/d{1,3})/.(/d{1,3})/.(/d{1,3})/.(/d{1,3})$', '/3'), 'XX')),2,'0') ||
                   lpad(trim(to_char(regexp_replace(ip, '^(/d{1,3})/.(/d{1,3})/.(/d{1,3})/.(/d{1,3})$', '/4'), 'XX')),2,'0');

     return to_number(ip_num_hex, 'XXXXXXXX');
  else
     return -1;
  end if;
exception
when others then
  return -99999999999;
end;


/


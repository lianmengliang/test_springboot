create PACKAGE P_AD_Order_Push AS
  TYPE T_CURSOR IS REF CURSOR;

  /*渠道订单推送*/

  procedure PQ_Order
  /*****************************************************************
        Procedure Name :PQ_Order
        Purpose: 订单获取
        Edit: 2017-04-11 add by 小沈
    ****************************************************************/
  (I_Type           In Number, --预留使用，多线程读取时使用 
   I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始
   O_Outrecordcount Out Number, --返回总记录数
   O_Outcursor      Out t_cursor, --返回游标
   O_Result         Out Number, --判断 0：查询成功，其他：出错
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  procedure PW_Back_Msg
  /*****************************************************************
        Procedure Name :PW_Back_Msg
        Purpose: 渠道返回信息
        Edit: 2017-04-11 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   I_APPId     In Number, --渠道应用ID 
   I_OrderNum  In Varchar2, --订单编号  
   I_P_Status  In Number, --对方对方接收状态 0 接收失败  1接收成功
   I_P_Backs   In Varchar2, -- 推送后返回状态   
   I_P_BackMsg In Varchar2, -- 推送后返回信息    
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure PQ_Interface
  /*****************************************************************
        Procedure Name :PQ_Interface
        Purpose: 获取接口信息
        Edit: 2017-04-11 add by 小沈
    ****************************************************************/
  (I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始
   O_Outrecordcount Out Number, --返回总记录数
   O_Outcursor      Out t_cursor, --返回游标
   O_Result         Out Number, --判断 0：查询成功，其他：出错
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  procedure PQ_Interface_APPID
  /*****************************************************************
        Procedure Name :PQ_Interface
        Purpose: 根据APPID获取接口信息
        Edit: 2017-04-11 add by 小沈
    ****************************************************************/
  (I_APPId     In Number, --渠道应用ID 
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number, --判断 0：查询成功，其他：出错
   O_Message   Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

end P_AD_Order_Push;


/


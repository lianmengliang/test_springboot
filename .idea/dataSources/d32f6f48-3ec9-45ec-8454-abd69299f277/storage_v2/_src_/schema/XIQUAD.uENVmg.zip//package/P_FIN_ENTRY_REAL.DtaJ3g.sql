create package P_FIN_Entry_Real is

  -- Purpose : 财务实际数据录入

  Procedure PW_DayExpend
  /*****************************************************************
        Procedure Name :PW_DayExpend
        Purpose: 每日消耗
        Edit: 2017-08-07 add by 小沈
    ****************************************************************/
  (I_APPId   In Number, --渠道应用ID
   I_Adid    In Number, --广告编号
   I_UrlId   In Number, --广告编号
   I_DTime   In Varchar2, --数据日期
   O_Result  Out Number,
   O_Message Out Varchar2);

  Procedure Job_AutoEntry;
  /*****************************************************************
      procedure name: Job_AutoEntry
      purpose: 数据自动录入
      edit: 2017-08-07 add by 小沈
  ****************************************************************/

end P_FIN_Entry_Real;


/


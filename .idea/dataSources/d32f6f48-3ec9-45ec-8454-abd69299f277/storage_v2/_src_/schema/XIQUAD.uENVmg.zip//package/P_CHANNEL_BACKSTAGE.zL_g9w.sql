create PACKAGE P_Channel_Backstage AS

  Type T_Cursor Is Ref Cursor;
  /*渠道管理后台*/

  procedure PW_Register
  /*****************************************************************
        Procedure Name :PW_Register
        Purpose: 渠道管理员注册帐号
        Edit: 2018-05-14 add by 小沈
    ****************************************************************/
  (I_Account   In Varchar2, --管理员帐号
   I_Password  In Varchar2, --用户密码
   I_Name      In Varchar2, --渠道管理员姓名 
   I_Phone     In Varchar2, --管理员联系电话  
   I_IP        In Varchar2, --ip
   O_AccountID Out Number, --管理员帐号ID
   O_Result    Out Number, --返回（0正确，其他为提示或错误）
   O_Message   Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  procedure PW_Login
  /*****************************************************************
        Procedure Name :PW_Login
        Purpose: 渠道管理员登录
        Edit: 2018-05-14 add by 小沈
    ****************************************************************/
  (I_Account   In Varchar2, --管理员帐号
   I_Password  In Varchar2, --用户密码
   I_IP        In Varchar2, --ip
   O_AccountID Out Number, --管理员帐号ID
   O_Result    Out Number, --返回（0正确，其他为提示或错误）
   O_Message   Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  Procedure PW_ChangePSW
  /*****************************************************************
        Procedure Name :PW_ChangePSW
        Purpose: 管理员修改密码
        Edit: 2018-05-14 add by 小沈
    ****************************************************************/
  (I_AccountID   In Number, --管理员帐号ID
   I_OldPassWord In VARCHAR2, --老密码
   I_NewPassWord In VARCHAR2, --新密码
   O_Result      Out Number, --判断 0：查询成功，其他：出错
   O_Message     Out VARCHAR2 --返回信息（操作结果，成功或者错误信息）
   );

  Procedure PQ_MenuList
  /*****************************************************************
        Procedure Name :PQ_MenuList
        Purpose: 获取权限列表
        Edit: 2018-05-14 add by 小沈
    ****************************************************************/
  (I_AccountID In Number, --管理员帐号ID
   O_Outcursor out t_cursor, --返回游标
   O_Result    out number, --判断 0：查询成功，其他：出错
   O_Message   out varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  Procedure PQ_AppList
  /*****************************************************************
        Procedure Name :PQ_AppList
        Purpose: 获取应用列表
        Edit: 2018-05-14 add by 小沈
    ****************************************************************/
  (I_AccountID In Number, --管理员帐号ID
   O_Outcursor out t_cursor, --返回游标
   O_Result    out number, --判断 0：查询成功，其他：出错
   O_Message   out varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  Procedure PQ_Revenue
  /*****************************************************************
        Procedure Name :PQ_Revenue
        Purpose: 渠道收入概况
        Edit: 2018-05-19 add by 小沈
    ****************************************************************/
  (I_AccountID In Number, --管理员帐号ID
   I_APPID     In Number, --渠道应用编号
   O_Outcursor out t_cursor, --返回游标
   O_Result    out number, --判断 0：查询成功，其他：出错
   O_Message   out varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  procedure PQ_Revenue_Trend
  /*****************************************************************
        Procedure Name :PQ_Revenue_Trend
        Purpose:  渠道收入趋势
        Edit: 2018-05-19 add by 小沈
    ****************************************************************/
  (I_AccountID      In Number, --管理员帐号ID
   I_APPID          In Number, --渠道应用编号
   I_SDate          In Varchar2, --开始日期
   I_EDate          In Varchar2, --截止日期
   I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始
   O_Outrecordcount Out Number, --返回总记录数
   O_Outcursor      Out t_cursor, --返回游标
   O_Result         Out Number, --判断 0：查询成功，其他：出错
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  procedure PQ_Revenue_Days
  /*****************************************************************
        Procedure Name :PQ_Revenue_Day
        Purpose:  渠道收入日表
        Edit: 2018-05-19 add by 小沈
    ****************************************************************/
  (I_AccountID      In Number, --管理员帐号ID
   I_APPID          In Number, --渠道应用编号
   I_SDate          In Varchar2, --开始日期
   I_EDate          In Varchar2, --截止日期
   I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始
   O_Outrecordcount Out Number, --返回总记录数
   O_Outcursor      Out t_cursor, --返回游标
   O_Result         Out Number, --判断 0：查询成功，其他：出错
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  procedure PQ_Revenue_ThatDay
  /*****************************************************************
        Procedure Name :PQ_Revenue_ThatDay
        Purpose:  渠道当天收入情况 
        Edit: 2018-05-19 add by 小沈
    ****************************************************************/
  (I_AccountID In Number, --管理员帐号ID
   I_APPID     In Number, --渠道应用编号
   I_Date      In Varchar2, --日期  
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number, --判断 0：查询成功，其他：出错
   O_Message   Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  procedure PQ_Revenue_AD
  /*****************************************************************
        Procedure Name :PQ_Revenue_AD
        Purpose:  广告支出明细
        Edit: 2018-06-19 add by 小沈
    ****************************************************************/
  (I_AccountID      In Number, --管理员帐号ID
   I_APPID          In Number, --渠道应用编号
   I_SDate          In Varchar2, --开始日期
   I_EDate          In Varchar2, --截止日期
   I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始
   O_Outrecordcount Out Number, --返回总记录数
   O_Outcursor      Out t_cursor, --返回游标
   O_Result         Out Number, --判断 0：查询成功，其他：出错
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );
   
 procedure PQ_Revenue_Order
  /*****************************************************************
        Procedure Name :PQ_Revenue_order
        Purpose: 渠道订单
        Edit: 2019-07-23 add by 小刘
    ****************************************************************/
  (I_AccountID      In Number, --管理员帐号ID
   I_APPID          In Number, --渠道应用编号
   I_SDate          In Varchar2, --开始日期
   I_EDate          In Varchar2, --截止日期
   I_OrderNum       In varchar2, --订单编号
   I_AppSign        In varchar2, --渠道账号
   I_Deviceid       In varchar2, --设备号
   I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始
   O_Outrecordcount Out Number, --返回总记录数
   O_Outcursor      Out t_cursor, --返回游标
   O_Result         Out Number, --判断 0：查询成功，其他：出错
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );
   
end P_Channel_Backstage;


/


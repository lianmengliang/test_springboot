create PACKAGE BODY P_AD_IsShow_List_Test AS

  /* 判断当前广告是否为该用户显示 --广告列表使用 使用表缓存  */

  Function FQ_IsShow
  /*****************************************************************
        Procedure Name :FQ_IsShow
        Purpose: 判断是否显示 0 不显示 1 显示
        Edit: 2018-11-17 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_Userid   In Number, --闲玩用户编号
   I_IP       In Varchar2, --用户当前IP
   I_IP_Num   In Number, --用户当前IP 数字化
   I_PType    In Number --1、ios  2、安卓
   ) Return Number As
    PRAGMA AUTONOMOUS_TRANSACTION; -------------方法函数 被嵌套，且有表操作 必写
  
    -- 是否显示 0 不显示 1 显示
  
    v_status      number := 0;
    v_n           number;
    v_isBind      number; --是否绑定 0否 1是
    v_ADStatus    number; --广告状态
    v_showtype    number; ---0不显示，1显示
    v_andpagename varchar2(100); --安卓包名
    v_iosPageName varchar2(100); --苹果包
    v_isdevice    number := 1; --是否限制设备
    v_urlid       number; --下载地址编号
    v_UrlS        number; --下载状态（0未使用，1正常使用，2日到量，3总到量，4停止使用）
  
    v_AllMoney number; --用户可获得金额
    v_AllTimes number; --已获得总奖励次数
    v_adtype   number; --广告类型（1棋牌游戏，2应用，3手游）
  
    v_province_user varchar2(100); -- 用户所在省份
    v_city_user     varchar2(100); -- 用户所在城市
    v_limit_type    number; --1:仅限当前区域体验 2：当前区域不可体验
    v_ip_short      varchar2(20); --短IP
  
    v_isCache number := 0; -- 可用缓存记录数
  
  begin
  
    if I_Userid is null or I_Userid = 0 then
      v_status := 0; --不显示
      return v_status;
    end if;
  
    if I_PType not in (1, 2) then
      v_status := 0; --不显示
      return v_status;
    end if;
  
    --渠道如果不存在或已下架则不显示
    select count(1)
      into v_n
      from ad_channel
     where appid = appid
       and status in (0, 1);
  
    if v_n <= 0 then
      v_status := 0; --不显示
      return v_status;
    end if;
  
    select status, showtype, adtype, isdevice, iospagename, pagename
      into v_ADStatus,
           v_showtype,
           v_adtype,
           v_isdevice,
           v_iosPageName,
           v_andpagename
      from ad_adinfo
     where adid = I_ADID;
  
    if v_ADStatus in (0, 4) then
      v_status := 0; --不显示
      return v_status;
    end if;
  
    --该存储过程为嵌套使用所以传入的设备号已处理
    --不显示广告只有测试机显示
    if v_showtype = 0 then
      select count(1)
        into v_n
        from ad_testdevice
       where deviceid = I_Deviceid
         and status = 0;
      if v_n <= 0 then
        v_status := 0;
        return v_status;
      end if;
    end if;
  
    --判断奖励是否已设置
    select count(1)
      into v_n
      from ad_awardset
     where adid = i_adid
       and appid = I_APPId;
  
    if v_n <= 0 then
      v_status := 0;
      return v_status;
    end if;
  
    --是否有下载地址
    select count(1) into v_n from ad_downurl where adid = i_adid;
    if v_n <= 0 then
      v_status := 0;
      return v_status;
    end if;
  
    --判断当前设备号有无在其他渠道体验过
    --有则直接不显示
    select count(1)
      into v_n
      from ad_app_bind
     where adid = i_adid
       and appid != I_APPId
       and deviceid = I_Deviceid;
  
    if v_n > 0 then
      v_status := 0;
      return v_status;
    end if;
  
    --判断当前设备是否有其他闲玩ID体验过 有则不显示
    --避免一个设备号多个帐号去体验
    select count(1)
      into v_n
      from ad_app_bind
     where adid = i_adid
       and userid != I_Userid
       and deviceid = I_Deviceid;
  
    if v_n > 0 then
      v_status := 0;
      return v_status;
    end if;
  
    --判断用户是否已经体验过了 [同用户不同手机还是显示原来的号所以可以体验]
    select count(1)
      into v_isBind
      from ad_app_bind
     where adid = i_adid
       and userid = I_Userid;
    --如果没体验过 且广告非正常投放 则不显示
    if v_isBind <= 0 and v_ADStatus != 1 then
      v_status := 0;
      return v_status;
    end if;
  
    --可能存在异常不显示 【绑定记录多条】
    if v_isBind > 1 then
      v_status := 0;
      return v_status;
    end if;
  
    --查看是否有缓存
    select count(1)
      into v_isCache
      from cache_ad_show
     where adid = i_adid
       and userid = i_userid
       and status = 1;
  
    if v_isCache = 1 then
      select isshow
        into v_status
        from cache_ad_show
       where adid = i_adid
         and userid = i_userid
         and status = 1;
      return v_status;
    else
      v_isCache := 0;
    end if;
  
    --如果金额为空则重新查询 JOB会跑 金额和显示状态
    if v_isCache = 0 then
      v_status := p_ad_isshow_v3.fq_isshow(i_adid     => i_adid,
                                           i_appid    => i_appid,
                                           i_deviceid => i_deviceid,
                                           i_userid   => i_userid,
                                           i_ip       => i_ip,
                                           i_ip_num   => i_ip_num,
                                           i_ptype    => i_ptype);
    
      --前面对广告的基础判断已判断，所以可以记录缓存，广告未投放等状态，再前面直接判断了  
      insert into cache_ad_show
        (id,
         adid,
         appid,
         deviceid,
         userid,
         ptype,
         ip,
         ip_num,
         isshow,
         status)
        select sq_cache_ad_show.nextval,
               i_adid,
               i_appid,
               i_deviceid,
               i_userid,
               i_ptype,
               i_ip,
               i_ip_num,
               v_status,
               1
          from dual
         where not exists (select *
                  from cache_ad_show
                 where adid = i_adid
                   and userid = i_userid);
    
      commit;
      return v_status;
    end if;
  
    v_status := 1; --显示
    return v_status;
  exception
    --失败
    when others then
      --v_msg := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      rollback;
      return 0;
  end FQ_IsShow;

end P_AD_IsShow_List_Test;
/


create package P_Channel_Manage is

  TYPE T_CURSOR IS REF CURSOR;

  /*渠道信息*/

  procedure pw_Add
  /*****************************************************************
        Procedure Name :pw_Add
        Purpose: 渠道信息增加
        Edit: 2017-02-15 add by 小沈
    ****************************************************************/
  (I_AdminID      In Varchar2,
   I_Name         In Varchar2, --  渠道应用名称
   I_Status       In Number, --  状态 0 测试 1开启 2停止
   I_APPSecret    In Varchar2, --  密钥 --随机字母字符串组成 16位
   I_AType        In Number, -- 应用类型 1苹果 2安卓
   I_Unit         In Varchar2, --  货币单位描述
   I_Rate         In Number, --  货币与人名币比率
   I_Downapp      In Varchar2, --  App下载方法
   I_Openurl      In Varchar2, -- 打开页面地址方法
   I_Ischange     In number, --  是否开启货币转换
   I_Arate        In number, --  渠道奖励设置比率
   I_Marketer     In Varchar2, --  市场人员
   I_Note         In Varchar2, --备注信息
   I_IsInt        In number, --是否以整数计算
   I_SHOWLOGO     In number, --显示闲玩Logo等相关信息
   I_ISCONVERSION In number, --是否转换为蘑菇星球
   I_INTEGRAL     In number, --是否是有积分渠道
   I_SHOWNAME     In Varchar2, --渠道名称（显示用）
   I_PRICERATE    In number, --渠道结算金额
   O_Result       Out number,
   O_Message      Out varchar2);

  procedure pw_Edit
  /*****************************************************************
        Procedure Name :pw_Edit
        Purpose: 渠道应用信息修改
        Edit: 2017-2-15 add by 小沈
    ****************************************************************/
  (I_AdminID      In Varchar2,
   I_APPId        In Number, --渠道应用ID
   I_Name         In Varchar2, --  渠道应用名称
   I_Status       In Number, --  状态 0 测试 1开启 2停止
   I_APPSecret    In Varchar2, --  密钥 --随机字母字符串组成 16位
   I_AType        In Number, -- 应用类型 1苹果 2安卓
   I_Unit         In Varchar2, --  货币单位描述
   I_Rate         In Number, --  货币与人名币比率
   I_Downapp      In Varchar2, --  App下载方法
   I_Openurl      In Varchar2, -- 打开页面地址方法
   I_Ischange     In number, --  是否开启货币转换
   I_Arate        In number, --  渠道奖励设置比率
   I_Marketer     In Varchar2, --  市场人员
   I_Note         In Varchar2, --备注信息
   I_IsInt        In number, --是否以整数计算
   I_SHOWLOGO     In number, --显示闲玩Logo等相关信息
   I_ISCONVERSION In number, --是否转换为蘑菇星球
   I_INTEGRAL     In number, --是否是有积分渠道
   I_SHOWNAME     In Varchar2, --渠道名称（显示用）
   I_PRICERATE    In number, --渠道结算金额
   O_Result       Out number,
   O_Message      Out varchar2);

  procedure pq_Info
  /*****************************************************************
        Procedure Name :pq_Info
        Purpose: 获取单个渠道信息
        Edit: 2017-2-15 add by 小沈
    ****************************************************************/
  (I_AdminID   In varchar2,
   I_APPId     In Number, --渠道应用ID
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out number,
   O_Message   Out varchar2);

  procedure pq_List
  /*****************************************************************
        Procedure Name :pq_List
        Purpose: 广告列表
        Edit: 2017-02-15 add by 小沈
    ****************************************************************/
  (I_AdmInId        In Varchar2,
   I_APPId          In Number, --渠道应用ID
   I_Name           In Varchar2, --渠道应用名称
   I_Status         In Number, --状态 0 测试 1开启 2 停止
   I_AType          In Number, --应用类型 1苹果 2安卓
   I_PageSize       In Number,
   I_PageNO         In Number,
   O_OutRecordCount Out Number,
   O_OutCursor      Out t_cursor, --返回游标
   O_Result         Out Number,
   O_Message        Out Varchar2);
  procedure pw_AccountSet
  /*****************************************************************
        Procedure Name :pw_Edit
        Purpose: 渠道账号设置
        Edit: 2018-11-01 add by 小胡
    ****************************************************************/
  (I_AdminID In Varchar2,
   I_APPId   In Number, --渠道应用ID
   I_Account In Varchar2, --  渠道账号
   O_Result  Out number,
   O_Message Out varchar2);
end P_Channel_Manage;
/


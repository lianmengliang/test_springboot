create PACKAGE P_AD_IsShow AS

  Function FQ_IsShow
  /*****************************************************************
        Procedure Name :FQ_IsShow
        Purpose: 判断是否显示
        Edit: 2017-11-20 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_ADStatus In Number, -- 投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放） 
   I_Deviceid In Varchar2, --设备号ID  
   I_PType    In Number --1、ios  2、安卓
   ) Return Number;

  Function FQ_Deviceid
  /*****************************************************************
        Procedure Name :FQ_Deviceid
        Purpose: 根据设备号判断是否显示 
        Edit: 2017-02-17 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_ADStatus In Number, -- 投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放） 
   I_Deviceid In Varchar2, --设备号ID  
   I_PType    In Number --1、ios  2、安卓
   ) Return Number;

end P_AD_IsShow;


/


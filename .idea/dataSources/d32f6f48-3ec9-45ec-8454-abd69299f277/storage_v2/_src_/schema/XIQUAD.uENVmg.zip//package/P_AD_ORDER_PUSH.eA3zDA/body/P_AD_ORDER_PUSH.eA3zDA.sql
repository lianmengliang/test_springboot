create PACKAGE BODY P_AD_Order_Push AS

  /*渠道订单推送*/

  procedure PQ_Order
  /*****************************************************************
        Procedure Name :PQ_Order
        Purpose: 订单获取
        Edit: 2017-04-11 add by 小沈
    ****************************************************************/
  (I_Type           In Number, --预留使用，多线程读取时使用 
   I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始
   O_Outrecordcount Out Number, --返回总记录数
   O_Outcursor      Out t_cursor, --返回游标
   O_Result         Out Number, --判断 0：查询成功，其他：出错
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n         number;
    v_unit      varchar2(50); --货币单位描述 默认元
    V_SQL       varchar2(3000);
    V_HeiRowNUM number; --小于第几行 分页用
    V_LowROWNUM number; --大于第几行 分页用
    V_SQLSelect varchar2(2000);
    v_PageSize  number;
    v_PageNO    number;
    v_DeviceId  varchar2(100);
  begin
    O_Result  := 0;
    O_Message := '查询成功';
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
    /*    v_PageSize := I_PageSize;
    v_PageNO   := I_PageNO;*/
    v_PageSize := 100;
    v_PageNO   := 1;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
    V_SQLSelect := 'select adid, adname, appid, ordernum, dlevel, awardgroup, pagename, deviceid, simid, appsign, merid,
 mername, event, price, money,itime  from ad_channel_order where  appid not in (1410)    and  p_ntime<=sysdate  and p_status in (0,2) and  p_times<5   and appid in (select appid from ad_interf_order where status=0  )  order by p_ntime asc  ';
  
    ----执行分页查询
    V_HeiRowNUM := v_PageNO * v_PageSize;
    V_LowROWNUM := V_HeiRowNUM - v_PageSize + 1;
  
    execute immediate 'select count(1) from (' || V_SQLSelect || ')'
      into O_Outrecordcount;
  
    V_SQL := 'select  adid, adname, appid, ordernum, dlevel,   pagename, deviceid, simid, appsign, merid,   case when appid=1270 then ''闲玩-''|| substr(event,0,16) else event end as  event,
    rtrim(to_char(price, ''fm999999990.99''), ''.'') price,rtrim(to_char(money, ''fm999999990.99''), ''.'') money ,itime   
    from  ( select  adid, adname, appid, ordernum, dlevel, awardgroup, pagename, deviceid, simid, appsign, merid,
     mername, event, price, money ,itime  ,rownum rn
    from (' || V_SQLSelect || ') A
    where rownum <= ' || TO_CHAR(V_HEIROWNUM) || '
    ) B
    where rn >= ' || TO_CHAR(V_LOWROWNUM);
  
    --注意对rownum别名的使用,第一次直接用rownum,第二次一定要用别名rn
    --- order by 放里面会影响速度
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    OPEN O_OUTCURSOR FOR V_SQL;
    return;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      ROLLBACK;
      O_Result := -9;
      -- O_Message := '查询失败';
      O_Message := '查询失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      RETURN;
  end PQ_Order;

  procedure PW_Back_Msg
  /*****************************************************************
        Procedure Name :PW_Back_Msg
        Purpose: 渠道返回信息
        Edit: 2017-04-11 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   I_APPId     In Number, --渠道应用ID 
   I_OrderNum  In Varchar2, --订单编号  
   I_P_Status  In Number, --对方对方接收状态 0 接收失败  1接收成功
   I_P_Backs   In Varchar2, -- 推送后返回状态   
   I_P_BackMsg In Varchar2, -- 推送后返回信息    
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    v_n     number;
    v_times number; --推送次数
    v_NTime date; --下次推送时间 
  begin
    o_result  := 0;
    o_message := '处理成功';
  
    --判断该订单是否需要修改 
    select count(1)
      into v_n
      from ad_channel_order
     where adid = I_ADID
       and appid = I_APPId
       and ordernum = I_OrderNum
       and p_status in (0, 2);
    --
    if v_n <= 0 then
      o_result  := 1;
      o_message := '订单不存在或者无需处理';
      return;
    end if;
  
    --如果对方接收失败则下次继续推送 共推送3次 
    if I_P_Status = 0 then
      select p_times
        into v_times
        from ad_channel_order
       where adid = I_ADID
         and appid = I_APPId
         and ordernum = I_OrderNum;
      --第二次推送时间 加15分钟
      if v_times = 0 then
        v_NTime := sysdate + 15 / (24 * 60);
        --第三次推送时间 加30分钟
      elsif v_times = 1 then
        v_NTime := sysdate + 30 / (24 * 60);
        --第四次推送时间 加60分钟
      elsif v_times = 2 then
        v_NTime := sysdate + 60 / (24 * 60);
      else
        --不再推送
        v_NTime := to_date('2999-01-01', 'yyyy-mm-dd');
      end if;
    
      update ad_channel_order
         set p_status  = 2,
             p_ntime   = v_NTime,
             p_time    = sysdate,
             p_times   = p_times + 1,
             p_backs   = I_P_Backs,
             p_backmsg = I_P_BackMsg
       where adid = I_ADID
         and appid = I_APPId
         and ordernum = I_OrderNum
         and p_status in (0, 2);
    
    end if;
  
    --如果对方接收成功
    if I_P_Status = 1 then
    
      update ad_channel_order
         set p_status  = 1,
             p_time    = sysdate,
             p_times   = p_times + 1,
             p_backs   = I_P_Backs,
             p_backmsg = I_P_BackMsg
       where adid = I_ADID
         and appid = I_APPId
         and ordernum = I_OrderNum
         and p_status in (0, 2);
    
    end if;
  
    commit;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      o_result := 1001;
      --o_message := '接收异常！';
      o_message := '处理失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      RETURN;
  end PW_Back_Msg;

  procedure PQ_Interface
  /*****************************************************************
        Procedure Name :PQ_Interface
        Purpose: 获取接口信息
        Edit: 2017-04-11 add by 小沈
    ****************************************************************/
  (I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始
   O_Outrecordcount Out Number, --返回总记录数
   O_Outcursor      Out t_cursor, --返回游标
   O_Result         Out Number, --判断 0：查询成功，其他：出错
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n         number;
    v_unit      varchar2(50); --货币单位描述 默认元
    V_SQL       varchar2(3000);
    V_HeiRowNUM number; --小于第几行 分页用
    V_LowROWNUM number; --大于第几行 分页用
    V_SQLSelect varchar2(2000);
    v_PageSize  number;
    v_PageNO    number;
    v_DeviceId  varchar2(100);
  begin
    O_Result  := 0;
    O_Message := '查询成功';
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
    /*    v_PageSize := I_PageSize;
    v_PageNO   := I_PageNO;*/
    v_PageSize := 100;
    v_PageNO   := 1;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
    V_SQLSelect := 'select appid, url,key, method, code, otime, htype, islog  from ad_interf_order where status=0 ';
  
    ----执行分页查询
    V_HeiRowNUM := v_PageNO * v_PageSize;
    V_LowROWNUM := V_HeiRowNUM - v_PageSize + 1;
  
    execute immediate 'select count(1) from (' || V_SQLSelect || ')'
      into O_Outrecordcount;
  
    V_SQL := 'select  appid, url,key,  method, code, otime, htype, islog   ,rn
    from  ( select  appid, url,key,  method, code, otime, htype, islog  ,rownum rn
    from (' || V_SQLSelect || ') A
    where rownum <= ' || TO_CHAR(V_HEIROWNUM) || '
    ) B
    where rn >= ' || TO_CHAR(V_LOWROWNUM);
  
    --注意对rownum别名的使用,第一次直接用rownum,第二次一定要用别名rn
    --- order by 放里面会影响速度
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    OPEN O_OUTCURSOR FOR V_SQL;
    return;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      ROLLBACK;
      O_Result := -9;
      -- O_Message := '查询失败';
      O_Message := '查询失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      RETURN;
  end PQ_Interface;

  procedure PQ_Interface_APPID
  /*****************************************************************
        Procedure Name :PQ_Interface
        Purpose: 根据APPID获取接口信息
        Edit: 2017-04-11 add by 小沈
    ****************************************************************/
  (I_APPId     In Number, --渠道应用ID 
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number, --判断 0：查询成功，其他：出错
   O_Message   Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n number;
  
  begin
    O_Result  := 0;
    O_Message := '查询成功';
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
  
    select count(1)
      into v_n
      from ad_interf_order
     where appid = I_APPId
       and status = 0;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
    OPEN O_OUTCURSOR FOR
      select appid, url, key, method, code, otime, htype, islog, ktype
        from ad_interf_order
       where appid = I_APPId
         and status = 0;
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
  
    return;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      ROLLBACK;
      O_Result := -9;
      -- O_Message := '查询失败';
      O_Message := '查询失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      RETURN;
  end PQ_Interface_APPID;

end P_AD_Order_Push;
/


create package P_WXAD_Interface is

  TYPE T_CURSOR IS REF CURSOR;
  ---微信广告接口
  procedure PQ_AdidToken
  /*****************************************************************
        Procedure Name :PQ_ADInfo
        Purpose: 微信关注广告，根据微信adid获取token 
        Edit: 2017-10-14 add by 小沈
    ****************************************************************/
  (I_Adid      In Number, --adid
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out number, --判断 0：查询成功，其他：出错
   O_Message   Out varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  procedure PW_SaveMessage
  /*****************************************************************
        Procedure Name: PW_SaveMessage
        Purpose:用户发送信息给微信，信息保存
        Edit: 2017-10-15 add by 小沈
        Comment:
    ****************************************************************/
  (I_Adid          In Number, --adid
   I_ToUserName    In Varchar2, --公众平台 APPID
   I_FromUserName  In Varchar2, --微信发送方帐号（一个OpenID）
   I_CreateTime    In Varchar2, --消息创建时间 （整型）
   I_MsgType       In Varchar2, --消息类型 消息类型 text ，event
   I_Content       In Varchar2, --消息内容
   I_MsgId         In Varchar2, --消息id，64位整型
   I_Ctime         In Varchar2, --消息创建时间 (转换后)
   O_ReturnMSG     Out Varchar2, -- 返回微信信息
   O_ReturnMSGType Out Number, --返回信息类型   1、回复文本消息 2、图片消息 3、语音消息 4、视频消息 5、音乐消息 6、图文消息
   O_Result        Out Number, -- 返回（0正确， 1回答错误 其他为提示或错误）
   O_Message       Out Varchar2 -- 返回信息（操作结果，成功或者错误信息）
   );

  procedure PW_Subscribe
  /*****************************************************************
        Procedure Name: PW_Subscribe
        Purpose:用户订阅或取消订阅
        Edit: 2017-10-15 add by 小沈
        Comment:
    ****************************************************************/
  (I_Adid          In Number, --adid
   I_ToUserName    In Varchar2, --公众平台 APPID
   I_FromUserName  In Varchar2, --微信发送方帐号（一个OpenID）
   I_CreateTime    In Varchar2, --消息创建时间 （整型）
   I_MsgType       In Varchar2, --消息类型 text ，event
   I_Event         In Varchar2, --事件类型，subscribe(订阅)、unsubscribe(取消订阅) 
   I_Ctime         In Varchar2, --消息创建时间 (转换后)
   O_ReturnMSG     Out Varchar2, -- 返回微信信息
   O_ReturnMSGType Out Number, --返回信息类型   1、回复文本消息 2、图片消息 3、语音消息 4、视频消息 5、音乐消息 6、图文消息
   O_Result        Out Number, -- 返回（0正确， 1回答错误 其他为提示或错误）
   O_Message       Out Varchar2 -- 返回信息（操作结果，成功或者错误信息）
   );

end P_WXAD_Interface;


/


create function FQ_MonetaryUnit
/*****************************************************************
  过程名称：显示货币单位
  创建日期：2018-03-21 add by 小沈
  返回：
  ****************************************************************/
(I_Money In Number, --传入金额
 I_Type  In Number --是否已万级为单位显示 0 :否 1：是
 ) return varchar2 --返回级别
 is
  v_str   varchar2(200) := '';
  v_money number;
begin

  if I_Money is null or I_Money = 0 then
    return v_str;
  end if;

  if I_Type = 0 then
    v_str := p_base_fun.fq_strround(i_num => I_Money);
    return v_str;
  end if;
  v_money := trunc(v_money);

  --如果传入金额大于等于1千万 按亿为单位
  if I_Money >= 10000000 then
    v_money := trunc(I_Money / 100000000, 2);
    v_str   := p_base_fun.fq_strround(i_num => v_money) || '亿';
    return v_str;
  end if;

  --大于等于1万 按万为单位
  if I_Money >= 10000 then
    v_money := trunc(I_Money / 10000, 2);
    v_str   := p_base_fun.fq_strround(i_num => v_money) || '万';
    return v_str;
  end if;

  --其余按普通显示
  v_str := p_base_fun.fq_strround(i_num => I_Money);
  return v_str;

  return v_str;
exception
  when others then
    return v_str;
end FQ_MonetaryUnit;


/


create package P_SMS_Send is

  TYPE T_CURSOR IS REF CURSOR;

  /*短信发送*/

  procedure PW_Add_Code
  /*****************************************************************
        Procedure Name :PW_Add
        Purpose: 短信添加
        Edit: 2018-07-05 add by 小沈
    ****************************************************************/
  (I_Phone     In Varchar2, --手机号码
   I_SendType  In Number, --发送类型 1:管理员登录
   I_SendCode  In Varchar2, --发送验证码 
   I_SendLevel In Number, --发送优先级,99为手工插入，最高优先级
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure PQ_List
  /*****************************************************************
        Procedure Name :PQ_List
        Purpose: 获取短信列表
        Edit: 2018-07-05 add by 小沈
    ****************************************************************/
  (I_PageSize       In Number,
   I_PageNO         In Number,
   O_OutRecordCount Out Number,
   O_OutCursor      Out t_cursor, --返回游标
   O_Result         Out Number,
   O_Message        Out Varchar2);

  procedure PW_UpStatus
  /*****************************************************************
        Procedure Name :PW_UpStatus
        Purpose: 修改短信状态为正在发送中
        Edit: 2018-07-05 add by 小沈
    ****************************************************************/
  (I_SmsId   In Number, --短信ID
   O_Result  Out Number,
   O_Message Out Varchar2);

  procedure PW_Result
  /*****************************************************************
        Procedure Name :PW_Result
        Purpose: 短信发送结果返回
        Edit: 2018-07-05 add by 小沈
    ****************************************************************/
  (I_SmsId   In Number, --短信ID
   I_Status  In Number, -- 返回状态 0：失败  1：成功
   I_Result  In Varchar2, --返回信息
   O_Result  Out Number,
   O_Message Out Varchar2);

end P_SMS_Send;
/


create package body P_Base_Fun is

  /*基础方法 集合*/

  Function FQ_StrRound
  /**保留2位小数*/
  (i_num IN number --数字
   ) return varchar2 --返回
   is
    v_num   number;
    v_round varchar2(100);
  begin
    if nvl(i_num, 0) = 0 then
      return '0';
    end if;
  
    --四舍五入
    v_num := round(i_num, 2);
  
    --整数处理
    if v_num = trunc(v_num) then
    
      select to_char(v_num, '999999999') into v_round from dual;
    
      return ltrim(v_round);
    end if;
  
    --0.几的小数处理
    if trunc(v_num) = 0 then
      select to_char(v_num, 'fm999999990.99') into v_round from dual;
    
      return ltrim(v_round);
    end if;
  
    --几.几0的小数处理
    if v_num > trunc(v_num) then
      select to_char(v_num, 'fm999999990.99') into v_round from dual;
    
      return ltrim(v_round);
    end if;
  
    return v_round;
  EXCEPTION
    WHEN OTHERS THEN
      return '0';
  end FQ_StrRound;

  Function FQ_StrRound
  /*****************************************************************
    过程名称：FQ_StrRound
    创建日期：2017-03-02
    功能说明：保留2位小数
    ****************************************************************/
  (i_num  IN number, --数字
   i_type in number --1显示位数，如1.00元或者2.30元 ；2不显示位数，如1元，2.3元，
   ) return varchar2 --返回
   is
    v_num   number;
    v_round varchar2(100);
  begin
    if nvl(i_num, 0) = 0 then
      return '0';
    end if;
  
    --四舍五入
    v_num := round(i_num, 2);
  
    --整数处理
    if v_num = trunc(v_num) then
      if i_type = 1 then
      
        select to_char(v_num, '999999990.00') into v_round from dual;
      else
        select to_char(v_num, '999999999') into v_round from dual;
      end if;
    
      return ltrim(v_round);
    end if;
  
    --0.几的小数处理
    if trunc(v_num) = 0 then
      if i_type = 1 then
        select to_char(v_num, '999999990.00') into v_round from dual;
      else
        select to_char(v_num, 'fm999999990.99') into v_round from dual;
      end if;
    
      return ltrim(v_round);
    end if;
  
    --几.几0的小数处理
    if v_num > trunc(v_num) then
      if i_type = 1 then
        select to_char(v_num, '999999990.00') into v_round from dual;
      else
        select to_char(v_num, 'fm999999990.99') into v_round from dual;
      end if;
    
      return ltrim(v_round);
    end if;
  
    return v_round;
  EXCEPTION
    WHEN OTHERS THEN
      if i_type = 1 then
        return '0.00';
      else
        return '0';
      end if;
  end FQ_StrRound;

  Function FQ_Deviceid_Check
  /*****************************************************************
        Procedure Name :FQ_Deviceid_Check
        Purpose:  设备号校验是否合法 0否 1是
        Edit: 2017-07-12 add by 小沈
    ****************************************************************/
  (I_DeviceId In Varchar2, --设备号
   I_PType    In Varchar2 --1.iphone，2.android
   ) Return Number As
  Begin
    if length(nvl(I_DeviceId, ' ')) <= 10 then
      --小于等于10个字符，不合法
      return 0;
    end if;
    if instr(I_DeviceId, '<') > 0 or instr(I_DeviceId, '>') > 0 then
      --小于等于10个字符，不合法
      return 0;
    end if;
  
    if substr(I_DeviceId, 1, 1) = substr(I_DeviceId, 2, 1) and
       substr(I_DeviceId, 1, 1) = substr(I_DeviceId, 3, 1) and
       substr(I_DeviceId, 1, 1) = substr(I_DeviceId, 4, 1) and
       substr(I_DeviceId, 1, 1) = substr(I_DeviceId, 5, 1) then
      --前5个字符一样，如00000，11111，不合法
      return 0;
    end if;
  
    if I_PType = 2 and length(I_DeviceId) >= 20 and
       lower(I_DeviceId) = I_DeviceId then
      --安卓，长度大于20，全部小写，疑似非法
      return 1;
    end if;
  
    return 2;
  End FQ_Deviceid_Check;

  function FQ_Str_Round
  /*****************************************************************
        Procedure Name :FQ_Str_Round
        Purpose: 金额千分位
        Edit: 2017-07-12 add by 小沈
    ****************************************************************/
  (I_Num In Number --数字
   ) return varchar2 --返回
  
   is
    v_num   number;
    v_round varchar2(100);
  begin
    if nvl(i_num, 0) = 0 then
      return '0';
    end if;
  
    --四舍五入
    v_num := round(i_num, 2);
  
    --整数处理
    if v_num = trunc(v_num) then
    
      select to_char(v_num, '999999999') into v_round from dual;
    
      return ltrim(v_round);
    end if;
  
    --0.几的小数处理
    if trunc(v_num) = 0 then
      select to_char(v_num, 'fm999999990.99') into v_round from dual;
    
      return ltrim(v_round);
    end if;
  
    --几.几0的小数处理
    if abs(v_num) > trunc(abs(v_num)) then
      select to_char(v_num, 'fm999999990.99') into v_round from dual;
    
      return ltrim(v_round);
    end if;
  
    return v_round;
  EXCEPTION
    WHEN OTHERS THEN
      return '0';
  end FQ_Str_Round;

  Function FQ_PhoneNum
  /*****************************************************************
        Procedure Name :FQ_PhoneNum
        Purpose: 是否为手机号码 0否 ；1是
        Edit: 2017-07-12 add by 小沈
    ****************************************************************/
  (I_PhoneNum In Varchar2) Return Number is
    v_Num Number;
  begin
  
    --判断长度
    if length(I_PhoneNum) != 11 then
      return 0;
    end if;
  
    --判断是否为数字
    for i in 1 .. 11 loop
      v_Num := ascii(substr(I_PhoneNum, i, 1));
      if v_Num < 48 or v_Num > 57 THEN
        return 0;
      end if;
    end loop;
  
    ---.*(1[[:digit:]]{10}).*
    if regexp_like(I_PhoneNum, '^1[34578]\d{9}$') then
      return 1;
    end if;
  
    return 0;
  
  exception
    when others then
      --dbms_output.put_line('异常：');  
      return 1;
  end FQ_PhoneNum;

  Function FQ_Random_Str
  /*****************************************************************
        Procedure Name :FQ_Random_Str
        Purpose: 生成指定长度随机数
        Edit: 2017-07-12 add by 小沈
    ****************************************************************/
  (I_len In Number --长度
   ) return Varchar2 --返回随机数
   is
    v_j number(18);
    type password_array is table of varchar2(1) index by binary_integer;
    v_pwdarr       password_array; --随机数组
    v_cardpassword varchar2(50);
    v_rndno4       varchar2(5);
  begin
  
    v_j := 0;
    --密码为非z,2,1,i,0,o的数字和字母的组合
    v_pwdarr(1) := '2';
    v_pwdarr(2) := 'c';
    v_pwdarr(3) := '3';
    v_pwdarr(4) := 'a';
    v_pwdarr(5) := 'b';
    v_pwdarr(6) := '8';
    v_pwdarr(7) := 'd';
    v_pwdarr(8) := 'j';
    v_pwdarr(9) := 's';
    v_pwdarr(10) := 'q';
    v_pwdarr(11) := 'k';
    v_pwdarr(12) := 'o';
    v_pwdarr(13) := 'u';
    v_pwdarr(14) := 't';
    v_pwdarr(15) := 'r';
    v_pwdarr(16) := '9';
    v_pwdarr(17) := 'p';
    v_pwdarr(18) := '7';
    v_pwdarr(19) := 'e';
    v_pwdarr(20) := 'w';
    v_pwdarr(21) := 'r';
    v_pwdarr(22) := 's';
    v_pwdarr(23) := 'a';
    v_pwdarr(24) := 'g';
    v_pwdarr(25) := 'h';
    v_pwdarr(26) := 'l';
    v_pwdarr(27) := '7';
    v_pwdarr(28) := '6';
    v_pwdarr(29) := 'z';
    v_pwdarr(30) := '1';
    v_pwdarr(31) := '4';
    v_pwdarr(32) := '5';
    v_pwdarr(33) := '8';
    v_pwdarr(34) := 'c';
    v_pwdarr(35) := 'f';
    v_pwdarr(36) := 'i';
    v_pwdarr(37) := 't';
    v_pwdarr(38) := 'u';
    v_pwdarr(39) := 'v';
    while v_j < i_len loop
      v_rndno4       := trunc(dbms_random.value(1, 39));
      v_cardpassword := v_cardpassword || v_pwdarr(v_rndno4);
      v_j            := v_j + 1;
    end loop;
    return v_cardpassword;
  end FQ_Random_Str;

  function FQ_Str_Unit_Old
  /*****************************************************************
        Procedure Name :fq_str_Unit
        Purpose: 转化以万为单位的金额
        Edit: 2007-10-07 add by  小沈
    ****************************************************************/
  (I_Money In Varchar2 --数字
   ) return varchar2 --返回
   is
    v_money      number := 0;
    v_mod        number; --余数
    v_RMoney     varchar2(1000);
    v_money_tmep number := 0;
    v_unit       varchar(50) := '万亿';
    v_unit_temp  varchar(10);
    v_i          number;
  begin
    ---判断是否为数字
    if p_base_fun.fq_is_number(I_Money) = 0 then
      return I_Money;
    end if;
  
    v_money := I_Money;
    if v_money < 10000 then
      return v_money;
    end if;
    v_money := trunc(v_money);
  
    if v_money >= 10000 then
      v_mod   := mod(v_money, 10000);
      v_money := trunc(v_money / 10000);
      v_i     := 1;
      while v_i <= 2 loop
      
        v_money_tmep := substr(v_money, -4);
        v_unit_temp  := substr(v_unit, v_i, 1);
      
        --如果无法截取 则默认金额显示
        if v_money_tmep is null then
          v_money_tmep := v_money;
          v_RMoney     := v_money_tmep || v_unit_temp || v_RMoney;
          exit;
        end if;
      
        v_RMoney := v_money_tmep || v_unit_temp || v_RMoney;
      
        /*v_money := substr(v_money, 1, instr(v_money, v_money_tmep) - 1);*/
        v_money := substr(v_money,
                          0,
                          instr(v_money, substr(v_money, -4)) - 1);
        --当剩余金额为空则推出
        exit when v_money is null;
      
        v_i := v_i + 1;
      end loop;
    
      Dbms_Output.put_line(v_RMoney);
    end if;
  
    if v_mod > 0 then
      return v_RMoney || to_char(v_mod, 'fm0000');
    else
      return v_RMoney;
    end if;
  
  EXCEPTION
    WHEN OTHERS THEN
      return '0';
  end FQ_Str_Unit_Old;

  function FQ_Str_Unit
  /*****************************************************************
        Procedure Name :fq_str_Unit
        Purpose: 转化以万为单位的金额
        Edit: 2007-12-10 add by  小沈
    ****************************************************************/
  (I_Money In Varchar2 --数字
   ) return varchar2 --返回
   is
    v_length number := 0;
    -- type type_array is varray(10) of varchar2(20);
    /*   1、varray(10)表示定义长度为10的数组
    2、varchar2(20)表示数组为字符型，且元素字符串长度不超过20*/
  
    type type_array is table of varchar2(20) index by binary_integer;
    /* 定义可变长度的一维数组   */
  
    var_array type_array;
    /*初始化为空数组*/
  
    v_Money  varchar2(50);
    v_RMoney varchar2(1000);
  
  begin
    ---判断是否为数字
    if p_base_fun.fq_is_number(I_Money) = 0 then
      return I_Money;
    end if;
  
    if to_number(I_Money) < 10000 then
      return I_Money;
    end if;
  
    v_length := ceil(length(I_Money) / 4);
    v_Money  := I_Money;
    /*通过遍历数组元素方式进行初始化操作*/
    for i in 1 .. v_length loop
    
      if length(v_Money) <= 4 then
        var_array(i) := v_Money;
      else
        var_array(i) := substr(v_Money, -4);
        v_Money := substr(v_Money, 1, length(v_Money) - 4);
      end if;
    
    end loop;
  
    for i in 1 .. var_array.count loop
    
      case i
        when 1 then
          if to_number(var_array(i)) > 0 then
            v_RMoney := to_number(var_array(i), 'fm9999');
          end if;
        
        when 2 then
          if to_number(var_array(i)) > 0 then
            if v_RMoney is null then
              v_RMoney := to_number(var_array(i), 'fm9999') || '万';
            else
              v_RMoney := to_number(var_array(i), 'fm9999') || '万' ||
                          v_RMoney;
            end if;
          end if;
        else
          --if to_number(var_array(i)) > 0 then
          if instr(v_RMoney, '亿') <= 0 or v_RMoney is null then
            v_RMoney := var_array(i) || '亿' || v_RMoney;
          else
            v_RMoney := var_array(i) || v_RMoney;
          end if;
          --end if;
      end case;
    
    end loop;
  
    return v_RMoney;
  
  exception
    when others then
      return I_Money;
  end FQ_Str_Unit;

  function FQ_Is_Number
  /*****************************************************************
        Procedure Name :FQ_Is_Number
        Purpose: 是否为数字 0:否 1：是
        Edit: 2007-10-07 add by  小沈
    ****************************************************************/
  (I_Str Varchar2) return Number is
    v_num number;
  begin
    v_num := to_number(I_Str);
    return 1;
  exception
    when others then
      return 0;
  end FQ_Is_Number;

  function FQ_MonetaryUnit
  /*****************************************************************
    过程名称：显示货币单位
    创建日期：2018-03-21 add by 小沈
    返回：
    ****************************************************************/
  (I_Money In Number, --传入金额
   I_Type  In Number --显示类型 0 :普通显示小数位2位补0 1：已万亿单位显示  2:没有小数点
   ) return varchar2 --返回级别
   is
    v_str   varchar2(200) := '';
    v_money number;
  begin
  
    if I_Money is null or I_Money = 0 then
      return v_str;
    end if;
  
    if I_Type = 0 then
      v_str := p_base_fun.fq_strround(i_num => I_Money, i_type => 1);
      return v_str;
    end if;
  
    if I_Type = 1 then
      --如果传入金额大于等于1千万 按亿为单位  --  trunc(I_Money / 100000000, 2);   || '亿';
      if I_Money >= 10000000 then
        v_money := trunc(I_Money / 10000, 2);
        v_str   := p_base_fun.fq_strround(i_num => v_money) || '万';
        return v_str;
      end if;
    
      --大于等于1万 按万为单位
      if I_Money >= 10000 then
        v_money := trunc(I_Money / 10000, 0);
        v_str   := p_base_fun.fq_strround(i_num => v_money) || '万';
        return v_str;
      end if;
    
      v_str := p_base_fun.fq_strround(i_num => I_Money, i_type => 2);
      return v_str;
    
    end if;
  
    if I_Type = 2 then
      v_str := p_base_fun.fq_strround(i_num => I_Money, i_type => 2);
      return v_str;
    end if;
  
    --其余按普通显示
    v_str := p_base_fun.fq_strround(i_num => I_Money, i_type => 1);
    return v_str;
  
  exception
    when others then
      return v_str;
  end FQ_MonetaryUnit;

  function FQ_MonetaryUnit
  /*****************************************************************
    过程名称：显示货币单位
    创建日期：2018-03-21 add by 小沈
    返回：
    ****************************************************************/
  (I_Money In Number, --传入金额
   I_Type  In Number, --显示类型 0 :普通显示小数位2位补0 1：已万亿单位显示  2:没有小数点
   I_From  In Number --1:列表 2：详情
   ) return varchar2 --返回级别
   is
    v_str   varchar2(200) := '';
    v_money number;
  begin
  
    if I_Money is null or I_Money = 0 then
      return v_str;
    end if;
  
    if I_Type = 0 then
      v_str := p_base_fun.fq_strround(i_num => I_Money, i_type => 1);
      return v_str;
    end if;
  
    if I_Type = 1 then
      --如果传入金额大于等于1千万 按亿为单位  --  trunc(I_Money / 100000000, 2);   || '亿';
      if I_Money >= 10000000 then
        if I_From = 1 then
          v_money := trunc(I_Money / 10000, 0);
        else
          v_money := trunc(I_Money / 10000, 2);
        end if;
        v_str := p_base_fun.fq_strround(i_num => v_money) || '万';
        return v_str;
      end if;
    
      --大于等于1万 按万为单位
      if I_Money >= 10000 then
        if I_From = 1 then
          v_money := trunc(I_Money / 10000, 0);
        else
          v_money := trunc(I_Money / 10000, 2);
        end if;
        v_str := p_base_fun.fq_strround(i_num => v_money, i_type => 2) || '万';
        return v_str;
      end if;
    
      v_str := p_base_fun.fq_strround(i_num => I_Money, i_type => 2);
      return v_str;
    
    end if;
  
    if I_Type = 2 then
      v_str := p_base_fun.fq_strround(i_num => I_Money, i_type => 2);
      return v_str;
    end if;
  
    --其余按普通显示
    v_str := p_base_fun.fq_strround(i_num => I_Money, i_type => 1);
    return v_str;
  
  exception
    when others then
      return v_str;
  end FQ_MonetaryUnit;

end P_Base_Fun;
/


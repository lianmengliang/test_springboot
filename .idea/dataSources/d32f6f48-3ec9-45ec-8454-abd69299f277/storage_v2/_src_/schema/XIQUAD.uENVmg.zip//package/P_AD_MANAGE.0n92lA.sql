create package P_AD_Manage is

  TYPE T_CURSOR IS REF CURSOR;

  /*广告信息添加*/

  procedure pq_AD_List
  /*****************************************************************
        Procedure Name :pq_AD_List
        Purpose: 广告列表
        Edit: 2016-12-05 add by 小沈
    ****************************************************************/
  (I_AdmInId        In Varchar2,
   I_ADID           In Number,
   I_ADName         In Varchar2,
   I_Status         In Number,
   I_ShowType       In Number,
   I_PhoneType      In Number,
   I_ADType         In Number,
   I_PageSize       In Number,
   I_PageNO         In Number,
   O_OutRecordCount Out Number,
   O_OutCursor      Out t_cursor, --返回游标
   O_Result         Out Number,
   O_Message        Out Varchar2);

  procedure pq_AD_Info
  /*****************************************************************
        Procedure Name :pq_AD_Info
        Purpose: 广告信息
        Edit: 2016-12-05 add by 小沈
    ****************************************************************/
  (I_AdminID   in varchar2,
   I_ADID      in Number,
   O_OutCursor OUT t_cursor, --返回游标
   O_Result    Out number,
   O_Message   Out varchar2);

  procedure pw_AD_Add
  /*****************************************************************
        Procedure Name :pw_AD_Add
        Purpose: 广告增加
        Edit: 2016-12-05 add by 小沈
    ****************************************************************/
  (I_AdminID       In Varchar2,
   I_Title         In Varchar2, -- 广告名称[内部使用]
   I_ADName        In Varchar2, --   前台显示广告名称
   I_Money         In Number, --  奖励总金额
   I_Intro         In Varchar2, --   广告简介
   I_Status        In Number, --   投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放）
   I_ShowType      In Number, --   0不显示，1显示
   I_StartTime     In Varchar2, --广告投放时间
   I_StopTime      In Varchar2, --停止投放时间
   I_PhoneType     In Number, --   1、ios，  2、安卓， 3、ios和安卓都显示
   I_ADType        In Number, --   广告类型（1游戏，2应用，3其他）
   I_APPSize       In Varchar2, --   文件大小
   I_ImgURL        In Varchar2, --   广告小图片地址
   I_Description   In Varchar2, --   广告介绍描述
   I_DesImgUrls    In Varchar2, --   广告图片描述 
   I_ADLink        In Varchar2, --   安卓广告地址
   I_PageName      In Varchar2, --   安卓应用的包名称
   I_IOSADLink     In Varchar2, --   IOS广告地址
   I_IOSPageName   In Varchar2, --   IOS应用程序名称 BoundleId
   I_IOSURLSchemes In Varchar2, --   IOS用于打开APP应用的 URL Schemes
   I_IOSPROName    In Varchar2, --   IOS 进程名称 ProcessName
   I_IOSVersion    In Varchar2, --   IOS应用版本号
   I_IOSKEYWord    In Varchar2, --   搜索关键字
   I_IOSRank       In Number, --   关键字在appstore排位
   I_APPSign       In Number, --   绑定方式 0、下载绑定 1、账号返回 2、自助提交  3、下载安装返回
   I_ButtonShow    In Number, --   下载按钮和进度条是否显示（1显示，0不显示）
   I_ButtonName    In Varchar2, --   试玩按钮名称
   I_ShowOrder     In Number, --  排序号
   I_MSGNOInstall  In Varchar2, --   未安装提示-无需下载app则提示和未注册一致
   I_MSGNoReg      In Varchar2, --   未注册提示
   I_MsgReg        In Varchar2, --   已注册提示
   I_MSGDayLimit   In Varchar2, --  日限量提示信息
   I_MSGAllLimit   In Varchar2, --  到量提示信息
   I_ISRECOMMEND   In Number, --  是否推荐该广告 1：推荐 0：不推荐
   I_RecommendSn   In Number, -- 推荐排序
   I_ISEASY        In Number, --  是否为简单广告 1：是 0：否
   O_Result        Out number,
   O_Message       Out varchar2);

  procedure pw_AD_Edit
  /*****************************************************************
        Procedure Name :pw_AD_Edit
        Purpose: 广告修改
        Edit: 2016-12-05 add by 小沈
    ****************************************************************/
  (I_AdminID       In Varchar2,
   I_ADID          In Number, --  广告ID
   I_Title         In Varchar2, -- 广告名称[内部使用]
   I_ADName        In Varchar2, --   前台显示广告名称
   I_Money         In Number, --  奖励总金额
   I_Intro         In Varchar2, --   广告简介
   I_Status        In Number, --   投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放）
   I_ShowType      In Number, --   0不显示，1显示
   I_StartTime     In Varchar2, --广告投放时间
   I_StopTime      In Varchar2, --停止投放时间
   I_PhoneType     In Number, --   1、ios，  2、安卓， 3、ios和安卓都显示
   I_ADType        In Number, --   广告类型（1游戏，2应用，3其他）
   I_APPSize       In Varchar2, --   文件大小
   I_ImgURL        In Varchar2, --   广告小图片地址
   I_Description   In Varchar2, --   广告介绍描述
   I_DesImgUrls    In Varchar2, --   广告图片描述 
   I_ADLink        In Varchar2, --   安卓广告地址
   I_PageName      In Varchar2, --   安卓应用的包名称
   I_IOSADLink     In Varchar2, --   IOS广告地址
   I_IOSPageName   In Varchar2, --   IOS应用程序名称 BoundleId
   I_IOSURLSchemes In Varchar2, --   IOS用于打开APP应用的 URL Schemes
   I_IOSPROName    In Varchar2, --   IOS 进程名称 ProcessName
   I_IOSVersion    In Varchar2, --   IOS应用版本号
   I_IOSKEYWord    In Varchar2, --   搜索关键字
   I_IOSRank       In Number, --   关键字在appstore排位
   I_APPSign       In Number, --   绑定方式 0、下载绑定 1、账号返回 2、自助提交  3、下载安装返回
   I_ButtonShow    In Number, --   下载按钮和进度条是否显示（1显示，0不显示）
   I_ButtonName    In Varchar2, --   试玩按钮名称
   I_ShowOrder     In Number, --  排序号
   I_MSGNOInstall  In Varchar2, --   未安装提示-无需下载app则提示和未注册一致
   I_MSGNoReg      In Varchar2, --   未注册提示
   I_MsgReg        In Varchar2, --   已注册提示
   I_MSGDayLimit   In Varchar2, --  日限量提示信息
   I_MSGAllLimit   In Varchar2, --  到量提示信息
   I_ISRECOMMEND   In Number, --  是否推荐该广告 1：推荐 0：不推荐
   I_RecommendSn   In Number, -- 推荐排序
   I_ISEASY        In Number, --  是否为简单广告 1：是 0：否
   O_Result        Out number,
   O_Message       Out varchar2);

  procedure pq_Award_List
  /*****************************************************************
        Procedure Name :pq_Award_List
        Purpose: 获取广告渠道应用的奖励设置 ---此入口进入奖励设置明细
        Edit: 2016-12-05 add by 小沈
    ****************************************************************/
  (I_AdminID   In Varchar2,
   I_ADID      In Number,
   I_APPID     In Number, --   渠道应用编号 0为默认 
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out number,
   O_Message   Out varchar2);

  procedure pq_Award_Info
  /*****************************************************************
        Procedure Name :pq_AD_INFO
        Purpose: 获取广告渠道应用的具体奖励设置
        Edit: 2016-12-05 add by 小沈
    ****************************************************************/
  (I_AdminID   In Varchar2,
   I_ADID      In Number,
   I_APPID     In Number, --   渠道应用编号 0为默认 
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out number,
   O_Message   Out varchar2);

  procedure pw_Award_Set
  /*****************************************************************
    Procedure Name: GW_AD_AwardTypeIN
    Purpose: 广告奖励设置录入
    Edit: 2017-02-15 add by 小沈 
    Comment:
    ****************************************************************/
  (I_AdminID         In Varchar2, --管理员ID
   I_ADID            In Number, --   广告ID
   I_APPID           In Number, --   渠道应用编号 0为默认 
   I_Type_List       In Varchar2, --   类型（1单次奖励，2循环奖励）
   I_Dlevel_List     In Varchar2, --   奖励级别
   I_Event_List      In Varchar2, --  奖励说明
   I_NeedLevel_List  In Varchar2, --  要求游戏等级（时间、积分)； 如果奖励类型为 3 则为充值的返现比例值 （如 充值返20% 则写20） 
   I_Times_List      In Varchar2, --  限制奖励次数
   I_Atype_List      In Varchar2, --  奖励类型：1-注册 ; 2-等级/首冲固定奖励 ; 3-充值理财百分比奖励
   I_AwardGroup_List In Varchar2, --   奖励组别，根据不同广告有自己的组别（大于90表是同组中只能获得其中1个奖励）
   I_GroupName_List  In Varchar2, --  组别说明 同一类奖励需分组
   I_PlaySecond_List In Varchar2, --  所需要体验时间 单位秒 
   I_Price_List      In Varchar2, --  单价
   I_AMoney_List     In Varchar2, --   奖励金额
   O_Result          Out Number,
   O_Message         Out Varchar2);

  procedure pq_DownUrlList
  /*****************************************************************
        Procedure Name :pq_DownUrlList
        Purpose: 下载地址列表
        Edit: 2017-02-16 add by 小沈
    ****************************************************************/
  (I_AdminID        In Varchar2, --管理员ID
   I_ADID           In Number, --   广告ID
   I_PageSize       In Number,
   I_PageNO         In Number,
   O_OutRecordCount Out Number,
   O_OutCursor      Out t_cursor, --返回游标
   O_Result         Out Number,
   O_Message        Out Varchar2);

  procedure pq_DownUrlInfo
  /*****************************************************************
        Procedure Name :pq_DownUrlInfo
        Purpose: 获取下载地址信息
        Edit: 2017-02-16 add by 小沈
    ****************************************************************/
  (I_AdminID   In Varchar2, --管理员ID
   I_UrlID     In Number, --下载编号 
   O_OUTCURSOR OUT T_CURSOR, --返回游标
   O_Result    Out number,
   O_Message   Out varchar2);

  procedure pw_DownUrlSet
  /*****************************************************************
        Procedure Name :pw_DownUrlSet
        Purpose:下载地址添加、修改
        Edit: 2017-02-16 add by 小沈
    ****************************************************************/
  (I_AdminID   In Varchar2, --管理员ID
   I_ADID      In Number, --   广告ID
   I_UrlID     In Number, --下载编号  
   I_APPUrl    In Varchar2, --app下载链接 注册地址
   I_PhoneType In Number, --1、ios，  2、安卓， 3、ios和安卓
   I_DayFlux   In Number, --日流量控制（默认-1不限制）
   I_AllFlux   In Number, --总流量控制（默认-1不限制）
   I_FluxTime  In Varchar2, --到量后，第二天开始投放时间 
   I_Status    In Number, --状态（0未使用，1正常使用，2日到量，3总到量，4停止使用）
   I_Marketer  In Varchar2, -- 市场人员姓名
   I_Customer  In Varchar2, -- 商家名称 
   I_DownType  In Number, --下载方式（0直接下载，1外部浏览器打开）
   O_Result    Out number,
   O_Message   Out varchar2);

  PROCEDURE pw_Award_MultSet
  /*****************************************************************
        Procedure Name :pw_Award_MultSet
        Purpose: 根据测试渠道奖励设置批量添加奖励
        Edit: 2017-03-22 add by 小胡
    ****************************************************************/
  (I_AdminID  In Varchar2, --管理员ID
   I_ADID     In Number, --广告ID 
   I_APPID    In Number, -- 渠道商ID  (暂时不起作用)
   I_ForCeShi In Number, --完全复制测试渠道添加，1表示是，0表示不是
   O_Result   Out number,
   O_Message  Out varchar2);

  PROCEDURE pw_Award_Delete
  /*****************************************************************
        Procedure Name :pw_Award_Delete
        Purpose: 删除指定广告的指定渠道奖励
        Edit: 2017-04-23 add by 小胡
    ****************************************************************/
  (I_AdminID In Varchar2, --管理员ID
   I_ADID    In Number, --广告ID  
   I_APPID   In Number, --渠道商ID
   O_Result  Out number,
   O_Message Out varchar2);

  PROCEDURE pq_Channel_AdList
  /*****************************************************************
        Procedure Name :pq_Channel_AdList_
        Purpose: 获取所有在投广告列表
        Edit: 2017-04-24 add by 小胡
    ****************************************************************/
  (I_AdminID   In Varchar2, --管理员ID
   I_APPID     In Number, --渠道商ID
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out number,
   O_Message   Out varchar2);

  PROCEDURE pw_Channel_AdJoin
  /*****************************************************************
        Procedure Name :pw_channel_adjoin
        Purpose: 渠道添加广告
        Edit: 2018-04-25 add by 小胡
    ****************************************************************/
  (I_AdminId  in varchar2, --管理员id
   I_APPID    in number, --渠道商应用ID字符串
   I_ADID     In varchar2, --  广告ID
   I_ForCeShi In Number, --完全根据测试渠道添加，1表示是，0表示不是
   O_Result   out number, --返回（0正确，其他为提示或错误）
   O_Message  out varchar2 --返回信息（操作结果，成功或者错误信息）
   );

  procedure pq_Ad_BannerList
  /*****************************************************************
    Procedure Name:pq_Ad_BannerList 
    Purpose: 查询Banner图
    Edit: 2018-04-28 add by 小胡
    ****************************************************************/
  (I_ADMINID   In Varchar2,
   I_ADID      In Number,
   I_ADNAME    In Varchar2,
   I_STATUS    In Number,
   I_PhoneType In Number,
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure pw_Ad_AddBanner
  /*****************************************************************
    Procedure Name: 添加Banner图
    ****************************************************************/
  (I_ADMINID   In Varchar2, --管理员id
   I_ADID      In Number, --广告Id
   I_ADNAME    In Varchar2, --广告名称
   I_IMGURL    In Varchar2, --Banner图存储路径
   I_STATUS    In Number, --状态 0：未开启 1：正常 2：关闭
   I_PHONETYPE In Number, --应用类型 1、ios，  2、安卓， 3、ios和安卓都显示
   I_ADTYPE    In Number, --广告类型 1：普通广告 2：关注广告
   I_STIME     In Varchar2, --Banner投放开始时间
   I_ETIME     In Varchar2, --Banner停止投放时间
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure pw_AD_EditBanner
  /*****************************************************************
    Procedure Name: 编辑Banner图
    ****************************************************************/
  (I_ID        In Varchar2, --Banner图id
   I_ADMINID   In Varchar2, --管理员id
   I_ADID      In Number, --广告Id
   I_ADNAME    In Varchar2, --广告名称
   I_IMGURL    In Varchar2, --Banner图存储路径
   I_STATUS    In Number, --状态 0：未开启 1：正常 2：关闭
   I_PHONETYPE In Number, --应用类型 1、ios，  2、安卓， 3、ios和安卓都显示
   I_ADTYPE    In Number, --广告类型 1：普通广告 2：关注广告
   I_STIME     In Varchar2, --Banner投放开始时间
   I_ETIME     In Varchar2, --Banner停止投放时间
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure pq_AD_GetBanner
  /*****************************************************************
    Procedure Name: 查询Banner图
    ****************************************************************/
  (I_ADMINID   In Varchar2, --管理员id
   I_ID        In Varchar2, --Banner图id
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure pw_Ad_DeleteBanner
  /*****************************************************************
    Procedure Name: 删除Banner图
    ****************************************************************/
  (I_ADMINID  In Varchar2, --管理员用户名
   I_BannerID In Number, --ID
   O_Result   Out Number,
   O_Message  Out Varchar2);
  procedure pw_ad_SetRecAD
  /*****************************************************************
        Procedure Name :pq_AD_List
        Purpose: 设置推荐广告
        Edit: 2018-8-21 add by 小胡
    ****************************************************************/
  (I_AdmInId In Varchar2, --管理员id
   I_ADIDS   In Varchar2, --广告id列表
   I_ISREC   In Number, --是否推荐 是否推荐广告，0：不推荐，1：推荐
   O_Result  Out Number,
   O_Message Out Varchar2);

  procedure pq_AD_RecList
  /*****************************************************************
        Procedure Name :pq_AD_List
        Purpose: 广告推荐列表
        Edit: 2018-8-21 add by 小胡
    ****************************************************************/
  (I_AdmInId        In Varchar2, --管理员id
   I_ADID           In Number, --广告id
   I_ADName         In Varchar2, --广告名称
   I_Status         In Number, --广告状态
   I_ShowType       In Number, --显示状态 0不显示，1显示
   I_PhoneType      In Number, --显示设备 1、ios，  2、安卓， 3、ios和安卓都显示
   I_IsRecommend    In Number, -- 是否推荐广告，0：不推荐，1：推荐
   I_PageSize       In Number,
   I_PageNO         In Number,
   O_OutRecordCount Out Number,
   O_OutCursor      Out t_cursor, --返回游标
   O_Result         Out Number,
   O_Message        Out Varchar2);

  Function FQ_ADMarketer
  /*****************************************************************
        Procedure Name :FQ_ADMarketer
        Purpose: 根据广告查询市场人员
        Edit: 2018-04-28 add by 小沈
    ****************************************************************/
  (I_ADID In Number --广告ID 
   ) Return Varchar2;
  procedure PQ_AwardOrderList
  /*****************************************************************
        Procedure Name :PQ_AwardOrderList
        Purpose: 奖励订单列表
        Edit: 2018-10-30 add by 小胡
    ****************************************************************/
  (I_AdmInId   In Varchar2, --管理员id
   I_ADID      In Number, --广告id
   I_APPID     In Varchar2, --渠道名称
   I_STATUS    In Number, --订单状态
   I_ORDERNUM  In Varchar2, --订单号
   I_PageSize  In Number,
   I_PageNO    In Number,
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2);
  procedure PQ_AwardOrderCheck
  /*****************************************************************
        Procedure Name :PQ_AwardOrderCheck
        Purpose: 奖励订单审核
        Edit: 2018-11-01 add by 小胡
    ****************************************************************/
  (I_AdmInId  In Varchar2, --管理员id
   I_ORDERNUM In Varchar2, --订单编号
   I_STATUS   In Number, --订单状态
   I_ADID     In Varchar2,
   I_APPID    In Varchar2,
   O_Result   Out Number,
   O_Message  Out Varchar2);
  /*  procedure PQ_Syncad
  \*****************************************************************
        Procedure Name :PQ_syncad
        Purpose: 同步闲玩广告
        Edit: 2019-05-29 add by 小刘
    ****************************************************************\
  (I_AdmInId In Varchar2, --管理员id
   I_ADID    In Varchar2,
   O_Result  Out Number,
   O_Message Out Varchar2);*/
end P_AD_Manage;
/


create PACKAGE BODY P_AD_List_V3 AS

  /*
  广告列表显示_3.0版本 --增加IP 限制判断
  2018-09-17
  */

  procedure PQ_List
  /*****************************************************************
        Procedure Name :PQ_ListH5
        Purpose: 获取广告列表
        Edit: 2018-03-27 add by 小沈
    ****************************************************************/
  (I_APPId          In Number, --渠道应用ID
   I_Deviceid       In Varchar2, --设备号ID
   I_SIMID          In Varchar2, --sim卡编号
   I_Userid         In Number, --闲玩用户编号
   I_PType          In Number, --1、ios  2、安卓
   I_UType          In Number, --用户需要状态 0：全部 1：正在参与
   I_IP             In Varchar2, --用户当前IP
   I_IP_Num         In Number, --用户当前IP 数字化
   I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始
   O_Outrecordcount Out Number, --返回总记录数
   O_Outcursor      Out t_cursor, --返回游标
   O_Result         Out Number, --判断 0：查询成功，其他：出错
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n         number;
    v_unit      varchar2(50); --货币单位描述 默认元
    V_SQL       varchar2(3000);
    V_SQL_Where varchar2(100) := ''; --条件语句
    V_HeiRowNUM number; --小于第几行 分页用
    V_LowRowNUM number; --大于第几行 分页用
    V_SQLSelect varchar2(2000);
    v_PageSize  number;
    v_PageNO    number;
    v_DeviceId  varchar2(100);
  
    v_result  number;
    v_message varchar2(100);
  begin
    O_Result  := 0;
    O_Message := '查询成功';
    --去空格处理
    v_DeviceId := fq_str_delspace(i_str => I_Deviceid);
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
    v_PageSize := I_PageSize;
    v_PageNO   := I_PageNO;
  
    if I_PageSize is null then
      O_Result  := 1;
      O_Message := '记录数不能为空';
      return;
    end if;
  
    if I_PageNO is null then
      O_Result  := 1;
      O_Message := '页数不能为空';
      return;
    end if;
  
    if I_Userid is null or I_Userid = 0 then
      O_Result  := 1;
      O_Message := '请先登录APP';
      return;
    end if;
  
    --设备号校验是否合法 0否 1是
    if p_base_fun.fq_deviceid_check(v_DeviceId, I_PType) = 0 then
      O_Result  := 1;
      O_Message := '请先对APP进行授权';
      return;
    end if;
  
    if v_DeviceId is null then
      O_Result  := 1;
      O_Message := '需要先对APP进行授权';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_channel
     where appid = I_APPId
       and status != 2;
  
    if v_n <= 0 then
      O_Result  := 1;
      O_Message := '渠道信息不存在';
      return;
    end if;
  
    select unit
      into v_unit
      from ad_channel
     where appid = I_APPId
       and status != 2;
  
    if I_UType = 1 then
      V_SQL_Where := '  and  UStatus in (2,3)   ';
    end if;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
    V_SQLSelect := 'select adid,adname,status,  money, intro, pagename,adtypedes , appsize, imgurl, adlink, showorder,to_char(stoptime,''yyyy-mm-dd'') stoptime,P_AD_IsShow_List.fq_isshow(adid,' ||
                   I_APPId || ', ''' || v_DeviceId || ''',' || I_Userid ||
                   ',''' || I_IP || ''',' || I_IP_Num || ',' || I_PType ||
                   ') isshow  from ad_adinfo where status in(1,2,3)
                   and phonetype in (' || I_PType ||
                   ',3) ';
  
    V_SQLSelect := '  select adid,adname,status,  money, intro, pagename,adtypedes , appsize,  imgurl, adlink, showorder, stoptime,isshow from ( ' ||
                   V_SQLSelect || ')   where  isshow=1 ';
  
    V_SQLSelect := 'select   adid,adname,status, money, intro, pagename,adtypedes ,  appsize, imgurl, adlink, showorder,stoptime,
       P_AD_ShowMoney_List.fq_userid(adid,' || I_APPId ||
                   ', status,''' || v_DeviceId || ''',' || I_Userid || ',' ||
                   I_PType || ') MoneyMsg from
       (' || V_SQLSelect || ' )   ';
  
    V_SQLSelect := '  select   adid,adname,status, money, intro, pagename ,adtypedes,  appsize, imgurl, adlink, showorder,stoptime,substr(MoneyMsg,0,instr(MoneyMsg,''_'')-1) UStatus,substr(MoneyMsg,instr(MoneyMsg,''_'')+1) ShowMoney  from
  ( ' || V_SQLSelect || '  ) where  MoneyMsg!=''123'' ';
  
    V_SQLSelect := 'select   adid,adname,status, money, intro, pagename,adtypedes ,  appsize, imgurl, adlink, showorder,stoptime,UStatus,ShowMoney,P_AD_List_V3.FQ_Sorting(status,UStatus) Sorting from ( ' ||
                   V_SQLSelect || ' )  where 1=1  ' || V_SQL_Where;
    --where UStatus!=2 当天无法拿到奖励则不显示
  
    ----执行分页查询
    V_HeiRowNUM := v_PageNO * v_PageSize;
    V_LowROWNUM := V_HeiRowNUM - v_PageSize + 1;
  
    execute immediate 'select count(1) from (' || V_SQLSelect || ')'
      into O_Outrecordcount;
    --regexp_substr(ShowMoney,''[0-9.0-9]+'') ShowMoney 只允许数字
    V_SQLSelect := 'select  adid,adname,status, money, intro, pagename,adtypedes , appsize, imgurl, adlink, showorder,stoptime,UStatus,ShowMoney,Sorting from (' ||
                   V_SQLSelect || ') order by Sorting desc,showorder asc ';
  
    V_SQL := ' select   adid,adname, intro, appsize,adtypedes,  imgurl, adlink ,stoptime, UStatus,  ShowMoney ,regexp_substr(ShowMoney,''[0-9.0-9.万.亿]+'') ShowMoney2,  unit   from (
     select    adid,adname, money, intro, pagename ,adtypedes,  appsize, imgurl, adlink ,ShowMoney, ''' ||
             v_unit ||
             ''' unit , UStatus,Sorting ,stoptime,rownum rn from (  ' ||
             V_SQLSelect || ') a where rownum <=' || to_char(V_HeiRowNUM) ||
             ') b where  rn >= ' || to_char(V_LowROWNUM) || ' ';
    --注意对rownum别名的使用,第一次直接用rownum,第二次一定要用别名rn
    --- order by 放里面会影响速度
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    OPEN O_OUTCURSOR FOR V_SQL;
    commit;
    return;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '查询失败';
      return;
  end PQ_List;

  Function FQ_Sorting
  /*****************************************************************
        Procedure Name :FQ_Sorting
        Purpose: 判断试玩赚钱广告列表 排序
        Edit: 2017-02-18 add by 小沈
    ****************************************************************/
  (I_ADStatus In Number, --投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放）
   I_UStatus  In Number --用户当前状态 0 表示未绑定 1表示用户已绑定但是无追加奖励 2表示为用户已绑定并有追加奖励  3表示为用户仅绑定
   ) Return Number As
  
    v_Sorting number;
  
  begin
    v_Sorting := 0;
  
    --未绑定广告正常
    if I_UStatus = 0 and I_ADStatus = 1 then
      v_Sorting := 3;
      return v_Sorting;
    end if;
  
    if I_UStatus = 3 then
      v_Sorting := 2;
      return v_Sorting;
    end if;
  
    --用户有追加奖励
    if I_UStatus = 2 then
      v_Sorting := 1;
      return v_Sorting;
    end if;
  
    if I_UStatus = 1 then
      v_Sorting := 0;
      return v_Sorting;
    end if;
  
    if I_ADStatus in (2, 3, 4) and I_UStatus = 0 then
      v_Sorting := -1;
      return v_Sorting;
    end if;
  
    return 0;
  exception
    --失败
    when others then
      rollback;
      return 0;
  end FQ_Sorting;

  procedure PQ_List_RandomAD
  /*****************************************************************
        Procedure Name :PQ_List_RandomAD
        Purpose: 获取随机广告
        Edit: 2018-09-17  add by 小沈
    ****************************************************************/
  (I_APPId     In Number, --渠道应用ID
   I_Deviceid  In Varchar2, --设备号ID
   I_SIMID     In Varchar2, --sim卡编号
   I_PType     In Number, --1、ios  2、安卓
   I_IP        In Varchar2, --用户当前IP
   I_IP_Num    In Number, --用户当前IP 数字化
   I_Userid    In Number, --闲玩用户编号
   I_Count     In Number, --获取随机广告的数量
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number, --判断 0：查询成功，其他：出错
   O_Message   Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n        number;
    v_unit     varchar2(50); --货币单位描述 默认元
    v_SQL      varchar2(4000);
    v_DeviceId varchar2(100); --用户设备号
    v_count    number;
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    --去空格处理
    v_DeviceId := fq_str_delspace(i_str => I_Deviceid);
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
    commit;
  
    --参数判断
    if I_Userid is null or I_Userid = 0 then
      O_Result  := 1;
      O_Message := '请先登录APP';
      return;
    end if;
  
    --设备号校验是否合法 0否 1是
    if p_base_fun.fq_deviceid_check(v_DeviceId, I_PType) = 0 then
      O_Result  := 1;
      O_Message := '请先对APP进行授权';
      return;
    end if;
  
    if v_DeviceId is null then
      O_Result  := 1;
      O_Message := '需要先对APP进行授权';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_channel
     where appid = I_APPId
       and status != 2;
  
    if v_n <= 0 then
      O_Result  := 1;
      O_Message := '渠道信息不存在';
      return;
    end if;
  
    if I_Count is null or I_Count <= 0 then
      v_count := 4;
    else
      v_count := I_Count;
    end if;
  
    select unit
      into v_unit
      from ad_channel
     where appid = I_APPId
       and status != 2;
  
    v_SQL := 'select adid,adname,imgurl,adlink,status from ad_adinfo where status in（1,2,3）and isrecommend=1 and phonetype in (' ||
             I_PType || ',3)';
    V_SQL := 'select  adid,adname, imgurl, adlink,
       P_AD_ShowMoney_List.fq_userid_list(adid,' || I_APPId ||
             ', status,''' || v_DeviceId || ''',' || I_Userid || ',' ||
             I_PType || ') MoneyMsg from
       (' || V_SQL ||
             ' ) where  P_AD_IsShow_List.fq_isshow(adid,' || I_APPId ||
             ', ''' || v_DeviceId || ''',' || I_Userid || ',''' || I_IP ||
             ''',' || I_IP_Num || ',' || I_PType || ')=1';
    V_SQL := '  select   adid,adname, imgurl, adlink, substr(MoneyMsg,instr(MoneyMsg,''_'')+1) ShowMoney  from
  ( ' || V_SQL || '  )';
  
    v_SQL := ' select adid,adname, imgurl, adlink,ShowMoney  from (' ||
             v_SQL || ') order by dbms_random.random';
  
    v_SQL := 'select adid,adname, imgurl, adlink,ShowMoney  from (' ||
             v_SQL || ') where rownum<= ' || v_count;
  
    V_SQL := ' select   adid,adname,  imgurl, adlink ,   ShowMoney ,regexp_substr(ShowMoney,''[0-9.0-9.万.亿]+'') ShowMoney2,  unit   from (
     select    adid,adname,  imgurl, adlink ,ShowMoney, ''' ||
             v_unit || ''' unit from (  ' || V_SQL || '))';
  
    OPEN O_Outcursor FOR v_SQL;
    return;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      ROLLBACK;
      O_Result  := -9;
      O_Message := '查询失败';
      RETURN;
  end PQ_List_RandomAD;

end P_AD_List_V3;
/


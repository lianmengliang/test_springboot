create package P_Job_ADAward is
  Procedure Job_AwardWaitCheck;
  /*****************************************************************
      procedure name: Job_AutoCheck
      purpose: 奖励等待表处理 （生成流水记录和订单表记录）
      edit: 2019-03-06 Add by 小胡
  ****************************************************************/
  procedure Job_AwardWaitCheck_v2;
  /*****************************************************************
      procedure name: PW_Activity_Award_v2
      purpose: 用户福利活动奖励
      edit: 2019-03-12 Add by 小胡
  ****************************************************************/
  procedure Job_AwardWaitCheck_v3;
  /*****************************************************************
      procedure name: PW_Activity_Award_v2
      purpose: 用户福利活动奖励
      edit: 2019-08-20 Add by 文浩
  ****************************************************************/
end P_Job_ADAward;
/


create PACKAGE BODY P_AD_Statistics_V2 AS

  /*广告界面打开统计 */

  procedure PW_Open
  /*****************************************************************
        Procedure Name :PW_Open
        Purpose: 打开统计
        Edit: 2018-09-25 add by 小沈
    ****************************************************************/
  (I_PType    In Number, --1、ios  2、安卓
   I_APPId    In Number, --渠道应用ID
   I_ADID     In Number, --广告ID
   I_APPSign  In Varchar2, --渠道应用标识符号、渠道用户id
   I_Deviceid In Varchar2, --设备号ID
   I_Userid   In Number, --闲玩用户编号
   I_IP       In Varchar2, --
   I_Times    In Number, --访问时长单位秒
   I_SType    In Number, --统计类型 0：列表 1：广告详情
   I_Source   In Number, --来源 1：H5 2:闲玩盒子
   O_Result   Out Number, --判断 0：查询成功，其他：出错
   O_Message  Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    V_N        Number;
    v_sppsign  varchar2(50);
    v_odd_even number; --奇偶数判断
    v_Source   Number := 1; --来源 1：H5 2:闲玩盒子
  
  begin
    O_Result  := 0;
    O_Message := '记录成功';
  
    if I_APPSign = '0' then
      select appsign
        into v_sppsign
        from ad_app_users
       where appid = I_APPId
         and userid = I_Userid;
    else
      v_sppsign := I_APPSign;
    end if;
  
    if I_Source is null or I_Source = 0 then
      v_Source := 1;
    else
      v_Source := I_Source;
    end if;
  
    ----------------------------------------------------
    --步骤一：不判断直接记录
    ----------------------------------------------------
  
    --取余判断奇数偶数，来判断取那张表
    v_odd_even := mod(to_number(to_char(sysdate, 'dd')), 2);
    if v_odd_even = 1 then
      insert into ad_stats_open
        (dtime,
         ptype,
         appid,
         adid,
         appsign,
         deviceid,
         userid,
         ip,
         itime,
         stype,
         times,
         user_source)
      values
        (trunc(sysdate),
         i_ptype,
         i_appid,
         i_adid,
         v_sppsign,
         i_deviceid,
         i_userid,
         i_ip,
         sysdate,
         i_stype,
         I_Times,
         v_Source);
    else
      insert into ad_stats_open_2
        (dtime,
         ptype,
         appid,
         adid,
         appsign,
         deviceid,
         userid,
         ip,
         itime,
         stype,
         times,
         user_source)
      values
        (trunc(sysdate),
         i_ptype,
         i_appid,
         i_adid,
         v_sppsign,
         i_deviceid,
         i_userid,
         i_ip,
         sysdate,
         i_stype,
         I_Times,
         v_Source);
    end if;
  
    ----------------------------------------------------
    --步骤二：完成
    ----------------------------------------------------
  
    commit;
    return;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '记录异常！';
      return;
  end PW_Open;
  procedure PW_Open_V2
  /*****************************************************************
        Procedure Name :PW_Open
        Purpose: 打开统计
        Edit: 2018-09-25 add by 小沈
    ****************************************************************/
  (I_PType    In Number, --1、ios  2、安卓
   I_APPId    In Number, --渠道应用ID
   I_ADID     In Number, --广告ID
   I_APPSign  In Varchar2, --渠道应用标识符号、渠道用户id
   I_Deviceid In Varchar2, --设备号ID
   I_Userid   In Number, --闲玩用户编号
   I_IP       In Varchar2, --
   I_Times    In Number, --访问时长单位秒
   I_SType    In Number, --统计类型 0：列表落地页 1：广告详情落地页 2、触发执行列表（未用到） 3:服务端列表请求4:API服务端详情页 5:API 服务端列表页 
   I_Source   In Number, --来源 1：H5 2:闲玩盒子
   I_ADType   In Number, --统计广告类型
   O_Result   Out Number, --判断 0：查询成功，其他：出错
   O_Message  Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    V_N        Number;
    v_sppsign  varchar2(50);
    v_odd_even number; --奇偶数判断
    v_Source   Number := 1; --来源 1：H5 2:闲玩盒子
  
  begin
    O_Result  := 0;
    O_Message := '记录成功';
  
    if I_APPSign = '0' then
      select appsign
        into v_sppsign
        from ad_app_users
       where appid = I_APPId
         and userid = I_Userid;
    else
      v_sppsign := I_APPSign;
    end if;
  
    if I_Source is null or I_Source = 0 then
      v_Source := 1;
    else
      v_Source := I_Source;
    end if;
  
    ----------------------------------------------------
    --步骤一：不判断直接记录
    ----------------------------------------------------
  
    --取余判断奇数偶数，来判断取那张表
    v_odd_even := mod(to_number(to_char(sysdate, 'dd')), 2);
    if v_odd_even = 1 then
      insert into ad_stats_open
        (dtime,
         ptype,
         appid,
         adid,
         appsign,
         deviceid,
         userid,
         ip,
         itime,
         stype,
         times,
         user_source,
         adtype)
      values
        (trunc(sysdate),
         i_ptype,
         i_appid,
         i_adid,
         v_sppsign,
         i_deviceid,
         i_userid,
         i_ip,
         sysdate,
         i_stype,
         I_Times,
         v_Source,
         I_ADType);
    else
      insert into ad_stats_open_2
        (dtime,
         ptype,
         appid,
         adid,
         appsign,
         deviceid,
         userid,
         ip,
         itime,
         stype,
         times,
         user_source,
         adtype)
      values
        (trunc(sysdate),
         i_ptype,
         i_appid,
         i_adid,
         v_sppsign,
         i_deviceid,
         i_userid,
         i_ip,
         sysdate,
         i_stype,
         I_Times,
         v_Source,
         I_ADType);
    end if;
  
    ----------------------------------------------------
    --步骤二：完成
    ----------------------------------------------------
  
    commit;
    return;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '记录异常！';
      return;
  end PW_Open_V2;

  Procedure Job_StatsDay
  /*****************************************************************
        procedure name: Job_StatsDay
        purpose: 统计日表
        edit: 2018-05-13 add by 小沈
    ****************************************************************/
   is
    v_appid number; --渠道编号
    v_n     number;
  
    v_Day           varchar2(100); --统计日期
    v_odd_even      number; --奇偶数判断
    v_sql           varchar2(1000);
    v_table         varchar2(100); --根据获取日期判断取那张表
    v_l_req_uv      number; --列表请求uv
    v_l_req_pv      number; --列表请求pv
    v_l_show_uv     number; --列表落地展示uv
    v_l_show_pv     number; --列表落地展示pv
    v_d_show_uv     number; --详情页展示uv
    v_d_show_pv     number; --详情页展示pv
    v_d_down_uv     number; --下载uv
    v_d_down_total  number; --下载次数
    v_d_reg_uv      number; --注册uv
    v_d_reg_total   number; --注册数
    v_f_table       number; --来源统计表 1：ad_stats_open （单数日期） 2：ad_stats_open_2 （双数日期）
    v_l_req_uv_x    number; --列表请求uv --闲玩盒子
    v_l_req_pv_x    number; --列表请求pv --闲玩盒子
    v_l_show_uv_x   number; --列表落地展示uv --闲玩盒子
    v_l_show_pv_x   number; --列表落地展示pv --闲玩盒子
    v_d_show_uv_x   number; --详情页展示uv --闲玩盒子
    v_d_show_pv_x   number; --详情页展示pv --闲玩盒子
    v_l_req_uv_api  number; --列表请求uv --api请求
    v_l_req_pv_api  number; --列表请求pv --api请求
    v_d_show_uv_api number; --详情页展示uv --api请求
    v_d_show_pv_api number; --详情页展示pv --api请求
  
    v_message varchar2(500);
  
    cursor AppId_List is
      select appid from ad_channel where status != 2;
  
  begin
    v_n := 0;
  
    v_Day := to_char(sysdate - 1, 'yyyy-mm-dd');
  
    --取余判断奇数偶数，来判断取那张表
    v_odd_even := mod(to_number(to_char(to_date(v_Day, 'yyyy-mm-dd'), 'dd')),
                      2);
    if v_odd_even = 1 then
      v_table := 'ad_stats_open';
    else
      v_table := 'ad_stats_open_2';
    end if;
  
    for C_AppId in AppId_List loop
      v_appid := c_appid.appid;
    
      select count(1)
        into v_n
        from ad_stats_day
       where dtime = to_date(v_Day, 'yyyy-mm-dd')
         and appid = v_appid;
      if v_n > 0 then
        goto Next_C_APPID;
      end if;
    
      --列表请求uv
      v_sql := 'select count(1) from (
select  deviceid ,count(1) from ' || v_table ||
               ' t where appid=' || v_appid || ' and stype =12
and itime>=to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'') and itime<to_date(''' || v_Day || ''',''yyyy-mm-dd'')+1  group by deviceid
)';
      execute immediate v_sql
        into v_l_req_uv;
    
      --列表请求 PV
      v_sql := 'select count(1)
          from ' || v_table || ' t
         where appid = ' || v_appid || '
           and stype =12
           and itime >= to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'')
           and itime < to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'') + 1';
      execute immediate v_sql
        into v_l_req_pv;
    
      --落地列表展示UV
      v_sql := 'select count(1)
          from (select deviceid, count(1)
                  from ' || v_table || ' t
                 where appid = ' || v_appid || '
                   and stype = 10
                   and itime >= to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'')
                   and itime < to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'') + 1
                 group by deviceid)';
      execute immediate v_sql
        into v_l_show_uv;
    
      --落地列表展示PV
      v_sql := 'select count(1)
          from ' || v_table || ' t
         where appid = ' || v_appid || '
           and stype =10
           and itime >= to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'')
           and itime < to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'') + 1';
      execute immediate v_sql
        into v_l_show_pv;
    
      --详情页UV
      v_sql := ' select count(1)
          from (select deviceid, count(1)
                  from ' || v_table || ' t
                 where appid = ' || v_appid || '
                   and stype =13
                   and itime >= to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'')
                   and itime < to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'') + 1
                 group by deviceid)';
      execute immediate v_sql
        into v_d_show_uv;
    
      --详情页PV
      v_sql := ' select  count(1)
                  from ' || v_table || ' t
                 where appid = ' || v_appid || '
                   and stype =13
                   and itime >= to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'')
                   and itime < to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'') + 1';
      execute immediate v_sql
        into v_d_show_pv;
    
      --点击下载UV
      v_sql := 'select count(1)
          from (select deviceid, count(1)
                  from ad_app_bind t
                 where appid = ' || v_appid || '
                   and itime >= to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'')
                   and itime < to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'') + 1
                 group by deviceid)';
      execute immediate v_sql
        into v_d_down_uv;
    
      --下载次数
      v_sql := 'select count(1)
          from ad_app_bind t
         where appid = ' || v_appid || '
           and itime >= to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'')
           and itime < to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'') + 1';
      execute immediate v_sql
        into v_d_down_total;
    
      --注册UV
      v_sql := 'select count(1)
          from (select deviceid, count(1)
                  from ad_app_bind t
                 where appid = ' || v_appid || '
                   and ustatus = 3
                   and lasttime >= to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'')
                   and lasttime < to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'') + 1
                 group by deviceid)';
      execute immediate v_sql
        into v_d_reg_uv;
    
      --注册数
      v_sql := 'select count(1)
          from ad_app_bind t
         where appid = ' || v_appid || '
           and ustatus = 3
           and lasttime >= to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'')
           and lasttime < to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'') + 1';
      execute immediate v_sql
        into v_d_reg_total;
    
      --列表请求uv --闲玩盒子
      v_sql := 'select count(1) from (
select  deviceid ,count(1) from ' || v_table ||
               ' t where appid=' || v_appid || ' and stype= 3 and user_source =2
and itime>=to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'') and itime<to_date(''' || v_Day || ''',''yyyy-mm-dd'')+1  group by deviceid
)';
      execute immediate v_sql
        into v_l_req_uv_x;
    
      --列表请求pv --闲玩盒子
      v_sql := 'select count(1)
          from ' || v_table || ' t
         where appid = ' || v_appid || '
           and stype = 3 and user_source =2
           and itime >= to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'')
           and itime < to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'') + 1';
      execute immediate v_sql
        into v_l_req_pv_x;
    
      --列表落地展示uv --闲玩盒子
      v_sql := 'select count(1)
          from (select deviceid, count(1)
                  from ' || v_table || ' t
                 where appid = ' || v_appid || '
                   and stype = 0 and user_source =2
                   and itime >= to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'')
                   and itime < to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'') + 1
                 group by deviceid)';
      execute immediate v_sql
        into v_l_show_uv_x;
    
      --列表落地展示pv --闲玩盒子
      v_sql := 'select count(1)
          from ' || v_table || ' t
         where appid = ' || v_appid || '
           and stype = 0 and user_source =2
           and itime >= to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'')
           and itime < to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'') + 1';
      execute immediate v_sql
        into v_l_show_pv_x;
    
      --详情页展示uv --闲玩盒子
      v_sql := ' select count(1)
          from (select deviceid, count(1)
                  from ' || v_table || ' t
                 where appid = ' || v_appid || '
                   and stype = 1 and user_source =2
                   and itime >= to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'')
                   and itime < to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'') + 1
                 group by deviceid)';
      execute immediate v_sql
        into v_d_show_uv_x;
    
      --详情页展示pv --闲玩盒子
      v_sql := ' select  count(1)
                  from ' || v_table || ' t
                 where appid = ' || v_appid || '
                   and stype = 1 and user_source =2
                   and itime >= to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'')
                   and itime < to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'') + 1';
      execute immediate v_sql
        into v_d_show_pv_x;
    
      --列表请求uv --api请求
      v_sql := 'select count(1) from (
select  deviceid ,count(1) from ' || v_table ||
               ' t where appid=' || v_appid || ' and stype =14
and itime>=to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'') and itime<to_date(''' || v_Day || ''',''yyyy-mm-dd'')+1  group by deviceid
)';
      execute immediate v_sql
        into v_l_req_uv_api;
    
      --列表请求pv --api请求
      v_sql := 'select count(1)
          from ' || v_table || ' t
         where appid = ' || v_appid || '
           and stype =14
           and itime >= to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'')
           and itime < to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'') + 1';
      execute immediate v_sql
        into v_l_req_pv_api;
    
      --详情页展示uv --api请求
      v_sql := ' select count(1)
          from (select deviceid, count(1)
                  from ' || v_table || ' t
                 where appid = ' || v_appid || '
                   and stype =15
                   and itime >= to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'')
                   and itime < to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'') + 1
                 group by deviceid)';
      execute immediate v_sql
        into v_d_show_uv_api;
    
      --详情页展示pv --api请求
      v_sql := ' select  count(1)
                  from ' || v_table || ' t
                 where appid = ' || v_appid || '
                   and stype =15
                   and itime >= to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'')
                   and itime < to_date(''' || v_Day ||
               ''',''yyyy-mm-dd'') + 1';
      execute immediate v_sql
        into v_d_show_pv_api;
    
      insert into ad_stats_day
        (dtime,
         appid,
         l_req_uv,
         l_req_pv,
         l_show_uv,
         l_show_pv,
         d_show_uv,
         d_show_pv,
         d_down_uv,
         d_down_total,
         d_reg_uv,
         d_reg_total,
         itime,
         f_table,
         l_req_uv_x,
         l_req_pv_x,
         l_show_uv_x,
         l_show_pv_x,
         d_show_uv_x,
         d_show_pv_x,
         l_req_uv_api,
         l_req_pv_api,
         d_show_uv_api,
         d_show_pv_api)
      values
        (to_date(v_Day, 'yyyy-mm-dd'),
         v_appid,
         v_l_req_uv, --列表请求uv
         v_l_req_pv, --列表请求pv
         v_l_show_uv, --列表落地展示uv
         v_l_show_pv, --列表落地展示pv
         v_d_show_uv, --详情页展示uv
         v_d_show_pv, --详情页展示pv
         v_d_down_uv, --下载uv
         v_d_down_total, ---下载次数
         v_d_reg_uv, --注册uv
         v_d_reg_total, --注册数
         sysdate,
         v_odd_even,
         v_l_req_uv_x,
         v_l_req_pv_x,
         v_l_show_uv_x,
         v_l_show_pv_x,
         v_d_show_uv_x,
         v_d_show_pv_x,
         v_l_req_uv_api,
         v_l_req_pv_api,
         v_d_show_uv_api,
         v_d_show_pv_api);
      commit;
    
      <<Next_C_APPID>>
      null;
    end loop;
  
    --无积分统计
    -- p_ad_statistics_v2.job_statsday_nointegral;
  
    --清除统计表  
    if v_odd_even = 1 then
      v_sql := 'truncate table ad_stats_open';
    else
      v_sql := 'truncate table ad_stats_open_2';
    end if;
    execute immediate v_sql;
  
  exception
    when others then
      rollback;
      v_message := '错误编码：' || sqlcode || '  错误信息 ：' || sqlerrm;
    
      return;
  end Job_StatsDay;

end P_AD_Statistics_V2;
/


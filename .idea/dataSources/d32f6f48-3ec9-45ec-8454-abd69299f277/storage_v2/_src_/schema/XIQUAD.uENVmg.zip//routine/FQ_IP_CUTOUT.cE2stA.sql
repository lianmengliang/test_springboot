create function FQ_IP_CutOUt
/*****************************************************************
  过程名称：IP字符串截取
  创建日期：2018-09-19
  返回：
  ****************************************************************/
(i_StrIp IN varchar2) return varchar2 --返回级别
 is
  v_out varchar2(1000);

begin

  v_out := substr(i_StrIp, 1, instr(i_StrIp, '.')) ||
           substr(substr(i_StrIp,
                         length(substr(i_StrIp, 1, instr(i_StrIp, '.') + 1))),
                  1,
                  instr(substr(i_StrIp,
                               length(substr(i_StrIp,
                                             1,
                                             instr(i_StrIp, '.') + 1))),
                        '.') - 1);

  return v_out;
EXCEPTION
  WHEN OTHERS THEN
    return i_StrIp;
end FQ_IP_CutOUt;


/


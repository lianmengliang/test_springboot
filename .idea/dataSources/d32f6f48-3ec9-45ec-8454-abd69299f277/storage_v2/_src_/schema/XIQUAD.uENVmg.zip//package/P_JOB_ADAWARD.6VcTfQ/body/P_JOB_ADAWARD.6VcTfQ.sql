create package body P_Job_ADAward is

  Procedure Job_AwardWaitCheck
  /*****************************************************************
        procedure name: Job_AutoCheck
        purpose: 奖励等待表处理 （生成流水记录和订单表记录）
        edit: 2019-03-06 Add by 小胡
    ****************************************************************/
   is
    v_adminPhone_s  varchar2(50); --超级管理员手机号
    v_n             number;
    v_awardTimes    number; -- 单步奖励的奖励次数
    v_Event         varchar2(500); -- 奖励描述
    v_Adtype        number; --广告类型
    v_ChannelStatus number; --渠道状态
    v_Atype         number; --奖励类型：1-注册 ； 2-等级/首冲固定奖励 ； 3-充值理财百分比奖励； 4-安装奖励； 5-当天签到奖励； 9-VIP或首充
    v_Urlid         number; --下载链接id
    v_Price         number; --结算金额
    v_batchid       varchar2(50);
    V_awardIsShow   number; --是否显示该奖励 0否 1是【如果为否，则该奖励不会给渠道推送】
    v_ADname        Varchar2(100); --广告名称
    v_ordernum      varchar2(50); --订单号
    v_Pagename      Varchar2(100); --包名
    v_result        number;
    v_message       varchar2(200);
    v_isOld         number; --是否为老用户 0否 1是 
  begin
    v_adminPhone_s := '18758009397'; --小沈手机号
  
    --默认奖励是显示的
    V_awardIsShow := 1;
    v_Pagename    := '';
  
    ----------------------------------------------------
    --步骤一：初始化
    ----------------------------------------------------
    select count(1)
      into v_n
      from ad_award_wait
     where itime > sysdate - 1 / 12
       and status = 1;
    --如果有数据还正在处理则此次job不做处理
    if v_n > 0 then
      return;
    end if;
    declare
      cursor AwardWait_List is
        select id,
               adid,
               appid,
               deviceid,
               userid,
               ptype,
               simid,
               appsign,
               merid,
               mername,
               ulevel,
               amoney,
               dlevel,
               needlevel,
               awardgroup,
               batchid,
               status
          from ad_award_wait
         where batchid = v_batchid
           and status = 1
         order by itime asc;
    
    begin
      --使用随机数和日期组合批次号
      select dbms_random.string('a', 5) into v_batchid from dual;
      v_batchid := to_char(sysdate, 'yyyymmddhh24miss') || v_batchid;
    
      --每次处理100条
      update ad_award_wait
         set batchid = v_batchid, status = 1, utime = sysdate
       where status = 0
         and id in (select id
                      from (select id
                              from ad_award_wait
                             where status = 0
                               and itime >= sysdate - 0.5
                             order by itime asc)
                     where rownum <= 100);
      commit;
    
      for C_AwardWait in AwardWait_List loop
        v_awardTimes := 0;
        v_Event      := '';
        v_message    := '';
        begin
        
          --查看用户是否被限制
          --设备号限制表判断
          select count(1)
            into v_n
            from ad_limit_deviceid
           where adid = C_AwardWait.adid
             and deviceid = C_AwardWait.Deviceid;
        
          if v_n > 0 then
            --修改状态为系统审核不通过
            v_result  := -2;
            v_message := '用户设备号被限制！';
            update ad_award_wait
               set status = 6, utime = sysdate, msg = v_message
             where id = C_AwardWait.id;
            GOTO CONTINUE_LOOP;
          end if;
        
          --设备号限制表判断
          select count(1)
            into v_n
            from ad_limit_user
           where adid = C_AwardWait.adid
             and userid = C_AwardWait.Userid;
          if v_n > 0 then
            --修改状态为系统审核不通过
            v_result  := -2;
            v_message := '闲玩用户被限制！';
            update ad_award_wait
               set status = 6, utime = sysdate, msg = v_message
             where id = C_AwardWait.id;
            GOTO CONTINUE_LOOP;
          end if;
        
          if v_n > 0 then
            --修改状态为系统审核不通过
            v_result  := -2;
            v_message := '用户设备号被限制！';
            update ad_award_wait
               set status = 6, utime = sysdate, msg = v_message
             where id = C_AwardWait.id;
            GOTO CONTINUE_LOOP;
          end if;
        
          select nvl(times, 0), event, atype, price, isshow
            into v_awardTimes, v_Event, v_Atype, v_Price, V_awardIsShow
            from (select times, event, atype, price, isshow
                    from ad_awardset
                   where adid = C_AwardWait.adid
                     and appid = C_AwardWait.appid
                     and dlevel = C_AwardWait.dlevel
                  union all
                  select null, null, null, null, null from dual)
           where rownum = 1;
        
          select count(1)
            into v_n
            from ad_app_flux
           where adid = C_AwardWait.adid
             and (userid = C_AwardWait.userid or
                 deviceid = upper(C_AwardWait.Deviceid))
             and dlevel = C_AwardWait.dlevel;
        
          --如果该设备已经获取过该奖励则跳过
          if v_n >= v_awardTimes then
          
            --修改状态为系统审核不通过
            v_result  := -2;
            v_message := '已获得过奖励了';
            update ad_award_wait
               set status = 6, utime = sysdate, msg = v_message
             where id = C_AwardWait.id;
            GOTO CONTINUE_LOOP;
          end if;
        
          select count(1)
            into v_n
            from ad_app_bind
           where adid = C_AwardWait.adid
             and appid = C_AwardWait.appid
             and userid = C_AwardWait.userid;
          if v_n = 0 then
            --修改状态为不通过
            v_result  := -2;
            v_message := '绑定记录不存在，发奖失败';
            update ad_award_wait
               set status = 6, utime = sysdate, msg = v_message
             where id = C_AwardWait.id;
            GOTO CONTINUE_LOOP;
          end if;
          ---连表获取相关参数
          select nvl(a.urlid, 0),
                 a.pagename,
                 a.isold,
                 nvl(b.adtype, 1),
                 nvl(b.adname, ''),
                 nvl(c.status, 2)
            into v_Urlid,
                 v_Pagename,
                 v_isOld,
                 v_Adtype,
                 v_ADname,
                 v_ChannelStatus
            from ad_app_bind a
            left join ad_adinfo b
              on a.adid = b.adid
            left join ad_channel c
              on a.appid = c.appid
           where a.adid = C_AwardWait.adid
             and a.appid = C_AwardWait.appid
             and a.userid = C_AwardWait.userid;
        
          --判断是否为老用户
          if v_isOld is null then
            select count(1)
              into v_n
              from ad_app_bind
             where adid != C_AwardWait.adid
               and userid = C_AwardWait.Userid
               and pagename = v_Pagename
               and ustatus in (2, 3);
            if v_n > 0 then
              v_isOld := 1;
            else
              v_isOld := 0;
            end if;
          end if;
        
          insert into ad_app_flux
            (id,
             adid,
             appid,
             deviceid,
             appsign,
             dlevel,
             merid,
             money,
             event,
             adtype,
             atype,
             simid,
             urlid,
             price,
             userid,
             ptype,
             isold)
            select SQ_AD_FLUX.NEXTVAL,
                   C_AwardWait.adid,
                   C_AwardWait.appid,
                   C_AwardWait.Deviceid,
                   C_AwardWait.Appsign,
                   C_AwardWait.Dlevel,
                   C_AwardWait.Merid,
                   C_AwardWait.Amoney,
                   v_Event,
                   v_adtype,
                   v_Atype,
                   C_AwardWait.simid,
                   v_Urlid,
                   v_Price,
                   C_AwardWait.Userid,
                   C_AwardWait.Ptype,
                   v_isOld
              from dual
             where (select count(1)
                      from ad_app_flux
                     where adid = C_AwardWait.adid
                       and (userid = C_AwardWait.Userid or
                           deviceid = upper(C_AwardWait.Deviceid))
                       and dlevel = C_AwardWait.Dlevel) < v_awardTimes;
        
          --如果奖励状态是可显示的才发奖
          if V_awardIsShow = 1 then
          
            /* -------------------------
            由渠道发奖,则插入订单表
            --------------------------*/
            --生成订单号
            v_ordernum := C_AwardWait.appid ||
                          to_char(sysdate, 'yyyymmddhh24miss') ||
                          C_AwardWait.adid || dbms_random.string('x', 5) ||
                          trunc(dbms_random.value(0, 10));
          
            insert into ad_channel_order
              (adid,
               adname,
               appid,
               ordernum,
               dlevel,
               awardgroup,
               pagename,
               deviceid,
               simid,
               appsign,
               merid,
               mername,
               event,
               price,
               money)
            values
              (C_AwardWait.adid,
               v_ADname,
               C_AwardWait.appid,
               v_ordernum,
               C_AwardWait.dlevel,
               C_AwardWait.awardgroup,
               v_Pagename,
               C_AwardWait.deviceid,
               C_AwardWait.simid,
               C_AwardWait.appsign,
               C_AwardWait.merid,
               C_AwardWait.mername,
               v_adname || v_Event,
               v_Price,
               C_AwardWait.amoney);
            v_result  := 0;
            v_message := '渠道发奖成功';
            update ad_award_wait
               set status = 2, utime = sysdate, msg = v_message
             where id = C_AwardWait.id
               and status = 1;
            commit;
            goto CONTINUE_LOOP;
          end if;
        
          <<CONTINUE_LOOP>>
          commit;
          --单条异常处理
        exception
          when others then
            rollback;
            v_message := '奖励异常 编码：' || SQLCODE || '信息 ：' || sqlerrm;
            update ad_award_wait
               set status = 3, utime = sysdate, msg = v_message
             where id = C_AwardWait.id;
            commit;
        end;
      end loop;
    end;
  exception
    when others then
      rollback;
      return;
  end Job_AwardWaitCheck;

  Procedure Job_AwardWaitCheck_v2
  /*****************************************************************
        procedure name: Job_AutoCheck
        purpose: 奖励等待表处理 （生成流水记录和订单表记录）
        edit: 2019-03-06 Add by 小胡
    ****************************************************************/
   is
    v_adminPhone_s  varchar2(50); --超级管理员手机号
    v_n             number;
    v_AwardOf       number; --奖励渠道 1:渠道发奖，2：闲玩发奖
    v_awardTimes    number; -- 单步奖励的奖励次数
    v_Event         varchar2(500); -- 奖励描述
    v_Adtype        number; --广告类型
    v_ChannelStatus number; --渠道状态
    v_OwnUser       number; --是否是自由用户 0：不是  1：是
    v_Atype         number; --奖励类型：1-注册 ； 2-等级/首冲固定奖励 ； 3-充值理财百分比奖励； 4-安装奖励； 5-当天签到奖励； 9-VIP或首充
    /*v_adClass       number; --广告类型 1：CPL广告 2：CPA广告*/
    v_Urlid         number; --下载链接id
    v_Price         number; --结算金额
    v_MoneyWait     number; --30分钟内等待表累计奖励金额
    v_MoneyFlux     number; --30分钟内累计流水表奖励金额
    v_batchid       varchar2(50);
    v_Matketer      varchar2(50); --广告所属市场人员
    v_MatketerPhone varchar2(50); --市场人员手机号
    v_msgContent    varchar2(100); --短信内容
    V_awardIsShow   number; --是否显示该奖励 0否 1是【如果为否，则该奖励不会给渠道推送】
    v_ADname        Varchar2(100); --广告名称
    v_ordernum      varchar2(50); --订单号
    v_Pagename      Varchar2(100); --包名
    v_Remark        varchar2(2000);
    v_result        number;
    v_message       varchar2(200);
    v_integral      number; --是否是有积分   1有积分   0无积分
    v_ptype         number;
    v_isOld         number; --是否为老用户 0否 1是 
    v_adid          number; --18年无积分adid
  begin
    v_adminPhone_s := '15669506895'; --小刘手机号
    --默认由渠道发奖
    v_AwardOf := 1;
    --默认奖励是显示的
    V_awardIsShow := 1;
    v_Pagename    := '';
    --默认为有积分
    v_integral := 1;
    ----------------------------------------------------
    --步骤一：初始化
    ----------------------------------------------------
    select count(1)
      into v_n
      from ad_award_wait
     where itime > sysdate - 1 / 12
       and status = 1;
    --如果有数据还正在处理则此次job不做处理
    if v_n > 0 then
      return;
    end if;
    declare
      cursor AwardWait_List is
        select id,
               adid,
               appid,
               deviceid,
               userid,
               ptype,
               simid,
               appsign,
               merid,
               mername,
               ulevel,
               amoney,
               dlevel,
               needlevel,
               awardgroup,
               batchid,
               status
          from ad_award_wait
         where batchid = v_batchid
           and status = 1
         order by itime asc;
    
    begin
      --使用随机数和日期组合批次号
      select dbms_random.string('a', 5) into v_batchid from dual;
      v_batchid := to_char(sysdate, 'yyyymmddhh24miss') || v_batchid;
    
      --每次处理100条
      update ad_award_wait
         set batchid = v_batchid, status = 1, utime = sysdate
       where status = 0
         and id in (select id
                      from (select id
                              from ad_award_wait
                             where status = 0
                               and itime >= sysdate - 0.5
                             order by itime asc)
                     where rownum <= 100);
      commit;
    
      for C_AwardWait in AwardWait_List loop
        v_awardTimes := 0;
        v_Event      := '';
        v_message    := '';
        begin
        
          --查看用户是否被限制
          --设备号限制表判断
          select count(1)
            into v_n
            from ad_limit_deviceid
           where adid = C_AwardWait.adid
             and deviceid = C_AwardWait.Deviceid;
        
          if v_n > 0 then
            --修改状态为系统审核不通过
            v_result  := -2;
            v_message := '用户设备号被限制！';
            update ad_award_wait
               set status = 6, utime = sysdate, msg = v_message
             where id = C_AwardWait.id;
            GOTO CONTINUE_LOOP;
          end if;
        
          --设备号限制表判断
          select count(1)
            into v_n
            from ad_limit_user
           where adid = C_AwardWait.adid
             and userid = C_AwardWait.Userid;
          if v_n > 0 then
            --修改状态为系统审核不通过
            v_result  := -2;
            v_message := '闲玩用户被限制！';
            update ad_award_wait
               set status = 6, utime = sysdate, msg = v_message
             where id = C_AwardWait.id;
            GOTO CONTINUE_LOOP;
          end if;
        
          if v_n > 0 then
            --修改状态为系统审核不通过
            v_result  := -2;
            v_message := '用户设备号被限制！';
            update ad_award_wait
               set status = 6, utime = sysdate, msg = v_message
             where id = C_AwardWait.id;
            GOTO CONTINUE_LOOP;
          end if;
        
          --判断是否在18年无积分领取过
          /*          select count(1)
            into v_n
            from ad_relate@xwanad_link
           where adid_wall = C_AwardWait.adid;
          if v_n > 0 then
            select adid
              into v_adid
              from ad_relate@xwanad_link
             where adid_wall = C_AwardWait.adid;
          
            --查看该广告是否领取过
            select count(1)
              into v_n
              from ad_award_detail@xwanad_link
             where adid = v_adid
               and dlevel = C_AwardWait.dlevel
               and merid = C_AwardWait.merid;
          
            if v_n > 0 then
              update ad_award_wait
                 set status       = 3,
                     msg          = '已在无积分渠道领取过奖励',
                     utime  = sysdate
               where id = C_AwardWait.id
                 and status in (0, 1);
              commit;
              goto CONTINUE_LOOP;
            end if;
          
          end if;*/
          --判断是否在18年无积分领取过 end
        
          select nvl(times, 0), event, atype, price, isshow
            into v_awardTimes, v_Event, v_Atype, v_Price, V_awardIsShow
            from (select times, event, atype, price, isshow
                    from ad_awardset
                   where adid = C_AwardWait.adid
                     and appid = C_AwardWait.appid
                     and dlevel = C_AwardWait.dlevel
                  union all
                  select null, null, null, null, null from dual)
           where rownum = 1;
        
          select count(1)
            into v_n
            from ad_app_flux
           where adid = C_AwardWait.adid
             and (userid = C_AwardWait.userid or
                 deviceid = upper(C_AwardWait.Deviceid))
             and dlevel = C_AwardWait.dlevel;
        
          --如果该设备已经获取过该奖励则跳过
          if v_n >= v_awardTimes then
          
            --修改状态为系统审核不通过
            v_result  := -2;
            v_message := '已获得过奖励了';
            update ad_award_wait
               set status = 6, utime = sysdate, msg = v_message
             where id = C_AwardWait.id;
            GOTO CONTINUE_LOOP;
          end if;
        
          select count(1)
            into v_n
            from ad_app_bind
           where adid = C_AwardWait.adid
             and appid = C_AwardWait.appid
             and userid = C_AwardWait.userid;
          if v_n = 0 then
            --修改状态为不通过
            v_result  := -2;
            v_message := '绑定记录不存在，发奖失败';
            update ad_award_wait
               set status = 6, utime = sysdate, msg = v_message
             where id = C_AwardWait.id;
            GOTO CONTINUE_LOOP;
          end if;
          select nvl(integral, 1), nvl(atype, 2)
            into v_integral, v_ptype
            from (select integral, atype
                    from ad_channel
                   where appid = C_AwardWait.appid
                  union
                  select null, null from dual)
           where rownum = 1;
          ---连表获取相关参数
          select nvl(a.urlid, 0),
                 /*a.adclass,*/
                 a.pagename,
                 a.isold,
                 nvl(b.adtype, 1),
                 nvl(b.adname, ''),
                 nvl(c.status, 2)
            into v_Urlid,
                 /*v_adClass,*/
                 v_Pagename,
                 v_isOld,
                 v_Adtype,
                 v_ADname,
                 v_ChannelStatus
            from ad_app_bind a
            left join ad_adinfo b
              on a.adid = b.adid
            left join ad_channel c
              on a.appid = c.appid
           where a.adid = C_AwardWait.adid
             and a.appid = C_AwardWait.appid
             and a.userid = C_AwardWait.userid;
        
          if v_integral = 1 then
            --查询有积分数据
            select nvl(ownuser, 0)
              into v_OwnUser
              from ad_app_users d
             where userid = C_AwardWait.userid;
          
          else
            v_OwnUser := 1;
          end if;
        
          --渠道状态为停止状态，则由闲玩发奖 ,v_AwardOf=1为渠道发奖，2为闲玩发奖
          if v_ChannelStatus = 2 then
            v_OwnUser := 1;
            v_AwardOf := 2;
          else
            if v_OwnUser = 1 then
              v_AwardOf := 2;
            else
              v_AwardOf := 1;
            end if;
          end if;
        
          --如果由闲玩发奖处理
          if v_AwardOf = 2 then
            --1、判断20分钟内的奖励金额是否超过1500,超过1500的全部设置为待审核，且发送短信提示
            select sum(amoney)
              into v_MoneyWait
              from ad_award_wait
             where itime > sysdate - 30 / (24 * 60)
               and adid = C_AwardWait.Adid
               and deviceid = C_AwardWait.Deviceid
               and status in (0, 1, 4);
          
            select sum(money)
              into v_MoneyFlux
              from ad_app_flux
             where itime > sysdate - 30 / (24 * 60)
               and adid = C_AwardWait.adid
               and deviceid = upper(C_AwardWait.Deviceid);
          
            if v_MoneyFlux + v_MoneyWait >= 1500 then
              update ad_award_wait
                 set status = 4,
                     utime  = sysdate,
                     msg    = '半小时累计奖励金额超过1500元，需要人工审核'
               where adid = C_AwardWait.Adid
                 and appid = C_AwardWait.Appid
                 and deviceid = C_AwardWait.Deviceid
                 and itime >= sysdate - 40 / (24 * 60)
                 and status in (0, 1);
              commit;
            
              select trim(marketer)
                into v_Matketer
                from ad_downurl
               where adid = C_AwardWait.Adid
                 and rownum = 1;
              --获取市场人员手机号   
              select nvl(phone, '')
                into v_MatketerPhone
                from (select phone
                        from t_admin
                       where name = v_Matketer
                      union all
                      select null from dual)
               where rownum = 1;
              --添加发送提示审核短信
              v_msgContent := '广告ID:' || C_AwardWait.Adid ||
                              '有由闲玩发奖的奖励需要审核';
              p_sms.pw_alarm_add(i_phone     => v_MatketerPhone,
                                 i_message   => v_msgContent,
                                 i_sendlevel => 1,
                                 i_sendtype  => 1,
                                 o_result    => v_result,
                                 o_message   => v_message);
            
              p_sms.pw_alarm_add(i_phone     => v_adminPhone_s,
                                 i_message   => v_msgContent,
                                 i_sendlevel => 1,
                                 i_sendtype  => 1,
                                 o_result    => v_result,
                                 o_message   => v_message);
              --修改状态为不通过
              v_result  := -2;
              v_message := '奖励超过1500元，需要审核';
              update ad_award_wait
                 set status = 4, utime = sysdate, msg = v_message
               where id = C_AwardWait.id;
              GOTO CONTINUE_LOOP;
            end if;
          end if;
        
          --  以上判断均通过后，不管是由谁发奖，流水表都插入一条记录
        
          --判断是否为老用户
          if v_isOld is null then
            select count(1)
              into v_n
              from ad_app_bind
             where adid != C_AwardWait.adid
               and userid = C_AwardWait.Userid
               and pagename = v_Pagename
               and ustatus in (2, 3);
            if v_n > 0 then
              v_isOld := 1;
            else
              v_isOld := 0;
            end if;
          end if;
        
          insert into ad_app_flux
            (id,
             adid,
             appid,
             deviceid,
             appsign,
             dlevel,
             merid,
             money,
             event,
             adtype,
             atype,
             simid,
             urlid,
             price,
             userid,
             ptype,
             /*adclass,*/
             ownuser,
             isold)
            select SQ_AD_FLUX.NEXTVAL,
                   C_AwardWait.adid,
                   C_AwardWait.appid,
                   C_AwardWait.Deviceid,
                   C_AwardWait.Appsign,
                   C_AwardWait.Dlevel,
                   C_AwardWait.Merid,
                   C_AwardWait.Amoney,
                   v_Event,
                   v_adtype,
                   v_Atype,
                   C_AwardWait.simid,
                   v_Urlid,
                   v_Price,
                   C_AwardWait.Userid,
                   C_AwardWait.Ptype,
                   /*v_adClass,*/
                   v_OwnUser,
                   v_isOld
              from dual
             where (select count(1)
                      from ad_app_flux
                     where adid = C_AwardWait.adid
                       and (userid = C_AwardWait.Userid or
                           deviceid = upper(C_AwardWait.Deviceid))
                       and dlevel = C_AwardWait.Dlevel) < v_awardTimes;
        
          --如果奖励状态是可显示的才发奖
          if V_awardIsShow = 1 then
            if v_AwardOf = 1 then
              /* -------------------------
              由渠道发奖,则插入订单表
              --------------------------*/
              --生成订单号
              v_ordernum := C_AwardWait.appid ||
                            to_char(sysdate, 'yyyymmddhh24miss') ||
                            C_AwardWait.adid || dbms_random.string('x', 5) ||
                            trunc(dbms_random.value(0, 10));
            
              insert into ad_channel_order
                (adid,
                 adname,
                 appid,
                 ordernum,
                 dlevel,
                 awardgroup,
                 pagename,
                 deviceid,
                 simid,
                 appsign,
                 merid,
                 mername,
                 event,
                 price,
                 money)
              values
                (C_AwardWait.adid,
                 v_ADname,
                 C_AwardWait.appid,
                 v_ordernum,
                 C_AwardWait.dlevel,
                 C_AwardWait.awardgroup,
                 v_Pagename,
                 C_AwardWait.deviceid,
                 C_AwardWait.simid,
                 C_AwardWait.appsign,
                 C_AwardWait.merid,
                 C_AwardWait.mername,
                 v_adname || v_Event,
                 v_Price,
                 C_AwardWait.amoney);
              v_result  := 0;
              v_message := '渠道发奖成功';
              update ad_award_wait
                 set status = 2, utime = sysdate, msg = v_message
               where id = C_AwardWait.id
                 and status = 1;
              commit;
            end if;
            if v_AwardOf = 2 then
            
              --由闲玩发奖，则增加主库的用户余额
              v_Remark := v_ADname || '，完成奖励【' || v_Event || '】';
            
              xiquad_box.p_ad_award.PW_ReWard(i_userid   => C_AwardWait.Userid,
                                              i_money    => C_AwardWait.amoney,
                                              i_type     => 0,
                                              i_remark   => v_Remark,
                                              i_deviceid => C_AwardWait.deviceid,
                                              i_appid    => C_AwardWait.appid,
                                              i_appsign  => C_AwardWait.appsign,
                                              I_Internal => v_integral,
                                              I_Ptype    => v_ptype,
                                              I_Owner    => v_OwnUser,
                                              o_result   => v_result,
                                              o_message  => v_message);
              if v_result = 0 then
                update ad_award_wait
                   set status = 2, utime = sysdate, msg = '闲玩奖励成功'
                 where id = C_AwardWait.id
                   and status = 1;
              else
                update ad_award_wait
                   set status = 3, utime = sysdate, msg = '奖励失败'
                 where id = C_AwardWait.id
                   and status = 1;
              end if;
            
            end if;
            goto CONTINUE_LOOP;
          end if;
        
          <<CONTINUE_LOOP>>
          commit;
          --单条异常处理
        exception
          when others then
            rollback;
            v_message := '奖励异常 编码：' || SQLCODE || '信息 ：' || sqlerrm;
            update ad_award_wait
               set status = 3, utime = sysdate, msg = v_message
             where id = C_AwardWait.id;
            commit;
        end;
      end loop;
    end;
  exception
    when others then
      rollback;
      return;
  end Job_AwardWaitCheck_v2;

  Procedure Job_AwardWaitCheck_v3
  /*****************************************************************
        procedure name: Job_AutoCheck
        purpose: 奖励等待表处理 （生成流水记录和订单表记录）
       edit: 2019-08-20 Add by 文浩
    ****************************************************************/
   is
    v_adminPhone_s  varchar2(50); --超级管理员手机号
    v_n             number;
    v_AwardOf       number; --奖励渠道 1:渠道发奖，2：闲玩发奖
    v_awardTimes    number; -- 单步奖励的奖励次数
    v_Event         varchar2(500); -- 奖励描述
    v_Adtype        number; --广告类型
    v_ChannelStatus number; --渠道状态
    v_OwnUser       number; --是否是自由用户 0：不是  1：是
    v_Atype         number; --奖励类型：1-注册 ； 2-等级/首冲固定奖励 ； 3-充值理财百分比奖励； 4-安装奖励； 5-当天签到奖励； 9-VIP或首充
    /*v_adClass       number; --广告类型 1：CPL广告 2：CPA广告*/
    v_Urlid         number; --下载链接id
    v_Price         number; --结算金额
    v_MoneyWait     number; --30分钟内等待表累计奖励金额
    v_MoneyFlux     number; --30分钟内累计流水表奖励金额
    v_batchid       varchar2(50);
    v_Matketer      varchar2(50); --广告所属市场人员
    v_MatketerPhone varchar2(50); --市场人员手机号
    v_msgContent    varchar2(100); --短信内容
    V_awardIsShow   number; --是否显示该奖励 0否 1是【如果为否，则该奖励不会给渠道推送】
    v_ADname        Varchar2(100); --广告名称
    v_ordernum      varchar2(50); --订单号
    v_Pagename      Varchar2(100); --包名
    v_Remark        varchar2(2000);
    v_result        number;
    v_message       varchar2(200);
    v_integral      number; --是否是有积分   1有积分   0无积分
    v_ptype         number;
    v_isOld         number; --是否为老用户 0否 1是 
    v_adid          number; --18年无积分adid
  begin
    v_adminPhone_s := '18758009397'; --小沈手机号
    --默认由渠道发奖
    v_AwardOf := 1;
    --默认奖励是显示的
    V_awardIsShow := 1;
    v_Pagename    := '';
    --默认为有积分
    v_integral := 1;
    ----------------------------------------------------
    --步骤一：初始化
    ----------------------------------------------------
    select count(1)
      into v_n
      from ad_award_wait
     where itime > sysdate - 1 / 12
       and status = 1;
    --如果有数据还正在处理则此次job不做处理
    if v_n > 0 then
      return;
    end if;
    declare
      cursor AwardWait_List is
        select id,
               adid,
               appid,
               deviceid,
               userid,
               ptype,
               simid,
               appsign,
               merid,
               mername,
               ulevel,
               amoney,
               dlevel,
               needlevel,
               awardgroup,
               batchid,
               status
          from ad_award_wait
         where batchid = v_batchid
           and status = 1
         order by itime asc;
    
    begin
      --使用随机数和日期组合批次号
      select dbms_random.string('a', 5) into v_batchid from dual;
      v_batchid := to_char(sysdate, 'yyyymmddhh24miss') || v_batchid;
    
      --每次处理100条
      update ad_award_wait
         set batchid = v_batchid, status = 1, utime = sysdate
       where status = 0
         and id in (select id
                      from (select id
                              from ad_award_wait
                             where status = 0
                               and itime >= sysdate - 0.5
                             order by itime asc)
                     where rownum <= 100);
      commit;
    
      for C_AwardWait in AwardWait_List loop
        v_awardTimes := 0;
        v_Event      := '';
        v_message    := '';
        begin
        
          --查看用户是否被限制
          --设备号限制表判断
          select count(1)
            into v_n
            from ad_limit_deviceid
           where adid = C_AwardWait.adid
             and deviceid = C_AwardWait.Deviceid;
        
          if v_n > 0 then
            --修改状态为系统审核不通过
            v_result  := -2;
            v_message := '用户设备号被限制！';
            update ad_award_wait
               set status = 6, utime = sysdate, msg = v_message
             where id = C_AwardWait.id;
            GOTO CONTINUE_LOOP;
          end if;
        
          --设备号限制表判断
          select count(1)
            into v_n
            from ad_limit_user
           where adid = C_AwardWait.adid
             and userid = C_AwardWait.Userid;
          if v_n > 0 then
            --修改状态为系统审核不通过
            v_result  := -2;
            v_message := '闲玩用户被限制！';
            update ad_award_wait
               set status = 6, utime = sysdate, msg = v_message
             where id = C_AwardWait.id;
            GOTO CONTINUE_LOOP;
          end if;
        
          if v_n > 0 then
            --修改状态为系统审核不通过
            v_result  := -2;
            v_message := '用户设备号被限制！';
            update ad_award_wait
               set status = 6, utime = sysdate, msg = v_message
             where id = C_AwardWait.id;
            GOTO CONTINUE_LOOP;
          end if;
        
          --判断是否在18年无积分领取过
          /*          select count(1)
            into v_n
            from ad_relate@xwanad_link
           where adid_wall = C_AwardWait.adid;
          if v_n > 0 then
            select adid
              into v_adid
              from ad_relate@xwanad_link
             where adid_wall = C_AwardWait.adid;
          
            --查看该广告是否领取过
            select count(1)
              into v_n
              from ad_award_detail@xwanad_link
             where adid = v_adid
               and dlevel = C_AwardWait.dlevel
               and merid = C_AwardWait.merid;
          
            if v_n > 0 then
              update ad_award_wait
                 set status       = 3,
                     msg          = '已在无积分渠道领取过奖励',
                     utime  = sysdate
               where id = C_AwardWait.id
                 and status in (0, 1);
              commit;
              goto CONTINUE_LOOP;
            end if;
          
          end if;*/
          --判断是否在18年无积分领取过 end
        
          select nvl(times, 0), event, atype, price, isshow
            into v_awardTimes, v_Event, v_Atype, v_Price, V_awardIsShow
            from (select times, event, atype, price, isshow
                    from ad_awardset
                   where adid = C_AwardWait.adid
                     and appid = C_AwardWait.appid
                     and dlevel = C_AwardWait.dlevel
                  union all
                  select null, null, null, null, null from dual)
           where rownum = 1;
        
          select count(1)
            into v_n
            from ad_app_flux
           where adid = C_AwardWait.adid
             and (userid = C_AwardWait.userid or
                 deviceid = upper(C_AwardWait.Deviceid))
             and dlevel = C_AwardWait.dlevel;
        
          --如果该设备已经获取过该奖励则跳过
          if v_n >= v_awardTimes then
          
            --修改状态为系统审核不通过
            v_result  := -2;
            v_message := '已获得过奖励了';
            update ad_award_wait
               set status = 6, utime = sysdate, msg = v_message
             where id = C_AwardWait.id;
            GOTO CONTINUE_LOOP;
          end if;
        
          select count(1)
            into v_n
            from ad_app_bind
           where adid = C_AwardWait.adid
             and appid = C_AwardWait.appid
             and userid = C_AwardWait.userid;
          if v_n = 0 then
            --修改状态为不通过
            v_result  := -2;
            v_message := '绑定记录不存在，发奖失败';
            update ad_award_wait
               set status = 6, utime = sysdate, msg = v_message
             where id = C_AwardWait.id;
            GOTO CONTINUE_LOOP;
          end if;
          select nvl(integral, 1), nvl(atype, 2)
            into v_integral, v_ptype
            from (select integral, atype
                    from ad_channel
                   where appid = C_AwardWait.appid
                  union
                  select null, null from dual)
           where rownum = 1;
          ---连表获取相关参数
          select nvl(a.urlid, 0),
                 /*a.adclass,*/
                 a.pagename,
                 a.isold,
                 nvl(b.adtype, 1),
                 nvl(b.adname, ''),
                 nvl(c.isconversion , 0)
            into v_Urlid,
                 /*v_adClass,*/
                 v_Pagename,
                 v_isOld,
                 v_Adtype,
                 v_ADname,
                 v_ChannelStatus
            from ad_app_bind a
            left join ad_adinfo b
              on a.adid = b.adid
            left join ad_channel c
              on a.appid = c.appid
           where a.adid = C_AwardWait.adid
             and a.appid = C_AwardWait.appid
             and a.userid = C_AwardWait.userid;
        
          if v_integral = 1 then
            --查询有积分数据
            select nvl(ownuser, 0)
              into v_OwnUser
              from ad_app_users d
             where userid = C_AwardWait.userid;
          
          else
            v_OwnUser := 1;
          end if;
        
          --渠道是无积分渠道则，则由闲玩发奖 ,v_AwardOf=1为渠道发奖，2为闲玩发奖
          if v_integral = 2 then
            v_OwnUser := 1;
            v_AwardOf := 2;
          else
            if v_OwnUser = 1 then
              v_AwardOf := 2;
            else
              v_AwardOf := 1;
            end if;
          end if;
        
          --如果由闲玩发奖处理
          if v_AwardOf = 2 then
            --1、判断20分钟内的奖励金额是否超过1500,超过1500的全部设置为待审核，且发送短信提示
            select sum(amoney)
              into v_MoneyWait
              from ad_award_wait
             where itime > sysdate - 30 / (24 * 60)
               and adid = C_AwardWait.Adid
               and deviceid = C_AwardWait.Deviceid
               and status in (0, 1, 4);
          
            select sum(money)
              into v_MoneyFlux
              from ad_app_flux
             where itime > sysdate - 30 / (24 * 60)
               and adid = C_AwardWait.adid
               and deviceid = upper(C_AwardWait.Deviceid);
          
            if v_MoneyFlux + v_MoneyWait >= 1500 then
              update ad_award_wait
                 set status = 4,
                     utime  = sysdate,
                     msg    = '半小时累计奖励金额超过1500元，需要人工审核'
               where adid = C_AwardWait.Adid
                 and appid = C_AwardWait.Appid
                 and deviceid = C_AwardWait.Deviceid
                 and itime >= sysdate - 40 / (24 * 60)
                 and status in (0, 1);
              commit;
            
              select trim(marketer)
                into v_Matketer
                from ad_downurl
               where adid = C_AwardWait.Adid
                 and rownum = 1;
              --获取市场人员手机号   
              select nvl(phone, '')
                into v_MatketerPhone
                from (select phone
                        from t_admin
                       where name = v_Matketer
                      union all
                      select null from dual)
               where rownum = 1;
              --添加发送提示审核短信
              v_msgContent := '广告ID:' || C_AwardWait.Adid ||
                              '有由闲玩发奖的奖励需要审核';
              p_sms.pw_alarm_add(i_phone     => v_MatketerPhone,
                                 i_message   => v_msgContent,
                                 i_sendlevel => 1,
                                 i_sendtype  => 1,
                                 o_result    => v_result,
                                 o_message   => v_message);
            
              p_sms.pw_alarm_add(i_phone     => v_adminPhone_s,
                                 i_message   => v_msgContent,
                                 i_sendlevel => 1,
                                 i_sendtype  => 1,
                                 o_result    => v_result,
                                 o_message   => v_message);
              --修改状态为不通过
              v_result  := -2;
              v_message := '奖励超过1500元，需要审核';
              update ad_award_wait
                 set status = 4, utime = sysdate, msg = v_message
               where id = C_AwardWait.id;
              GOTO CONTINUE_LOOP;
            end if;
          end if;
        
          --  以上判断均通过后，不管是由谁发奖，流水表都插入一条记录
        
          --判断是否为老用户
          if v_isOld is null then
            select count(1)
              into v_n
              from ad_app_bind
             where adid != C_AwardWait.adid
               and userid = C_AwardWait.Userid
               and pagename = v_Pagename
               and ustatus in (2, 3);
            if v_n > 0 then
              v_isOld := 1;
            else
              v_isOld := 0;
            end if;
          end if;
        
          insert into ad_app_flux
            (id,
             adid,
             appid,
             deviceid,
             appsign,
             dlevel,
             merid,
             money,
             event,
             adtype,
             atype,
             simid,
             urlid,
             price,
             userid,
             ptype,
             /*adclass,*/
             ownuser,
             isold)
            select SQ_AD_FLUX.NEXTVAL,
                   C_AwardWait.adid,
                   C_AwardWait.appid,
                   C_AwardWait.Deviceid,
                   C_AwardWait.Appsign,
                   C_AwardWait.Dlevel,
                   C_AwardWait.Merid,
                   C_AwardWait.Amoney,
                   v_Event,
                   v_adtype,
                   v_Atype,
                   C_AwardWait.simid,
                   v_Urlid,
                   v_Price,
                   C_AwardWait.userid,
                   C_AwardWait.Ptype,
                   /*v_adClass,*/
                   v_OwnUser,
                   v_isOld
              from dual
             where (select count(1)
                      from ad_app_flux
                     where adid = C_AwardWait.adid
                       and (userid = C_AwardWait.Userid or
                           deviceid = upper(C_AwardWait.Deviceid))
                       and dlevel = C_AwardWait.Dlevel) < v_awardTimes;
        
          --如果奖励状态是可显示的才发奖
          if V_awardIsShow = 1 then
            if v_AwardOf = 1 then
              /* -------------------------
              由渠道发奖,则插入订单表
              --------------------------*/
              --生成订单号
              v_ordernum := C_AwardWait.appid ||
                            to_char(sysdate, 'yyyymmddhh24miss') ||
                            C_AwardWait.adid || dbms_random.string('x', 5) ||
                            trunc(dbms_random.value(0, 10));
            
              insert into ad_channel_order
                (adid,
                 adname,
                 appid,
                 ordernum,
                 dlevel,
                 awardgroup,
                 pagename,
                 deviceid,
                 simid,
                 appsign,
                 merid,
                 mername,
                 event,
                 price,
                 money)
              values
                (C_AwardWait.adid,
                 v_ADname,
                 C_AwardWait.appid,
                 v_ordernum,
                 C_AwardWait.dlevel,
                 C_AwardWait.awardgroup,
                 v_Pagename,
                 C_AwardWait.deviceid,
                 C_AwardWait.simid,
                 C_AwardWait.appsign,
                 C_AwardWait.merid,
                 C_AwardWait.mername,
                 v_adname || v_Event,
                 v_Price,
                 C_AwardWait.amoney);
              v_result  := 0;
              v_message := '渠道发奖成功';
              update ad_award_wait
                 set status = 2, utime = sysdate, msg = v_message
               where id = C_AwardWait.id
                 and status = 1;
              commit;
            end if;
            if v_AwardOf = 2 then
                insert into xiquad_box.TA_AWARD_WAIT
                  (id,
                   adid,
                   appid,
                   deviceid,
                   userid,
                   ptype,
                   simid,
                   appsign,
                   merid,
                   mername,
                   ulevel,
                   amoney,
                   dlevel,
                   needlevel,
                   awardgroup,
                   itime,
                   batchid,
                   status,
                   msg,
                   remark,
                   adminname,
                   utime)
                  select xiquad_box.sq_ta_award_wait.NEXTVAL as id,
                         adid,
                         appid,
                         deviceid,
                         0,
                         ptype,
                         simid,
                         appsign,
                         merid,
                         mername,
                         ulevel,
                         amoney,
                         dlevel,
                         needlevel,
                         awardgroup,
                         sysdate,
                         batchid,
                         0,
                         msg,
                         v_adname || v_Event,
                         adminname,
                         utime
                    from ad_award_wait
                   where id = C_AwardWait.id;

            
              update ad_award_wait
                 set status = 2, utime = sysdate, msg = '已推送给盒子发奖'
               where id = C_AwardWait.id
                 and status = 1;
              commit;
            end if;
            goto CONTINUE_LOOP;
          end if;
        
          <<CONTINUE_LOOP>>
          commit;
          --单条异常处理
        exception
          when others then
            rollback;
            v_message := '奖励异常 编码：' || SQLCODE || '信息 ：' || sqlerrm;
            update ad_award_wait
               set status = 3, utime = sysdate, msg = v_message
             where id = C_AwardWait.id;
            commit;
        end;
      end loop;
    end;
  exception
    when others then
      rollback;
      return;
  end Job_AwardWaitCheck_v3;

end P_Job_ADAward;
/


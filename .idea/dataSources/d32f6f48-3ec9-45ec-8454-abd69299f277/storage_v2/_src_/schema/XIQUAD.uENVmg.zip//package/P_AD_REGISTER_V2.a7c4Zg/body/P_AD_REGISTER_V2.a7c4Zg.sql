create package body P_AD_Register_V2 is

  /*广告主注册信息*/

  procedure PW_Back_Reg
  /*****************************************************************
        Procedure Name :PW_Back_Reg
        Purpose: 广告主返回注册信息
        Edit: 2018-04-12 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告id
   I_FID       In Varchar2, --广告主统计的来源id[apk渠道编号]
   I_DeviceId  In Varchar2, --返回设备号imei idfa
   I_SIMID     In Varchar2, --返回sim卡id
   I_UserId    In Varchar2, --用户注册帐号id
   I_Name      In Varchar2, --用户注册帐号
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    v_n        Number;
    v_Deviceid varchar2(100); --设备号
    v_ptype    Number; --1、ios  2、安卓
    v_userid   Number; --闲玩用户ID
    v_appid    Number; --渠道合作编号
    v_appsign  Varchar2(200); --渠道合作编号
    v_status   Number; --匹配状态 0 失败 ； 1  成功
    v_amoney   Number; --奖励金额
    v_result   Number; --
    v_message  Varchar2(100); --
    v_record   Number := 0; --之前是否已有记录 0否 1是
    v_isChange NUmber := 0; --是否修改成功

  begin
    o_result  := 0;
    o_message := '接收成功';
    v_status  := 0;
    v_appid   := 0;
    v_appsign := '0';
    open O_OUTCURSOR for
      select 1 from dual where 1 = 2;
  
    --去空格处理
    v_DeviceId := fq_str_delspace(i_str => I_Deviceid);
  
    select count(1)
      into v_n
      from ad_adv_back_reg
     where adid = I_ADID
       and userid = I_UserId;
  
    if v_n > 0 then
      v_record := 1;
      --判断是否已匹配
      select count(1)
        into v_n
        from ad_adv_back_reg
       where adid = I_ADID
         and userid = I_UserId
         and status = 1;
      --如果存在且已匹配成功
      if v_n > 0 then
        open O_OUTCURSOR for
          select I_DeviceId as deviceid,
                 v_appsign  as appsign,
                 v_amoney   as amoney
            from dual;
      
        o_result  := 0;
        o_message := '该用户信息已记录！';
        return;
      end if;
    end if;
  
    --查看设备号是否有点击记录 且帐号未返回
  
    select count(1)
      into v_n
      from ad_app_bind
     where adid = I_ADID
       and deviceid = v_DeviceId
       and ustatus = 1;
    --如果没匹配到，则尝试判断是否为老用户用新手机体验了该广告
    if v_n <= 0 then
      v_isChange := p_ad_register_v2.fq_changedeviceid(i_adid     => i_adid,
                                                       i_deviceid => i_deviceid,
                                                       i_userid   => i_userid);
    
      if v_isChange = 1 then
        select count(1)
          into v_n
          from ad_app_bind
         where adid = I_ADID
           and deviceid = v_DeviceId
           and ustatus = 1;
      end if;
    end if;
  
    if v_n > 0 then
      select appid, appsign, userid, ptype
        into v_appid, v_appsign, v_userid, v_ptype
        from ad_app_bind
       where adid = I_ADID
         and deviceid = v_DeviceId;
      v_status := 1;
    
    end if;
  
    if v_record = 0 then
      
      --添加
      insert into ad_adv_back_reg
        (adid,
         fid,
         appid,
         appsign,
         deviceid,
         simid,
         userid,
         name,
         status,
         lasttime)
      values
        (I_adid,
         I_FID,
         v_appid,
         v_appsign,
         v_DeviceId,
         I_SIMID,
         I_UserId,
         I_Name,
         v_status,
         sysdate);
    
    end if;
  
    commit;
  
    --如果匹配成功 则 进行注册奖励
    --匹配状态 0 失败 ； 1  成功
    if v_status = 1 then
    
      --如果是之前有返回帐号信息的，后来重新匹配上的 则需要修改 【一般出现在有注册返回和注册查询接口 的情况】
      if v_record = 1 then
        --修改原先匹配帐号信息
        update ad_adv_back_reg
           set deviceid = v_DeviceId,
               appid    = v_appid,
               appsign  = v_appsign,
               status   = v_status,
               lasttime = sysdate
         where adid = I_adid
           and userid = I_UserId;
      end if;
    
      select count(1)
        into v_n
        from ad_app_bind
       where adid = I_adid
         and appid = v_appid
         and ustatus = 1
         and deviceid = v_DeviceId;
    
      if v_n > 0 then
        update ad_app_bind
           set merid    = I_UserId,
               mername  = I_Name,
               ustatus  = 3,
               lasttime = sysdate
         where adid = I_adid
           and appid = v_appid
           and ustatus = 1
           and deviceid = v_DeviceId;
      
        commit;
      
        p_ad_award_main.pq_allmain(i_adid     => i_adid,
                                      i_appid    => v_appid,
                                      i_deviceid => i_deviceid,
                                      i_simid    => i_simid,
                                      i_userid   => v_userid,
                                      i_ptype    => v_ptype,
                                      i_merid    => I_UserId,
                                      i_mername  => I_Name,
                                      i_levle    => 0, --注册为0等级
                                      i_atype    => 1, --  发奖类型 1 按固定值发放
                                      i_agroup   => 1, --注册为第一组别
                                      o_amoney   => v_amoney,
                                      o_result   => v_result,
                                      o_message  => v_message);
        commit;
      end if;
    
    end if;
  
    open O_OUTCURSOR for
      select I_DeviceId as deviceid,
             v_appsign  as appsign,
             v_amoney   as amoney
        from dual;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 1001;
      O_Message := '接收异常！';
      -- o_message := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_Back_Reg;

  function FQ_ChangeDeviceid
  /*****************************************************************
    过程名称：修改绑定表为注册信息设备号
    创建日期：2018-06-12 add by 小沈
    返回：修改是否成功 0：否 1：是
    ****************************************************************/
  (I_ADID     In Number, --广告id 
   I_DeviceId In Varchar2, --返回设备号imei idfa
   I_UserId   In Varchar2 --用户注册帐号id
   ) return Number --返回修改是否成功 0：否 1：是
   is
    v_n        number;
    v_adidlist varchar(100); --上一期广告id集合 合作过多期 120,130,140 使用逗号隔开  
    v_bindID   number := 0; --绑定ID 
    v_XWUserid number := 0; --新一期注册闲玩用户ID
  begin
    --判断是否有老用户接口
    select count(1) into v_n from ad_interf_olduser where adid = I_ADID;
    if v_n <= 0 then
      return 0;
    end if;
  
    select adid_list
      into v_adidlist
      from ad_interf_olduser
     where adid = I_ADID;
  
    ---根据帐号查找闲玩用户ID ----> 判断当前广告该闲玩ID是否有参与----->注册时的设备号与当前广告设备号是否一致，不一致则修改当前广告设备号
  
    --判断用户是否为老用户 
    execute immediate ' select nvl(max(id),0) from ad_app_bind where adid in (' ||
                      v_adidlist || ') and merid =  ''' || I_UserId ||
                      '''  and ustatus in (2, 3)'
      into v_bindID;
    --如果没有老用户记录则返回
    if v_bindID <= 0 then
      return 0;
    end if;
  
    ---查询老一期体验时的闲玩用户ID 
    select userid into v_XWUserid from ad_app_bind where id = v_bindID;
    --判断当前广告该闲玩ID是否有参与
    select count(1)
      into v_n
      from ad_app_bind
     where adid = I_ADID
       and userid = v_XWUserid
       and ustatus = 1;
  
    if v_n < 0 then
      return 0;
    end if;
  
    --判断注册设备号和用户开始任务设备号是否一致，不一致则修改
    select count(1)
      into v_n
      from ad_app_bind
     where adid = I_ADID
       and userid = v_XWUserid
       and ustatus = 1
       and deviceid = I_DeviceId;
  
    if v_n < 0 then
      update ad_app_bind
         set deviceid = I_DeviceId
       where adid = I_ADID
         and userid = v_XWUserid
         and ustatus = 1;
      commit;
      return 1;
    end if;
  
    return 0;
  
  exception
    when others then
      return 0;
  end FQ_ChangeDeviceid;

  procedure PW_Select_Reg
  /*****************************************************************
        Procedure Name :PW_Select_Reg
        Purpose: 闲玩主动查询注册信息值记录
        Edit: 2018-06-12 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告id
   I_FID      In Varchar2, --广告主统计的来源id[apk渠道编号]
   I_DeviceId In Varchar2, --注册设备号imei idfa
   I_SIMID    In Varchar2, --返回sim卡id
   I_Merid    In Varchar2, --用户注册帐号id
   I_MerName  In Varchar2, --用户注册帐号
   I_XWUserid In Number, --闲玩用户ID 
   O_Result   Out Number,
   O_Message  Out Varchar2) is
    v_n         Number;
    v_Deviceid  varchar2(100); --设备号 
    v_OutCursor t_cursor; --返回游标
  begin
    o_result  := 0;
    o_message := '接收成功';
  
    --去空格处理
    v_DeviceId := fq_str_delspace(i_str => I_Deviceid);
  
    --判断注册成功设备号与实际绑定设备号是否一致,如果不一致则修改为注册设备号；
    select count(1)
      into v_n
      from ad_app_bind
     where adid = I_ADID
       and userid = I_XWUserid
       and deviceid != v_DeviceId
       and ustatus = 1;
    if v_n > 0 then
      update ad_app_bind
         set deviceid = v_DeviceId, simid = I_SIMID
       where adid = I_ADID
         and userid = I_XWUserid
         and deviceid != v_DeviceId
         and ustatus = 1;
      commit;
    end if;
  
    p_ad_register_v2.pw_back_reg(i_adid      => i_adid,
                                 i_fid       => i_fid,
                                 i_deviceid  => v_DeviceId,
                                 i_simid     => i_simid,
                                 i_userid    => I_Merid,
                                 i_name      => I_MerName,
                                 o_outcursor => v_outcursor,
                                 o_result    => O_Result,
                                 o_message   => O_Message);
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 1001;
      O_Message := '接收异常！';
      -- o_message := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_Select_Reg;

end P_AD_Register_V2;
/


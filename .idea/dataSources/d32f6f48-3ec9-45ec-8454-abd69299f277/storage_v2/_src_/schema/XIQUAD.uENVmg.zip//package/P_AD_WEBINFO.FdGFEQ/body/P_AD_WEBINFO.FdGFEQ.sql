create PACKAGE BODY P_AD_WebInfo AS

  /*广告页面详情_2.0 版本 */

  procedure PQ_ADInfo
  /*****************************************************************
        Procedure Name :PQ_ADInfo
        Purpose: 获取广告详细信息
        Edit: 2018-04-09 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   I_APPId     In Number, --渠道应用ID
   I_Deviceid  In Varchar2, --设备号ID
   I_SIMID     In Varchar2, --sim卡编号
   I_Userid    In Number, --闲玩用户编号
   I_PType     In Number, --1、ios  2、安卓
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number, --判断 0：查询成功，其他：出错
   O_Message   Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n             Number;
    V_ADName        Varchar2(200); --广告标题
    V_Imgurl        Varchar2(500); --广告小图片地址
    V_Status        Number; --投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放）
    V_APPSize       Varchar2(50); --文件大小
    V_ShowMoney     Varchar2(100); --显示奖励金额
    V_Intro         Varchar2(100); --广告简介
    V_Description   Varchar2(1000); --广告介绍描述
    V_DesImgUrls    Varchar2(500); --广告图片描述
    V_Pagename      Varchar2(100); --包名
    V_IosPagename   Varchar2(100); --IOS 包名
    V_IosUrlSchemes Varchar2(100); --ios用于打开app应用的 url schemes 
    V_IosProname    Varchar2(100); --ios 进程名称 processname 
    V_AppSign       Number; --绑定方式 0、下载绑定 1、账号返回 2、自助提交  3、下载安装返回
    V_MsgNoInstall  Varchar2(500); --未安装提示-无需下载app则提示和未注册一致
    V_MsgNoReg      Varchar2(500); --未注册提示
    V_MsgReg        Varchar2(500); --已注册提示
    V_MsgDayLimit   Varchar2(500); --日限量提示信息
    V_MsgAllLimit   Varchar2(500); --到量提示信息
    V_ButtonShow    Number; --是否显示正常体验按钮 默认正常显示
    V_ButtonName    Varchar2(50); --试玩按钮名称
    V_IsShow        Number; -- 是否显示 0 不显示 1 显示
  
    v_ShowMsg  varchar2(500); --展示信息
    v_Bind     number; --是否绑定 0 否 1 是
    v_Deviceid varchar2(100); --注册设备号
    v_MerId    varchar2(100); -- 商家帐号id/sim卡编号
    v_MerName  varchar2(100); --商家帐号名称/sim卡编号
  
    V_UStatus   number; --用户体验状态 1：下载； 2：用户已提交； 3：商家成功返回；  【不可有状态 0 】  ；
    v_StartTime varchar2(50); --广告投放日期
    v_StopTime  varchar2(50); --广告停止日期
    v_NowDate   varchar2(50) := to_char(sysdate, 'yyyy-mm-dd hh24:mi'); --当前日期
    v_GameInfo  varchar2(200); --游戏信息
    v_Amoney    number := 0; --已获得金额
    v_unit      varchar2(50); --货币单位描述 默认元
    v_rate      number; --货币与人名币比率 1：1
  begin
    O_Result  := 0;
    O_Message := '查询成功';
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
    v_bind       := 0;
    v_Deviceid   := '';
    v_IsShow     := 0; -- 是否显示 0 不显示 1 显示
    v_merid      := '';
    v_mername    := '';
    V_UStatus    := 0; --用户体验状态 0：下载； 1：用户已提交； 2：商家成功返回；
    V_ShowMoney  := '0';
    V_ButtonShow := 0; --默认不显示，如果所有校验都通过则显示
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
  
    if I_Userid is null or I_Userid = 0 then
      O_Result  := 1;
      O_Message := '请先登录APP';
      return;
    end if;
  
    if I_Deviceid is null then
      O_Result  := 1;
      O_Message := '请先登录APP';
      return;
    end if;
  
    --去空格处理
    v_DeviceId := fq_str_delspace(i_str => I_Deviceid);
    --设备号校验是否合法 0否 1是
    if p_base_fun.fq_deviceid_check(v_DeviceId, I_PType) = 0 then
      O_Result  := 1;
      O_Message := '请先对APP进行授权';
      return;
    end if;
  
    if v_DeviceId is null then
      O_Result  := 1;
      O_Message := '需要先对APP进行授权';
      return;
    end if;
  
    if I_ADID is null then
      O_Result  := 2;
      O_Message := '请返回后刷新，再重新点击进入';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_adinfo
     where adid = I_ADID
       and phonetype in (I_PType, 3);
  
    if v_n <= 0 then
      O_Result  := 3;
      O_Message := '该任务不存在，请返回后选择其他任务';
      return;
    end if;
  
    select unit, rate
      into v_unit, v_rate
      from ad_channel
     where appid = I_APPId;
  
    select adname,
           imgurl,
           status,
           appsize,
           to_char(starttime, 'yyyy-mm-dd hh24:mi'),
           to_char(stoptime, 'yyyy-mm-dd hh24:mi'),
           intro,
           description,
           desimgurls, --广告图片描述
           pagename, --安卓应用的包名称
           iospagename, --ios应用程序名称 boundleid 
           iosurlschemes, --ios用于打开app应用的 url schemes 
           iosproname, --ios 进程名称 processname 
           appsign, --绑定方式 0、下载绑定 1、账号返回 2、自助提交  3、下载安装返回 
           buttonname, --试玩按钮名称ios应用程序名称 boundleid 
           msgnoinstall, --未安装提示-无需下载app则提示和未注册一致
           msgnoreg, --未注册、仅下载 提示
           msgreg, --已注册提示
           GameInfo, --用户游戏里面的信息用\n分割 帐号：fsfsfs\n充值金额：100元  
           msgdaylimit, --日限量提示信息
           msgalllimit --到量提示信息
      into v_adname,
           v_imgurl,
           v_status,
           v_appsize,
           v_StartTime,
           v_StopTime,
           V_Intro,
           v_description,
           v_desimgurls,
           v_pagename,
           V_IosPagename,
           V_IosUrlSchemes,
           V_IosProname,
           V_AppSign,
           v_buttonname,
           v_msgnoinstall,
           v_msgnoreg,
           v_msgreg,
           v_GameInfo,
           v_msgdaylimit,
           v_msgalllimit
      from ad_adinfo
     where adid = I_ADID;
  
    /*判断广告状态*/
  
    case v_status
      when 0 then
        v_ShowMsg := '该广告尚未投放，请先体验其他广告！';
        Goto Ending;
      when 4 then
        v_ShowMsg := '该广告尚已停止投放，请体验其他广告！';
        Goto Ending;
      else
        v_n := 0;
    end case;
  
    ---判断用户是否可以参与该广告
    -- 是否显示 0 不显示 1 显示
    v_IsShow := p_ad_isshow_v2.fq_isshow(i_adid     => i_adid,
                                         i_appid    => i_appid,
                                         i_deviceid => v_DeviceId,
                                         i_userid   => i_userid,
                                         i_ptype    => i_ptype);
  
    --如果广告为不显示，则判断是否因为广告状态原因，如果非广告状态原因则统一提示
    if v_IsShow = 0 then
      case v_status
        when 0 then
          v_ShowMsg := '该广告尚未投放，请先体验其他广告！';
        when 2 then
          v_ShowMsg := v_msgdaylimit;
        when 3 then
          v_ShowMsg := v_msgalllimit;
        when 4 then
          v_ShowMsg := '该广告尚已停止投放，请体验其他广告！';
        else
          v_ShowMsg := '您无法参与该广告，请返回后体验其他广告！';
      end case;
    
      Goto Ending;
    end if;
  
    --判断该用户是否参与过该广告 绑定记录只能是一个
    select count(1)
      into v_n
      from ad_app_bind
     where adid = I_ADID
       and appid = I_APPId
       and userid = i_userid;
  
    if v_n = 1 then
      v_bind := 1;
    elsif v_n > 1 then
      v_ShowMsg := '您暂时无法参与该广告，请返回后体验其他广告！';
      Goto Ending;
    else
      v_bind := 0;
    end if;
  
    --如果用户未绑定
    if v_bind = 0 then
      --显示未下载提示
      v_ShowMsg := V_MsgNoInstall;
    
      --如果用户已绑定过则获取用户先关信息
    elsif v_bind = 1 then
    
      select merid, mername, deviceid, ustatus
        into v_merid, v_mername, v_Deviceid, v_ustatus
        from ad_app_bind
       where adid = I_ADID
         and appid = I_APPId
         and userid = i_userid;
    
      -- v_appsign ：绑定方式 0、下载绑定 1、账号返回 2、自助提交  3、下载安装返回 
      -- v_ustatus： 用户体验状态 1：下载； 2：用户已提交； 3：商家成功返回；  【不可有状态 0 】
      --如果 广告设置 为 非下载绑定  且 用户状态为 下载状态 则 提示用户的 为 未注册提示
    
      if v_appsign in (1, 2, 3) and v_ustatus = 1 then
        v_ShowMsg := V_MsgNoReg;
      else
        v_ShowMsg := V_MsgReg;
      end if;
    
      v_ShowMsg := replace(v_ShowMsg, '[MerID]', v_merid); --替换账号ID
      v_ShowMsg := replace(v_ShowMsg, '[MerName]', v_mername); --替换账号
    
      select count(1)
        into v_n
        from ad_app_flux
       where adid = I_ADID
         and appid = I_APPId
         and userid = i_userid;
    
      if v_n > 0 then
        select nvl(sum(money), 0)
          into v_Amoney
          from ad_app_flux
         where adid = I_ADID
           and appid = I_APPId
           and userid = i_userid;
      
        v_Amoney := v_Amoney * v_rate;
      
      end if;
    
    end if;
  
    V_ShowMoney := p_ad_showmoney_v2.fq_userid(i_adid     => i_adid,
                                               i_appid    => i_appid,
                                               i_adstatus => v_status,
                                               i_deviceid => v_DeviceId,
                                               i_userid   => i_userid,
                                               i_ptype    => i_ptype);
  
    V_ShowMoney := substr(V_ShowMoney, instr(V_ShowMoney, '_') + 1);
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
    V_ButtonShow := 1; --如果所有校验都通过则显示
  
    <<Ending>>
    null;
  
    OPEN O_OutCursor FOR
      select i_adid          as adid,
             V_ADName        as adname, --广告标题
             V_Imgurl        as imgurl, --广告小图片地址
             V_Status        as status, --投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放）
             V_APPSize       as appsize, --文件大小
             v_StartTime     as StartTime, --投放日期
             v_StopTime      as StopTime, --停止日期
             v_NowDate       as NowDate, --当前日期
             V_ShowMoney     as ShowMoney, --显示奖励金额
             V_Intro         as Intro, --广告简介
             V_Description   as Description, --广告介绍描述
             V_DesImgUrls    as DesImgUrls, --广告图片描述
             V_Pagename      as Pagename, --包名
             V_IosPagename   as IosPagename, --ios应用程序名称 boundleid 
             V_IosUrlSchemes as IosUrlSchemes, --ios用于打开app应用的 url schemes 
             V_IosProname    as IosProname, --ios 进程名称 processname 
             v_ShowMsg       as ShowMsg, --显示信息
             V_ButtonShow    as ButtonShow, --下载按钮和进度条是否显示（1显示，0不显示）
             V_ButtonName    as ButtonName, --试玩按钮名称
             v_Bind          as Bind, --是否绑定 0 否 1 是
             v_ustatus       as UStatus, --用户体验状态 1：下载； 2：用户已提交； 3：商家成功返回；  【不可有状态 0 】
             v_MerId         as MerId, --商家帐号id/sim卡编号
             v_MerName       as MerName, --商家帐号名称/sim卡编号
             v_Deviceid      as BindDeviceid, --用户绑定设备号
             v_GameInfo      as GameInfo, --游戏信息
             v_Amoney        as Amoney, --用户已获得奖励金额
             v_unit          as unit --货币单位
      
        from dual;
  
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
  
    return;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      ROLLBACK;
      O_Result  := -9;
      O_Message := '查询失败' || sqlerrm || sqlcode;
      RETURN;
  end PQ_ADInfo;

  procedure PQ_UserClick
  /*****************************************************************
        Procedure Name :PQ_UserClick
        Purpose: 用户点击操作
        Edit: 2018-04-11 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   I_APPId     In Number, --渠道应用ID
   I_Deviceid  In Varchar2, --设备号ID
   I_SIMID     In Varchar2, --sim卡编号
   I_Userid    In Number, --闲玩用户编号
   I_APPSign   In Varchar2, --渠道应用标识符号、渠道用户id
   I_PType     In Number, --1、ios  2、安卓
   I_IP        In Varchar2, --
   I_CType     In Number, --用户操作类型 1：下载  2：打开
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number, --判断 0：查询成功，其他：出错
   O_Message   Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    V_n           Number;
    v_Deviceid    varchar2(100); --注册设备号
    V_IsShow      Number; --是否显示 0 否  1是
    V_ADName      Varchar2(100); --前台显示广告名称
    V_PageName    Varchar2(100); --应用的包名称
    V_Status      Number;
    V_MsgDayLimit Varchar2(500); --日限量提示信息
    V_MsgAllLimit Varchar2(500); --到量提示信息
    V_UrlS        Number; --下载状态（0未使用，1正常使用，2日到量，3总到量，4停止使用）
    V_UrlId       Number; --下载编号
    V_APPUrl      Varchar2(500); --app下载链接 注册地址
    V_DownType    Number; --下载类型 0:直接下载 1：跳外部浏览器下载 
    V_PlaySecond  Number; --所需体验时间
    V_Description Varchar2(500); --所需要求描述
  
    V_Random  Number; --随机数
    V_DownCT  Number; --可用下载条数 
    v_result  number;
    v_message Varchar2(500);
  
  begin
    O_Result     := 0;
    O_Message    := '操作成功';
    V_Status     := 0;
    V_UrlId      := 0;
    V_PlaySecond := 0;
    V_DownType   := 0;
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
  
    if I_APPId = 1502 then
      o_result  := 0;
      o_message := '暂停下载';
      return;
    end if;
  
    if I_Userid is null or I_Userid = 0 then
      O_Result  := 1;
      O_Message := '请先登录APP';
      return;
    end if;
  
    if I_Deviceid is null then
      O_Result  := 1;
      O_Message := '请先登录APP';
      return;
    end if;
  
    --去空格处理
    v_DeviceId := fq_str_delspace(i_str => I_Deviceid);
    --设备号校验是否合法 0否 1是
    if p_base_fun.fq_deviceid_check(v_DeviceId, I_PType) = 0 then
      O_Result  := 1;
      O_Message := '请先对APP进行授权';
      return;
    end if;
  
    if v_DeviceId is null then
      O_Result  := 1;
      O_Message := '需要先对APP进行授权';
      return;
    end if;
  
    if I_ADID is null then
      O_Result  := 2;
      O_Message := '请返回后刷新，再重新点击进入';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_adinfo
     where adid = I_ADID
       and phonetype in (I_PType, 3);
  
    if v_n <= 0 then
      O_Result  := 3;
      O_Message := '该任务不存在，请返回后选择其他任务';
      return;
    end if;
  
    select adname, Status, pagename, msgdaylimit, msgalllimit
      into V_ADName, v_Status, V_PageName, V_MsgDayLimit, V_MsgAllLimit
      from ad_adinfo
     where adid = I_Adid;
  
    /*判断广告状态*/
  
    case v_status
      when 0 then
        O_Result  := 3;
        O_Message := '该广告尚未投放，请先体验其他广告！';
        return;
      
      when 4 then
        O_Result  := 3;
        O_Message := '该广告尚已停止投放，请体验其他广告！';
        return;
      else
        O_Result := 0;
    end case;
  
    ---判断用户是否可以参与该广告
    -- 是否显示 0 不显示 1 显示 
  
    v_IsShow := p_ad_isshow_v2.fq_isshow(i_adid     => i_adid,
                                         i_appid    => i_appid,
                                         i_deviceid => v_DeviceId,
                                         i_userid   => i_userid,
                                         i_ptype    => i_ptype);
  
    if v_IsShow = 0 then
      O_Result  := 4;
      O_Message := '您无法参与该广告，请返回后体验其他广告！';
      return;
    end if;
  
    --p_ad_isshow_v2 已判断一个设备多个帐号的情况
    --判断该用户是否参与过该广告
    select count(1)
      into v_n
      from ad_app_bind
     where adid = I_ADID
       and appid = I_APPId
       and userid = i_userid;
  
    if v_n = 0 then
      --老用户激活，需要卸载重装的游戏，会使用该方法，用户如果手机已安装了该APP，会提示用户先卸载 
      p_ad_olduser_v2.pw_olduser_click(i_adid     => i_adid,
                                       i_ptype    => i_ptype,
                                       i_deviceid => v_DeviceId,
                                       i_userid   => i_userid,
                                       o_result   => v_result,
                                       o_message  => v_message);
    
      if v_result = 0 then
        --判断用户是否激活成功并触发了绑定
        select count(1)
          into v_n
          from ad_app_bind
         where adid = I_ADID
           and appid = I_APPId
           and userid = i_userid;
      end if;
    
    end if;
  
    --如果用户没参与过
    if v_n = 0 then
    
      -- 如果用户未绑定
      ---广告到量状态提示
      case v_status
        when 2 then
          O_Result  := 3;
          O_Message := v_msgdaylimit;
          return;
        
        when 3 then
          O_Result  := 3;
          O_Message := V_MsgAllLimit;
          return;
        else
          O_Result := 0;
      end case;
    
      --查看下载地址数量
    
      select count(1)
        into V_DownCT
        from ad_downurl
       where adid = I_ADID
         and status = 1
         and phonetype in (I_PType, 3);
    
      if V_DownCT = 0 then
      
        O_Result  := 5;
        O_Message := '该广告暂时没有可用下载地址，请返回后体验其他广告！';
        return;
      
      elsif V_DownCT = 1 then
        --如果只有一个下载地址 则直接取
        select urlid, appurl, downtype
          into v_UrlId, v_APPUrl, V_DownType
          from ad_downurl
         where adid = I_ADID
           and status = 1
           and phonetype in (I_PType, 3);
      
      else
        --如果有多个下载地址则随机取
      
        select trunc(dbms_random.value(1, V_DownCT + 1))
          into V_Random
          from dual;
      
        select urlid, appurl, downtype
          into v_UrlId, v_APPUrl, V_DownType
          from (select urlid, appurl, downtype, rownum as rn
                  from ad_downurl
                 where adid = i_adid
                   and status = 1
                   and phonetype in (I_PType, 3))
         where rn = V_Random;
      
      end if;
    
      insert into ad_app_bind
        (id,
         adid,
         appid,
         deviceid,
         simid,
         appsign,
         merid,
         mername,
         pagename,
         urlid,
         ptype,
         ip,
         ustatus,
         lasttime,
         userid)
      values
        (SQ_ad_bind.Nextval,
         I_ADID,
         I_APPId,
         v_DeviceId,
         I_SIMID,
         I_APPSign,
         v_DeviceId,
         v_DeviceId,
         V_PageName,
         V_UrlId,
         I_PType,
         I_IP,
         1,
         sysdate,
         i_userid);
      commit;
    
    elsif v_n = 1 then
    
      --防止一个用户体验多个包
      select max(urlid)
        into v_UrlId
        from ad_app_bind
       where adid = I_ADID
         and userid = i_userid;
    
      select count(1)
        into v_n
        from ad_downurl
       where adid = I_ADID
         and urlid = v_UrlId;
    
      --获取该下载连接的状态
      -- 如果该状态非正常 说明该商家不投放了 ，这个链接下的用户也不在奖励
      if v_n > 0 then
        select status, appurl, downtype
          into v_UrlS, v_APPUrl, V_DownType
          from ad_downurl
         where adid = I_ADID
           and urlid = v_UrlId;
      else
        v_UrlS := 0;
      end if;
    
      --状态（0未使用，1正常使用，2日到量，3总到量，4停止使用）
      if v_UrlS in (0, 4) then
        O_Result  := 3;
        O_Message := '该广告尚未投放或已停止，请体验其他广告！';
        return;
      end if;
    
    else
      --如果 用户该 广告存在多条绑定记录
      O_Result  := 4;
      O_Message := '您暂时无法参与该广告，请返回后体验其他广告！';
      return;
    end if;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
    V_APPUrl := replace(V_APPUrl, '[deviceid]', v_DeviceId);
    OPEN O_OutCursor FOR
      select V_ADName      as ADName, --前台显示广告名称
             V_PageName    as PageName, --应用的包名称
             V_UrlId       as UrlId, --下载编号
             V_APPUrl      as APPUrl, --app下载链接 注册地址
             V_DownType    as DownType, ---下载类型 0:直接下载 1：跳外部浏览器下载
             V_PlaySecond  as PlaySecond, --所需体验时间
             V_Description as Description --所需要求描述
        from dual;
  
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    commit;
    return;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      ROLLBACK;
      O_Result  := -9;
      O_Message := '您已在其他地方下载过该APP，暂时无法继续体验！';
      RETURN;
  end PQ_UserClick;

  procedure PQ_AwardList
  /*****************************************************************
        Procedure Name :PQ_AwardList
        Purpose: 获取广告奖励列表
        Edit: 2018-04-11 add by 小沈
    ****************************************************************/
  (I_ADID           In Number, --广告ID
   I_APPId          In Number, --渠道应用ID
   I_Deviceid       In Varchar2, --设备号ID
   I_SIMID          In Varchar2, --sim卡编号
   I_Userid         In Number, --闲玩用户编号
   I_PType          In Number, --1、ios  2、安卓
   I_ATYPE          In Number, -- 奖励类型 1 普通 2充值和VIP
   O_Outrecordcount out number, --返回总记录数
   O_Outcursor      out t_cursor, --返回游标
   O_Result         out number, --判断 0：查询成功，其他：出错
   O_Message        out varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    V_SQL   varchar2(3000);
    V_SQL_S varchar2(200);
  
    v_Deviceid varchar2(100); --注册设备号
    V_Unit     varchar2(50); --货币单位描述 默认元
    V_Rate     number(10, 3); --货币与人名币比率 1：1
  
    v_isint    number := 0; --是否整数计算 0否1是  
    v_ischange number := 0; --是否开启货币转换 0：否 1：是
  
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
  
    if I_Userid is null or I_Userid = 0 then
      O_Result  := 1;
      O_Message := '请先登录APP';
      return;
    end if;
  
    if I_Deviceid is null then
      O_Result  := 1;
      O_Message := '请先登录APP';
      return;
    end if;
  
    --去空格处理
    v_DeviceId := fq_str_delspace(i_str => I_Deviceid);
    --设备号校验是否合法 0否 1是
    if p_base_fun.fq_deviceid_check(v_DeviceId, I_PType) = 0 then
      O_Result  := 1;
      O_Message := '请先对APP进行授权';
      return;
    end if;
  
    if v_DeviceId is null then
      O_Result  := 1;
      O_Message := '需要先对APP进行授权';
      return;
    end if;
  
    if I_ADID is null then
      O_Result  := 2;
      O_Message := '请返回后刷新，再重新点击进入';
      return;
    end if;
  
    if I_ATYPE = 1 then
      V_SQL_S := ' and a.atype not in (3,9)  ';
    elsif I_ATYPE = 2 then
      V_SQL_S := ' and a.atype in (3,9)  ';
    
    else
      V_SQL_S := '   ';
    end if;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
    select unit, rate, ischange, isint
      into V_Unit, V_Rate, v_ischange, v_isint
      from ad_channel
     where appid = I_APPId;
  
    V_SQL := ' select  adid,dlevel,event,p_base_fun.fq_monetaryunit(money,' ||
             v_ischange || ',2) money, ''' || V_Unit ||
             ''' as unit ,case when already_times<times then 1 else 2 end as trystatus ,needlevel,atype,awardgroup  ,rownum as rn
     from( 
    select a.adid, a.dlevel,a.event,a.needlevel,a.atype, a.awardgroup, a.times,case when ' ||
             v_isint || '=1 then  trunc((a.times*a.amoney)*' || V_Rate ||
             ')  else (a.times*a.amoney)*' || V_Rate ||
             ' end as Money  ,nvl(b.cnt, 0) already_times from ad_awardset a
      left join ( select adid, dlevel, count(1) cnt  from ad_app_flux  where adid = ' ||
             I_ADID || ' and userid = ' || I_Userid ||
             ' group by adid, dlevel) b
                        on a.adid = b.adid
                       and a.dlevel = b.dlevel
                     where a.adid =  ' || I_ADID || '
                       and a.appid =  ' || I_APPId || V_SQL_S || '  
                       order by  a.dlevel asc  )  ';
    execute immediate 'select count(1) from (' || V_SQL || ')'
      into O_Outrecordcount;
  
    OPEN O_OUTCURSOR FOR V_SQL;
  
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    commit;
    return;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      ROLLBACK;
      O_Result  := -9;
      O_Message := '查询失败';
      RETURN;
  end PQ_AwardList;

end P_AD_WebInfo;
/


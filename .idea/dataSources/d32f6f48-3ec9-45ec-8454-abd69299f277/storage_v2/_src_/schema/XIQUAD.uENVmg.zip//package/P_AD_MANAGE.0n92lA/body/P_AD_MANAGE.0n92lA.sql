create package body P_AD_Manage is

  /*广告信息添加*/

  procedure pq_AD_List
  /*****************************************************************
        Procedure Name :pq_AD_List
        Purpose: 广告列表
        Edit: 2016-12-05 add by 小沈
    ****************************************************************/
  (I_AdmInId        In Varchar2,
   I_ADID           In Number,
   I_ADName         In Varchar2,
   I_Status         In Number,
   I_ShowType       In Number,
   I_PhoneType      In Number,
   I_ADType         In Number,
   I_PageSize       In Number,
   I_PageNO         In Number,
   O_OutRecordCount Out Number,
   O_OutCursor      Out t_cursor, --返回游标
   O_Result         Out Number,
   O_Message        Out Varchar2) is
    v_sql       varchar2(2000);
    v_selectsql varchar2(1000);
    V_HEIROWNUM NUMBER;
    V_LOWROWNUM NUMBER;
    V_QX        NUMBER; --本模块的权限代码
  begin
    o_result  := 0;
    o_message := '显示成功';
    V_QX      := 104; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    v_sql := 'select adid,title,adname
             ,decode(status,0,''未投放'',1,''<span style="color:blue">正常</span>'',2,''日到量'',3,''总到量'',''停止投放'')||decode(showtype,0,''<span style="color:red">(不显示)</span>'','''') status
             ,to_char(starttime,''yyyy-mm-dd'') starttime,to_char(stoptime ,''yyyy-mm-dd'') stoptime,adtype from ad_adinfo where 1=1 ';
  
    v_selectsql := '';
  
    if I_ADID is not null then
      v_selectsql := v_selectsql || ' and adid = ' || I_ADID;
    end if;
    if I_ADName is not null then
      v_selectsql := v_selectsql || ' and (title like ''%' || I_ADName ||
                     '%'' or adname like ''%' || I_ADName || '%'')';
    end if;
    if I_Status is not null then
      v_selectsql := v_selectsql || ' and status =''' || I_Status || '''';
    end if;
    if I_ShowType is not null then
      v_selectsql := v_selectsql || ' and ShowType =''' || I_ShowType || '''';
    end if;
    if I_PhoneType is not null then
      v_selectsql := v_selectsql || ' and PhoneType =''' || I_PhoneType || '''';
    end if;
    if I_ADType is not null then
      v_selectsql := v_selectsql || ' and ADType =''' || I_ADType || '''';
    end if;
  
    execute immediate 'select count(1) from ad_adinfo where 1 = 1' ||
                      v_selectsql
      into O_OUTRECORDCOUNT;
  
    v_sql := v_sql || v_selectsql ||
             '  order by  status , showtype asc, itime desc';
  
    ----执行分页查询
    V_HEIROWNUM := I_PAGENO * I_PAGESIZE;
    V_LOWROWNUM := V_HEIROWNUM - I_PAGESIZE + 1;
    V_SQL       := 'select adid,title,adname,status,starttime,stoptime,adtype , p_ad_manage.fq_admarketer(adid) marketer ,rn
                    FROM (
                    select adid,title,adname,status,starttime,stoptime,adtype,rownum rn
                    FROM (' || v_sql || ') A
                    WHERE rownum <= ' ||
                   TO_CHAR(V_HEIROWNUM) || '
                    ) B
                    WHERE rn >= ' || TO_CHAR(V_LOWROWNUM);
    open O_OUTCURSOR for v_sql;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '获取失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pq_AD_list;

  procedure pq_AD_Info
  /*****************************************************************
        Procedure Name :pq_AD_Info
        Purpose: 广告信息
        Edit: 2016-12-05 add by 小沈
    ****************************************************************/
  (I_AdminID   In Varchar2,
   I_ADID      In Number,
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out number,
   O_Message   Out varchar2) is
    v_sql varchar2(1000);
    V_QX  NUMBER; --本模块的权限代码
  begin
    o_result  := 0;
    o_message := '显示成功';
    V_QX      := 104; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    if I_ADID is null then
      o_result  := 101;
      o_message := '参数有误！';
      return;
    end if;
  
    v_sql := 'select  adid, title, adname, money, intro, status, showtype, to_char(starttime,''yyyy-mm-dd hh24:mi:ss'') starttime , to_char(stoptime,''yyyy-mm-dd hh24:mi:ss'') stoptime, phonetype, adtype,
     appsize, imgurl, description,desimgurls,  adlink, pagename, iosadlink, iospagename, iosurlschemes, iosproname, iosversion,RECOMMEND_ORDER,is_easy,
     ioskeyword, iosrank, appsign, buttonshow, buttonname, showorder, msgnoinstall, msgnoreg, msgreg, msgdaylimit, msgalllimit,isrecommend 
from ad_adinfo where ADID=' || I_ADID;
  
    open O_OUTCURSOR for v_sql;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '获取失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pq_AD_Info;

  procedure pw_AD_Add
  /*****************************************************************
        Procedure Name :pw_AD_Add
        Purpose: 广告增加
        Edit: 2016-12-05 add by 小沈
    ****************************************************************/
  (I_AdminID       In Varchar2,
   I_Title         In Varchar2, -- 广告名称[内部使用]
   I_ADName        In Varchar2, --   前台显示广告名称
   I_Money         In Number, --  奖励总金额
   I_Intro         In Varchar2, --   广告简介
   I_Status        In Number, --   投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放）
   I_ShowType      In Number, --   0不显示，1显示
   I_StartTime     In Varchar2, --广告投放时间
   I_StopTime      In Varchar2, --停止投放时间
   I_PhoneType     In Number, --   1、ios，  2、安卓， 3、ios和安卓都显示
   I_ADType        In Number, --   广告类型（1游戏，2应用，3其他）
   I_APPSize       In Varchar2, --   文件大小
   I_ImgURL        In Varchar2, --   广告小图片地址
   I_Description   In Varchar2, --   广告介绍描述
   I_DesImgUrls    In Varchar2, --   广告图片描述 
   I_ADLink        In Varchar2, --   安卓广告地址
   I_PageName      In Varchar2, --   安卓应用的包名称
   I_IOSADLink     In Varchar2, --   IOS广告地址
   I_IOSPageName   In Varchar2, --   IOS应用程序名称 BoundleId
   I_IOSURLSchemes In Varchar2, --   IOS用于打开APP应用的 URL Schemes
   I_IOSPROName    In Varchar2, --   IOS 进程名称 ProcessName
   I_IOSVersion    In Varchar2, --   IOS应用版本号
   I_IOSKEYWord    In Varchar2, --   搜索关键字
   I_IOSRank       In Number, --   关键字在appstore排位
   I_APPSign       In Number, --   绑定方式 0、下载绑定 1、账号返回 2、自助提交  3、下载安装返回
   I_ButtonShow    In Number, --   下载按钮和进度条是否显示（1显示，0不显示）
   I_ButtonName    In Varchar2, --   试玩按钮名称
   I_ShowOrder     In Number, --  排序号
   I_MSGNOInstall  In Varchar2, --   未安装提示-无需下载app则提示和未注册一致
   I_MSGNoReg      In Varchar2, --   未注册提示
   I_MsgReg        In Varchar2, --   已注册提示
   I_MSGDayLimit   In Varchar2, --  日限量提示信息
   I_MSGAllLimit   In Varchar2, --  到量提示信息
   I_ISRECOMMEND   In Number, --  是否推荐该广告 1：推荐 0：不推荐
   I_RecommendSn   In Number, -- 推荐排序
   I_ISEASY        In Number, --  是否为简单广告 1：是 0：否
   O_Result        Out number,
   O_Message       Out varchar2) is
    V_ADID         Number; --广告ID
    V_ADLink       Varchar2(500); --   安卓广告地址
    V_IOSADLink    Varchar2(500); --   IOS广告地址
    V_QX           Number; --本模块的权限代码
    V_MSGNOInstall varchar2(500); --未安装提示-无需下载app则提示和未注册一致 
    V_MSGNoReg     varchar2(500); --未注册/已下载提示 
    V_MsgReg       varchar2(500); --已注册提示 
    V_MsgDayLimit  varchar2(200); --日限量提示信息   
    V_MsgAllLimit  varchar2(200); --到量提示信息 
  begin
    o_result  := 0;
    o_message := '保存成功';
  
    V_MSGNOInstall := I_MSGNOInstall; --未安装提示-无需下载app则提示和未注册一致 
    V_MSGNoReg     := I_MSGNoReg; --未注册/已下载提示 
    V_MsgReg       := I_MsgReg; --已注册提示 
    V_MsgDayLimit  := I_MSGDayLimit; --日限量提示信息   
    V_MsgAllLimit  := I_MSGAllLimit; --到量提示信息 
  
    V_QX := 104; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    V_MSGNOInstall := replace(V_MSGNOInstall, '[adname]', I_ADName); --未安装提示-无需下载app则提示和未注册一致 
    V_MSGNoReg     := replace(V_MSGNoReg, '[adname]', I_ADName); --未注册/已下载提示 
    V_MsgReg       := replace(V_MsgReg, '[adname]', I_ADName); --已注册提示 
    V_MsgDayLimit  := replace(V_MsgDayLimit, '[adname]', I_ADName); --日限量提示信息   
    V_MsgAllLimit  := replace(V_MsgAllLimit, '[adname]', I_ADName); --到量提示信息 
  
    V_ADID      := SQ_AD_INFO.NEXTVAL;
    V_ADLink    := replace(I_ADLink, '[adid]', V_ADID);
    V_IOSADLink := replace(I_IOSADLink, '[adid]', V_ADID);
  
    insert into ad_adinfo
      (adid,
       title,
       adname,
       money,
       intro,
       status,
       showtype,
       starttime,
       stoptime,
       phonetype,
       adtype,
       appsize,
       imgurl,
       description,
       desimgurls,
       adlink,
       pagename,
       iosadlink,
       iospagename,
       iosurlschemes,
       iosproname,
       iosversion,
       ioskeyword,
       iosrank,
       appsign,
       buttonshow,
       buttonname,
       showorder,
       msgnoinstall,
       msgnoreg,
       msgreg,
       msgdaylimit,
       msgalllimit,
       isrecommend,
       recommend_order,
       is_easy)
    values
      (V_ADID,
       I_title,
       I_adname,
       I_money,
       I_intro,
       I_status,
       I_showtype,
       to_date(I_starttime, 'yyyy-mm-dd hh24:mi:ss'),
       to_date(I_stoptime, 'yyyy-mm-dd hh24:mi:ss'),
       I_phonetype,
       I_adtype,
       I_appsize,
       I_imgurl,
       I_description,
       I_DesImgUrls,
       V_ADLink,
       I_pagename,
       V_IOSADLink,
       I_iospagename,
       I_iosurlschemes,
       I_iosproname,
       I_iosversion,
       I_ioskeyword,
       I_iosrank,
       I_appsign,
       I_buttonshow,
       I_buttonname,
       I_showorder,
       V_MSGNOInstall,
       V_MSGNoReg,
       V_MsgReg,
       V_MsgDayLimit,
       V_MsgAllLimit,
       I_ISRECOMMEND,
       I_RecommendSn,
       I_ISEASY);
  
    commit;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_MESSAGE := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pw_AD_Add;

  procedure pw_AD_Edit
  /*****************************************************************
        Procedure Name :pw_AD_Edit
        Purpose: 广告修改
        Edit: 2016-12-05 add by 小沈
    ****************************************************************/
  (I_AdminID       In Varchar2,
   I_ADID          In Number, --  广告ID
   I_Title         In Varchar2, -- 广告名称[内部使用]
   I_ADName        In Varchar2, --   前台显示广告名称
   I_Money         In Number, --  奖励总金额
   I_Intro         In Varchar2, --   广告简介
   I_Status        In Number, --   投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放）
   I_ShowType      In Number, --   0不显示，1显示
   I_StartTime     In Varchar2, --广告投放时间
   I_StopTime      In Varchar2, --停止投放时间
   I_PhoneType     In Number, --   1、ios，  2、安卓， 3、ios和安卓都显示
   I_ADType        In Number, --   广告类型（1游戏，2应用，3其他）
   I_APPSize       In Varchar2, --   文件大小
   I_ImgURL        In Varchar2, --   广告小图片地址
   I_Description   In Varchar2, --   广告介绍描述
   I_DesImgUrls    In Varchar2, --   广告图片描述 
   I_ADLink        In Varchar2, --   安卓广告地址
   I_PageName      In Varchar2, --   安卓应用的包名称
   I_IOSADLink     In Varchar2, --   IOS广告地址
   I_IOSPageName   In Varchar2, --   IOS应用程序名称 BoundleId
   I_IOSURLSchemes In Varchar2, --   IOS用于打开APP应用的 URL Schemes
   I_IOSPROName    In Varchar2, --   IOS 进程名称 ProcessName
   I_IOSVersion    In Varchar2, --   IOS应用版本号
   I_IOSKEYWord    In Varchar2, --   搜索关键字
   I_IOSRank       In Number, --   关键字在appstore排位
   I_APPSign       In Number, --   绑定方式 0、下载绑定 1、账号返回 2、自助提交  3、下载安装返回
   I_ButtonShow    In Number, --   下载按钮和进度条是否显示（1显示，0不显示）
   I_ButtonName    In Varchar2, --   试玩按钮名称
   I_ShowOrder     In Number, --  排序号
   I_MSGNOInstall  In Varchar2, --   未安装提示-无需下载app则提示和未注册一致
   I_MSGNoReg      In Varchar2, --   未注册提示
   I_MsgReg        In Varchar2, --   已注册提示
   I_MSGDayLimit   In Varchar2, --  日限量提示信息
   I_MSGAllLimit   In Varchar2, --  到量提示信息
   I_ISRECOMMEND   In Number, --  是否推荐该广告 1：推荐 0：不推荐
   I_RecommendSn   In Number, -- 推荐排序
   I_ISEASY        In Number, --  是否为简单广告 1：是 0：否
   O_Result        Out number,
   O_Message       Out varchar2) is
    V_QX           NUMBER; --本模块的权限代码、
    v_n            number;
    V_MSGNOInstall varchar2(500); --未安装提示-无需下载app则提示和未注册一致 
    V_MSGNoReg     varchar2(500); --未注册/已下载提示 
    V_MsgReg       varchar2(500); --已注册提示 
    V_MsgDayLimit  varchar2(200); --日限量提示信息   
    V_MsgAllLimit  varchar2(200); --到量提示信息 
  begin
    o_result  := 0;
    o_message := '保存成功';
  
    V_QX := 104; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    --输入参数是否正确
    if i_ADID is null then
      o_result  := 102;
      o_message := '输入参数有误，请检查！';
      return;
    end if;
  
    select count(1) into v_n from ad_adinfo where ADID = i_ADID;
  
    if v_n = 0 then
      o_result  := 104;
      o_message := '未找到指定广告，不能修改！';
      return;
    end if;
  
    V_MSGNOInstall := I_MSGNOInstall; --未安装提示-无需下载app则提示和未注册一致 
    V_MSGNoReg     := I_MSGNoReg; --未注册/已下载提示 
    V_MsgReg       := I_MsgReg; --已注册提示 
    V_MsgDayLimit  := I_MSGDayLimit; --日限量提示信息   
    V_MsgAllLimit  := I_MSGAllLimit; --到量提示信息 
  
    V_MSGNOInstall := replace(V_MSGNOInstall, '[adname]', I_ADName); --未安装提示-无需下载app则提示和未注册一致 
    V_MSGNoReg     := replace(I_MSGNoReg, '[adname]', I_ADName); --未注册/已下载提示 
    V_MsgReg       := replace(V_MsgReg, '[adname]', I_ADName); --已注册提示 
    V_MsgDayLimit  := replace(V_MsgDayLimit, '[adname]', I_ADName); --日限量提示信息   
    V_MsgAllLimit  := replace(V_MsgAllLimit, '[adname]', I_ADName); --到量提示信息 
  
    update ad_adinfo
       set title           = I_title,
           adname          = I_adname,
           money           = I_money,
           intro           = I_intro,
           status          = I_status,
           showtype        = I_showtype,
           starttime       = to_date(I_starttime, 'yyyy-mm-dd hh24:mi:ss'),
           stoptime        = to_date(I_stoptime, 'yyyy-mm-dd hh24:mi:ss'),
           phonetype       = I_phonetype,
           adtype          = I_adtype,
           appsize         = I_appsize,
           imgurl          = I_imgurl,
           description     = I_description,
           desimgurls      = I_DesImgUrls,
           adlink          = I_adlink,
           pagename        = I_pagename,
           iosadlink       = I_iosadlink,
           iospagename     = I_iospagename,
           iosurlschemes   = I_iosurlschemes,
           iosproname      = I_iosproname,
           iosversion      = I_iosversion,
           ioskeyword      = I_ioskeyword,
           iosrank         = I_iosrank,
           appsign         = I_appsign,
           buttonshow      = I_buttonshow,
           buttonname      = I_buttonname,
           showorder       = I_showorder,
           msgnoinstall    = V_MSGNOInstall,
           msgnoreg        = V_MSGNoReg,
           msgreg          = V_MsgReg,
           msgdaylimit     = V_MsgDayLimit,
           msgalllimit     = V_MsgAllLimit,
           isrecommend     = I_ISRECOMMEND,
           is_easy         = I_ISEASY,
           RECOMMEND_ORDER = I_RecommendSn
     where ADID = i_ADID;
    commit;
  
    select count(1) into v_n from ad_activity where adid = I_ADID;
    if v_n > 0 then
      update ad_activity
         set etime = to_date(I_stoptime, 'yyyy-mm-dd hh24:mi:ss')
       where adid = I_ADID;
      commit;
    end if;
    /*    同步无积分广告信息
    P_SynAD_Data.PW_Syn_Wall@Xwanad_Link(I_ADID    => I_ADID,
                                         O_Result  => v_result,
                                         O_Message => v_Message);*/
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_MESSAGE := '修改失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pw_AD_Edit;

  procedure pq_Award_List
  /*****************************************************************
        Procedure Name :pq_Award_List
        Purpose: 获取广告渠道应用的奖励设置 ---此入口进入奖励设置明细
        Edit: 2016-12-05 add by 小沈
    ****************************************************************/
  (I_AdminID   In Varchar2,
   I_ADID      In Number,
   I_APPID     In Number, --   渠道应用编号 0为默认 
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out number,
   O_Message   Out varchar2) is
    v_sql        varchar2(1000);
    v_selectsql  varchar2(200);
    v_selectsql2 varchar2(200);
    V_QX         NUMBER; --本模块的权限代码
  begin
    o_result  := 0;
    o_message := '显示成功';
    V_QX      := 104; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    if I_ADID is null then
      o_result  := 1;
      o_message := '广告ID不能为空！';
      return;
    end if;
  
    v_selectsql  := v_selectsql || '   adid  = ' || I_ADID;
    v_selectsql2 := v_selectsql2 || '   a.adid  = ' || I_ADID;
  
    if I_APPId is not null and I_APPID != -1 then
      v_selectsql  := v_selectsql || ' and appid  = ' || I_APPId;
      v_selectsql2 := v_selectsql2 || '  and a.appid  = ' || I_APPId;
    end if;
  
    v_sql := ' select a.adid,a.appid,b.name,a.dlevel,  a.event,a.times,a.price,a.amoney  from (
  select a.adid, a.appid, a.type, a.dlevel, a.event, a.needlevel, a.times, a.atype, a.awardgroup, a.groupname, a.price, a.amoney  from ad_awardset a ,
  (select adid,appid, min(dlevel) mdlevel from ad_awardset where   ' ||
             v_selectsql || '  group by adid,appid  ) b
   where  ' || v_selectsql2 ||
             ' and a.adid=b.adid and a.appid=b.appid  and a.dlevel=b.mdlevel ) a, ad_channel b where a.appid=b.appid ';
  
    open O_OUTCURSOR for v_sql;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_MESSAGE := '获取失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pq_Award_List;

  procedure pq_Award_Info
  /*****************************************************************
        Procedure Name :pq_AD_INFO
        Purpose: 获取广告渠道应用的具体奖励设置
        Edit: 2016-12-05 add by 小沈
    ****************************************************************/
  (I_AdminID   In Varchar2,
   I_ADID      In Number,
   I_APPID     In Number, --   渠道应用编号 0为默认 
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out number,
   O_Message   Out varchar2) is
    V_QX NUMBER; --本模块的权限代码
  begin
    o_result  := 0;
    o_message := '显示成功';
    V_QX      := 104; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    if I_ADID is null then
      o_result  := 1;
      o_message := '广告ID不能为空！';
      return;
    end if;
  
    if I_APPID is null then
      o_result  := 2;
      o_message := '渠道应用编号不能为空！';
      return;
    end if;
  
    open O_OUTCURSOR for
      select type,
             dlevel,
             event,
             needlevel,
             times,
             atype,
             awardgroup,
             groupname,
             psecond,
             price,
             amoney
        from ad_awardset
       where adid = I_ADID
         and appid = I_APPID
       order by dlevel;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_MESSAGE := '获取失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pq_Award_Info;

  procedure pw_Award_Set
  /*****************************************************************
    Procedure Name: GW_AD_AwardTypeIN
    Purpose: 广告奖励设置录入
    Edit: 2017-02-15 add by 小沈 
    Comment:
    ****************************************************************/
  (I_AdminID         In Varchar2, --管理员ID
   I_ADID            In Number, --   广告ID
   I_APPID           In Number, --   渠道应用编号 0为默认 
   I_Type_List       In Varchar2, --   类型（1单次奖励，2循环奖励）
   I_Dlevel_List     In Varchar2, --   奖励级别
   I_Event_List      In Varchar2, --  奖励说明
   I_NeedLevel_List  In Varchar2, --  要求游戏等级（时间、积分)； 如果奖励类型为 3 则为充值的返现比例值 （如 充值返20% 则写20） 
   I_Times_List      In Varchar2, --  限制奖励次数
   I_Atype_List      In Varchar2, --  奖励类型：1-注册 ; 2-等级/首冲固定奖励 ; 3-充值理财百分比奖励
   I_AwardGroup_List In Varchar2, --   奖励组别，根据不同广告有自己的组别（大于90表是同组中只能获得其中1个奖励）
   I_GroupName_List  In Varchar2, --  组别说明 同一类奖励需分组
   I_PlaySecond_List In Varchar2, --  所需要体验时间 单位秒 
   I_Price_List      In Varchar2, --  单价
   I_AMoney_List     In Varchar2, --   奖励金额
   O_Result          Out Number,
   O_Message         Out Varchar2) IS
    v_n  number;
    V_QX number;
  
    V_Type_List       Varchar2(4000); --   类型（1单次奖励，2循环奖励）
    V_Dlevel_List     Varchar2(4000); --   奖励级别
    V_Event_List      Varchar2(4000); --  奖励说明
    V_NeedLevel_List  Varchar2(4000); --  要求游戏等级（时间、积分)； 如果奖励类型为 3 则为充值的返现比例值 （如 充值返20% 则写20） 
    V_Times_List      Varchar2(4000); --  限制奖励次数
    V_Atype_List      Varchar2(4000); --  奖励类型：1-注册 ; 2-等级/首冲固定奖励 ; 3-充值理财百分比奖励
    V_AwardGroup_List Varchar2(4000); --   奖励组别，根据不同广告有自己的组别（大于90表是同组中只能获得其中1个奖励）
    V_GroupName_List  Varchar2(4000); --  组别说明 同一类奖励需分组
    V_PlaySecond_List Varchar2(4000); --所需要体验时间 单位秒 
    V_Price_List      Varchar2(4000); --  单价
    V_AMoney_List     Varchar2(4000); --   奖励金额
  
    V_Type       Number(10); -- 类型（1单次奖励，2循环奖励）
    V_Dlevel     Number(10); -- 奖励级别
    V_Event      Varchar2(500); -- 奖励说明
    V_NeedLevel  Number(38, 2); -- 要求游戏等级（时间、积分)；充值奖励时为充值的返蛋比例值 （如 充值返20% 则写20） 
    V_Times      Number(4); -- 限制奖励次数
    V_Atype      Number(1); -- 奖励类型：1-注册 ; 2-等级/首冲固定奖励 ; 3-充值理财百分比奖励
    V_AwardGroup Number(5); --  奖励组别，根据不同广告有自己的组别（大于90表是同组中只能获得其中1个奖励）
    V_GroupName  Varchar2(500); -- 组别说明 同一类奖励需分组
    V_PlaySecond Number(5); --所需要体验时间 单位秒 
    V_Price      Number(10, 3); --  单价
    V_AMoney     Number(10, 3); -- 奖励金额
    v_PriceRate  Number(10, 3); -- 渠道结算金额比率 如商家结算1元，则渠道结算0.8元
  BEGIN
    -------------------------------------------------------------------
    --步骤一：变量初始化
    -------------------------------------------------------------------
    O_RESULT  := 0;
    O_MESSAGE := '录入成功';
  
    V_Type_List       := I_Type_List; --   类型（1单次奖励，2循环奖励）
    V_Dlevel_List     := I_Dlevel_List; --   奖励级别
    V_Event_List      := I_Event_List; --  奖励说明
    V_NeedLevel_List  := I_NeedLevel_List; --  要求游戏等级（时间、积分)； 如果奖励类型为 3 则为充值的返现比例值 （如 充值返20% 则写20） 
    V_Times_List      := I_Times_List; --  限制奖励次数
    V_Atype_List      := I_Atype_List; --  奖励类型：1-注册 ; 2-等级/首冲固定奖励 ; 3-充值理财百分比奖励
    V_AwardGroup_List := I_AwardGroup_List; --   奖励组别，根据不同广告有自己的组别（大于90表是同组中只能获得其中1个奖励）
    V_GroupName_List  := I_GroupName_List; --  组别说明 同一类奖励需分组
    V_PlaySecond_List := I_PlaySecond_List; --所需要体验时间 单位秒 
    V_Price_List      := I_Price_List; --  单价
    V_AMoney_List     := I_AMoney_List; --   奖励金额
  
    --管理员输入是否正确
    if I_AdminID is null then
      O_RESULT  := 101;
      O_MESSAGE := '请重新登录后在操作！';
      RETURN;
    end if;
  
    --有下列权限的管理员有本模块的查询权
    V_QX := 104; --编辑权限
  
    --管理员是否有操作此模块的权限
    if p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    -------------------------------------------------------------------
    --步骤二：循环添加记录
    -------------------------------------------------------------------
    if length(V_Dlevel_List) <= 3 then
      O_RESULT  := 2;
      O_MESSAGE := '请先设置你的奖励，请检查！';
      RETURN;
    end if;
  
    if I_APPID = -1 then
      O_RESULT  := 3;
      O_MESSAGE := '请先从列表页选择渠道后，再来添加！';
      return;
    end if;
  
    if I_APPID = 1060 then
      O_RESULT  := 4;
      O_MESSAGE := '豆豆趣玩不再添加新广告！';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_awardset
     where adid = I_ADID
       and appid = I_APPID;
    if v_n > 0 then
      delete ad_awardset
       where adid = I_ADID
         and appid = I_APPID;
      commit;
    end if;
  
    LOOP
    
      --拆分  类型（1单次奖励，2循环奖励）
      if INSTR(V_Type_List, '$#@') <= 0 then
        --如果没有“$#@”符号，则直接取值，不拆分
        v_Type      := V_Type_List;
        V_Type_List := '';
      else
        v_Type      := substr(V_Type_List, 0, instr(V_Type_List, '$#@') - 1); --从字符串0开始复制，到第一个"$#@"退一位结束
        V_Type_List := substr(V_Type_List, instr(V_Type_List, '$#@') + 3); --从第一组分隔符开始取 到结束
      end if;
    
      --拆分 奖励级别
      if INSTR(V_Dlevel_List, '$#@') <= 0 then
        v_Dlevel      := V_Dlevel_List;
        V_Dlevel_List := '';
      else
        v_Dlevel      := substr(V_Dlevel_List,
                                0,
                                instr(V_Dlevel_List, '$#@') - 1);
        V_Dlevel_List := substr(V_Dlevel_List,
                                instr(V_Dlevel_List, '$#@') + 3);
      end if;
    
      --拆分  奖励说明
      if INSTR(V_Event_List, '$#@') <= 0 then
        v_Event      := V_Event_List;
        V_Event_List := '';
      else
        v_Event      := substr(V_Event_List,
                               0,
                               instr(V_Event_List, '$#@') - 1);
        V_Event_List := substr(V_Event_List, instr(V_Event_List, '$#@') + 3);
      end if;
    
      --拆分 等级要求
      if INSTR(V_NeedLevel_List, '$#@') <= 0 then
        v_Needlevel      := V_NeedLevel_List;
        V_NeedLevel_List := '';
      else
        v_Needlevel      := substr(V_NeedLevel_List,
                                   0,
                                   instr(V_NeedLevel_List, '$#@') - 1);
        V_NeedLevel_List := substr(V_NeedLevel_List,
                                   instr(V_NeedLevel_List, '$#@') + 3);
      end if;
    
      --拆分 奖励次数
      if INSTR(V_Times_List, '$#@') <= 0 then
        v_Times      := V_Times_List;
        V_Times_List := '';
      else
        v_Times      := substr(V_Times_List,
                               0,
                               instr(V_Times_List, '$#@') - 1);
        V_Times_List := substr(V_Times_List, instr(V_Times_List, '$#@') + 3);
      end if;
    
      --拆分 奖励类型  ：1-注册 ; 2-等级/首冲固定奖励 ; 3-充值理财百分比奖励
      if INSTR(V_Atype_List, '$#@') <= 0 then
        v_Atype      := V_Atype_List;
        V_Atype_List := '';
      else
        v_Atype      := substr(V_Atype_List,
                               0,
                               instr(V_Atype_List, '$#@') - 1);
        V_Atype_List := substr(V_Atype_List, instr(V_Atype_List, '$#@') + 3);
      end if;
    
      --拆分 奖励组别
      if INSTR(V_AwardGroup_List, '$#@') <= 0 then
        v_Awardgroup      := V_AwardGroup_List;
        V_AwardGroup_List := '';
      else
        v_Awardgroup      := substr(V_AwardGroup_List,
                                    0,
                                    instr(V_AwardGroup_List, '$#@') - 1);
        V_AwardGroup_List := substr(V_AwardGroup_List,
                                    instr(V_AwardGroup_List, '$#@') + 3);
      end if;
    
      --拆分 组别说明
      if INSTR(V_GroupName_List, '$#@') <= 0 then
        v_Groupname      := V_GroupName_List;
        V_GroupName_List := '';
      else
        v_Groupname      := substr(V_GroupName_List,
                                   0,
                                   instr(V_GroupName_List, '$#@') - 1);
        V_GroupName_List := substr(V_GroupName_List,
                                   instr(V_GroupName_List, '$#@') + 3);
      end if;
    
      --拆分 所需要体验时间 单位秒 
      if INSTR(V_PlaySecond_List, '$#@') <= 0 then
        V_PlaySecond      := V_PlaySecond_List;
        V_PlaySecond_List := '';
      else
        V_PlaySecond      := substr(V_PlaySecond_List,
                                    0,
                                    instr(V_PlaySecond_List, '$#@') - 1);
        V_PlaySecond_List := substr(V_PlaySecond_List,
                                    instr(V_PlaySecond_List, '$#@') + 3);
      end if;
    
      --拆分  单价
      if INSTR(V_Price_List, '$#@') <= 0 then
        v_Price      := V_Price_List;
        V_Price_List := '';
      else
        v_Price      := substr(V_Price_List,
                               0,
                               instr(V_Price_List, '$#@') - 1);
        V_Price_List := substr(V_Price_List, instr(V_Price_List, '$#@') + 3);
      end if;
    
      --拆分    奖励金额
      if INSTR(V_AMoney_List, '$#@') <= 0 then
        V_AMoney      := V_AMoney_List;
        V_AMoney_List := '';
      else
        V_AMoney      := substr(V_AMoney_List,
                                0,
                                instr(V_AMoney_List, '$#@') - 1);
        V_AMoney_List := substr(V_AMoney_List,
                                instr(V_AMoney_List, '$#@') + 3);
      end if;
    
      if V_AMoney < 0 then
        O_RESULT  := -5;
        O_MESSAGE := '奖励级别：' || v_dlevel || ' 奖励金额 不能小于0请检查';
        ROLLBACK;
        RETURN;
      end if;
    
      if V_AMoney > v_Price then
        O_RESULT  := -5;
        O_MESSAGE := '奖励级别：' || v_dlevel || ' 奖励金额不能大于结算金额请检查';
        ROLLBACK;
        RETURN;
      end if;
    
      if v_awardgroup <= 0 then
        O_RESULT  := -5;
        O_MESSAGE := '奖励级别：' || v_dlevel || ' 奖励组别 不能小于或等于0请检查';
        ROLLBACK;
        RETURN;
      end if;
    
      if instr(v_groupname, 'XX奖励') > 0 then
        O_RESULT  := -5;
        O_MESSAGE := '奖励级别：' || v_dlevel || ' 组别说明 尚未替换请检查';
        ROLLBACK;
        RETURN;
      end if;
    
      insert into ad_awardset
        (adid,
         appid,
         type,
         dlevel,
         event,
         needlevel,
         times,
         atype,
         awardgroup,
         groupname,
         psecond,
         price,
         amoney)
      values
        (I_ADID,
         I_APPID,
         v_type,
         v_dlevel,
         v_event,
         v_needlevel,
         v_times,
         v_atype,
         v_awardgroup,
         v_groupname,
         V_PlaySecond,
         v_price,
         v_amoney);
    
      EXIT WHEN V_Dlevel_List IS NULL;
    
    END LOOP;
  
    commit;
  
    --如果是渠道结算1：9的渠道，则结算金额乘以1.125
/*    select price_rate
      into v_PriceRate
      from ad_channel
     where appid = I_APPID;
    if v_PriceRate != 0.8 then
      update ad_awardset
         set price = price * v_PriceRate * 1.25
       where adid = I_ADID
         and appid = I_APPID;
    end if;*/
  
    commit;
  
    RETURN;
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '添加/修改奖励失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  END pw_Award_Set;

  procedure pq_DownUrlList
  /*****************************************************************
        Procedure Name :pq_DownUrlList
        Purpose: 下载地址列表
        Edit: 2017-02-16 add by 小沈
    ****************************************************************/
  (I_AdminID        In Varchar2, --管理员ID
   I_ADID           In Number, --   广告ID
   I_PageSize       In Number,
   I_PageNO         In Number,
   O_OutRecordCount Out Number,
   O_OutCursor      Out t_cursor, --返回游标
   O_Result         Out Number,
   O_Message        Out Varchar2) is
    V_SQL          VARCHAR2(2000);
    V_SQLCondition VARCHAR2(1000);
    V_SQLCount     VARCHAR2(1000);
    V_STARTNUM     NUMBER;
    V_ENDNUM       NUMBER;
    v_pagesize     number;
    V_QX           Number;
  BEGIN
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
  
    O_Result  := 0;
    O_Message := '成功';
    OPEN O_OUTCURSOR FOR 'select 1  from dual where 1=2'; --游标初始化
  
    V_QX := 104; --编辑权限
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    v_pagesize := i_pagesize;
    --查询：
    V_SQL := ' select adid ,urlid ,appurl ,phonetype  , decode(status,0,''未使用'',1,''<font style="color:blue">正常使用</font>'',2,''<font style="color:red">日到量</font>'',3,''<font style="color:red">总到量</font>'',4,''<font style="color:red">停止使用</font>'',''其他'') status  ,
     dayflux , allflux   ,to_char(fluxtime,''hh24:mi'') fluxtime  ,
     fulltime  ,  marketer  ,customer  from ad_downurl  where 1=1  ';
  
    --查询条件赋值
    V_SQLCondition := ' and adid= ' || i_adid ||
                      ' order by  status asc , urlid asc ';
  
    V_SQL := V_SQL || V_SQLCondition;
  
    ----取记录总数  加上查询条件
    V_SQLCount := 'select COUNT(1) from ad_downurl  where 1=1' ||
                  V_SQLCondition;
  
    execute immediate V_SQLCount
      into O_OUTRECORDCOUNT;
  
    OPEN O_OUTCURSOR FOR V_SQL;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
    V_ENDNUM   := v_pagesize * I_PAGENO;
    V_STARTNUM := V_ENDNUM - v_pagesize + 1;
  
    V_SQL := ' select  adid ,urlid ,appurl ,phonetype ,status, dayflux , allflux ,fluxtime,fulltime, marketer  ,customer,  rn
           from (
                select   adid ,urlid ,appurl ,phonetype ,status, dayflux , allflux ,fluxtime,fulltime, marketer  ,customer,  rownum rn  from (' ||
             V_SQL || ') a
               where rownum <=' || v_endnum ||
             ')  b
          where rn>=' || v_startnum;
    OPEN O_OUTCURSOR FOR V_SQL;
  
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '查询失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  END pq_DownUrlList;

  procedure pq_DownUrlInfo
  /*****************************************************************
        Procedure Name :pq_DownUrlInfo
        Purpose: 获取下载地址信息
        Edit: 2017-02-16 add by 小沈
    ****************************************************************/
  (I_AdminID   In Varchar2, --管理员ID
   I_UrlID     In Number, --下载编号 
   O_OUTCURSOR OUT T_CURSOR, --返回游标
   O_Result    Out number,
   O_Message   Out varchar2) is
    V_QX Number;
    v_n  number;
  BEGIN
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
  
    O_RESULT  := 0;
    O_MESSAGE := '成功';
    OPEN O_OUTCURSOR FOR 'select 1  from dual where 1=2'; --游标初始化
  
    V_QX := 104; --编辑权限
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    select count(1) into v_n from ad_downurl where urlid = I_UrlID;
  
    if v_n = 0 then
      O_RESULT  := 1;
      O_MESSAGE := '没有该下载地址信息！';
      RETURN;
    end if;
  
    OPEN O_OUTCURSOR FOR
      select adid,
             urlid,
             appurl,
             phonetype,
             dayflux,
             allflux,
             to_char(fluxtime, 'hh24:mi') fluxtime, --到量后，第二天开始投放时间  
             status, --状态（0未使用，1正常使用，2日到量，3总到量，4停止使用） 
             marketer, --市场人员姓名 
             customer, --商家名称  
             downtype --下载方式
        from ad_downurl
       where urlid = I_UrlID;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
  
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '查询失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  END pq_DownUrlInfo;

  procedure pw_DownUrlSet
  /*****************************************************************
        Procedure Name :pw_DownUrlSet
        Purpose:下载地址添加、修改
        Edit: 2017-02-16 add by 小沈
    ****************************************************************/
  (I_AdminID   In Varchar2, --管理员ID
   I_ADID      In Number, --   广告ID
   I_UrlID     In Number, --下载编号  
   I_APPUrl    In Varchar2, --app下载链接 注册地址
   I_PhoneType In Number, --1、ios，  2、安卓， 3、ios和安卓
   I_DayFlux   In Number, --日流量控制（默认-1不限制）
   I_AllFlux   In Number, --总流量控制（默认-1不限制）
   I_FluxTime  In Varchar2, --到量后，第二天开始投放时间 
   I_Status    In Number, --状态（0未使用，1正常使用，2日到量，3总到量，4停止使用）
   I_Marketer  In Varchar2, -- 市场人员姓名
   I_Customer  In Varchar2, -- 商家名称 
   I_DownType  In Number, --下载方式（0直接下载，1外部浏览器打开）
   O_Result    Out number,
   O_Message   Out varchar2) is
    V_UrlID Number;
    V_QX    Number;
    v_n     Number;
  BEGIN
    O_Result := 0;
  
    if I_UrlID > 0 then
      O_Message := '修改下载地址成功！';
    else
      O_Message := '添加下载地址成功！';
    end if;
  
    V_QX := 104; --编辑权限
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    ----------------------------------------------------
    --步骤一：判断
    ----------------------------------------------------
  
    select count(1) into v_n from ad_adinfo where adid = I_adid;
    if v_n = 0 then
      O_RESULT  := 1;
      O_MESSAGE := '该广告不存在，不能添加！';
      RETURN;
    end if;
  
    if I_APPUrl is null then
      O_RESULT  := 2;
      O_MESSAGE := '下载地址不能为空，请检查！';
      RETURN;
    end if;
  
    if I_status not in (0, 1, 2, 3, 4) then
      O_RESULT  := 3;
      O_MESSAGE := '该状态不存在，请检查！';
      RETURN;
    end if;
  
    if I_UrlID > 0 then
    
      select count(1) into v_n from ad_downurl where urlid = I_UrlID;
      if v_n <= 0 then
        O_RESULT  := 4;
        O_MESSAGE := '该下载信息不存在，请检查！';
        RETURN;
      end if;
    
    else
    
      --1、ios，  2、安卓， 3、ios和安卓
      select count(1)
        into v_n
        from ad_downurl
       where adid = I_adid
         and appurl = I_APPUrl;
    
      if v_n >= 1 then
        O_RESULT  := 5;
        O_MESSAGE := '该地址已经存在，请检查！';
        RETURN;
      end if;
    
    end if;
  
    ----------------------------------------------------
    --步骤一：插入记录
    ----------------------------------------------------
    if I_UrlID = 0 then
      select SQ_AD_DownUrl.Nextval into V_UrlID from dual where 1 = 1;
    
      insert into ad_downurl
        (adid,
         urlid,
         appurl,
         phonetype,
         dayflux,
         allflux,
         fluxtime,
         status,
         marketer,
         customer,
         downtype,
         admin)
      values
        (I_ADID,
         V_UrlID,
         I_APPUrl,
         I_PhoneType,
         I_DayFlux,
         I_AllFlux,
         to_date(to_char(trunc(sysdate), 'yyyy-mm-dd') || I_FluxTime,
                 'yyyy-mm-dd hh24:mi:ss'),
         I_Status,
         I_Marketer,
         I_Customer,
         I_DownType,
         I_AdminID);
    
    else
    
      update ad_downurl
         set appurl    = I_APPUrl,
             phonetype = I_PhoneType,
             dayflux   = I_DayFlux,
             allflux   = I_AllFlux,
             fluxtime  = to_date(to_char(trunc(sysdate), 'yyyy-mm-dd') ||
                                 I_FluxTime,
                                 'yyyy-mm-dd hh24:mi:ss'),
             status    = I_Status,
             marketer  = I_Marketer,
             customer  = I_Customer,
             downtype  = I_DownType,
             eadmin    = I_AdminID,
             eltime    = sysdate
       where adid = I_ADID
         and urlid = I_UrlID;
    
    end if;
    commit;
  EXCEPTION
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '修改下载地址失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pw_DownUrlSet;

  PROCEDURE pw_Award_MultSet
  /*****************************************************************
        Procedure Name :pw_Award_MultSet
        Purpose: 根据测试渠道奖励设置批量添加奖励  
        Edit: 2017-03-22 add by 小胡
    ****************************************************************/
  (I_AdminID  In Varchar2, --管理员ID
   I_ADID     In Number, --广告ID  
   I_APPID    In Number, --渠道商ID  (暂时未用到)
   I_ForCeShi In Number, --完全根据测试渠道添加，1表示是，0表示不是 3复制蘑菇星球批量添加
   O_Result   Out number,
   O_Message  Out varchar2) is
    V_QX        Number; --权限
    v_n         Number; --数量
    v_s         Number; --广告类型
    v_appid     Number; --复制的渠道ID
    v_PriceRate Number(10, 3); -- 渠道结算金额比率 如商家结算1元，则渠道结算0.8元
  BEGIN
  
    O_RESULT  := 0;
    O_MESSAGE := '添加奖励成功';
  
    V_QX := 104; --编辑权限
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
    ---判断广告类型 属于安卓还是IOS--如果广告类型和渠道类型一致或者广告类型是安卓IOS都可以才复制奖励
    select phonetype into v_s from ad_adinfo where adid = I_ADID;
    --IOS广告稿复制1011，安卓或者 安卓及IOS复制1010
    if v_s in (2, 3) then
      if I_ForCeShi = 3 then
        v_appid := 3351;
      else
        v_appid := 1010;
      end if;
    else
      if v_s = 1 then
        v_appid := 1011;
      end if;
    end if;
  
    ---判断测试渠道是否添加了奖励设置
    select count(1)
      into v_n
      from ad_awardset
     where appid = v_appid
       and adid = I_ADID;
    if v_n <= 0 then
      O_RESULT  := 101;
      O_MESSAGE := '测试渠道奖励未设置！';
      return;
    end if;
  
    ---根据测试渠道设置的奖励循环添加已上线渠道的奖励设置
    DECLARE
      CURSOR myCur IS
         select appid, name, a_rate
          from ad_channel
         where (status = 1 or appid = 3351)
           and (atype = v_s or v_s = 3);
      
       CURSOR myCur1 IS
         select appid, name, a_rate
          from ad_channel
         where status = 2 and isconversion = 1
           and (atype = v_s or v_s = 3);     
    begin
     if I_ForCeShi = 3 then
      for cur in myCur1 LOOP
        select count(1)
          into v_n
          from ad_awardset
         where adid = I_ADID
           and appid = cur.appid;
        if v_n <= 0 then
      -----添加奖励设置
          insert into ad_awardset
            (adid,
             appid,
             type,
             dlevel,
             event,
             needlevel,
             times,
             atype,
             awardgroup,
             groupname,
             psecond,
             price,
             amoney,
             itime,
             isshow)
            select adid,
                   cur.appid,
                   type,
                   dlevel,
                   event,
                   needlevel,
                   times,
                   atype,
                   awardgroup,
                   groupname,
                   psecond,
                   price,
                   amoney,
                   sysdate,
                   isshow
              from ad_awardset
             WHERE appid = v_appid
               AND adid = I_ADID;
          commit;
        end if;
      end loop;
     else
      for cur in myCur LOOP
        select count(1)
          into v_n
          from ad_awardset
         where adid = I_ADID
           and appid = cur.appid;
        if v_n <= 0 then
        
          -----添加奖励设置,如果是渠道商为PC蛋蛋，奖励金额除以1.2 
          insert into ad_awardset
            (adid,
             appid,
             type,
             dlevel,
             event,
             needlevel,
             times,
             atype,
             awardgroup,
             groupname,
             psecond,
             price,
             amoney,
             itime,
             isshow)
            select adid,
                   cur.appid,
                   type,
                   dlevel,
                   event,
                   needlevel,
                   times,
                   atype,
                   awardgroup,
                   groupname,
                   psecond,
                   price,
                   case
                     when I_ForCeShi = 0 then
                      case
                        when atype = 9 then
                         amoney
                        else
                         price * cur.a_rate
                      end
                     else
                      amoney
                   end,
                   sysdate,
                   isshow
              from ad_awardset
             WHERE appid = v_appid
               AND adid = I_ADID;
          commit;
          --如果是渠道结算1：9的渠道，则结算金额乘以1.125
          select price_rate
            into v_PriceRate
            from ad_channel
           where appid = cur.appid;
          if v_PriceRate != 0.9 then
            update ad_awardset
               set price = case
                             when price * v_PriceRate / 9 * 10 > amoney then
                              price * v_PriceRate / 9 * 10
                             else
                              amoney
                           end
             where adid = I_ADID
               and appid = cur.appid;
          end if;
          commit;
        end if;
      end loop;
      end if;
    end;
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_Result  := 110;
      O_Message := '添加奖励失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      RETURN;
  END pw_Award_MultSet;

  PROCEDURE pw_Award_Delete
  /*****************************************************************
        Procedure Name :pw_Award_Delete
        Purpose: 删除指定广告的指定渠道奖励
        Edit: 2017-04-23 add by 小胡
    ****************************************************************/
  (I_AdminID In Varchar2, --管理员ID
   I_ADID    In Number, --广告ID  
   I_APPID   In Number, --渠道商ID
   O_Result  Out number,
   O_Message Out varchar2) is
    V_QX Number;
    v_n  number;
  BEGIN
  
    O_RESULT  := 0;
    O_MESSAGE := '删除奖励成功';
    V_QX      := 104; --编辑权限
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    ---如果该渠道有奖励，则把它删除
    select count(1)
      into v_n
      from ad_awardset
     where adid = I_ADID
       and appid = I_APPID;
    if v_n <= 0 then
      O_RESULT  := 101;
      O_MESSAGE := '该渠道未设置奖励！';
      return;
    end if;
  
    delete from ad_awardset
     where adid = I_ADID
       and appid = I_APPID;
    commit;
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_Result  := 110;
      O_Message := '删除奖励失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      RETURN;
  END pw_Award_Delete;

  PROCEDURE pq_Channel_AdList
  /*****************************************************************
        Procedure Name :pq_Channel_AdList_
        Purpose: 根据渠道编号获取所有在投广告列表
        Edit: 2017-04-24 add by 小胡
    ****************************************************************/
  (I_AdminID   In Varchar2, --管理员ID
   I_APPID     In Number, --渠道商ID
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out number,
   O_Message   Out varchar2) is
    v_n   number;
    V_QX  number;
    V_str varchar2(100);
    v_sql varchar2(2000);
  BEGIN
  
    O_RESULT  := 0;
    O_MESSAGE := '获取所有在投广告列表成功';
    V_QX      := 321; --编辑权限
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    --渠道ID判断
    if I_APPID is null then
      O_Result  := 1;
      O_Message := '渠道ID不能为空！';
      return;
    end if;
    select count(1) into v_n from ad_channel where appid = I_APPID;
    if v_n <= 0 then
      O_Result  := 1;
      O_Message := '渠道ID错误';
      return;
    end if;
    --获取渠道名称
    select name into V_str from ad_channel where appid = I_APPID;
  
    --查询在投广告 
    v_sql := 'select ' || I_APPID || ' as appid,''' || V_str ||
             ''' as channelname,adid,title,statusstr,starttime,stoptime,channelstatus, rownum  from (
select a.adid , a.title ,decode(status,0,''未投放'',1,''<span style="color:blue">正常</span>'',2,''日到量'',3,''总到量'',''停止投放'')|| decode(showtype,0,''<span style="color:red">(不显示)</span>'','''') statusstr ,
 a.starttime ,a.stoptime , case when  b.appid is null then 0 else 1 end as channelstatus from ad_adinfo a  
 left join (select  appid,adid ,count(1) from  ad_awardset where appid=' ||
             I_APPID || ' and adid in 
(select adid from  ad_adinfo where status=1 and showtype=1) group by appid,adid  ) b 
 on  a.adid=b.adid  and b.appid=' || I_APPID ||
             '   where  a.status=1 and a.showtype=1 and(a.phonetype in ((select atype from ad_channel where appid=' ||
             I_APPID || '),3))  order by starttime desc  
) order by channelstatus';
  
    open O_OUTCURSOR for v_sql;
  
    --异常处理
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_Result  := 110;
      O_Message := '获取渠道在投广告列表失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      RETURN;
  END pq_Channel_AdList;

  PROCEDURE pw_Channel_AdJoin
  /*****************************************************************
        Procedure Name :pw_channel_adjoin
        Purpose: 渠道添加广告
        Edit: 2018-04-25 add by 小胡
    ****************************************************************/
  (I_AdminId  in varchar2, --管理员id
   I_APPID    in number, --渠道商应用ID字符串
   I_ADID     In varchar2, --  广告ID
   I_ForCeShi In Number, --完全根据测试渠道添加，1表示是，0表示不是 2复制蘑菇星球
   O_Result   out number, --返回（0正确，其他为提示或错误）
   O_Message  out varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    v_n         number;
    V_QX        number;
    v_s         number;
    v_aw        number;
    v_phonetype number; --广告类型1-IOS，2-安卓，3-IOS及安卓
    v_appid     number; --测试渠道id，ios为1011,否则为1010
    v_arate     number; --渠道奖励比率
    v_adname    varchar(100); --广告名称
    v_PriceRate Number(10, 3); -- 渠道结算金额比率 如商家结算1元，则渠道结算0.8元
  begin
    o_result  := 0;
    o_message := '操作成功';
  
    V_QX := 321; --给渠道添加广告的权限
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    select a_rate into v_arate from ad_channel where appid = I_APPID;
    DECLARE
    
      CURSOR myCur IS
      --用逗号分割广告ID字符串
        select regexp_substr(I_ADID, '[^,]+', 1, level, 'i') as adid
          from dual
        connect by level <=
                   length(I_ADID) - length(regexp_replace(I_ADID, ',', '')) + 1;
    begin
      for cur in myCur LOOP
        select count(1) into v_n from ad_adinfo where adid = cur.adid;
        --判断广告是否存在
        if v_n > 0 then
        
          select count(1)
            into v_s
            from ad_awardset
           where adid = cur.adid
             and appid = I_APPID;
        
          --判断是否已投放过 ，渠道投放此广告是根据ios测试渠道还是安卓测试渠道添加
          if v_s <= 0 then
            select phonetype
              into v_phonetype
              from ad_adinfo
             where adid = cur.adid;
          
            if I_ForCeShi in (0, 1) then
            
              if v_phonetype in (2, 3) then
                v_appid := 1010;
              else
                if v_phonetype = 1 then
                  v_appid := 1011;
                end if;
              end if;
            elsif I_ForCeShi = 2 then
              v_appid := 3351;
            end if;
            ---判断此广告的测试渠道是否添加了奖励设置
            select count(1)
              into v_aw
              from ad_awardset
             where appid = v_appid
               and adid = cur.adid;
            if v_aw <= 0 then
              select title
                into v_adname
                from ad_adinfo
               where adid = cur.adid;
              O_RESULT  := 101;
              O_MESSAGE := '错误：广告【' || v_adname || '】的测试渠道[' || v_appid ||
                           ']奖励未设置！';
              RETURN;
            end if;
            if v_aw > 0 then
              -- ---添加奖励设置-------------------------------------
              insert into ad_awardset
                (adid,
                 appid,
                 type,
                 dlevel,
                 event,
                 needlevel,
                 times,
                 atype,
                 awardgroup,
                 groupname,
                 psecond,
                 price,
                 amoney,
                 itime,
                 isshow)
                select adid,
                       I_APPID,
                       type,
                       dlevel,
                       event,
                       needlevel,
                       times,
                       atype,
                       awardgroup,
                       groupname,
                       psecond,
                       price,
                       case
                         when I_ForCeShi = 0 then
                          case
                            when atype = 9 then
                             amoney
                            else
                             price * v_arate
                          end
                         else
                          amoney
                       end,
                       sysdate,
                       isshow
                  from ad_awardset
                 WHERE appid = v_appid
                   AND adid = cur.adid;
              commit;
              --------------------------------
              --如果是渠道结算1：9的渠道，则结算金额乘以1.125
              select price_rate
                into v_PriceRate
                from ad_channel
               where appid = I_APPID;
              if v_PriceRate != 0.8 then
                update ad_awardset
                   set price = price * v_PriceRate * 1.25
                 where adid = cur.adid
                   and appid = I_APPID
                   and (select starttime
                          from Ad_Adinfo
                         where adid = cur.adid) <
                       to_date('2019-06-16', 'yyyy-mm-dd');
              end if;
              --如果是渠道结算1：8的渠道，则结算金额除以0.9
              select price_rate
                into v_PriceRate
                from ad_channel
               where appid = I_APPID;
              if v_PriceRate != 0.9 then
                update ad_awardset
                   set price = case
                                 when price * v_PriceRate / 9 * 10 > amoney then
                                  price * v_PriceRate / 9 * 10
                                 else
                                  amoney
                               end
                 where adid = cur.adid
                   and appid = I_APPID;
              end if;
              --------------------------------------------------
            end if;
          
          end if;
        
        end if;
      end loop;
      commit;
    end;
    --异常处理
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      O_Result  := 110;
      O_Message := '渠道添加广告错误 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      RETURN;
  end pw_Channel_AdJoin;

  procedure pq_Ad_BannerList
  /*****************************************************************
    Procedure Name:pq_Ad_BannerList 
    Purpose: 查询Banner图
    Edit: 2018-04-28 add by 小胡
    ****************************************************************/
  (I_ADMINID   In Varchar2,
   I_ADID      In Number,
   I_ADNAME    In Varchar2,
   I_STATUS    In Number,
   I_PhoneType In Number,
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    V_QX        number;
    v_sql       varchar2(2000);
    v_selectsql varchar2(1000);
  begin
    o_result  := 0;
    o_message := '显示成功';
    V_QX      := 341; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    v_sql := 'select id,adid,title,imgurl
               ,decode(status,1,''<span style="color:blue">正常</span>'',2,''关闭'',''未开启'') status,
               decode(phonetype,1,''IOS'',2,''安卓'',''IOS及安卓'') phonetype
               ,to_char(btime,''yyyy-mm-dd'') starttime,to_char(etime ,''yyyy-mm-dd'') stoptime,
               decode(adtype,1,''普通广告'',''关注广告'') adtype,ltime,status as ordernum  from ad_banner_v2 where 1=1 ';
  
    v_selectsql := '';
  
    ---条件查询
    if I_ADID is not null then
      v_selectsql := v_selectsql || ' and adid = ' || I_ADID;
    end if;
    if I_ADName is not null then
      v_selectsql := v_selectsql || ' and (title like ''%' || I_ADName ||
                     '%'')';
    end if;
    if I_Status is not null then
      v_selectsql := v_selectsql || ' and status =''' || I_Status || '''';
    end if;
    if I_PhoneType is not null then
      v_selectsql := v_selectsql || ' and PhoneType =''' || I_PhoneType || '''';
    end if;
  
    v_sql := v_sql || v_selectsql || '  order by  ordernum,ltime desc';
    open O_OUTCURSOR for v_sql;
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '获取失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
    
  end pq_Ad_BannerList;

  procedure pw_Ad_AddBanner
  /*****************************************************************
    Procedure Name:pw_Ad_AddBanner 
    Procedure Name: 添加Banner图
    Edit: 2018-08-30 add by 小胡
    ****************************************************************/
  (I_ADMINID   In Varchar2, --管理员id
   I_ADID      In Number, --广告Id
   I_ADNAME    In Varchar2, --广告名称
   I_IMGURL    In Varchar2, --Banner图存储路径
   I_STATUS    In Number, --状态 0：未开启 1：正常 2：关闭
   I_PHONETYPE In Number, --应用类型 1、ios，  2、安卓， 3、ios和安卓都显示
   I_ADTYPE    In Number, --广告类型 1：普通广告 2：关注广告
   I_STIME     In Varchar2, --Banner投放开始时间
   I_ETIME     In Varchar2, --Banner停止投放时间
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    v_n  number;
    V_QX number;
  begin
    o_result  := 0;
    o_message := '添加成功';
    V_QX      := 341; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    --检验输入参数是否正确
    if I_ADID is null then
      o_result  := 102;
      o_message := '输入参数有误，请检查！';
      return;
    end if;
  
    select count(1) into v_n from ad_adinfo where ADID = I_ADID;
  
    if v_n = 0 then
      o_result  := 104;
      o_message := '未找到指定广告，不能添加！';
      return;
    end if;
  
    ---添加Banner
    insert into ad_banner_v2
      (id, adid, title, imgurl, status, phonetype, btime, etime, adtype)
    values
      (sq_ad_banner.nextval,
       I_ADID,
       I_ADNAME,
       I_IMGURL,
       I_STATUS,
       I_PHONETYPE,
       to_date(I_STIME, 'yyyy-mm-dd hh24:mi:ss'),
       to_date(I_ETIME, 'yyyy-mm-dd hh24:mi:ss'),
       I_ADTYPE);
    commit;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '获取失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
    
  end pw_Ad_AddBanner;

  procedure pw_AD_EditBanner
  /*****************************************************************
    Procedure Name:pw_AD_EditBanner 
    Procedure Name: 编辑Banner图
    Edit: 2018-08-30 add by 小胡
    ****************************************************************/
  (I_ID        In Varchar2, --Banner图id
   I_ADMINID   In Varchar2, --管理员id
   I_ADID      In Number, --广告Id
   I_ADNAME    In Varchar2, --广告名称
   I_IMGURL    In Varchar2, --Banner图存储路径
   I_STATUS    In Number, --状态 0：未开启 1：正常 2：关闭
   I_PHONETYPE In Number, --应用类型 1、ios，  2、安卓， 3、ios和安卓都显示
   I_ADTYPE    In Number, --广告类型 1：普通广告 2：关注广告
   I_STIME     In Varchar2, --Banner投放开始时间
   I_ETIME     In Varchar2, --Banner停止投放时间
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    v_n  number;
    v_s  number;
    V_QX number;
  
  begin
    o_result  := 0;
    o_message := '显示成功';
    V_QX      := 341; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    --检验输入参数是否正确
    if I_ADID is null then
      o_result  := 102;
      o_message := '输入参数有误，请检查！';
      return;
    end if;
  
    select count(1) into v_n from ad_adinfo where ADID = I_ADID;
  
    if v_n = 0 then
      o_result  := 104;
      o_message := '未找到指定广告，不能编辑！';
      return;
    end if;
  
    select count(1) into v_s from ad_banner_v2 where id = I_ID;
    if v_s = 0 then
      o_result  := 104;
      o_message := '未找到该banner图，不能编辑！';
      return;
    end if;
  
    update ad_banner_v2
       set adid      = I_ADID,
           title     = I_ADNAME,
           imgurl    = I_IMGURL,
           status    = I_STATUS,
           phonetype = I_PHONETYPE,
           btime     = to_date(I_STIME, 'yyyy-mm-dd hh24:mi:ss'),
           etime     = to_date(I_ETIME, 'yyyy-mm-dd hh24:mi:ss'),
           ltime     = sysdate,
           adtype    = I_ADTYPE
     where ID = I_ID;
  
    commit;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '获取失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
    
  end pw_AD_EditBanner;

  procedure pq_AD_GetBanner
  /*****************************************************************
    Procedure Name: 查询Banner图
    ****************************************************************/
  (I_ADMINID   In Varchar2, --管理员id
   I_ID        In Varchar2, --Banner图id
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    v_n   number;
    V_QX  number;
    v_sql varchar2(1000);
  begin
    o_result  := 0;
    o_message := '显示成功';
    V_QX      := 341; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    --检验输入参数是否正确
    if I_ID is null then
      o_result  := 102;
      o_message := '输入参数有误，请检查！';
      return;
    end if;
  
    select count(1) into v_n from ad_banner_v2 where ID = I_ID;
  
    if v_n = 0 then
      o_result  := 104;
      o_message := '未找到该Banner图，不能编辑！';
      return;
    end if;
  
    v_sql := 'select id,adid,title,imgurl,status,phonetype,to_char(btime,''yyyy-mm-dd hh24:mi:ss'') btime,to_char(etime,''yyyy-mm-dd hh24:mi:ss'') etime,adtype from ad_banner_v2 where id=' || I_ID;
  
    open O_OUTCURSOR for v_sql;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '获取失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
    
  end pq_AD_GetBanner;

  procedure pw_Ad_DeleteBanner
  /*****************************************************************
    Procedure Name: 删除Banner图
    ****************************************************************/
  (I_ADMINID  In Varchar2, --管理员用户名
   I_BannerID In Number, --ID
   O_Result   Out Number,
   O_Message  Out Varchar2) is
    v_n  number;
    V_QX number;
  begin
    o_result  := 0;
    o_message := '删除成功';
    V_QX      := 341; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    --检验输入参数是否正确
    if I_BannerID is null then
      o_result  := 102;
      o_message := '输入参数有误，请检查！';
      return;
    end if;
  
    select count(1) into v_n from ad_banner_v2 where ID = I_BannerID;
  
    if v_n = 0 then
      o_result  := 104;
      o_message := '未找到该banner图，删除失败 ！';
      return;
    end if;
  
    ---删除Banner
    delete ad_banner_v2 where id = I_BannerID;
    commit;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '删除失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
    
  end pw_Ad_DeleteBanner;

  procedure pw_ad_SetRecAD
  /*****************************************************************
        Procedure Name :pq_AD_List
        Purpose: 设置推荐广告
        Edit: 2018-8-21 add by 小胡
    ****************************************************************/
  (I_AdmInId In Varchar2, --管理员id
   I_ADIDS   In Varchar2, --广告id列表
   I_ISREC   In Number, --是否推荐 是否推荐广告，0：不推荐，1：推荐
   O_Result  Out Number,
   O_Message Out Varchar2) is
    v_n  number;
    V_QX NUMBER; --本模块的权限代码
  begin
    O_Result  := 0;
    O_Message := '设置成功';
    V_QX      := 391; --初始化权限代码
  
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    DECLARE
    
      CURSOR myCur IS
      --用逗号分割广告ID字符串
        select regexp_substr(I_ADIDS, '[^,]+', 1, level, 'i') as adid
          from dual
        connect by level <= length(I_ADIDS) -
                   length(regexp_replace(I_ADIDS, ',', '')) + 1;
    begin
    
      for cur in myCur LOOP
        select count(1) into v_n from ad_adinfo where adid = cur.adid;
        if v_n > 0 then
          update ad_adinfo set isrecommend = I_ISREC where adid = cur.adid;
          commit;
        end if;
      end loop;
    end;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '获取失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pw_ad_SetRecAD;

  procedure pq_AD_RecList
  /*****************************************************************
        Procedure Name :pq_AD_List
        Purpose: 广告推荐列表
        Edit: 2018-8-21 add by 小胡
    ****************************************************************/
  (I_AdmInId        In Varchar2, --管理员id
   I_ADID           In Number, --广告id
   I_ADName         In Varchar2, --广告名称
   I_Status         In Number, --广告状态
   I_ShowType       In Number, --显示状态 0不显示，1显示
   I_PhoneType      In Number, --显示设备 1、ios，  2、安卓， 3、ios和安卓都显示
   I_IsRecommend    In Number, -- 是否推荐广告，0：不推荐，1：推荐
   I_PageSize       In Number,
   I_PageNO         In Number,
   O_OutRecordCount Out Number,
   O_OutCursor      Out t_cursor, --返回游标
   O_Result         Out Number,
   O_Message        Out Varchar2) is
    v_sql       varchar2(2000);
    v_selectsql varchar2(1000);
    V_HEIROWNUM NUMBER;
    V_LOWROWNUM NUMBER;
    V_QX        NUMBER; --本模块的权限代码
  begin
    o_result  := 0;
    o_message := '显示成功';
    V_QX      := 391; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    v_sql := 'select adid,title,adname
             ,decode(status,0,''未投放'',1,''<span style="color:blue">正常</span>'',2,''日到量'',3,''总到量'',''停止投放'')||decode(showtype,0,''<span style="color:red">(不显示)</span>'','''') status
             ,to_char(starttime,''yyyy-mm-dd'') starttime,to_char(stoptime ,''yyyy-mm-dd'') stoptime,adtype,decode(isrecommend,0,''<span style="color:#f00">不推荐</span>'',1,''<span style="color:blue">推荐</span>'') as isrecommend,
             isrecommend isrec,RECOMMEND_ORDER showorder,decode(status,1,19,2,18,3,17,4,16,0,15,10) ADSort
               from ad_adinfo where 1=1 and status = 1  ';
  
    v_selectsql := '';
  
    if I_ADID is not null then
      v_selectsql := v_selectsql || ' and adid = ' || I_ADID;
    end if;
    if I_ADName is not null then
      v_selectsql := v_selectsql || ' and (title like ''%' || I_ADName ||
                     '%'' or adname like ''%' || I_ADName || '%'')';
    end if;
    if I_Status is not null then
      v_selectsql := v_selectsql || ' and status =''' || I_Status || '''';
    end if;
    if I_ShowType is not null then
      v_selectsql := v_selectsql || ' and ShowType =''' || I_ShowType || '''';
    end if;
    if I_PhoneType is not null then
      v_selectsql := v_selectsql || ' and PhoneType =''' || I_PhoneType || '''';
    end if;
    if I_IsRecommend is not null then
      v_selectsql := v_selectsql || ' and ISRECOMMEND =''' || I_IsRecommend || '''';
    end if;
    execute immediate 'select count(1) from ad_adinfo where 1 = 1 and status = 1' ||
                      v_selectsql
      into O_OUTRECORDCOUNT;
  
    v_sql := v_sql || v_selectsql ||
             '  order by isrecommend desc, ADSort desc ,showtype desc, RECOMMEND_ORDER asc,  itime desc';
  
    ----执行分页查询
    V_HEIROWNUM := I_PAGENO * I_PAGESIZE;
    V_LOWROWNUM := V_HEIROWNUM - I_PAGESIZE + 1;
    V_SQL       := 'select adid,title,adname,status,starttime,stoptime,adtype , p_ad_manage.fq_admarketer(adid) marketer ,rn,isrecommend,isrec ,showorder
                    FROM (
                    select adid,title,adname,status,starttime,stoptime,adtype,rownum rn,isrecommend,isrec ,showorder
                    FROM (' || v_sql || ') A
                    WHERE rownum <= ' ||
                   TO_CHAR(V_HEIROWNUM) || '
                    ) B
                    WHERE rn >= ' || TO_CHAR(V_LOWROWNUM);
    open O_OUTCURSOR for v_sql;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '获取失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pq_AD_RecList;

  Function FQ_ADMarketer
  /*****************************************************************
        Procedure Name :FQ_ADMarketer
        Purpose: 根据广告查询市场人员
        Edit: 2018-04-28 add by 小沈
    ****************************************************************/
  (I_ADID In Number --广告ID 
   ) Return Varchar2 As
  
    v_n        number;
    v_marketer varchar2(50);
  
  begin
  
    select count(1) into v_n from ad_downurl where adid = I_ADID;
    if v_n <= 0 then
      v_marketer := '无';
      return v_marketer;
    end if;
    select marketer
      into v_marketer
      from (select marketer
              from ad_downurl
             where adid = I_ADID
            --and status not in (0, 4)
             order by itime asc)
     where rownum = 1;
  
    return v_marketer;
  exception
    --失败
    when others then
      --v_msg := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      rollback;
      return v_marketer;
  end FQ_ADMarketer;
  procedure PQ_AwardOrderList
  /*****************************************************************
        Procedure Name :PQ_AwardOrderList
        Purpose: 奖励订单列表
        Edit: 2018-10-30 add by 小胡
    ****************************************************************/
  (I_AdmInId   In Varchar2, --管理员id
   I_ADID      In Number, --广告id
   I_APPID     In Varchar2, --渠道名称
   I_STATUS    In Number, --订单状态
   I_ORDERNUM  In Varchar2, --订单号
   I_PageSize  In Number,
   I_PageNO    In Number,
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    v_SQL       varchar2(2000);
    V_HEIROWNUM number;
    V_LOWROWNUM number;
    V_QX        number;
  begin
    O_Result  := 0;
    O_Message := '显示成功';
    V_QX      := 104; --初始化权限代码  
    open O_OutCursor for
      select 1 from dual where 1 != 1;
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    v_sql := 'select a.adid,a.adname,a.appid,a.ordernum,a.dlevel,a.awardgroup,b.event,a.deviceid,a.appsign,a.merid,a.mername,a.money,a.price,' ||
             ' case when a.p_status=1 then ''接收成功'' when a.p_status=2 then ''推送失败'' when a.p_status=-1 then ''待系统审核'' when a.p_status=3 then ''不推送'' when a.p_status=9 then ''待人工审核'' end statusStr,a.p_status status'
            
             ||
             ',to_char(a.p_time ,''yyyy-mm-dd hh24:mi:ss'') ptime,to_char(a.itime ,''yyyy-mm-dd hh24:mi:ss'') itime from ad_channel_order a,ad_awardset b where a.adid=b.adid and a.appid=b.appid and a.dlevel=b.dlevel  ';
    if I_ADID is not null then
      v_SQL := v_SQL || ' and a.adid=' || I_ADID;
    end if;
    if I_APPID is not null then
      v_sql := v_SQL || ' and a.appid=' || I_APPID;
    end if;
    if I_STATUS is not null then
      v_sql := v_SQL || ' and a.p_status=' || I_STATUS;
    end if;
    if I_ORDERNUM is not null then
      v_sql := v_SQL || ' and a.ordernum=''' || I_ORDERNUM || '''';
    end if;
  
    --v_SQL:=v_SQL||' order by itime desc';
    ----执行分页查询
    V_HEIROWNUM := I_PAGENO * I_PAGESIZE;
    V_LOWROWNUM := V_HEIROWNUM - I_PAGESIZE + 1;
    V_SQL       := 'select adid,adname,appid,ordernum,dlevel,awardgroup,event,deviceid,appsign,merid,mername,money,price,statusStr,status,ptime,itime,rn
                    FROM (
                  select adid,adname,appid,ordernum,dlevel,awardgroup,event,deviceid,appsign,merid,mername,money,price,statusStr,status,ptime,itime,rownum rn
                    FROM (' || v_sql || ') A
                    WHERE rownum <= ' ||
                   TO_CHAR(V_HEIROWNUM) || '
                    ) B
                    WHERE rn >= ' || TO_CHAR(V_LOWROWNUM);
  
    open O_OUTCURSOR for v_sql;
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '查询失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PQ_AwardOrderList;

  procedure PQ_AwardOrderCheck
  /*****************************************************************
        Procedure Name :PQ_AwardOrderCheck
        Purpose: 奖励订单审核
        Edit: 2018-11-01 add by 小胡
    ****************************************************************/
  (I_AdmInId  In Varchar2, --管理员id
   I_ORDERNUM In Varchar2, --订单编号
   I_STATUS   In Number, --订单状态
   I_ADID     In Varchar2,
   I_APPID    In Varchar2,
   O_Result   Out Number,
   O_Message  Out Varchar2) is
    V_QX number;
    v_n  number;
  begin
    O_Result  := 0;
    O_Message := '审核成功';
    V_QX      := 104; --初始化权限代码  
  
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    select count(1)
      into v_n
      from ad_channel_order
     where ordernum = I_ORDERNUM
       and adid = I_ADID
       and appid = I_APPID;
    if v_n > 0 then
      if I_STATUS = 0 then
        update ad_channel_order
           set p_status = I_STATUS,
               p_ntime  = sysdate - (2 / (24 * 60)),
               p_times  = 0
         where ordernum = I_ORDERNUM
           and adid = I_ADID
           and appid = I_APPID
           and p_status not in (0, 3);
      else
        update ad_channel_order
           set p_status = I_STATUS
         where ordernum = I_ORDERNUM
           and adid = I_ADID
           and appid = I_APPID
           and p_status not in (0, 3);
      end if;
      commit;
    end if;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '查询失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PQ_AwardOrderCheck;

/*  procedure PQ_Syncad
  \*****************************************************************
        Procedure Name :PQ_syncad
        Purpose: 同步闲玩广告
        Edit: 2019-05-29 add by 小刘
    ****************************************************************\
  (I_AdmInId In Varchar2, --管理员id
   I_ADID    In Varchar2,
   O_Result  Out Number,
   O_Message Out Varchar2) is
    V_QX     number;
    v_n      number;
    new_adid number;
    cursor mycur is
      select actid,
             aname,
             intro,
             new_adid as adid,
             dlevel,
             pcount,
             etime,
             arank,
             status
        from ad_activity@xwanad_link
       where adid = I_ADID;
    v_actid number;
  begin
    O_Result  := 0;
    O_Message := '同步成功';
    V_QX      := 471; --初始化权限代码  
  
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
    select count(1) into v_n from ad_adinfo@dbl_adwll where adid = I_ADID;
    if v_n <= 0 then
      O_Result  := 101;
      O_Message := '没有该广告';
    end if;
    if v_n > 0 then
      new_adid := SQ_AD_INFO.NEXTVAL;
    
      insert into ad_adinfo
        (adid,
         title,
         adname,
         money,
         intro,
         status,
         showtype,
         starttime,
         stoptime,
         phonetype,
         adtype,
         appsize,
         imgurl,
         description,
         desimgurls,
         adlink,
         pagename,
         iosadlink,
         iospagename,
         iosurlschemes,
         iosproname,
         iosversion,
         ioskeyword,
         iosrank,
         appsign,
         buttonshow,
         buttonname,
         showorder,
         msgnoinstall,
         msgnoreg,
         msgreg,
         msgdaylimit,
         msgalllimit,
         isrecommend,
         is_easy)
        select new_adid as adid,
               title,
               adname,
               money,
               intro,
               status,
               0,
               starttime,
               stoptime,
               phonetype,
               adtype,
               appsize,
               imgurl,
               description,
               desimgurls,
               'https://h5.51xianwan.com/try/try_list_plus.aspx?adid=' ||
               new_adid,
               pagename,
               iosadlink,
               iospagename,
               iosurlschemes,
               iosproname,
               iosversion,
               ioskeyword,
               iosrank,
               appsign,
               buttonshow,
               buttonname,
               showorder,
               msgnoinstall,
               msgnoreg,
               msgreg,
               msgdaylimit,
               msgalllimit,
               isrecommend,
               is_easy
          from ad_adinfo@dbl_adwll
         where adid = I_ADID;
      select count(1)
        into v_n
        from AD_AWARDSET@DBL_ADWLL
       where adid = I_ADID;
      if v_n > 0 then
        insert into AD_AWARDSET
          (adid,
           appid,
           type,
           dlevel,
           event,
           needlevel,
           times,
           atype,
           awardgroup,
           groupname,
           psecond,
           price,
           amoney,
           isshow)
          select new_adid as adid,
                 appid,
                 type,
                 dlevel,
                 event,
                 needlevel,
                 times,
                 atype,
                 awardgroup,
                 groupname,
                 psecond,
                 price,
                 amoney,
                 isshow
            from ad_awardset@dbl_adwll
           where adid = I_ADID
             and appid = 1010;
      end if;
      select count(1)
        into v_n
        from AD_ACTIVITY@DBL_ADWLL
       where adid = I_ADID;
      if v_n > 0 then
        for cur in mycur loop
          select SQ_AD_ACTIVITY.NEXTVAL into v_actid from dual;
          insert into Ad_Activity
            (actid,
             aname,
             intro,
             adid,
             dlevel,
             pcount,
             etime,
             arank,
             status)
          values
            (v_actid,
             cur.aname,
             cur.intro,
             cur.adid,
             cur.dlevel,
             cur.pcount,
             cur.etime,
             cur.arank,
             cur.status);
        
          select count(1)
            into v_n
            from AD_ACTIVITY_AWARD@DBL_ADWLL
           where adid = I_ADID;
          if v_n > 0 then
            insert into AD_ACTIVITY_AWARD
              (adid, actid, srank, erank, money, price, status)
              select new_adid as adid,
                     v_actid  as actid,
                     srank,
                     erank,
                     money,
                     price,
                     status
                from AD_ACTIVITY_AWARD@DBL_ADWLL
               where adid = I_ADID
                 and actid = cur.actid;
          end if;
        end loop;
      end if;
    
      O_Message := O_Message || '，嘻趣编号:' || new_adid;
      commit;
    end if;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '查询失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PQ_Syncad;*/
end P_AD_Manage;
/


create PACKAGE P_Temp_Test AS
  TYPE T_CURSOR IS REF CURSOR;

  procedure PQ_UserClick
  /*****************************************************************
        Procedure Name :PQ_UserClick
        Purpose: 用户点击操作
        Edit: 2017-02-18 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   I_APPId     In Number, --渠道应用ID
   I_Deviceid  In Varchar2, --设备号ID
   I_SIMID     In Varchar2, --sim卡编号
   I_APPSign   In Varchar2, --渠道应用标识符号、渠道用户id
   I_PType     In Number, --1、ios  2、安卓
   I_IP        In Varchar2, --
   I_CType     In Number, --用户操作类型 1：下载  2：打开
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number, --判断 0：查询成功，其他：出错
   O_Message   Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );
   
end P_Temp_Test;


/


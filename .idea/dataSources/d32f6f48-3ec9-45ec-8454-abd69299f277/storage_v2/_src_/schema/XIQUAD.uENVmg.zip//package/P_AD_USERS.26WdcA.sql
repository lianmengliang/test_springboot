create PACKAGE P_AD_Users AS

  TYPE T_CURSOR IS REF CURSOR;

  /*
  根据广告渠道用户生成闲玩用户ID 
  */

  procedure PQ_User
  /*****************************************************************
        Procedure Name :PQ_User
        Purpose: 查找闲玩用户编号
        Edit: 2018-03-27 add by 小沈
    ****************************************************************/
  (I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_SIMID    In Varchar2, --sim卡编号
   I_AppSign  In Varchar2, --渠道用户标识
   I_PType    In Number, --1、ios  2、安卓  
   O_Userid   Out Number, --返回闲玩用户ID
   O_Deviceid Out Varchar2, --返回处理后的设备号
   O_Result   Out Number, --判断 0：查询成功，其他：出错
   O_Message  Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

end P_AD_Users;


/


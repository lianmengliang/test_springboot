create PACKAGE P_AD_Statistics_V2 AS
  TYPE T_CURSOR IS REF CURSOR;

  /*广告界面打开统计 */

  procedure PW_Open
  /*****************************************************************
        Procedure Name :PW_Open
        Purpose: 打开统计
        Edit: 2018-09-25 add by 小沈
    ****************************************************************/
  (I_PType    In Number, --1、ios  2、安卓
   I_APPId    In Number, --渠道应用ID
   I_ADID     In Number, --广告ID
   I_APPSign  In Varchar2, --渠道应用标识符号、渠道用户id
   I_Deviceid In Varchar2, --设备号ID
   I_Userid   In Number, --闲玩用户编号
   I_IP       In Varchar2, --
   I_Times    In Number, --访问时长单位秒
   I_SType    In Number, --统计类型 0：列表 1：广告详情
   I_Source   In Number, --来源 1：H5 2:闲玩盒子
   O_Result   Out Number, --判断 0：查询成功，其他：出错
   O_Message  Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );
  procedure PW_Open_V2
  /*****************************************************************
        Procedure Name :PW_Open
        Purpose: 打开统计
        Edit: 2018-09-25 add by 小沈
    ****************************************************************/
  (I_PType    In Number, --1、ios  2、安卓
   I_APPId    In Number, --渠道应用ID
   I_ADID     In Number, --广告ID
   I_APPSign  In Varchar2, --渠道应用标识符号、渠道用户id
   I_Deviceid In Varchar2, --设备号ID
   I_Userid   In Number, --闲玩用户编号
   I_IP       In Varchar2, --
   I_Times    In Number, --访问时长单位秒
   I_SType    In Number, --统计类型 0：列表落地页 1：广告详情落地页 2、触发执行列表（未用到） 3:服务端列表请求4:API服务端详情页 5:API 服务端列表页 
   I_Source   In Number, --来源 1：H5 2:闲玩盒子
   I_ADType   In Number, --统计广告类型
   O_Result   Out Number, --判断 0：查询成功，其他：出错
   O_Message  Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );
  Procedure Job_StatsDay;
  /*****************************************************************
      procedure name: Job_StatsDay
      purpose: 统计日表
      edit: 2018-05-13 add by 小沈
  ****************************************************************/

end P_AD_Statistics_V2;
/


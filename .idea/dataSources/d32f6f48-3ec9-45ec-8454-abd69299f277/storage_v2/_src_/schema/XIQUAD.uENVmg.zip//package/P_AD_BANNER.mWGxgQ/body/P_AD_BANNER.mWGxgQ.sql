create PACKAGE BODY P_AD_Banner AS

  /*广告Banner */

  procedure PQ_List
  /*****************************************************************
        Procedure Name :PQ_List
        Purpose: 获取banner 列表
        Edit: 2018-09-17 add by 小沈
    ****************************************************************/
  (I_APPId          In Number, --渠道应用ID
   I_Deviceid       In Varchar2, --设备号ID
   I_SIMID          In Varchar2, --sim卡编号
   I_Userid         In Number, --闲玩用户编号
   I_PType          In Number, --1、ios  2、安卓
   I_IP             In Varchar2, --用户当前IP
   I_IP_Num         In Number, --用户当前IP 数字化
   O_Outrecordcount Out Number, --返回总记录数
   O_Outcursor      Out t_cursor, --返回游标
   O_Result         Out Number, --判断 0：查询成功，其他：出错
   O_Message        Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is

    v_DeviceId varchar2(100);
  begin
    O_Result  := 0;
    O_Message := '查询成功';
  
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    --阅趣--IOS  不显示banner
    if I_APPId = 1451 then
      return;
    end if;
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
    --去空格处理
    v_DeviceId := fq_str_delspace(i_str => I_Deviceid);
    --设备号校验是否合法 0否 1是
    if p_base_fun.fq_deviceid_check(v_DeviceId, I_PType) = 0 then
      O_Result  := 1;
      O_Message := '请先对APP进行授权';
      return;
    end if;
  
    if v_DeviceId is null then
      O_Result  := 1;
      O_Message := '用户信息不能为空';
      return;
    end if;
  
    select count(1)
      into O_Outrecordcount
      from ad_banner_v2
     where status = 1
       and phonetype in (I_PType, 3)
       and btime <= sysdate
       and sysdate <= etime
       and P_AD_IsShow_List.fq_isshow(i_adid     => adid,
                                      i_appid    => i_appid,
                                      i_deviceid => v_DeviceId,
                                      i_userid   => i_userid,
                                      i_ip       => i_ip,
                                      i_ip_num   => i_ip_num,
                                      i_ptype    => i_ptype) = 1;
  
    ----------------------------------------------------
    --步骤二：返回记录集
    ----------------------------------------------------
    OPEN O_OUTCURSOR FOR
      select adid,
             title,
             imgurl,
             p_ad_banner.fq_ad_link(I_APPId, I_PType,adid) as link_url,
             adtype
        from ad_banner_v2
       where status = 1
         and phonetype in (I_PType, 3)
         and btime <= sysdate
         and sysdate <= etime
         and P_AD_IsShow_List.fq_isshow(i_adid     => adid,
                                        i_appid    => i_appid,
                                        i_deviceid => v_DeviceId,
                                        i_userid   => i_userid,
                                        i_ip       => i_ip,
                                        i_ip_num   => i_ip_num,
                                        i_ptype    => i_ptype) = 1
       order by dbms_random.value();
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    commit;
    return;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      ROLLBACK;
      O_Result  := -9;
      O_Message := '查询失败';
      RETURN;
  end PQ_List;

  function FQ_AD_Link
  /*****************************************************************
        Procedure Name :FQ_AD_Link
        Purpose: 获取广告连接
       Edit: 2018-04-13 add by 小沈
    ****************************************************************/
  (I_APPId In Number, --渠道应用ID
   I_PType In Number, --1、ios  2、安卓
   I_Adid  In Number --广告编号
   ) return varchar2 --返回
   is
    v_adlink varchar2(500) := '';
  begin
    if I_APPId not in (1010, 1003) and I_PType = 2 then
      return v_adlink;
    end if;
  
    if I_PType = 2 then
      select adlink into v_adlink from ad_adinfo where adid = I_Adid;
    else
      select iosadlink into v_adlink from ad_adinfo where adid = I_Adid;
    end if;
  
    return v_adlink;
  EXCEPTION
    WHEN OTHERS THEN
      return '';
  end FQ_AD_Link;

end P_AD_Banner;
/


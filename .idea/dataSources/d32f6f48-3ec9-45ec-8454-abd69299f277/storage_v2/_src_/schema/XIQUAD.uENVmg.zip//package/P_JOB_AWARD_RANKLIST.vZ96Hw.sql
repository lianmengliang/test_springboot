create PACKAGE P_JOB_AWARD_RANKLIST AS
  TYPE T_CURSOR IS REF CURSOR;
  /*****************************************************************
   Procedure Name :P_JOB_AWARD_DAILYLIST
   Purpose: 每5分钟更新一次日榜榜单。在每天凌晨0点05分需要最后结算一次昨天的统计数据，才是最准的日榜
   Edit: 2019/7/1 20:18:35 add by 旭东
  ****************************************************************/
  procedure P_JOB_DAILYLIST_TASK(
    I_TASKTYPE NUMBER --任务类型 0：统计今天的   1：统计昨天的
    );

  /*****************************************************************
   Procedure Name :P_JOB_SETTLE_DAILLYLIST_TASK
   Purpose: 每天9点结算昨日榜单，只做结算与同步用户信息到盒子主库
   Edit: 2019/7/1 20:18:35 add by 旭东
  ****************************************************************/
  procedure P_JOB_SETTLE_DAILLYLIST_TASK;
  
  
  /*****************************************************************
   Procedure Name :P_JOB_HANDLE_SETTLE__TASK
   Purpose: 每天10点执行，将已经结算的榜单并且是用户状态待审核的奖励信息审核将该奖励改为可让用户提现，并给盒子主库用户加钱和流水
   Edit: 2019/7/1 20:18:35 add by 旭东
  ****************************************************************/
  procedure P_JOB_HANDLE_SETTLE__TASK;
  
  /*****************************************************************
   Procedure Name :P_JOB_HANDLE_DRAW_TASK
   Purpose: 每小时执行一次 将七天内的提现状态是已申请处理中的奖励状态去盒子主库查询最终的发奖状态，并更新回来
   Edit: 2019/7/1 20:18:35 add by 旭东
  ****************************************************************/
  procedure P_JOB_HANDLE_DRAW_TASK;
  
  
  

end P_JOB_AWARD_RANKLIST;
/


create package body P_WXAD_Award is

  /*微信广告奖励主入口*/

  procedure Job_Wait is
    /***************************************************************
      procedure name :Job_Wait
     purpose：
          对在待奖区的用户进行奖励
      edit: 2017-10-23 add by 小沈
    ****************************************************************/
  
    v_n        number; --
    v_RowCount number; --防并发
  
    v_ordernum Varchar2(100); --订单编号
    v_adname   varchar2(100); --前台显示广告名称 
    v_event    varchar2(200); --奖励说明 
    cursor Cur_List is
    
      select id,
             adid,
             appid,
             deviceid,
             simid,
             appsign,
             openid,
             dlevel,
             price,
             amoney
        from wx_ad_flux
       where exptime <= sysdate
         and status = 0
       order by exptime asc;
  
  begin
  
    ----------------------------------------------------
    --步骤一：修改状态
    ----------------------------------------------------
    for cur in Cur_List loop
    
      --修改 状态
      update wx_ad_flux
         set status = 9
       where id = cur.id
         and status = 0;
      v_RowCount := sql%rowcount;
      if v_RowCount != 1 then
        rollback;
        goto NextLoop;
      end if;
    
      --添加渠道订单
      select event
        into v_event
        from wx_ad_awardset
       where adid = cur.adid
         and dlevel = cur.dlevel
         and appid = cur.appid;
    
      select adname into v_adname from wx_adinfo where adid = cur.adid;
    
      v_ordernum := 'wx_' || cur.appid ||
                    to_char(sysdate, 'yyyymmddhh24miss') || cur.adid ||
                    dbms_random.string('x', 5) ||
                    trunc(dbms_random.value(0, 10));
    
      insert into ad_channel_order
        (adid,
         adname,
         appid,
         ordernum,
         dlevel,
         awardgroup,
         pagename,
         deviceid,
         simid,
         appsign,
         merid,
         mername,
         event,
         price,
         money)
      values
        (cur.adid,
         v_adname,
         cur.appid,
         v_ordernum,
         cur.dlevel,
         1,
         v_adname,
         cur.deviceid,
         cur.simid,
         cur.appsign,
         cur.openid,
         cur.openid,
         v_adname || v_event,
         cur.price,
         cur.amoney);
    
      update wx_ad_flux
         set status = 1, awardtime = sysdate
       where id = cur.id
         and status = 9;
    
      v_RowCount := sql%rowcount;
    
      if v_RowCount != 1 then
        rollback;
        goto NextLoop;
      end if;
      commit;
    
      <<NextLoop>>
      null;
    
    end loop;
  
    commit;
  
    return;
  exception
    when others then
      rollback;
      return;
  end Job_Wait;

end P_WXAD_Award;
/


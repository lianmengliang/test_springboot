create procedure AAA_initializeADFlux
/*****************************************************************
      Procedure Name :AAA_initializeUser
      Purpose: 初始化广告绑定表用户闲玩ID
      Edit: 2016-10-31 add by 小沈
  ****************************************************************/
(O_Result  out number, --返回（0正确，其他为提示或错误）
 O_Message out varchar2 --返回信息（操作结果，成功或者错误信息）
 ) is
  v_n        number;
  v_userid   number;
  v_deviceid varchar2(100);
  v_result   number;
  v_message  varchar2(100);
  v_s_date   date;
  v_e_date   date;

  /*  cursor Cur_Date is
      select s_date, e_date
        from aaa_temp
       where status = 0
         and sign = I_Sign;
  */
  cursor Cur_Flux is
  
  /*    select appid, adid, deviceid, appsign, count(1)
                            from ad_app_flux
                           where itime >= v_s_date
                             and itime <= v_e_date + 1
                             and userid is null
                          --and adid = 2034
                          --and deviceid = '354728073257626'
                           group by appid, adid, deviceid, appsign
                           order by adid asc;*/
  
    select appid, adid, deviceid, appsign, count(1)
      from ad_app_flux
     where itime >= to_date('2018-04-12', 'yyyy-mm-dd')
       and itime < sysdate - 0.05
       and userid is null
     group by appid, adid, deviceid, appsign
     order by adid asc;

begin

  ----------------------------------------------------
  --步骤一：校验数据输入的合法性，以及初始化赋值
  ----------------------------------------------------
  O_Result  := 0;
  O_Message := '初始化完成';

  /* for cur_o in Cur_Date loop
  v_s_date := cur_o.s_date;
  v_e_date := cur_o.e_date;
  update aaa_temp
     set status = 9
   where status = 0
     and sign = I_Sign;
  commit;*/

  for cur_t in Cur_Flux loop
    --判断当前ID有无处理过
    --upper(deviceid) = cur_t.deviceid
    select count(1)
      into v_n
      from ad_app_bind
     where adid = cur_t.adid
       and appid = cur_t.appid
       and upper(deviceid) = cur_t.deviceid
       and appsign = cur_t.appsign
       and userid is not null;
    --有且只有1条
    if v_n = 1 then
      select userid
        into v_userid
        from ad_app_bind
       where adid = cur_t.adid
         and appid = cur_t.appid
         and upper(deviceid) = cur_t.deviceid
         and appsign = cur_t.appsign
         and userid is not null;
    
      update ad_app_flux
         set userid = v_userid
       where adid = cur_t.adid
         and appid = cur_t.appid
         and deviceid = cur_t.deviceid
         and appsign = cur_t.appsign
         and userid is null;
      commit;
    end if;
  
  end loop;

  /*  update aaa_temp
       set status = 1
     where s_date = v_s_date
       and e_date = v_e_date
       and status = 9;
    commit;
  end loop;*/

  ----------------------------------------------------
  --步骤三：完成
  ----------------------------------------------------

  return;
exception
  when others then
    rollback;
    O_Result  := -9;
    O_Message := '初始化异常！错误消息：' || sqlerrm || '错误ID:' || sqlcode;
    return;
  
end AAA_initializeADFlux;


/


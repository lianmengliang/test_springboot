create package P_AD_Activity is
  TYPE T_CURSOR IS REF CURSOR;

  procedure PQ_Activity_AwardRecord
  /*****************************************************************
        Procedure Name :PQ_Activity_AwardRecord
        Purpose: 获取福利活动领奖记录
        Edit: 2018-7-2  add by 小胡
    ****************************************************************/
  (I_ADID      In Number, --广告id
   I_ACTID     In Varchar2, --活动id
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number, --判断 0：查询成功，其他：出错
   O_Message   Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );
  procedure PW_Activity_AddRecord;
  /*****************************************************************
      Procedure Name :PQ_Activity_AddRecord
      Purpose: H5获取广告列表
      Edit: 2018-7-2  add by 小胡
  ****************************************************************/

  procedure PQ_ActAwardMoney
  /*****************************************************************
        Procedure Name :PQ_ActAwardMoney
        Purpose: 获取福利活动 奖励金额和结算金额
        Edit: 2018-08-13 add by 小胡
    ****************************************************************/
  (I_ADID  In Number, --广告ID 
   I_ACTID In Number, --活动id
   I_RANK  In Number, --排名
   O_MONEY Out Number, --奖励金额
   O_PRICE Out Number --结算金额
   );
  Function FQ_ActMoney
  /*****************************************************************
        Procedure Name :ActMoney
        Purpose: 查询奖励金额
        Edit: 2018-08-14 add by 小胡
    ****************************************************************/
  (I_ADID  In Number, --广告ID 
   I_ACTID In Number, --活动id
   I_RANK  In Number --排名
   ) Return number;

  procedure PQ_ACTIVITY
  /*****************************************************************
        Procedure Name :PQ_ACTIVITY
        Purpose: 获取福利活动
        Edit: 2018-08-15 add by 小胡
    ****************************************************************/
  (I_ADID      In Number, --广告ID 
   I_MerId     In Varchar2, --用户游戏账号id
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number, --判断 0：查询成功，其他：出错
   O_Message   Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   );

end P_AD_Activity;
/


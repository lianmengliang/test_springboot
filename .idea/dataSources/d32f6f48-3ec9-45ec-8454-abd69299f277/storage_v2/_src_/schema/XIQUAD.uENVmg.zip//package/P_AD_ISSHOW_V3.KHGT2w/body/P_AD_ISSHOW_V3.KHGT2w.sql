create PACKAGE BODY P_AD_IsShow_V3 AS

  /* 判断当前广告是否为该用户显示 */

  Function FQ_IsShow
  /*****************************************************************
        Procedure Name :FQ_IsShow
        Purpose: 判断是否显示 0 不显示 1 显示
        Edit: 2018-09-17 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_Userid   In Number, --闲玩用户编号
   I_IP       In Varchar2, --用户当前IP
   I_IP_Num   In Number, --用户当前IP 数字化
   I_PType    In Number --1、ios  2、安卓
   ) Return Number As
    PRAGMA AUTONOMOUS_TRANSACTION; -------------方法函数 被嵌套，且有表操作 必写
    -- 是否显示 0 不显示 1 显示
  
    v_status      number := 0;
    v_n           number;
    v_isBind      number; --是否绑定 0否 1是
    v_ADStatus    number; --广告状态
    v_showtype    number; ---0不显示，1显示
    v_andpagename varchar2(100); --安卓包名
    v_iosPageName varchar2(100); --苹果包
    v_isdevice    number := 1; --是否限制设备
    v_urlid       number; --下载地址编号
    v_UrlS        number; --下载状态（0未使用，1正常使用，2日到量，3总到量，4停止使用）
  
    v_AllMoney number; --用户可获得金额
    v_AllTimes number; --已获得总奖励次数
    v_adtype   number; --广告类型（1棋牌游戏，2应用，3手游）  
  
    v_province_user varchar2(100); -- 用户所在省份
    v_city_user     varchar2(100); -- 用户所在城市
    v_limit_type    number; --1:仅限当前区域体验 2：当前区域不可体验 
    v_ip_short      varchar2(20); --短IP
  
  begin
  
    if I_Userid is null or I_Userid = 0 then
      v_status := 0; --不显示
      return v_status;
    end if;
  
    if I_PType not in (1, 2) then
      v_status := 0; --不显示
      return v_status;
    end if;
  
    --渠道如果不存在或已下架则不显示
    select count(1)
      into v_n
      from ad_channel
     where appid = appid
       and status in (0, 1);
  
    if v_n <= 0 then
      v_status := 0; --不显示
      return v_status;
    end if;
  
    select status, showtype, adtype, isdevice, iospagename, pagename
      into v_ADStatus,
           v_showtype,
           v_adtype,
           v_isdevice,
           v_iosPageName,
           v_andpagename
      from ad_adinfo
     where adid = I_ADID;
  
    if v_ADStatus in (0, 4) then
      v_status := 0; --不显示
      return v_status;
    end if;
  
    --该存储过程为嵌套使用所以传入的设备号已处理
    --不显示广告只有测试机显示
    if v_showtype = 0 then
      select count(1)
        into v_n
        from ad_testdevice
       where deviceid = I_Deviceid
         and status = 0;
      if v_n <= 0 then
        v_status := 0;
        return v_status;
      end if;
    end if;
  
    --判断奖励是否已设置
    select count(1)
      into v_n
      from ad_awardset
     where adid = i_adid
       and appid = I_APPId;
  
    if v_n <= 0 then
      v_status := 0;
      return v_status;
    end if;
  
    --是否有下载地址
    select count(1) into v_n from ad_downurl where adid = i_adid;
    if v_n <= 0 then
      v_status := 0;
      return v_status;
    end if;
  
    --判断当前设备号有无在其他渠道体验过
    --有则直接不显示
    select count(1)
      into v_n
      from ad_app_bind
     where adid = i_adid
       and appid != I_APPId
       and deviceid = I_Deviceid;
  
    if v_n > 0 then
      v_status := 0;
      return v_status;
    end if;
  
    --判断当前设备是否有其他闲玩ID体验过 有则不显示
    --避免一个设备号多个帐号去体验
    select count(1)
      into v_n
      from ad_app_bind
     where adid = i_adid
       and userid != I_Userid
       and deviceid = I_Deviceid;
  
    if v_n > 0 then
      v_status := 0;
      return v_status;
    end if;
  
    --判断用户是否已经体验过了 [同用户不同手机还是显示原来的号所以可以体验]
    select count(1)
      into v_isBind
      from ad_app_bind
     where adid = i_adid
       and userid = I_Userid;
    --如果没体验过 且广告非正常投放 则不显示
    if v_isBind <= 0 and v_ADStatus != 1 then
      v_status := 0;
      return v_status;
    end if;
    --可能存在异常不显示 【绑定记录多条】
    if v_isBind > 1 then
      v_status := 0;
      return v_status;
    end if;
  
    --如果正常带量 ，且没体验过 则需要进行校验
    if v_isBind <= 0 then
    
      --渠道限制判断
      select count(1)
        into v_n
        from ad_limit_appid
       where adid = I_ADID
         and appid = I_APPId;
      if v_n > 0 then
        v_status := 0;
        return v_status;
      end if;
    
      --设备号限制表判断
      select count(1)
        into v_n
        from ad_limit_deviceid
       where adid = i_adid
         and deviceid = I_Deviceid;
      if v_n > 0 then
        v_status := 0;
        return v_status;
      end if;
    
      --包名限制判断
    
      --判断是否有老用户激活接口，如果有表示不进行包名限制
      select count(1)
        into v_n
        from ad_interf_olduser
       where adid = I_ADID
         and status = 0;
    
      if v_n <= 0 and v_isdevice = 1 then
      
        --1、ios  2、安卓  只限制包，因为换了手机商家还是支持去玩的
        select /*+index(ad_app_bind,IDE_AD_APP_BIND_DEVI_P)*/
         count(1)
          into v_n
          from ad_app_bind
         where deviceid = I_Deviceid
           and adid != I_ADID
           and (pagename = v_iosPageName or pagename = v_andpagename);
        if v_n > 0 then
          v_status := 0;
          return v_status;
        end if;
      
        select count(1)
          into v_n
          from ad_app_bind
         where userid = I_Userid
           and adid != I_ADID
           and (pagename = v_iosPageName or pagename = v_andpagename);
        if v_n > 0 then
          v_status := 0;
          return v_status;
        end if;
      
      end if;
    
      --广告体验限制
      select count(1) into v_n from ad_limit_adid where adid = I_ADID;
      if v_n > 0 then
        --如果用户已经参加过限制了它的广告 则无法体验该广告
        select count(1)
          into v_n
          from ad_app_bind
         where adid in
               (select limitadid from ad_limit_adid where adid = I_ADID)
           and deviceid = I_Deviceid;
        if v_n > 0 then
          v_status := 0;
          return v_status;
        end if;
      end if;
    
      ---IP限制体验 
    
      v_ip_short := fq_ip_cutout(I_IP);
    
      --渠道限制广告类型
      select count(1)
        into v_n
        from ad_limit_ip_chanel
       where appid = I_APPId
         and adtype = v_adtype;
      if v_n > 0 then
      
        --获取用户ID 所在城市 与省份 
        select province, city
          into v_province_user, v_city_user
          from ip_library_two
         where ip_start_short = v_ip_short
           and ip_start_num <= I_IP_Num
           and I_IP_Num <= ip_end_num;
      
        --判断用户所在的城市是否为限制城市
        select count(1)
          into v_n
          from ad_limit_ip_chanel
         where appid = I_APPId
           and adtype = v_adtype
           and (instr(province, v_province_user) > 0 or
               instr(city, v_city_user) > 0);
        if v_n > 0 then
          v_status := 0;
          return v_status;
        end if;
      
      end if;
    
      --广告限制区域
      select count(1) into v_n from ad_limit_ip where adid = I_ADID;
      if v_n > 0 then
      
        --获取用户ID 所在城市 与省份 
        select province, city
          into v_province_user, v_city_user
          from ip_library_two
         where ip_start_num <= I_IP_Num
           and I_IP_Num <= ip_end_num;
      
        --1:仅限当前区域体验 2：当前区域不可体验 
        select limit_type
          into v_limit_type
          from ad_limit_ip
         where adid = I_adid;
      
        select count(1)
          into v_n
          from ad_limit_ip_chanel
         where appid = I_APPId
           and adtype = v_adtype
           and (instr(province, v_province_user) > 0 or
               instr(city, v_city_user) > 0);
      
        if v_n > 0 then
        
          --判断用户所在的城市为可体验区域 
          if v_limit_type = 1 then
            v_status := 1;
            return v_status;
          end if;
        
          --判断用户所在的城市为不可体验区域 
          if v_limit_type = 2 then
            v_status := 0;
            return v_status;
          end if;
        
        else
          --判断用户所在的城市为可体验区域 
          if v_limit_type = 1 then
            v_status := 0;
            return v_status;
          end if;
        
          --判断用户所在的城市为不可体验区域 
          if v_limit_type = 2 then
            v_status := 1;
            return v_status;
          end if;
        
        end if;
      
      end if;
    
      --用户没有体验过则直接显示
      v_status := 1;
      return v_status;
    
    else
      --如果用户已经体验过
    
      --防止一个用户体验多个
      select max(urlid)
        into v_urlid
        from ad_app_bind
       where adid = I_ADID
         and userid = I_Userid;
    
      select count(1)
        into v_n
        from ad_downurl
       where adid = I_ADID
         and urlid = v_urlid;
    
      --获取该下载连接的状态
      -- 如果该状态非正常 说明该商家不投放了 ，这个连接下的用户也不在奖励
      if v_n > 0 then
        select status
          into v_UrlS
          from ad_downurl
         where adid = I_ADID
           and urlid = v_urlid;
      else
        v_UrlS := 0;
      end if;
    
      --状态（0未使用，1正常使用，2日到量，3总到量，4停止使用）
      if v_UrlS in (0, 4) then
        v_status := 0; --不显示
        return v_status;
      end if;
    
/*      -- 根据闲玩用户 获得还可获得奖励金额
      p_ad_showmoney_v2.pq_usermoney(i_adid     => i_adid,
                                     i_appid    => i_appid,
                                     i_adstatus => v_ADStatus,
                                     i_deviceid => i_deviceid,
                                     i_userid   => i_userid,
                                     i_ptype    => i_ptype,
                                     o_allmoney => v_AllMoney,
                                     o_alltimes => v_AllTimes);
    
      if v_AllMoney <= 0 then
        v_status := 0; --不显示
        return v_status;
      end if;*/
    
    end if;
    v_status := 1; --显示
    return v_status;
  exception
    --失败
    when others then
      --v_msg := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      rollback;
      return 0;
  end FQ_IsShow;

end P_AD_IsShow_V3;
/


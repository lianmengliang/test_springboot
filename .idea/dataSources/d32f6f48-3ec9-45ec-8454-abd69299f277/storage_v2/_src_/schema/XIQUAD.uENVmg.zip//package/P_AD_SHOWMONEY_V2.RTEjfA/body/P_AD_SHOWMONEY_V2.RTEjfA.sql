create PACKAGE BODY P_AD_ShowMoney_V2 AS

  /*判断 用户还可获得奖励金额 */

  Function FQ_Userid
  /*****************************************************************
        Procedure Name :FQ_Userid
        Purpose:  根据闲玩用户 判断用户还可获得奖励金额 
        Edit: 2018-04-09 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_ADStatus In Number, --广告投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放）
   I_Deviceid In Varchar2, --设备号ID
   I_Userid   In Number, --闲玩用户编号
   I_PType    In Number --1、ios  2、安卓
   ) Return varchar2 As
    -- 0_金额 【0 表示未绑定 1表示用户已绑定但是无追加奖励 2表示为用户已绑定并有追加奖励  3表示为用户仅绑定】
    v_bind number; --绑定数
  
    v_AllMoney number; --用户可获得金额
    v_AllTimes number; --已获得总奖励次数
    v_unit     varchar2(50); --货币单位描述 默认元
    v_rate     number; --货币与人名币比率 1：1
    v_msg      varchar2(500) := '0_0'; ---返回信息
    v_ischange number := 0; --是否开启货币转换 0：否 1：是
  
  begin
  
    v_AllMoney := 0;
    v_AllTimes := 0;
  
    --判断用户是否绑定
    select count(1)
      into v_bind
      from ad_app_bind
     where adid = I_ADID
       and userid = I_Userid;
  
    -- 根据闲玩用户 获得还可获得奖励金额
    p_ad_showmoney_v2.pq_usermoney(i_adid     => i_adid,
                                   i_appid    => i_appid,
                                   i_adstatus => i_adstatus,
                                   i_deviceid => i_deviceid,
                                   i_userid   => i_userid,
                                   i_ptype    => i_ptype,
                                   o_allmoney => v_AllMoney,
                                   o_alltimes => v_AllTimes);
  
    --货币单位描述 默认元
    --货币与人名币比率 1：1
    select unit, rate, ischange
      into v_unit, v_rate, v_ischange
      from ad_channel
     where appid = I_APPId;
  
    -- 0_金额 【0 表示未绑定 1表示用户已绑定但是无追加奖励 2表示为用户已绑定并有追加奖励  3表示为用户仅绑定】
  
    if v_bind = 0 then
      --未绑定
      v_msg := '0_' || P_Base_Fun.fq_monetaryunit(v_AllMoney, v_ischange) ||
               v_unit;
      return v_msg;
    
    else
      --已绑定，但是无可领取奖励
      if v_AllMoney <= 0 then
        v_msg := '1_' || P_Base_Fun.fq_monetaryunit(v_AllMoney, v_ischange) ||
                 v_unit;
        return v_msg;
      
      else
        --如果没拿过奖励则为仅下载
        if v_AllTimes = 0 then
          v_msg := '3_' ||
                   P_Base_Fun.fq_monetaryunit(v_AllMoney, v_ischange) ||
                   v_unit;
        else
          v_msg := '2_' ||
                   P_Base_Fun.fq_monetaryunit(v_AllMoney, v_ischange) ||
                   v_unit;
        end if;
      
        return v_msg;
      end if;
    
    end if; 
  
    return v_msg;
  
  exception
    --失败
    when others then
      rollback;
      v_msg := '0_0';
      --v_msg := sqlerrm || sqlcode;
      return v_msg;
  end FQ_Userid;

  procedure PQ_UserMoney
  /*****************************************************************
        Procedure Name :FQ_UserMoney
        Purpose:  根据闲玩用户 返回还可获得奖励金额
        Edit: 2018-04-09 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_ADStatus In Number, --广告投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放）
   I_Deviceid In Varchar2, --设备号ID
   I_Userid   In Number, --闲玩用户编号
   I_PType    In Number, --1、ios  2、安卓
   O_AllMoney Out Number, --可获得总奖励金额
   O_AllTimes Out Number --已获得奖励次数
   ) is

    v_Money    number; --金额
    v_Times    number; --已获得奖励次数
    v_AllMoney number; --用户可获得金额
    v_AllTimes number; --已获得总奖励次数
    v_isint    number := 0; --是否整数计算 0否1是  
    v_rate     number; --货币与人名币比率 1：1
  
    cursor myCur is
      select awardgroup, count(1) ct
        from ad_awardset
       where adid = I_ADID
         and appid = I_APPId
         and awardgroup >= 90
       group by awardgroup;
  begin
    v_Money    := 0;
    v_AllMoney := 0;
    v_Times    := 0;
    v_AllTimes := 0;
  
    O_AllMoney := 0;
    O_AllTimes := 0;
  
    if I_ADStatus not in (1, 2, 3) then
      return;
    end if;
  
    select rate, isint
      into v_rate, v_isint
      from ad_channel
     where appid = I_APPId;
  
    --普通奖励已获得奖励金额 ，次数
    select nvl(sum(AllMoney), 0), sum(cnt)
      into v_Money, v_Times
      from (select case
                     when v_isint = 1 then
                      trunc(((amoney * times) - (amoney * cnt)) * v_rate)
                     else
                      ((amoney * times) - (amoney * cnt)) * v_rate
                   end as AllMoney,
                   cnt
              from (select a.adid,
                           a.appid,
                           a.type,
                           a.dlevel,
                           a.awardgroup,
                           a.amoney,
                           a.times,
                           0 cnt
                      from ad_awardset a
                     where a.adid = I_ADID
                       and a.appid = I_APPId
                       and a.awardgroup < 90));
    /*
    select nvl(sum(AllMoney), 0), sum(cnt)
      into v_Money, v_Times
      from (select case
                     when v_isint = 1 then
                      trunc(((amoney * times) - (amoney * cnt)) * v_rate)
                     else
                      ((amoney * times) - (amoney * cnt)) * v_rate
                   end as AllMoney,
                   cnt
              from (select a.adid,
                           a.appid,
                           a.type,
                           a.dlevel,
                           a.awardgroup,
                           a.amoney,
                           a.times,
                           nvl(b.cnt, 0) cnt
                      from ad_awardset a
                      left join (select adid, dlevel, count(1) cnt
                                  from ad_app_flux
                                 where adid = I_ADID
                                   and userid = I_Userid
                                 group by adid, dlevel) b
                        on a.adid = b.adid
                       and a.dlevel = b.dlevel
                     where a.adid = I_ADID
                       and a.appid = I_APPId
                       and a.awardgroup < 90));*/
  
    v_AllMoney := v_AllMoney + v_Money;
    v_AllTimes := v_AllTimes + v_Times;
  
    --单次奖励组别奖励金额计算
    for cur in myCur loop
    
      select case
               when v_isint = 1 then
                trunc(((amoney * times) - (amoney * cnt)) * v_rate)
               else
                ((amoney * times) - (amoney * cnt)) * v_rate
             end as AllMoney,
             cnt
        into v_Money, v_Times
        from (select max(amoney) amoney, max(times) times, sum(cnt) cnt
                from (select a.adid,
                             a.appid,
                             a.type,
                             a.dlevel,
                             a.awardgroup,
                             a.amoney,
                             a.times,
                             0 cnt
                        from ad_awardset a
                       where a.adid = I_ADID
                         and a.appid = I_APPId
                         and a.awardgroup = cur.awardgroup));
      /*
      select case
               when v_isint = 1 then
                trunc(((amoney * times) - (amoney * cnt)) * v_rate)
               else
                ((amoney * times) - (amoney * cnt)) * v_rate
             end as AllMoney,
             cnt
        into v_Money, v_Times
        from (select max(amoney) amoney, max(times) times, sum(cnt) cnt
                from (select a.adid,
                             a.appid,
                             a.type,
                             a.dlevel,
                             a.awardgroup,
                             a.amoney,
                             a.times,
                             nvl(b.cnt, 0) cnt
                        from ad_awardset a
                        left join (select adid, dlevel, count(1) cnt
                                    from ad_app_flux
                                   where adid = I_ADID
                                     and userid = I_Userid
                                   group by adid, dlevel) b
                          on a.adid = b.adid
                         and a.dlevel = b.dlevel
                       where a.adid = I_ADID
                         and a.appid = I_APPId
                         and a.awardgroup = cur.awardgroup));*/
    
      v_AllMoney := v_AllMoney + v_Money;
      v_AllTimes := v_AllTimes + v_Times;
    end loop;
    O_AllMoney := v_AllMoney;
    O_AllTimes := v_AllTimes; 
    return;
  exception
    --失败
    when others then
      rollback;
      O_AllMoney := 0;
      O_AllTimes := 0;
      return;
  end PQ_UserMoney;

  Function FQ_Userid_List
  /*****************************************************************
        Procedure Name :FQ_Userid_List
        Purpose:  根据闲玩用户 判断用户还可获得奖励金额  列表使用
        Edit: 2018-11-16 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_ADStatus In Number, --广告投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放）
   I_Deviceid In Varchar2, --设备号ID
   I_Userid   In Number, --闲玩用户编号
   I_PType    In Number --1、ios  2、安卓
   ) Return varchar2 As
    -- 0_金额 【0 表示未绑定 1表示用户已绑定但是无追加奖励 2表示为用户已绑定并有追加奖励  3表示为用户仅绑定】
    v_bind number; --绑定数
  
    v_AllMoney number; --用户可获得金额
    v_AllTimes number; --已获得总奖励次数
    v_unit     varchar2(50); --货币单位描述 默认元
    v_rate     number; --货币与人名币比率 1：1
    v_msg      varchar2(500) := '0_0'; ---返回信息
    v_ischange number := 0; --是否开启货币转换 0：否 1：是
  
  begin
  
    v_AllMoney := 0;
    v_AllTimes := 0;
  
    --判断用户是否绑定
    select count(1)
      into v_bind
      from ad_app_bind
     where adid = I_ADID
       and userid = I_Userid;
  
    -- 根据闲玩用户 获得还可获得奖励金额
    p_ad_showmoney_v2.PQ_UserMoney_List(i_adid     => i_adid,
                                        i_appid    => i_appid,
                                        i_adstatus => i_adstatus,
                                        i_deviceid => i_deviceid,
                                        i_userid   => i_userid,
                                        i_ptype    => i_ptype,
                                        o_allmoney => v_AllMoney,
                                        o_alltimes => v_AllTimes);
  
    --货币单位描述 默认元
    --货币与人名币比率 1：1
    select unit, rate, ischange
      into v_unit, v_rate, v_ischange
      from ad_channel
     where appid = I_APPId;
  
    -- 0_金额 【0 表示未绑定 1表示用户已绑定但是无追加奖励 2表示为用户已绑定并有追加奖励  3表示为用户仅绑定】
  
    if v_bind = 0 then
      --未绑定
      v_msg := '0_' || P_Base_Fun.fq_monetaryunit(v_AllMoney, v_ischange) ||
               v_unit;
      return v_msg;
    
    else
      --已绑定，但是无可领取奖励
      if v_AllMoney <= 0 then
        v_msg := '1_' || P_Base_Fun.fq_monetaryunit(v_AllMoney, v_ischange) ||
                 v_unit;
        return v_msg;
      
      else
        --如果没拿过奖励则为仅下载
        if v_AllTimes = 0 then
          v_msg := '3_' ||
                   P_Base_Fun.fq_monetaryunit(v_AllMoney, v_ischange) ||
                   v_unit;
        else
          v_msg := '2_' ||
                   P_Base_Fun.fq_monetaryunit(v_AllMoney, v_ischange) ||
                   v_unit;
        end if;
      
        return v_msg;
      end if;
    
    end if; 
    
    return v_msg;
  
  exception
    --失败
    when others then
      rollback;
      v_msg := '0_0';
      --v_msg := sqlerrm || sqlcode;
      return v_msg;
  end FQ_Userid_List;

  procedure PQ_UserMoney_List
  /*****************************************************************
        Procedure Name :PQ_UserMoney_List
        Purpose:  根据闲玩用户 返回还可获得奖励金额 列表使用
        Edit: 2018-11-06 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_ADStatus In Number, --广告投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放）
   I_Deviceid In Varchar2, --设备号ID
   I_Userid   In Number, --闲玩用户编号
   I_PType    In Number, --1、ios  2、安卓
   O_AllMoney Out Number, --可获得总奖励金额
   O_AllTimes Out Number --已获得奖励次数
   ) is
  
    v_Money    number; --金额
    v_Times    number; --已获得奖励次数
    v_AllMoney number; --用户可获得金额
    v_AllTimes number; --已获得总奖励次数
    v_isint    number := 0; --是否整数计算 0否1是  
    v_rate     number; --货币与人名币比率 1：1
  
    cursor myCur is
      select awardgroup, count(1) ct
        from ad_awardset
       where adid = I_ADID
         and appid = I_APPId
         and awardgroup >= 90
       group by awardgroup;
  begin
    v_Money    := 0;
    v_AllMoney := 0;
    v_Times    := 0;
    v_AllTimes := 0;
  
    O_AllMoney := 0;
    O_AllTimes := 0;
  
    if I_ADStatus not in (1, 2, 3) then
      return;
    end if;
  
    select rate, isint
      into v_rate, v_isint
      from ad_channel
     where appid = I_APPId;
  
    --普通奖励已获得奖励金额 ，次数
    select nvl(sum(AllMoney), 0), sum(cnt)
      into v_Money, v_Times
      from (select case
                     when v_isint = 1 then
                      trunc(((amoney * times) - (amoney * cnt)) * v_rate)
                     else
                      ((amoney * times) - (amoney * cnt)) * v_rate
                   end as AllMoney,
                   cnt
              from (select a.adid,
                           a.appid,
                           a.type,
                           a.dlevel,
                           a.awardgroup,
                           a.amoney,
                           a.times,
                           0 cnt
                      from ad_awardset a
                     where a.adid = I_ADID
                       and a.appid = I_APPId
                       and a.awardgroup < 90));
  
    v_AllMoney := v_AllMoney + v_Money;
    v_AllTimes := v_AllTimes + v_Times;
  
    --单次奖励组别奖励金额计算
    for cur in myCur loop
    
      select case
               when v_isint = 1 then
                trunc(((amoney * times) - (amoney * cnt)) * v_rate)
               else
                ((amoney * times) - (amoney * cnt)) * v_rate
             end as AllMoney,
             cnt
        into v_Money, v_Times
        from (select max(amoney) amoney, max(times) times, sum(cnt) cnt
                from (select a.adid,
                             a.appid,
                             a.type,
                             a.dlevel,
                             a.awardgroup,
                             a.amoney,
                             a.times,
                             0 cnt
                        from ad_awardset a
                       where a.adid = I_ADID
                         and a.appid = I_APPId
                         and a.awardgroup = cur.awardgroup));
    
      v_AllMoney := v_AllMoney + v_Money;
      v_AllTimes := v_AllTimes + v_Times;
    end loop;
    O_AllMoney := v_AllMoney;
    O_AllTimes := v_AllTimes; 
    return;
  exception
    --失败
    when others then
      rollback;
      O_AllMoney := 0;
      O_AllTimes := 0;
      return;
  end PQ_UserMoney_List;

end P_AD_ShowMoney_V2;
/


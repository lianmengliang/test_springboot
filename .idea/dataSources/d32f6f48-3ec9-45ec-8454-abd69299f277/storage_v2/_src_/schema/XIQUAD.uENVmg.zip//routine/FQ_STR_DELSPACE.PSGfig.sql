create function        FQ_Str_DelSpace
/*****************************************************************
  过程名称：字符串中去掉空格
  创建日期：2013-11-07
  返回：
  ****************************************************************/
(i_str IN varchar2) return varchar2 --返回级别
 is
  v_out varchar2(1000);
  v_str varchar2(1000);
begin
  if i_str is null then
    return null;
  end if;

  v_out := '';

  v_str := substr(i_str, 1, 500);

  LOOP
    if length(v_str) = 1 then
      v_out := v_out || ltrim(rtrim(v_str));
      return v_out;
    end if;

    if substr(v_str, 0, 1) != ' ' then
      v_out := v_out || substr(v_str, 0, 1);
    end if;
    v_str := substr(v_str, 2);

  END LOOP;

  return v_out;
EXCEPTION
  WHEN OTHERS THEN
    return i_str;
end FQ_Str_DelSpace;


/


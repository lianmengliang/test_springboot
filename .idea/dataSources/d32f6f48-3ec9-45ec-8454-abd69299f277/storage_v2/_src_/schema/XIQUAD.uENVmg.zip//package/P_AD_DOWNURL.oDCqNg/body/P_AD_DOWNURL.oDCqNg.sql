create PACKAGE BODY P_AD_DownUrl AS

  /*广告页面 获取下载连接  */

  procedure PQ_DownUrl
  /*****************************************************************
        Procedure Name :PQ_DownUrl
        Purpose: 因为小米手机https开头并已apk 
        结尾下载完成后不会自动安装，所以增加个跳转的口子
        Edit: 2018-08-02 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   I_Urld      In Number, --渠道应用ID 
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number, --判断 0：查询成功，其他：出错
   O_Message   Out Varchar2 --返回信息（操作结果，成功或者错误信息）
   ) is
    V_DownCT Number;
  
  begin
    O_Result  := 0;
    O_Message := '操作成功';
  
    OPEN O_Outcursor FOR 'select 1 from dual where 1=2'; --游标初始化
  
    ----------------------------------------------------
    --步骤一：校验数据输入的合法性，以及初始化赋值
    ----------------------------------------------------
  
    --查看下载地址数量
  
    select count(1)
      into V_DownCT
      from ad_downurl
     where adid = I_ADID
       and status = 1
       and urlid = I_Urld;
  
    if V_DownCT > 0 then
      open o_outcursor for
        select adid, urlid, appurl
          from ad_downurl
         where adid = I_ADID
           and status = 1
           and urlid = I_Urld;
    end if;
  
    ----------------------------------------------------
    --步骤三：完成
    ----------------------------------------------------
    commit;
    return;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      ROLLBACK;
      O_Result  := -9;
      O_Message := '暂时无法获取下载地址，请稍后再试！';
      RETURN;
  end PQ_DownUrl;

end P_AD_DownUrl;
/


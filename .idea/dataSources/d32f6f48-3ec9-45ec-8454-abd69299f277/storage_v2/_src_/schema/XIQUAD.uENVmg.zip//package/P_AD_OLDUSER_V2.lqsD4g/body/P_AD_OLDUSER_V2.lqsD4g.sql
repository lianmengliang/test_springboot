create PACKAGE BODY P_AD_OldUser_V2 AS

  /* 老用户激活*/

  procedure PQ_OldUser
  /*****************************************************************
        Procedure Name :PQ_Interf_OldUser
        Purpose: 查询老用户信息【只处理接口激活和自动激活的广告】
                 第一优先：老用户激活根据设备号激活，当前广告当前设备号在哪个渠道优先激活新一期就归该渠道
                 第二优先：根据闲玩用户ID去查找上期帐号避免用户更换手机后无法激活
                 如果又换手机又更换帐号只能人工处理
        Edit: 2018-04-10 add by 小沈
    ****************************************************************/
  (I_ADID      In Number, --广告ID
   I_PType     In Number, --1、ios  2、安卓
   I_DeviceId  In Varchar2, --用户设备号
   I_Userid    In Number, --闲玩用户编号
   O_Outcursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    v_n           number;
    v_bindID      number := 0; --绑定ID
    v_adidlist    varchar(100); --上一期广告id集合 合作过多期 120,130,140 使用逗号隔开 
    v_lastadid    number := 0; --用户最近绑定记录广告ID
    v_fid         varchar2(100); --广告主统计的来源id[apk渠道编号]  
    v_lastfid     varchar2(100); --上一期 广告主统计的来源id[apk渠道编号]  
    v_Appid       number; --渠道应用编号 
    v_Appsign     varchar2(200); --渠道应用标识符号、渠道用户id 
    v_Merid       varchar2(100); --用户注册帐号id 
    v_Mername     varchar2(100); --用户注册帐号
    v_DeviceIdOld varchar2(100); --用户注册时设备号
    v_Simid       varchar2(100); --返回sim卡id 
    V_DownCT      number; --可用下载条数
    V_Random      number; --随机数
    V_UrlId       number; --下载编号 
    v_type        number; --激活类型 1：接口激活  2：自动激活 
    v_isChange    number := 0; --是否变更过设备号 0否 1是 如果是的话服务端需要先用老设备查询注册信息，没有的情况再用新设备查询注册信息
    v_Result      Number := 0;
    v_Message     Varchar2(200) := '';
    v_ismer       number := 0; --是否已商家自动返回为主 0：否 1：是 
  begin
    O_Result   := 0;
    O_Message  := '成功获取';
    v_lastadid := 0;
    v_type     := 1;
    open O_Outcursor for 'select 1 from dual where 1=2'; --游标初始化
    --是否有非点击下载时才激活的配置
  
    select count(1)
      into v_n
      from ad_interf_olduser
     where adid = I_ADID
       and status = 0;
  
    if v_n <= 0 then
      O_Result  := 1;
      O_Message := '该广告没有老用户激活接口';
      return;
    end if;
  
    select adid_list, fid, type, ismer
      into v_adidlist, v_fid, v_type, v_ismer
      from ad_interf_olduser
     where adid = I_ADID
       and status = 0;
  
    if v_ismer = 1 and v_type != 1 and v_type != 3 then
      O_Result  := 2;
      O_Message := '该广告已商家返回为主';
      return;
    end if;
  
    --判断有无老帐号 获取最新的绑定ID
    execute immediate 'select nvl(max(id),0) from ad_app_bind   where adid in (' ||
                      v_adidlist || ') and deviceid = ''' || I_DeviceId ||
                      '''  and ustatus in (2, 3) '
      into v_bindID;
    --如果没有绑定记录说明是新用户
    if v_bindID = 0 then
      --再根据闲玩ID再查询一次，判断用户是否更换过手机
      execute immediate 'select nvl(max(id),0) from ad_app_bind   where adid in (' ||
                        v_adidlist || ') and userid =  ' || I_Userid ||
                        '   and ustatus in (2, 3) '
        into v_bindID;
      if v_bindID = 0 then
        O_Result  := 1;
        O_Message := '该用户可能为新用户';
        return;
      end if;
      --如果通过闲玩ID查到了说明用户变更过手机
      v_isChange := 1;
    end if;
  
    --获取用户注册的帐号信息
    select adid, merid
      into v_lastadid, v_merid
      from ad_app_bind
     where id = v_bindID;
  
    --获取用户注册具体情况，避免一个帐号多次返回取值错误故进行排序
    select fid, appid, appsign, userid, name, deviceid, simid
      into v_lastfid,
           v_appid,
           v_appsign,
           v_merid,
           v_mername,
           v_DeviceIdOld,
           v_simid
      from (select fid,
                   appid,
                   appsign,
                   userid,
                   name,
                   deviceid,
                   simid,
                   rownum as rn
              from ad_adv_back_reg
             where adid = v_lastadid
               and userid = v_merid
             order by itime asc)
     where rn = 1;
  
    --查看下载地址数量
  
    select count(1)
      into V_DownCT
      from ad_downurl
     where adid = I_ADID
       and status = 1
       and phonetype in (I_PType, 3);
  
    if V_DownCT <= 0 then
      O_Result  := 2;
      O_Message := '无可下载连接，暂时不能体验！';
      return;
    end if;
  
    --预先配置下载地址编号，激活时需要
    --如果有多个下载地址则随机取
  
    select trunc(dbms_random.value(1, V_DownCT + 1))
      into V_Random
      from dual;
  
    select urlid
      into v_UrlId
      from (select urlid, rownum as rn
              from ad_downurl
             where adid = i_adid
               and status = 1
               and phonetype in (I_PType, 3))
     where rn = V_Random;
  
    open O_Outcursor for
      select adid,
             url, --接口地址 
             isauto, ---是否系统自动同步上期用户帐号  0 否 1 是  
             params, ---接口参数组合 需带? 会自动替换 [deviceid] [keycode] [lastfid]:上一期广告主app编号 [fid]:本期广告主app编号
             keycode, --keycode生成规则  会自动替换 [deviceid] [lastfid]:上一期广告主app编号 [fid]:本期广告主app编号
             isupper, --keycode是否大写 0否 1是 
             jsont, --json 返回格式类型  
             jsons, --json 返回状态判断值 
             jsonv, --json 返回状态   如果等于该值 表示该设备号为老用户激活，并成功激活 
             method, --传输方式 1-get 2-post 
             code, --编码格式 utf-8  gb2312 
             otime, --超时时间 单位秒 
             htype, --http 请求方法 1 
             islog, --是否记录到ad_interf_log 日志表   0否 1是
             ismer, --是否已商家自动返回为主 0：否 1：是 
             v_fid         as fid, --本期广告主app编号
             v_lastadid    as lastadid, --上一期广告ID
             v_lastfid     as lastfid, --上一期广告主app编号 
             v_merid       as merid,
             v_mername     as mername,
             v_DeviceIdOld as deviceidOld, --注册帐号时设备号
             v_isChange    as isChange, --是否变更过设备号 0否 1是 如果是的话服务端需要先用老设备查询注册信息，没有的情况再用新设备查询注册信息
             v_UrlId       as urlid, --用户下载地址-预设 
             v_type        as vtype --激活方式 1、接口激活 2、数据库自动激活 3、卸载重装激活
        from ad_interf_olduser
       where adid = I_ADID
         and status = 0;
  
    --如果为自动激活帐号，不调用商家接口
    if v_type = 2 then
    
      P_AD_OldUser_V2.PW_Activate_OldUser(i_adid     => i_adid,
                                          i_fid      => v_fid,
                                          i_urlid    => v_UrlId,
                                          i_lastadid => v_lastadid,
                                          i_lastfid  => v_lastfid,
                                          i_appid    => v_appid,
                                          i_deviceid => v_DeviceIdOld, --自动激活使用注册时的设备号
                                          i_simid    => v_simid,
                                          i_userid   => I_Userid,
                                          i_appsign  => v_appsign,
                                          i_ptype    => i_ptype,
                                          i_ip       => '127.0.0.1',
                                          o_result   => v_result,
                                          o_message  => v_message);
    
      open O_Outcursor for 'select 1 from dual where 1=2'; --游标初始化
      if v_result = 0 then
        O_Result := 20; --如果返回20前端判断为已自动激活
      else
        O_Result := 3;
      end if;
      O_Message := '系统自动激活无需调用接口！';
      return;
    
    end if;
    commit;
  
  exception
    --失败 
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '获取异常';
      O_Message := '获取异常 错误编码：' || sqlcode || '  错误信息 ：' || sqlerrm;
      return;
  end PQ_OldUser;

  procedure PW_OldUser_Click
  /*****************************************************************
        Procedure Name :PW_OldUser_Click
        Purpose: 广告接口_用户点击下载后激活老帐号
        Edit: 2018-04-11 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_PType    In Number, --1、ios  2、安卓
   I_DeviceId In Varchar2, --用户设备号 
   I_Userid   In Number, --闲玩用户编号
   O_Result   Out Number,
   O_Message  Out Varchar2) is
    v_n           number;
    v_bindID      number := 0; --绑定ID
    v_adidlist    varchar(100); --上一期广告id集合 合作过多期 120,130,140 使用逗号隔开 
    v_lastadid    number;
    v_fid         varchar2(100); --广告主统计的来源id[apk渠道编号]  
    v_lastfid     varchar2(100); --上一期 广告主统计的来源id[apk渠道编号]  
    v_Appid       Number; --渠道应用编号 
    v_Appsign     varchar2(200); --渠道应用标识符号、渠道用户id 
    v_Merid       varchar2(100); --用户注册帐号id 
    v_Mername     varchar2(100); --用户注册帐号
    v_DeviceIdOld varchar2(100); --用户注册时设备号
    v_Simid       varchar2(100); --返回sim卡id 
    V_DownCT      Number; --可用下载条数
    V_Random      Number; --随机数
    V_UrlId       Number; --下载编号 
    v_type        Number; --激活类型 1：接口激活  2：自动激活 
    v_ismer       number := 0; --是否已商家自动返回为主 0：否 1：是 
    v_Result      Number := 0;
    v_Message     Varchar2(200) := '';
  begin
    O_Result   := 0;
    O_Message  := '成功获取';
    v_lastadid := 0;
    v_type     := 1;
  
    select count(1)
      into v_n
      from ad_interf_olduser
     where adid = I_ADID
       and status = 0
       and type = 3;
  
    if v_n <= 0 then
      O_Result  := 1;
      O_Message := '该广告没有老用户激活接口';
      return;
    end if;
  
    select adid_list, fid, type, ismer
      into v_adidlist, v_fid, v_type, v_ismer
      from ad_interf_olduser
     where adid = I_ADID
       and status = 0
       and type = 3;
  
    if v_ismer = 1 then
      O_Result  := 2;
      O_Message := '该广告已商家返回为主';
      return;
    end if;
  
    --判断有无老帐号 获取最新的绑定ID
    execute immediate 'select nvl(max(id),0) from ad_app_bind   where adid in (' ||
                      v_adidlist || ') and deviceid = ''' || I_DeviceId ||
                      '''  and ustatus in (2, 3) '
      into v_bindID;
    --如果没有绑定记录说明是新用户
    if v_bindID = 0 then
      --再根据闲玩ID再查询一次，判断用户是否更换过手机
      execute immediate 'select nvl(max(id),0) from ad_app_bind   where adid in (' ||
                        v_adidlist || ') and userid =  ' || I_Userid ||
                        '   and ustatus in (2, 3) '
        into v_bindID;
      if v_bindID = 0 then
        O_Result  := 1;
        O_Message := '该用户可能为新用户';
        return;
      end if;
    
    end if;
  
    --获取用户注册的帐号信息
    select adid, merid
      into v_lastadid, v_merid
      from ad_app_bind
     where id = v_bindID;
  
    --获取用户注册具体情况，避免一个帐号多次返回取值错误故进行排序
    select fid, appid, appsign, userid, name, deviceid, simid
      into v_lastfid,
           v_appid,
           v_appsign,
           v_merid,
           v_mername,
           v_DeviceIdOld,
           v_simid
      from (select fid,
                   appid,
                   appsign,
                   userid,
                   name,
                   deviceid,
                   simid,
                   rownum as rn
              from ad_adv_back_reg
             where adid = v_lastadid
               and userid = v_merid
             order by itime asc)
     where rn = 1;
  
    --查看下载地址数量
  
    select count(1)
      into V_DownCT
      from ad_downurl
     where adid = I_ADID
       and status = 1
       and phonetype in (I_PType, 3);
  
    if V_DownCT <= 0 then
      O_Result  := 2;
      O_Message := '无可下载连接，暂时不能体验！';
      return;
    end if;
  
    --如果有多个下载地址则随机取
  
    select trunc(dbms_random.value(1, V_DownCT + 1))
      into V_Random
      from dual;
  
    select urlid
      into v_UrlId
      from (select urlid, rownum as rn
              from ad_downurl
             where adid = i_adid
               and status = 1
               and phonetype in (I_PType, 3))
     where rn = V_Random;
  
    P_AD_OldUser_V2.PW_Activate_OldUser(i_adid     => i_adid,
                                        i_fid      => v_fid,
                                        i_urlid    => v_UrlId,
                                        i_lastadid => v_lastadid,
                                        i_lastfid  => v_lastfid,
                                        i_appid    => v_appid,
                                        i_deviceid => v_DeviceIdOld, --自动激活使用注册时的设备号
                                        i_simid    => v_simid,
                                        i_userid   => I_Userid,
                                        i_appsign  => v_appsign,
                                        i_ptype    => i_ptype,
                                        i_ip       => '127.0.0.1',
                                        o_result   => v_result,
                                        o_message  => v_message);
    commit;
  
  exception
    --失败 
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '获取异常';
      return;
  end PW_OldUser_Click;

  procedure PW_Activate_OldUser
  /*****************************************************************
        Procedure Name :PW_Activate_OldUser
        Purpose: 激活老帐号
        Edit: 2018-04-10 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_Fid      In Varchar2, --本期广告主统计的来源id[apk渠道编号] 
   I_UrlId    In Number, --广告下载编号
   I_LastAdid In Number, --上一期广告ID
   I_LastFid  In Varchar2, --上一期广告主渠道编号 
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID[传的为老设备号，如果做老用户，传老设备可以用新设备和老设备都查]
   I_SIMID    In Varchar2, --sim卡编号
   I_Userid   In Number, --闲玩用户编号
   I_APPSign  In Varchar2, --渠道应用标识符号、渠道用户id 
   I_PType    In Number, --1、ios  2、安卓
   I_IP       In Varchar2, --
   O_Result   Out Number,
   O_Message  Out Varchar2) is
    v_n number;
  
    v_Deviceid varchar2(100); --注册设备号
    v_merid    varchar2(100); -- 商家帐号id 
    v_mername  varchar2(100); -- 商家帐号名称 
    v_pagename varchar2(100); --应用的包名称 
    v_ustatus  number(38); -- 用户体验状态 1：下载； 2：用户已提交； 3：商家成功返回；  【不可有状态 0 】 
  
  begin
    O_Result  := 0;
    O_Message := '激活成功！';
  
    select count(1)
      into v_n
      from ad_interf_olduser
     where adid = I_ADID
       and status = 0;
  
    if v_n <= 0 then
      O_Result  := 1;
      O_Message := '该广告没有老用户激活接口';
      return;
    end if;
    --去空格处理
    v_DeviceId := fq_str_delspace(i_str => I_Deviceid);
  
    select count(1)
      into v_n
      from ad_app_bind
     where adid = I_LastAdid
       and deviceid = v_DeviceId
       and ustatus in (2, 3);
    if v_n <= 0 then
      O_Result  := 2;
      O_Message := '该用户未找到注册信息';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_adv_back_reg
     where adid = i_adid
       and deviceid = v_DeviceId;
  
    if v_n > 0 then
      O_Result  := 3;
      O_Message := '用户已存在！';
      return;
    end if;
  
    select merid, mername, ustatus, pagename
      into v_merid, v_mername, v_ustatus, v_pagename
      from ad_app_bind
     where adid = I_LastAdid
       and deviceid = v_DeviceId
       and ustatus in (2, 3);
  
    select count(1)
      into v_n
      from ad_adv_back_reg
     where adid = I_adid
       and userid = v_merid;
  
    if v_n > 0 then
      O_Result  := 4;
      O_Message := '用户已存在！';
      return;
    end if;
  
    --添加
    insert into ad_adv_back_reg
      (adid, fid, appid, appsign, deviceid, simid, userid, name, status)
    values
      (I_adid,
       I_FID,
       I_APPId,
       I_APPSign,
       v_DeviceId,
       I_SIMID,
       v_merid,
       v_mername,
       1);
  
    commit;
  
    --判断用户之前是否下载过了，如果是则修改帐号信息
    select count(1)
      into v_n
      from ad_app_bind
     where adid = I_adid
       and deviceid = v_DeviceId;
  
    if v_n <= 0 then
    
      insert into ad_app_bind
        (id,
         adid,
         appid,
         deviceid,
         simid,
         appsign,
         merid,
         mername,
         pagename,
         urlid,
         ptype,
         itime,
         ip,
         ustatus,
         lasttime,
         userid)
      values
        (sq_ad_bind.nextval,
         I_ADID,
         I_APPId,
         v_DeviceId,
         I_SIMID,
         I_APPSign,
         v_merid,
         v_mername,
         v_pagename,
         I_UrlId,
         I_PType,
         sysdate,
         I_IP,
         v_ustatus,
         sysdate,
         I_Userid);
      commit;
    else
      update ad_app_bind
         set merid = v_merid, mername = v_mername, ustatus = 3
       where adid = I_adid
         and deviceid = v_DeviceId;
      commit;
    end if;
  
    insert into ad_adv_olduser
      (adid, lastadid, fid, lastfid, deviceid, merid, mername, appid)
    values
      (I_ADID,
       I_LastAdid,
       I_Fid,
       I_LastFid,
       v_DeviceId,
       v_merid,
       v_mername,
       I_APPId);
  
    commit;
  
  exception
    --失败 
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '激活失败！';
    
      --O_Message := '激活失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_Activate_OldUser;

end P_AD_OldUser_V2;
/


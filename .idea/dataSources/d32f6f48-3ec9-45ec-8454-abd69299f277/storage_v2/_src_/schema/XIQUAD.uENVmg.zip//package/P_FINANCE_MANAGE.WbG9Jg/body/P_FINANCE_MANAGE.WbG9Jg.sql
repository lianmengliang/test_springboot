create package body P_Finance_Manage is

  -- Purpose : 财务管理

  procedure PQ_AwardLevel_List
  /*****************************************************************
        Procedure Name :PQ_AwardLevel_List
        Purpose: 奖励级别列表
        Edit: 2018-11-27 add by 小沈
    ****************************************************************/
  (I_AdminID       In Varchar2,
   I_ADID          In Number,
   I_URLID         IN Number,
   O_AdTitle       Out Varchar2,
   O_CUSTOMER      out Varchar2,
   O_Marketer      out varchar2,
   O_OutCursor     Out t_cursor, --返回游标
   O_OutInfoCursor out t_cursor, --返回信息游标
   O_Result        Out Number,
   O_Message       Out Varchar2) is
    V_QX    NUMBER; --本模块的权限代码
    v_ptype number; -- 广告类型
    v_appid number; -- appid
  begin
    o_result  := 0;
    o_message := '显示成功';
    V_QX      := 481; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    if I_ADID is null then
      o_result  := 1;
      o_message := '广告ID不能为空！';
      return;
    end if;
  
    select t.title, t.phonetype, t1.marketer, t1.customer
      into O_AdTitle, v_ptype, O_Marketer, O_CUSTOMER
      from ad_adinfo t
      left join ad_downurl t1
        on t.adid = t1.adid
     where t.adid = I_ADID
       and t1.urlid = I_URLID;
  
    if v_ptype in (2, 3) then
      v_appid := 1010;
    else
      v_appid := 1011;
    end if;
  
    open O_OUTCURSOR for
      select a.adid,
             a.type, --奖励类型：1-注册 ； 2-等级/首冲固定奖励 ； 3-充值理财百分比奖励； 4-安装奖励； 5-当天签到奖励； 9-vip或首充 
             a.dlevel, --奖励级别 
             a.event, --奖励级别 
             a.amoney, --奖励金额 
             b.price, --单价 
             b.isauto -- 是否自动获取奖励数据
        from ad_awardset a
        left join fin_ad_set_l b
          on a.adid = b.adid
         and a.dlevel = b.dlevel
       where a.adid = I_ADID
         and a.appid = v_appid
       order by a.dlevel asc;
  
    open O_OutInfoCursor for
      select adid,
             urlid,
             puttime,
             ishand,
             interface,
             customer,
             marketer,
             taxrate,
             paytype,
             maxdebt,
             ad_manage
        from fin_ad_set
       where adid = I_ADID
         and urlid = I_URLID;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 110;
      O_MESSAGE := '获取失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PQ_AwardLevel_List;

  procedure PW_Set
  /*****************************************************************
    Procedure Name: PW_Set
    Purpose: 广告结算设置
    Edit: 2018-11-27 add by 小沈 
    Comment:
    ****************************************************************/
  (I_AdminID     In Varchar2, --管理员ID
   I_ADID        In Number, --   广告ID   
   I_UrlID       In Number, --下载地址id 
   I_PutTime     In Varchar2, --投放时间 
   I_IsHand      In Number, --  是否需要手工录入  0:否 ;1:是 
   I_Interface   In Number, --  是否有做接口 0:否 ;1:是 
   I_Customer    In Varchar2, --   商家名称 
   I_Marketer    In Varchar2, --   市场人员 
   I_Taxrate     In Number, --  税率 6% 传 0.06 
   I_PayType     In Number, --  付款方式 预付 1； 后付 2； 
   I_MaxDebt     In Number, --  最大允许欠款金额
   I_Ad_Manage   In Varchar2, --   广告负责人   
   I_Dlevel_List In Varchar2, --   奖励级别
   I_Eventl_List In Varchar2, --   奖励说明
   I_IsAuto_List In Varchar2, --  是否自动获取奖励数据  
   I_Price_List  In Varchar2, --  单价
   O_Result      Out Number,
   O_Message     Out Varchar2) IS
    v_n  number;
    V_QX number;
  
    V_Dlevel_List Varchar2(4000); --   奖励级别 
    V_Price_List  Varchar2(4000); --  单价
    V_Eventl_List Varchar2(4000); --  奖励说明
    V_IsAuto_List Varchar2(4000);
  
    V_Dlevel Number(10); -- 奖励级别 
    V_Price  Number(10, 3); --  单价 
    V_Eventl Varchar2(1000); --  奖励说明
    V_IsAuto Number(2); -- 是否自动获取奖励设置
  
  begin
    -------------------------------------------------------------------
    --步骤一：变量初始化
    -------------------------------------------------------------------
    O_Result  := 0;
    O_Message := '录入成功';
  
    V_Dlevel_List := I_Dlevel_List; --   奖励级别 
    V_Price_List  := I_Price_List; --  单价
    V_Eventl_List := I_Eventl_List; --   渠道单价
    V_IsAuto_List := I_IsAuto_List; -- 是否自动获取奖励数据
  
    --管理员输入是否正确
    if I_AdminID is null then
      O_Result  := 101;
      O_Message := '请重新登录后在操作！';
      RETURN;
    end if;
  
    --有下列权限的管理员有本模块的查询权
    V_QX := 481; --编辑权限
  
    --管理员是否有操作此模块的权限
    if p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_Result  := 101;
      O_Message := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    -------------------------------------------------------------------
    --步骤二：循环添加记录
    -------------------------------------------------------------------
    if length(V_Dlevel_List) <= 3 then
      O_Result  := 2;
      O_Message := '请先设置你的奖励，请检查！';
      RETURN;
    end if;
  
    select count(1) into v_n from fin_ad_set_l where adid = I_ADID;
  
    if v_n > 0 then
      delete fin_ad_set where adid = I_ADID;
      delete fin_ad_set_l where adid = I_ADID;
      insert into fin_log
        (appid, adid, urlid, itime, msg)
      values
        (0,
         I_ADID,
         I_UrlID,
         sysdate,
         '管理员：' || I_ADMINID || '对广告' || I_ADID || '结算进行了重新编辑');
    
      commit;
    end if;
  
    insert into fin_ad_set
      (adid,
       urlid,
       puttime,
       ishand,
       interface,
       customer,
       marketer,
       taxrate,
       paytype,
       maxdebt,
       ad_manage,
       admin)
    values
      (I_ADID,
       I_UrlID,
       to_date(I_PutTime, 'yyyy-MM-dd HH24:mi:ss'),
       I_IsHand,
       I_Interface,
       I_Customer,
       I_marketer,
       I_taxrate,
       I_paytype,
       I_maxdebt,
       I_Ad_Manage,
       I_AdminID);
  
    loop
    
      --拆分 奖励级别
      if instr(V_Dlevel_List, '$#@') <= 0 then
        --如果没有“$#@”符号，则直接取值，不拆分
        v_Dlevel      := V_Dlevel_List;
        V_Dlevel_List := '';
      else
        v_Dlevel      := substr(V_Dlevel_List,
                                0,
                                instr(V_Dlevel_List, '$#@') - 1); --从字符串0开始复制，到第一个"$#@"退一位结束
        V_Dlevel_List := substr(V_Dlevel_List,
                                instr(V_Dlevel_List, '$#@') + 3); --从第一组分隔符开始取 到结束
      end if;
    
      --拆分  单价
      if instr(V_Price_List, '$#@') <= 0 then
        v_Price      := V_Price_List;
        V_Price_List := '';
      else
        v_Price      := substr(V_Price_List,
                               0,
                               instr(V_Price_List, '$#@') - 1);
        V_Price_List := substr(V_Price_List, instr(V_Price_List, '$#@') + 3);
      end if;
    
      --拆分  渠道单价
      if instr(V_Eventl_List, '$#@') <= 0 then
        V_Eventl      := V_Eventl_List;
        V_Eventl_List := '';
      else
        V_Eventl      := substr(V_Eventl_List,
                                0,
                                instr(V_Eventl_List, '$#@') - 1);
        V_Eventl_List := substr(V_Eventl_List,
                                instr(V_Eventl_List, '$#@') + 3);
      end if;
    
      --拆分  是否获取奖励数据
      if instr(V_IsAuto_List, '$#@') <= 0 then
        V_IsAuto      := V_IsAuto_List;
        V_IsAuto_List := '';
      else
        V_IsAuto      := substr(V_IsAuto_List,
                                0,
                                instr(V_IsAuto_List, '$#@') - 1);
        V_IsAuto_List := substr(V_IsAuto_List,
                                instr(V_IsAuto_List, '$#@') + 3);
      end if;
    
      if v_Price < 0 then
        O_Result  := 10;
        O_Message := '奖励级别：' || v_dlevel || ' 结算金额 不能小于0请检查';
        rollback;
        return;
      end if;
    
      if V_IsAuto Not in (0, 1) then
        O_Result  := 16;
        O_Message := '是否自动获取奖励：' || V_IsAuto || ' 必须是0或1请检查';
        rollback;
        return;
      end if;
    
      insert into fin_ad_set_l
        (adid, urlid, dlevel, event, price, isauto)
      values
        (I_ADID, I_UrlID, v_Dlevel, V_Eventl, v_Price, V_IsAuto);
    
      exit when v_dlevel_list is null;
    
    end loop;
  
    commit;
  
    return;
  exception
    --失败
    when others then
      rollback;
      O_Result  := 110;
      O_Message := '添加/修改奖励失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  END PW_Set;

end P_Finance_Manage;
/


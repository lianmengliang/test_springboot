create package body P_AD_Older_Manage is

  procedure PQ_UserList
  /*****************************************************************
        Procedure Name :PQ_UserList
        Purpose: 获取老用户激活设置列表
        Edit: 2019-2-22 add by 一帆
    ****************************************************************/
  (I_AdmInId        In Varchar2, --管理员ID
   I_Adid           In Number, --广告ID
   I_AdName         In Varchar2, --广告名称
   I_PageSize       In Number, --每页记录数
   I_PageNO         In Number, --当前页码,从 1 开始
   O_OutCursor      Out t_cursor, --返回游标
   O_Outrecordcount Out Number, --返回总记录数
   O_Result         Out Number,
   O_Message        Out Varchar2) is
    V_PageNo    Number;
    V_PageSize  Number;
    V_QX        number;
    V_HeiRowNUM number; --小于第几行 分页用
    V_LowRowNUM number; --大于第几行 分页用
    V_Sql       Varchar2(2000);
  begin
    V_PageNo   := I_PageNo;
    V_PageSize := I_PageSize;
    O_Result   := 0;
    O_Message  := '成功';
    open O_OutCursor for
      select 1 from dual where 1 = 2; --初始化游标
    V_QX := 541; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
    -- 初始化SQL
    V_Sql := 'select
     t.adid,
       p.title,
       p.adname,
       t.status,
       t.Flux_Total,
       t.Flux_Day,
       t.Complete,
       t.flux_time
  from ad_win_older_set t
 inner join ad_adinfo p
    on t.adid = p.adid
    where 1=1';
    -- 有无输入adid
    if I_Adid is not null and I_Adid != 0 then
      V_Sql := V_Sql || ' and t.adid = ' || to_char(I_Adid);
    end if;
    -- 有输入名称时
    if I_AdName is not null then
      V_Sql := V_Sql || ' and (p.title like ''%' || I_AdName ||
               '%'' or p.adname like ''%' || I_AdName || '%'')';
    end if;
    ----执行分页查询
    V_HeiRowNUM := v_PageNO * v_PageSize;
    V_LowROWNUM := V_HeiRowNUM - v_PageSize + 1;

    execute immediate 'select count(1) from (' || V_Sql || ')'
      into O_Outrecordcount;

    -- 排序
    V_Sql := V_Sql || ' order by t.status desc';
    -- 拼装分页SQL
    V_Sql := 'select adid,title,adname,status,flux_total,flux_day,complete,flux_time from (
     select rownum rn,adid,title,adname,status,flux_total,flux_day,complete,flux_time from (' ||
             v_Sql || ') b ' || ') c where c.rn >= ' ||
             to_char(V_LowROWNUM) || ' and ' || 'c.rn <= ' ||
             to_char(V_HeiRowNUM) ;
    --返回
    OPEN O_OUTCURSOR FOR V_SQL;
  exception
    --失败
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '查询异常！';
      -- o_message := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PQ_UserList;

  procedure PQ_UserItem
  /*****************************************************************
        Procedure Name :PQ_UserItem
        Purpose: 获取老用户激活设置
        Edit: 2019-2-22 add by 一帆
    ****************************************************************/
  (I_AdmInId   In Varchar2, --管理员ID
   I_Adid      In Number, --广告ID
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    V_QX number;
  begin
    O_Result  := 0;
    O_Message := '成功';
    open O_OutCursor for
      select 1 from dual where 1 = 2; --初始化游标
    V_QX := 541; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
    open O_OutCursor for
      select t.adid,
             p.title,
             p.adname,
             t.adid_list,
             t.status,
             t.Flux_Total,
             t.Flux_Day,
             t.Complete,
             t.flux_time
        from ad_win_older_set t
       inner join ad_adinfo p
          on t.adid = p.adid
       where t.adid = I_Adid;
  exception
    --失败
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '查询异常！';
      -- o_message := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PQ_UserItem;

  procedure PW_UpDateOlder
  /*****************************************************************
        Procedure Name :PW_UpDateOlder
        Purpose: 修改老用户激活设置
        Edit: 2019-2-22 add by 一帆
    ****************************************************************/
  (I_AdmInId   In Varchar2, --管理员ID
   I_Adid      In Number, -- 广告ID
   I_OlderAdid In Varchar2, --老广告Id,
   I_Total     In Number, --激活总数
   I_Flux_Day  In Number, --每日带量数
   I_Flux_Time In Date, --带量时间
   I_Status    In Number, --状态
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    V_QX number;
  begin
    O_Result  := 0;
    O_Message := '成功';
    V_QX      := 541; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
    update ad_win_older_set
       set adid_list  = I_OlderAdid,
           flux_day   = I_Flux_Day,
           flux_total = I_Total,
           flux_time  = I_Flux_Time,
           status     = I_Status,
           Adminid    = I_AdmInId,
           L_Admin    = I_AdmInId,
           LTime      = sysdate
     where adid = I_Adid;

  exception
    --失败
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '查询异常！';
      -- o_message := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_UpDateOlder;

  procedure PW_AddOlder
  /*****************************************************************
        Procedure Name :PW_AddOlder
        Purpose: 修改老用户激活设置
        Edit: 2019-2-22 add by 一帆
    ****************************************************************/
  (I_AdmInId   In Varchar2, --管理员ID
   I_Adid      In Number, -- 广告ID
   I_OlderAdid In Varchar2, --老广告Id,
   I_Total     In Number, --激活总数
   I_Flux_Day  In Number, --每日带量数
   I_Flux_Time In Date, --带量时间
   I_Status    In Number, --状态
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    V_QX number;
  begin
    O_Result  := 0;
    O_Message := '成功';
    V_QX      := 541; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
    insert into ad_win_older_set
      (adid, adid_list, status, flux_day, flux_total, flux_time, l_admin)
    values
      (I_Adid,
       I_OlderAdid,
       I_Status,
       I_Flux_Day,
       I_Total,
       I_Flux_Time,
       I_AdmInId);

  exception
    --失败
    when others then
      rollback;
      O_Result  := -9;
      O_Message := '查询异常！';
      -- o_message := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_AddOlder;

end P_AD_Older_Manage;
/


create PACKAGE BODY P_AD_IsShow AS
  /*广告是否显示 （含 快速赚钱 、分享赚钱 体验赚钱 ）*/

  Function FQ_IsShow
  /*****************************************************************
        Procedure Name :FQ_IsShow
        Purpose: 判断是否显示
        Edit: 2017-11-20 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_ADStatus In Number, -- 投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放） 
   I_Deviceid In Varchar2, --设备号ID  
   I_PType    In Number --1、ios  2、安卓
   ) Return Number As
    PRAGMA AUTONOMOUS_TRANSACTION; -------------方法函数 被嵌套，且有表操作 必写
    -- 是否显示 0 不显示 1 显示
    v_n        number;
    v_status   number := 0;
    v_lastTime date; --最后一次判断时间
    v_ADStatus number; --广告状态
    v_showtype number; ---0不显示，1显示 
    v_msg      varchar2(500);
  begin
  
    --设备号校验是否合法 0否 1是
    if p_base_fun.fq_deviceid_check(I_Deviceid, I_PType) = 0 then
      v_status := 0; --不显示
      return v_status;
    end if;
  
    -- 
    if I_ADStatus in (0, 4) then
      v_status := 0; --不显示
      return v_status;
    end if;
  
    --判断奖励是否已设置
    select count(1)
      into v_n
      from ad_awardset
     where adid = i_adid
       and appid = I_APPId;
  
    if v_n <= 0 then
      v_status := 0;
      return v_status;
    end if;
  
    select status, showtype
      into v_ADStatus, v_showtype
      from ad_adinfo
     where adid = I_ADID;
  
    --如果广告正在投放中则需要判断用户是否被限制过
    if v_ADStatus in (1, 2, 3) and v_showtype = 1 then
      select count(1)
        into v_n
        from ad_limit_show
       where adid = I_ADID
         and appid = I_APPId
         and deviceid = I_Deviceid;
      --如果用户在上一次的判断是否显示中 
      --********************   每天凌晨 该表会被清空重新计算   ***********************
      if v_n > 0 then
        select status, itime
          into v_status, v_lastTime
          from ad_limit_show
         where adid = I_ADID
           and appid = I_APPId
           and deviceid = I_Deviceid;
      
        --如果上一次为显示，则判断是否有最新的奖励，如果没有则保持原装，如果有则需要重新计算
        if v_status = 1 then
          --奖励判断时不需要加渠道编号进行判断
          select count(1)
            into v_n
            from ad_app_flux
           where adid = I_ADID
             and deviceid = I_Deviceid
             and itime > v_lastTime;
        
          if v_n <= 0 then
            return v_status;
          end if;
        else
          return v_status;
        end if;
      
      end if;
    end if;
  
    v_status := p_ad_isshow.fq_deviceid(i_adid     => i_adid,
                                        i_appid    => i_appid,
                                        i_adstatus => i_adstatus,
                                        i_deviceid => i_deviceid,
                                        i_ptype    => i_ptype);
    if v_ADStatus in (1, 2, 3) and v_showtype = 1 then
      select count(1)
        into v_n
        from ad_limit_show
       where adid = I_ADID
         and appid = I_APPId
         and deviceid = I_Deviceid;
    
      if v_n <= 0 then
        insert into ad_limit_show
          (adid, deviceid, appid, status, itime)
        values
          (i_adid, i_deviceid, i_appid, v_status, sysdate);
      else
        update ad_limit_show
           set status = v_status
         where adid = I_ADID
           and appid = I_APPId
           and deviceid = I_Deviceid;
      end if;
      commit;
    end if;
  
    return v_status;
  exception
    --失败
    when others then
      --v_msg := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      rollback;
      return 0;
  end FQ_IsShow;

  Function FQ_Deviceid
  /*****************************************************************
        Procedure Name :FQ_Deviceid
        Purpose: 根据设备号判断是否显示 
        Edit: 2017-02-17 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_ADStatus In Number, -- 投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放） 
   I_Deviceid In Varchar2, --设备号ID  
   I_PType    In Number --1、ios  2、安卓
   ) Return Number As
    -- 是否显示 0 不显示 1 显示
    v_n           number;
    v_status      number;
    v_Awarding    number; --是否有奖励正在进行中 
    v_showtype    number; ---0不显示，1显示 
    v_andpagename varchar2(100); --安卓包名
    v_iosPageName varchar2(100); --苹果包
    v_isdevice    number := 1; --是否限制设备
  
    v_urlid number; --下载地址编号
    v_UrlS  number; --下载状态（0未使用，1正常使用，2日到量，3总到量，4停止使用）
  
    cursor myCur is
      select dlevel, times, atype, needlevel
        from ad_awardset
       where adid = I_ADID
         and atype != 3
         and appid = I_APPId
       order by dlevel asc;
  
  begin
  
    --设备号校验是否合法 0否 1是
    if p_base_fun.fq_deviceid_check(I_Deviceid, I_PType) = 0 then
      v_status := 0; --不显示
      return v_status;
    end if;
  
    if I_Deviceid is null then
      v_status := 0; --不显示
      return v_status;
    end if;
  
    -- 
    if I_ADStatus in (0, 4) then
      v_status := 0; --不显示
      return v_status;
    end if;
  
    --判断奖励是否已设置
    select count(1)
      into v_n
      from ad_awardset
     where adid = i_adid
       and appid = I_APPId;
  
    if v_n <= 0 then
      v_status := 0;
      return v_status;
    end if;
  
    --0不显示，1显示 如果广告还在测试阶段 只有测试用户才可以看见
    select showtype, pagename, iospagename, isdevice
      into v_showtype, v_AndPageName, v_iosPageName, v_isdevice
      from ad_adinfo
     where adid = I_ADID;
  
    if v_showtype = 0 then
      select count(1)
        into v_n
        from ad_testdevice
       where deviceid = I_Deviceid
         and status = 0;
      if v_n <= 0 then
        v_status := 0;
        return v_status;
      end if;
    end if;
  
    ---获取用户下载编号判断该编号是否正常
    select count(1)
      into v_n
      from ad_app_bind
     where adid = i_adid
       and deviceid = I_Deviceid;
  
    --绑定多次存在异常不显示
    if v_n > 1 then
      v_status := 0;
      return v_status;
    end if;
  
    --王牌赢三张1期 豆豆趣玩 没绑定的用户不显示
    if I_APPId = 1060 and I_ADID in (2199, 2210, 2200) and v_n <= 0 then
      v_status := 0;
      return v_status;
    end if;
  
    ---------------如果参与过该广告
    if v_n = 1 then
    
      --判断用户参与的广告是否为该渠道
      select count(1)
        into v_n
        from ad_app_bind
       where adid = i_adid
         and appid = I_APPId
         and deviceid = I_Deviceid;
    
      if v_n <= 0 then
        v_status := 0;
        return v_status;
      end if;
    
      --防止一个用户体验多个
      select max(urlid)
        into v_urlid
        from ad_app_bind
       where adid = I_ADID
         and deviceid = I_Deviceid;
    
      select count(1)
        into v_n
        from ad_downurl
       where adid = I_ADID
         and urlid = v_urlid;
    
      --获取该下载连接的状态
      -- 如果该状态非正常 说明该商家不投放了 ，这个连接下的用户也不在奖励
      if v_n > 0 then
        select status
          into v_UrlS
          from ad_downurl
         where adid = I_ADID
           and urlid = v_urlid;
      else
        v_UrlS := 0;
      end if;
    
      --状态（0未使用，1正常使用，2日到量，3总到量，4停止使用）
      if v_UrlS in (0, 4) then
        v_status := 0; --不显示
        return v_status;
      end if;
    
      --如果用户绑定过 则判断用户是否还有 可领取奖励
    
      for cur in myCur loop
        v_Awarding := 0;
      
        --返回  状态 0 未完成 1已完成 2 已过期 3 正在完成中 4 不予奖励 
      
        v_Awarding := p_ad_isreward.fq_deviceid(i_adid     => i_adid,
                                                i_appid    => i_appid,
                                                i_dlevel   => cur.dlevel,
                                                i_deviceid => i_deviceid,
                                                i_ptype    => i_ptype);
        if v_Awarding = 3 then
          exit;
        end if;
      end loop;
      --说明用户还有奖励可以领取中 则该广告显示  否则说明该用户已无可领取奖励 则不显示
      if v_Awarding = 3 then
        v_status := 1; --显示
        return v_status;
      else
        v_status := 0; --不显示
        return v_status;
      end if;
    
    end if;
  
    ------------------未绑定用户 判断 
    --如果广告正常
    if I_ADStatus = 1 then
    
      --渠道限制判断
      select count(1)
        into v_n
        from ad_limit_appid
       where adid = I_ADID
         and appid = I_APPId;
      if v_n > 0 then
        v_status := 0;
        return v_status;
      end if;
    
      --设备号限制表判断
      select count(1)
        into v_n
        from ad_limit_deviceid
       where adid = i_adid
         and deviceid = I_Deviceid;
      if v_n > 0 then
        v_status := 0;
        return v_status;
      end if;
    
      --包名限制判断
    
      --判断是否有老用户激活接口，如果有表示不进行包名限制
      select count(1)
        into v_n
        from ad_interf_olduser
       where adid = I_ADID
         and status = 0;
    
      if v_n <= 0 and v_isdevice = 1 then
      
        --1、ios  2、安卓
        select /*+index(ad_app_bind,IDE_AD_APP_BIND_DEVI_P)*/
         count(1)
          into v_n
          from ad_app_bind
         where deviceid = I_Deviceid
           and adid != I_ADID
           and (pagename = v_iosPageName or pagename = v_andpagename);
        if v_n > 0 then
          v_status := 0;
          return v_status;
        end if;
      
      end if;
    
      --广告体验限制
      select count(1) into v_n from ad_limit_adid where adid = I_ADID;
      if v_n > 0 then
        --如果用户已经参加过限制了它的广告 则无法体验该广告
        select count(1)
          into v_n
          from ad_app_bind
         where adid in
               (select limitadid from ad_limit_adid where adid = I_ADID)
           and deviceid = I_Deviceid;
        if v_n > 0 then
          v_status := 0;
          return v_status;
        end if;
      end if;
    
      --用户没有体验过则直接显示
      v_status := 1;
      return v_status;
    
    end if;
  
    --如果广告以为总到量 则判断设备号是否
    --有体验过 并且是否还可以拿到奖励 如果已经不能拿奖励则不在显示
    if I_ADStatus in (2, 3) then
      select count(1)
        into v_n
        from ad_app_bind
       where adid = I_ADID
         and deviceid = I_Deviceid;
    
      --用户没有体验过该广告 则 不显示 
      if v_n <= 0 then
        v_status := 0;
        return v_status;
      end if;
    
      for cur in myCur loop
        v_Awarding := 0;
        --返回  状态 0 未完成 1已完成 2 已过期 3 正在完成中 4 不予奖励 
      
        v_Awarding := p_ad_isreward.fq_deviceid(i_adid     => i_adid,
                                                i_appid    => i_appid,
                                                i_dlevel   => cur.dlevel,
                                                i_deviceid => i_deviceid,
                                                i_ptype    => i_ptype);
        if v_Awarding = 3 then
          exit;
        end if;
      end loop;
      --说明用户还有奖励可以领取中 则该广告显示  否则说明该用户已无可领取奖励 则不显示
      if v_Awarding = 3 then
        v_status := 1;
        return v_status;
      else
        v_status := 0;
        return v_status;
      end if;
    
      --到达这里 说明用户已无可领取奖励
    
      v_status := 0;
      return v_status;
    
    end if;
  
    return 0;
  exception
    --失败
    when others then
      rollback;
      return 0;
  end FQ_Deviceid;

end P_AD_IsShow;
/


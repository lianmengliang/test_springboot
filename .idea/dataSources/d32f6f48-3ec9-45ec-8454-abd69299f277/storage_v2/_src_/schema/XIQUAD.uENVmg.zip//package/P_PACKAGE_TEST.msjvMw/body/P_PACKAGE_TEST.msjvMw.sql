create package body p_package_test is

  procedure pq_AD_ActRecordList
  /*****************************************************************
        Procedure Name :pq_AD_ActAwardList
        Purpose: 冲级赛名单
        Edit: 2018-8-22 add by 小胡
    ****************************************************************/
  (I_AdmInId        In Varchar2, --管理员id
   I_ADID           In Number, --广告id
   I_ACTID          In Number, --活动ID
   I_PageSize       In Number,
   I_PageNO         In Number,
   O_OutRecordCount Out Number,
   O_OutCursor      Out t_cursor, --返回游标
   O_Result         Out Number,
   O_Message        Out Varchar2) is
    v_sql       varchar2(2000);
    V_HEIROWNUM NUMBER;
    V_LOWROWNUM NUMBER;
    V_QX        NUMBER; --本模块的权限代码
    v_n         Number;
  begin
    o_result  := 0;
    o_message := '查询成功';
    ---初始化游标
    open O_OutCursor for
      select 1 from dual where 1 = 2;
    V_QX := 104; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    select count(1) into v_n from ad_adinfo where adid = I_ADID;
    if v_n <= 0 then
      O_Result  := 2;
      O_Message := '广告ID输入错误！';
      return;
    end if;
  
    select count(1) into v_n from ad_activity where actid = I_ACTID;
    if v_n <= 0 then
      O_Result  := 2;
      O_Message := '活动不存在';
      return;
    end if;
  
    v_sql := 'select  c.adid ,c.title ,c.merid ,c.dlevel ,d.money ,c.itime ,c.rn as RANK,c.actid ,e.aname  from (
 select adid,title,merid,dlevel,itime,rownum rn,actid from ( select b.adid,b.title,a.merid,a.dlevel,to_char(a.itime ,''yyyy-mm-dd hh:mm:ss'') itime,' ||
             I_ACTID ||
             ' as actid from ad_app_flux a,ad_adinfo b
  where a.adid=b.adid and a.dlevel = (select dlevel from ad_activity where  adid=' ||
             I_ADID || ' and actid=' || I_ACTID || ' ) and b.adid=' ||
             I_ADID ||
             ' order by dlevel,itime) 
   where  rownum <=(select pcount from ad_activity where actid=' ||
             I_ACTID ||
             ' ))c,ad_activity_award d,ad_activity e where e.actid=d.actid and c.adid=d.adid and c.actid=d.actid and rn >=d.srank and rn<=d.erank';
  
    execute immediate 'select count(1) from (select adid,deviceid,merid from ad_app_flux where adid=' ||
                      I_ADID ||
                      ' and dlevel = (select dlevel from ad_activity where  adid=' ||
                      I_ADID || ' and actid=' || I_ACTID ||
                      ' ) and rownum<=(select pcount from ad_activity where actid=' ||
                      I_ACTID || ' ) )'
      into O_OUTRECORDCOUNT;
  
    ----执行分页查询
    V_HEIROWNUM := I_PAGENO * I_PAGESIZE;
    V_LOWROWNUM := V_HEIROWNUM - I_PAGESIZE + 1;
    V_SQL       := 'select adid,title,merid,dlevel,money,itime,RANK,actid,aname,rn 
                    FROM (
                    select adid,title,merid,dlevel,money,itime,RANK,actid,aname,rownum rn  
                    FROM (' || v_sql || ') 
                    WHERE rownum <= ' ||
                   TO_CHAR(V_HEIROWNUM) || '
                    ) 
                    WHERE rn >= ' || TO_CHAR(V_LOWROWNUM);
    open O_OUTCURSOR for v_sql;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '查询失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pq_AD_ActRecordList;

  procedure pq_Ad_BannerList
  /*****************************************************************
    Procedure Name:pq_Ad_BannerList 
    Purpose: 查询Banner图
    Edit: 2018-04-28 add by 小胡
    ****************************************************************/
  (I_ADMINID   In Varchar2,
   I_ADID      In Number,
   I_ADNAME    In Varchar2,
   I_STATUS    In Number,
   I_PhoneType In Number,
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    V_QX        number;
    v_sql       varchar2(2000);
    v_selectsql varchar2(1000);
  begin
    o_result  := 0;
    o_message := '显示成功';
    V_QX      := 341; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    v_sql := 'select id,adid,title,imgurl
               ,decode(status,1,''<span style="color:blue">正常</span>'',2,''关闭'',''未开启'') status,
               decode(phonetype,1,''IOS'',2,''安卓'',''IOS及安卓'') phonetype
               ,to_char(btime,''yyyy-mm-dd'') starttime,to_char(etime ,''yyyy-mm-dd'') stoptime,
               decode(adtype,1,''普通广告'',''关注广告'') adtype,ltime,status as ordernum  from ad_banner_v2 where 1=1 ';
  
    v_selectsql := '';
  
    ---条件查询
    if I_ADID is not null then
      v_selectsql := v_selectsql || ' and adid = ' || I_ADID;
    end if;
    if I_ADName is not null then
      v_selectsql := v_selectsql || ' and (title like ''%' || I_ADName ||
                     '%'')';
    end if;
    if I_Status is not null then
      v_selectsql := v_selectsql || ' and status =''' || I_Status || '''';
    end if;
    if I_PhoneType is not null then
      v_selectsql := v_selectsql || ' and PhoneType =''' || I_PhoneType || '''';
    end if;
  
    v_sql := v_sql || v_selectsql || '  order by  ordernum,ltime desc';
    open O_OUTCURSOR for v_sql;
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '获取失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
    
  end pq_Ad_BannerList;

  procedure pw_Ad_AddBanner
  /*****************************************************************
    Procedure Name:pw_Ad_AddBanner 
    Procedure Name: 添加Banner图
    Edit: 2018-08-30 add by 小胡
    ****************************************************************/
  (I_ADMINID   In Varchar2, --管理员id
   I_ADID      In Number, --广告Id
   I_ADNAME    In Varchar2, --广告名称
   I_IMGURL    In Varchar2, --Banner图存储路径
   I_STATUS    In Number, --状态 0：未开启 1：正常 2：关闭
   I_PHONETYPE In Number, --应用类型 1、ios，  2、安卓， 3、ios和安卓都显示
   I_ADTYPE    In Number, --广告类型 1：普通广告 2：关注广告
   I_STIME     In Varchar2, --Banner投放开始时间
   I_ETIME     In Varchar2, --Banner停止投放时间
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    v_n  number;
    V_QX number;
  begin
    o_result  := 0;
    o_message := '添加成功';
    V_QX      := 341; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    --检验输入参数是否正确
    if I_ADID is null then
      o_result  := 102;
      o_message := '输入参数有误，请检查！';
      return;
    end if;
  
    select count(1) into v_n from ad_adinfo where ADID = I_ADID;
  
    if v_n = 0 then
      o_result  := 104;
      o_message := '未找到指定广告，不能添加！';
      return;
    end if;
  
    ---添加Banner
    insert into ad_banner_v2
      (id, adid, title, imgurl, status, phonetype, btime, etime, adtype)
    values
      (sq_ad_banner.nextval,
       I_ADID,
       I_ADNAME,
       I_IMGURL,
       I_STATUS,
       I_PHONETYPE,
       to_date(I_STIME, 'yyyy-mm-dd hh24:mi:ss'),
       to_date(I_ETIME, 'yyyy-mm-dd hh24:mi:ss'),
       I_ADTYPE);
    commit;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '获取失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
    
  end pw_Ad_AddBanner;

  procedure pw_AD_EditBanner
  /*****************************************************************
    Procedure Name:pw_AD_EditBanner 
    Procedure Name: 编辑Banner图
    Edit: 2018-08-30 add by 小胡
    ****************************************************************/
  (I_ID        In Varchar2, --Banner图id
   I_ADMINID   In Varchar2, --管理员id
   I_ADID      In Number, --广告Id
   I_ADNAME    In Varchar2, --广告名称
   I_IMGURL    In Varchar2, --Banner图存储路径
   I_STATUS    In Number, --状态 0：未开启 1：正常 2：关闭
   I_PHONETYPE In Number, --应用类型 1、ios，  2、安卓， 3、ios和安卓都显示
   I_ADTYPE    In Number, --广告类型 1：普通广告 2：关注广告
   I_STIME     In Varchar2, --Banner投放开始时间
   I_ETIME     In Varchar2, --Banner停止投放时间
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    v_n  number;
    v_s  number;
    V_QX number;
  begin
    o_result  := 0;
    o_message := '显示成功';
    V_QX      := 341; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    --检验输入参数是否正确
    if I_ADID is null then
      o_result  := 102;
      o_message := '输入参数有误，请检查！';
      return;
    end if;
  
    select count(1) into v_n from ad_adinfo where ADID = I_ADID;
  
    if v_n = 0 then
      o_result  := 104;
      o_message := '未找到指定广告，不能编辑！';
      return;
    end if;
  
    select count(1) into v_s from ad_banner_v2 where id = I_ID;
    if v_s = 0 then
      o_result  := 104;
      o_message := '未找到该banner图，不能编辑！';
      return;
    end if;
  
    update ad_banner_v2
       set adid      = I_ADID,
           title     = I_ADNAME,
           imgurl    = I_IMGURL,
           status    = I_STATUS,
           phonetype = I_PHONETYPE,
           btime     = to_date(I_STIME, 'yyyy-mm-dd hh24:mi:ss'),
           etime     = to_date(I_ETIME, 'yyyy-mm-dd hh24:mi:ss'),
           ltime     = sysdate,
           adtype    = I_ADTYPE
     where ID = I_ID;
  
    commit;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '获取失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
    
  end pw_AD_EditBanner;

  procedure PQ_AD_ChangeXH
  /*****************************************************************
       Procedure Name:PQ_AD_ChangeXH 
       Procedure Name: 查询广告消耗报表的额外金额修改记录
       Edit: 2018-09-7 add by 小胡
    ****************************************************************/
  (I_ADMINID   In Varchar2, --管理员id
   I_ADID      In Number, --广告ID
   I_TYPE      In Number, --记录类型 1、调整 2、余额
   I_ID        In Number, --记录ID
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    V_QX     Number;
    V_SQL    varchar2(3000);
    v_SelStr varchar2(2000);
  begin
    o_result  := 0;
    o_message := '显示成功';
    V_QX      := 104; --初始化权限代码
    v_SelStr  := '';
    open O_OutCursor for
      select 1 from dual where 1 = 2; --初始化游标
  
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    V_SQL := ' select a.id,a.adid,b.title,a.money ,a.type,a.text,to_char(a.itime,''yyyy-MM-dd HH24:mi:ss'') itime,a.lastadmin ,a.status   from fin_ad_xhchange a ,ad_adinfo b where a.adid=b.adid and a.status=1 ';
  
    if I_ADID is not null then
      v_SelStr := v_SelStr || ' and a.adid= ' || I_ADID;
    end if;
    if I_ID is not null then
      v_SelStr := v_SelStr || ' and a.id= ' || I_ID;
    end if;
    if I_TYPE is not null then
      v_SelStr := v_SelStr || ' and a.type= ' || I_TYPE;
    end if;
  
    V_SQL := V_SQL || v_SelStr;
  
    V_SQL := ' select 0 id,' || I_ADID ||
             ' adid,''合计：'' title ,sum(money) money,0 type,null text,null itime,null lastadmin,0 status from fin_ad_xhchange a where 1=1 ' ||
             v_SelStr || ' union ' || V_SQL;
    V_SQL := 'select id,' || I_ADID ||
             ' adid,title,type,money ,text, itime,lastadmin ,status from (' ||
             V_SQL || ')';
    open O_OutCursor for V_SQL;
    return;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '获取数据失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PQ_AD_ChangeXH;

  procedure PW_AD_AddChangeXH
  /*****************************************************************
       Procedure Name:PW_AD_AddChangeXH 
       Procedure Name:  添加广告消耗报表的额外金额修改记录
       Edit: 2018-09-7 add by 小胡
    ****************************************************************/
  (I_ADMINID In Varchar2, --管理员id
   I_ADID    In Number, --广告ID
   I_TYPE    In Number, --记录类型 1、调整 2、余额
   I_MONEY   In Number, --金额
   I_Text    In Varchar2, --备注
   O_Result  Out Number,
   O_Message Out Varchar2) is
    V_QX Number;
    v_n  number;
  begin
    o_result  := 0;
    o_message := '添加成功';
    V_QX      := 104; --初始化权限代码
  
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    --数据判断
    if I_ADID is null then
      o_result  := -2;
      o_message := '广告id不能为空';
      return;
    end if;
    if I_TYPE is null then
      o_result  := -2;
      o_message := '类型不能为空';
      return;
    end if;
    if I_MONEY is null then
      o_result  := -2;
      o_message := '金额不能为空';
      return;
    end if;
    if I_Text is null then
      o_result  := -2;
      o_message := '备注不能为空';
      return;
    end if;
    select count(1) into v_n from ad_adinfo where adid = I_ADID;
    if v_n <= 0 then
      o_result  := -2;
      o_message := '该广告不存在';
      return;
    end if;
  
    insert into fin_ad_xhchange
      (id, adid, type, money, text, lasttime, lastadmin)
    values
      (SQ_FIN_XHCHANGE_RECORD.Nextval,
       I_ADID,
       I_TYPE,
       I_MONEY,
       I_Text,
       sysdate,
       I_ADMINID);
    commit;
    return;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '获取数据失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_AD_AddChangeXH;

  procedure PW_AD_UpdateChangeXH
  /*****************************************************************
       Procedure Name:PW_AD_UpdateChangeXH 
       Procedure Name:  修改广告消耗报表的额外金额修改记录
       Edit: 2018-09-7 add by 小胡
    ****************************************************************/
  (I_ADMINID In Varchar2, --管理员id
   I_ID      In Number, --记录ID
   I_ADID    In Number, --广告ID
   I_TYPE    In Number, --记录类型 1、调整 2、余额
   I_MONEY   In Number, --金额
   I_Text    In Varchar2, --备注
   O_Result  Out Number,
   O_Message Out Varchar2) is
    V_QX Number;
    v_n  number;
  begin
    o_result  := 0;
    o_message := '添加成功';
    V_QX      := 104; --初始化权限代码
  
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    --数据判断
    if I_ADID is null then
      o_result  := -2;
      o_message := '广告id不能为空';
      return;
    end if;
    if I_ID is null then
      o_result  := -2;
      o_message := '广告id不能为空';
      return;
    end if;
    if I_TYPE is null then
      o_result  := -2;
      o_message := '类型不能为空';
      return;
    end if;
    if I_MONEY is null then
      o_result  := -2;
      o_message := '金额不能为空';
      return;
    end if;
    if I_Text is null then
      o_result  := -2;
      o_message := '备注不能为空';
      return;
    end if;
    select count(1) into v_n from ad_adinfo where adid = I_ADID;
    if v_n <= 0 then
      o_result  := -2;
      o_message := '该广告不存在';
      return;
    end if;
  
    select count(1)
      into v_n
      from fin_ad_xhchange
     where id = I_ID
       and status = 1;
    if v_n <= 0 then
      o_result  := -2;
      o_message := '记录不存在，无法修改';
      return;
    end if;
  
    update fin_ad_xhchange
       set money     = I_MONEY,
           text      = I_Text,
           lasttime  = sysdate,
           lastadmin = I_ADMINID
     where id = I_ID
       and status = 1;
  
    commit;
    return;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '获取数据失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_AD_UpdateChangeXH;

  procedure PW_AD_DeleteChangeXH
  /*****************************************************************
       Procedure Name:PW_AD_DeleteChangeXH 
       Procedure Name:  删除广告消耗报表的额外金额修改记录
       Edit: 2018-09-7 add by 小胡
    ****************************************************************/
  (I_ADMINID In Varchar2, --管理员id
   I_ID      In Number, --记录ID
   O_Result  Out Number,
   O_Message Out Varchar2) is
    V_QX Number;
    v_n  number;
  begin
    o_result  := 0;
    o_message := '删除成功';
    V_QX      := 104; --初始化权限代码
  
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    --数据判断
    if I_ID is null then
      o_result  := -2;
      o_message := '广告id不能为空';
      return;
    end if;
  
    select count(1) into v_n from fin_ad_xhchange where id = I_ID;
    if v_n <= 0 then
      o_result  := -2;
      o_message := '记录不存在，无法删除';
      return;
    end if;
  
    update fin_ad_xhchange set status = 3 where id = I_ID;
    commit;
    return;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '删除失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_AD_DeleteChangeXH;

  procedure pq_fin_AD_list
  /*****************************************************************
        Procedure Name :pq_fin_AD_list
        Purpose: 广告列表
        Edit: 2018-9-08 add by 小胡
    ****************************************************************/
  (I_AdmInId        In Varchar2,
   I_ADID           In Number,
   I_ADName         In Varchar2,
   I_Status         In Number,
   I_ShowType       In Number,
   I_PhoneType      In Number,
   I_ADType         In Number,
   I_Market         In Varchar2,
   I_SDATE          In Varchar2,
   I_EDATE          In Varchar2,
   I_PageSize       In Number,
   I_PageNO         In Number,
   O_OutRecordCount Out Number,
   O_OutCursor      Out t_cursor, --返回游标
   O_Result         Out Number,
   O_Message        Out Varchar2) is
    v_sql       varchar2(2000);
    v_selectsql varchar2(1000);
    V_HEIROWNUM NUMBER;
    V_LOWROWNUM NUMBER;
    V_QX        NUMBER; --本模块的权限代码
  begin
    o_result  := 0;
    o_message := '显示成功';
    open O_OutCursor for
      select 1 from dual where 1 = 2;
    V_QX := 104; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    v_sql := 'select adid,title,adname
             ,decode(status,0,''未投放'',1,''<span style="color:blue">正常</span>'',2,''日到量'',3,''总到量'',''停止投放'')||decode(showtype,0,''<span style="color:red">(不显示)</span>'','''') status
             ,to_char(starttime,''yyyy-mm-dd'') starttime,to_char(stoptime ,''yyyy-mm-dd'') stoptime,adtype from ad_adinfo af  where 1=1 ';
  
    v_selectsql := '';
  
    if I_ADID is not null then
      v_selectsql := v_selectsql || ' and adid = ' || I_ADID;
    end if;
    if I_ADName is not null then
      v_selectsql := v_selectsql || ' and (title like ''%' || I_ADName ||
                     '%'' or adname like ''%' || I_ADName || '%'')';
    end if;
    if I_Status is not null then
      v_selectsql := v_selectsql || ' and status =''' || I_Status || '''';
    end if;
    if I_ShowType is not null then
      v_selectsql := v_selectsql || ' and ShowType =''' || I_ShowType || '''';
    end if;
    if I_PhoneType is not null then
      v_selectsql := v_selectsql || ' and PhoneType =''' || I_PhoneType || '''';
    end if;
    if I_ADType is not null then
      v_selectsql := v_selectsql || ' and ADType =''' || I_ADType || '''';
    end if;
    if I_Market is not null then
      v_selectsql := v_selectsql ||
                     'and (select count(1) from ad_downurl aw where aw.adid=af.adid and marketer like ''%' ||
                     I_Market || '%'')>0 ';
    end if;
    if I_SDATE is not null then
      v_selectsql := v_selectsql || ' and starttime >=to_date(''' ||
                     I_SDATE || ''',''yyyy-mm-dd'') ';
    end if;
    if I_EDATE is not null then
      v_selectsql := v_selectsql || ' and stoptime <=to_date(''' || I_EDATE ||
                     ''',''yyyy-mm-dd'') ';
    end if;
  
    execute immediate 'select count(1) from ad_adinfo af where 1 = 1' ||
                      v_selectsql
      into O_OUTRECORDCOUNT;
  
    v_sql := v_sql || v_selectsql ||
             '  order by  status , showtype asc, itime desc';
  
    ----执行分页查询
    V_HEIROWNUM := I_PAGENO * I_PAGESIZE;
    V_LOWROWNUM := V_HEIROWNUM - I_PAGESIZE + 1;
    V_SQL       := 'select adid,title,adname,status,starttime,stoptime,adtype , p_ad_manage.fq_admarketer(adid) marketer ,rn
                    FROM (
                    select adid,title,adname,status,starttime,stoptime,adtype,rownum rn
                    FROM (' || v_sql || ') A
                    WHERE rownum <= ' ||
                   TO_CHAR(V_HEIROWNUM) || '
                    ) B
                    WHERE rn >= ' || TO_CHAR(V_LOWROWNUM);
    open O_OUTCURSOR for v_sql;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '获取失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pq_fin_AD_list;

  procedure PW_Back_Reg
  /*****************************************************************
        Procedure Name :PW_Back_Reg
        Purpose: 广告主返回注册信息
        Edit: 2018-11-15 add by xiaohu
    ****************************************************************/
  (I_ADID      In Number, --广告id
   I_FID       In Varchar2, --广告主统计的来源id[apk渠道编号]
   I_DeviceId  In Varchar2, --返回设备号imei idfa
   I_SIMID     In Varchar2, --返回sim卡id
   I_UserId    In Varchar2, --用户注册帐号id
   I_Name      In Varchar2, --用户注册帐号
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out Number,
   O_Message   Out Varchar2) is
    v_n        Number;
    v_Deviceid varchar2(100); --设备号
    v_ptype    Number; --1、ios  2、安卓
    v_userid   Number; --闲玩用户ID
    v_appid    Number; --渠道合作编号
    v_appsign  Varchar2(200); --渠道合作编号
    v_status   Number; --匹配状态 0 失败 ； 1  成功
    v_amoney   Number; --奖励金额
    v_result   Number; --
    v_message  Varchar2(100); --
    v_record   Number := 0; --之前是否已有记录 0否 1是
    v_isChange NUmber := 0; --是否修改成功
  
  begin
    o_result  := 0;
    o_message := '接收成功';
    v_status  := 0;
    v_appid   := 0;
    v_appsign := '0';
    v_result  := 0;
    v_message := '';
    open O_OUTCURSOR for
      select 1 from dual where 1 = 2;
  
    --去空格处理
    v_DeviceId := fq_str_delspace(i_str => I_Deviceid);
  
    select count(1)
      into v_n
      from ad_adv_back_reg
     where adid = I_ADID
       and userid = I_UserId;
  
    if v_n > 0 then
      v_record := 1;
      --判断是否已匹配
      select count(1)
        into v_n
        from ad_adv_back_reg
       where adid = I_ADID
         and userid = I_UserId
         and status = 1;
      --如果存在且已匹配成功
      if v_n > 0 then
        open O_OUTCURSOR for
          select I_DeviceId as deviceid,
                 v_appsign  as appsign,
                 v_amoney   as amoney
            from dual;
      
        o_result  := 0;
        o_message := '该用户信息已记录！';
        return;
      end if;
    end if;
  
    --查看设备号是否有点击记录 且帐号未返回
  
    select count(1)
      into v_n
      from ad_app_bind
     where adid = I_ADID
       and deviceid = v_DeviceId
       and ustatus = 1;
    --如果没匹配到，则尝试判断是否为老用户用新手机体验了该广告
    if v_n <= 0 then
      v_isChange := p_ad_register_v2.fq_changedeviceid(i_adid     => i_adid,
                                                       i_deviceid => i_deviceid,
                                                       i_userid   => i_userid);
    
      if v_isChange = 1 then
        select count(1)
          into v_n
          from ad_app_bind
         where adid = I_ADID
           and deviceid = v_DeviceId
           and ustatus = 1;
      end if;
    end if;
  
    select appid, appsign, userid, ptype
      into v_appid, v_appsign, v_userid, v_ptype
      from ad_app_bind
     where adid = I_ADID
       and deviceid = v_DeviceId;
    v_status := 1;
  
    if v_record = 0 then
    
      --添加
      insert into ad_adv_back_reg
        (adid,
         fid,
         appid,
         appsign,
         deviceid,
         simid,
         userid,
         name,
         status,
         lasttime)
      values
        (I_adid,
         I_FID,
         v_appid,
         v_appsign,
         v_DeviceId,
         I_SIMID,
         I_UserId,
         I_Name,
         v_status,
         sysdate);
    
    end if;
  
    commit;
  
    --如果匹配成功 则 进行注册奖励
    --匹配状态 0 失败 ； 1  成功
    if v_status = 1 then
    
      --如果是之前有返回帐号信息的，后来重新匹配上的 则需要修改 【一般出现在有注册返回和注册查询接口 的情况】
      if v_record = 1 then
        --修改原先匹配帐号信息
        update ad_adv_back_reg
           set deviceid = v_DeviceId,
               appid    = v_appid,
               appsign  = v_appsign,
               status   = v_status,
               lasttime = sysdate
         where adid = I_adid
           and userid = I_UserId;
      end if;
    
      select count(1)
        into v_n
        from ad_app_bind
       where adid = I_adid
         and appid = v_appid
         and ustatus = 1
         and deviceid = v_DeviceId;
    
      if v_n > 0 then
        update ad_app_bind
           set merid    = I_UserId,
               mername  = I_Name,
               ustatus  = 3,
               lasttime = sysdate
         where adid = I_adid
           and appid = v_appid
           and ustatus = 1
           and deviceid = v_DeviceId;
      
        commit;
      
        p_ad_award_main.pq_allmain(i_adid     => i_adid,
                                   i_appid    => v_appid,
                                   i_deviceid => i_deviceid,
                                   i_simid    => i_simid,
                                   i_userid   => v_userid,
                                   i_ptype    => v_ptype,
                                   i_merid    => I_UserId,
                                   i_mername  => I_Name,
                                   i_levle    => 0, --注册为0等级
                                   i_atype    => 1, --  发奖类型 1 按固定值发放
                                   i_agroup   => 1, --注册为第一组别
                                   o_amoney   => v_amoney,
                                   o_result   => v_result,
                                   o_message  => v_message);
        commit;
      end if;
    
    end if;
  
    open O_OUTCURSOR for
      select I_DeviceId as deviceid,
             v_appsign  as appsign,
             v_amoney   as amoney
        from dual;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 1001;
      O_Message := '接收异常！';
      -- o_message := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PW_Back_Reg;

  procedure pq_AD_Info
  /*****************************************************************
        Procedure Name :pq_AD_Info
        Purpose: 广告信息
        Edit: 2016-12-05 add by 小沈
    ****************************************************************/
  (I_AdminID   In Varchar2,
   I_ADID      In Number,
   O_OutCursor Out t_cursor, --返回游标
   O_Result    Out number,
   O_Message   Out varchar2) is
    v_sql varchar2(1000);
    V_QX  NUMBER; --本模块的权限代码
  begin
    o_result  := 0;
    o_message := '显示成功';
    V_QX      := 104; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    if I_ADID is null then
      o_result  := 101;
      o_message := '参数有误！';
      return;
    end if;
  
    v_sql := 'select  adid, title, adname, money, intro, status, showtype, to_char(starttime,''yyyy-mm-dd hh24:mi:ss'') starttime , to_char(stoptime,''yyyy-mm-dd hh24:mi:ss'') stoptime, phonetype, adtype,
     appsize, imgurl, description,desimgurls,  adlink, pagename, iosadlink, iospagename, iosurlschemes, iosproname, iosversion,is_easy,
     ioskeyword, iosrank, appsign, buttonshow, buttonname, showorder, msgnoinstall, msgnoreg, msgreg, msgdaylimit, msgalllimit,isrecommend 
from ad_adinfo where ADID=' || I_ADID;
  
    open O_OUTCURSOR for v_sql;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '获取失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pq_AD_Info;

  procedure pw_AD_Add
  /*****************************************************************
        Procedure Name :pw_AD_Add
        Purpose: 广告增加
        Edit: 2016-12-05 add by 小沈
    ****************************************************************/
  (I_AdminID       In Varchar2,
   I_Title         In Varchar2, -- 广告名称[内部使用]
   I_ADName        In Varchar2, --   前台显示广告名称
   I_Money         In Number, --  奖励总金额
   I_Intro         In Varchar2, --   广告简介
   I_Status        In Number, --   投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放）
   I_ShowType      In Number, --   0不显示，1显示
   I_StartTime     In Varchar2, --广告投放时间
   I_StopTime      In Varchar2, --停止投放时间
   I_PhoneType     In Number, --   1、ios，  2、安卓， 3、ios和安卓都显示
   I_ADType        In Number, --   广告类型（1游戏，2应用，3其他）
   I_APPSize       In Varchar2, --   文件大小
   I_ImgURL        In Varchar2, --   广告小图片地址
   I_Description   In Varchar2, --   广告介绍描述
   I_DesImgUrls    In Varchar2, --   广告图片描述 
   I_ADLink        In Varchar2, --   安卓广告地址
   I_PageName      In Varchar2, --   安卓应用的包名称
   I_IOSADLink     In Varchar2, --   IOS广告地址
   I_IOSPageName   In Varchar2, --   IOS应用程序名称 BoundleId
   I_IOSURLSchemes In Varchar2, --   IOS用于打开APP应用的 URL Schemes
   I_IOSPROName    In Varchar2, --   IOS 进程名称 ProcessName
   I_IOSVersion    In Varchar2, --   IOS应用版本号
   I_IOSKEYWord    In Varchar2, --   搜索关键字
   I_IOSRank       In Number, --   关键字在appstore排位
   I_APPSign       In Number, --   绑定方式 0、下载绑定 1、账号返回 2、自助提交  3、下载安装返回
   I_ButtonShow    In Number, --   下载按钮和进度条是否显示（1显示，0不显示）
   I_ButtonName    In Varchar2, --   试玩按钮名称
   I_ShowOrder     In Number, --  排序号
   I_MSGNOInstall  In Varchar2, --   未安装提示-无需下载app则提示和未注册一致
   I_MSGNoReg      In Varchar2, --   未注册提示
   I_MsgReg        In Varchar2, --   已注册提示
   I_MSGDayLimit   In Varchar2, --  日限量提示信息
   I_MSGAllLimit   In Varchar2, --  到量提示信息
   I_ISRECOMMEND   In Number, --  是否推荐该广告 1：推荐 0：不推荐
   I_ISEASY        In Number, --  是否为简单广告 1：是 0：否
   O_Result        Out number,
   O_Message       Out varchar2) is
    V_ADID         Number; --广告ID
    V_ADLink       Varchar2(500); --   安卓广告地址
    V_IOSADLink    Varchar2(500); --   IOS广告地址
    V_QX           Number; --本模块的权限代码
    V_MSGNOInstall varchar2(500); --未安装提示-无需下载app则提示和未注册一致 
    V_MSGNoReg     varchar2(500); --未注册/已下载提示 
    V_MsgReg       varchar2(500); --已注册提示 
    V_MsgDayLimit  varchar2(200); --日限量提示信息   
    V_MsgAllLimit  varchar2(200); --到量提示信息 
  begin
    o_result  := 0;
    o_message := '保存成功';
  
    V_MSGNOInstall := I_MSGNOInstall; --未安装提示-无需下载app则提示和未注册一致 
    V_MSGNoReg     := I_MSGNoReg; --未注册/已下载提示 
    V_MsgReg       := I_MsgReg; --已注册提示 
    V_MsgDayLimit  := I_MSGDayLimit; --日限量提示信息   
    V_MsgAllLimit  := I_MSGAllLimit; --到量提示信息 
  
    V_QX := 104; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    V_MSGNOInstall := replace(V_MSGNOInstall, '[adname]', I_ADName); --未安装提示-无需下载app则提示和未注册一致 
    V_MSGNoReg     := replace(V_MSGNoReg, '[adname]', I_ADName); --未注册/已下载提示 
    V_MsgReg       := replace(V_MsgReg, '[adname]', I_ADName); --已注册提示 
    V_MsgDayLimit  := replace(V_MsgDayLimit, '[adname]', I_ADName); --日限量提示信息   
    V_MsgAllLimit  := replace(V_MsgAllLimit, '[adname]', I_ADName); --到量提示信息 
  
    V_ADID      := SQ_AD_INFO.NEXTVAL;
    V_ADLink    := replace(I_ADLink, '[adid]', V_ADID);
    V_IOSADLink := replace(I_IOSADLink, '[adid]', V_ADID);
  
    insert into ad_adinfo
      (adid,
       title,
       adname,
       money,
       intro,
       status,
       showtype,
       starttime,
       stoptime,
       phonetype,
       adtype,
       appsize,
       imgurl,
       description,
       desimgurls,
       adlink,
       pagename,
       iosadlink,
       iospagename,
       iosurlschemes,
       iosproname,
       iosversion,
       ioskeyword,
       iosrank,
       appsign,
       buttonshow,
       buttonname,
       showorder,
       msgnoinstall,
       msgnoreg,
       msgreg,
       msgdaylimit,
       msgalllimit,
       isrecommend,
       is_easy)
    values
      (V_ADID,
       I_title,
       I_adname,
       I_money,
       I_intro,
       I_status,
       I_showtype,
       to_date(I_starttime, 'yyyy-mm-dd hh24:mi:ss'),
       to_date(I_stoptime, 'yyyy-mm-dd hh24:mi:ss'),
       I_phonetype,
       I_adtype,
       I_appsize,
       I_imgurl,
       I_description,
       I_DesImgUrls,
       V_ADLink,
       I_pagename,
       V_IOSADLink,
       I_iospagename,
       I_iosurlschemes,
       I_iosproname,
       I_iosversion,
       I_ioskeyword,
       I_iosrank,
       I_appsign,
       I_buttonshow,
       I_buttonname,
       I_showorder,
       V_MSGNOInstall,
       V_MSGNoReg,
       V_MsgReg,
       V_MsgDayLimit,
       V_MsgAllLimit,
       I_ISRECOMMEND,
       I_ISEASY);
  
    commit;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_MESSAGE := '添加失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pw_AD_Add;

  procedure pw_AD_Edit
  /*****************************************************************
        Procedure Name :pw_AD_Edit
        Purpose: 广告修改
        Edit: 2016-12-05 add by 小沈
    ****************************************************************/
  (I_AdminID       In Varchar2,
   I_ADID          In Number, --  广告ID
   I_Title         In Varchar2, -- 广告名称[内部使用]
   I_ADName        In Varchar2, --   前台显示广告名称
   I_Money         In Number, --  奖励总金额
   I_Intro         In Varchar2, --   广告简介
   I_Status        In Number, --   投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放）
   I_ShowType      In Number, --   0不显示，1显示
   I_StartTime     In Varchar2, --广告投放时间
   I_StopTime      In Varchar2, --停止投放时间
   I_PhoneType     In Number, --   1、ios，  2、安卓， 3、ios和安卓都显示
   I_ADType        In Number, --   广告类型（1游戏，2应用，3其他）
   I_APPSize       In Varchar2, --   文件大小
   I_ImgURL        In Varchar2, --   广告小图片地址
   I_Description   In Varchar2, --   广告介绍描述
   I_DesImgUrls    In Varchar2, --   广告图片描述 
   I_ADLink        In Varchar2, --   安卓广告地址
   I_PageName      In Varchar2, --   安卓应用的包名称
   I_IOSADLink     In Varchar2, --   IOS广告地址
   I_IOSPageName   In Varchar2, --   IOS应用程序名称 BoundleId
   I_IOSURLSchemes In Varchar2, --   IOS用于打开APP应用的 URL Schemes
   I_IOSPROName    In Varchar2, --   IOS 进程名称 ProcessName
   I_IOSVersion    In Varchar2, --   IOS应用版本号
   I_IOSKEYWord    In Varchar2, --   搜索关键字
   I_IOSRank       In Number, --   关键字在appstore排位
   I_APPSign       In Number, --   绑定方式 0、下载绑定 1、账号返回 2、自助提交  3、下载安装返回
   I_ButtonShow    In Number, --   下载按钮和进度条是否显示（1显示，0不显示）
   I_ButtonName    In Varchar2, --   试玩按钮名称
   I_ShowOrder     In Number, --  排序号
   I_MSGNOInstall  In Varchar2, --   未安装提示-无需下载app则提示和未注册一致
   I_MSGNoReg      In Varchar2, --   未注册提示
   I_MsgReg        In Varchar2, --   已注册提示
   I_MSGDayLimit   In Varchar2, --  日限量提示信息
   I_MSGAllLimit   In Varchar2, --  到量提示信息
   I_ISRECOMMEND   In Number, --  是否推荐该广告 1：推荐 0：不推荐
   I_ISEASY        In Number, --  是否为简单广告 1：是 0：否
   
   O_Result  Out number,
   O_Message Out varchar2) is
    V_QX           NUMBER; --本模块的权限代码、
    v_n            number;
    V_MSGNOInstall varchar2(500); --未安装提示-无需下载app则提示和未注册一致 
    V_MSGNoReg     varchar2(500); --未注册/已下载提示 
    V_MsgReg       varchar2(500); --已注册提示 
    V_MsgDayLimit  varchar2(200); --日限量提示信息   
    V_MsgAllLimit  varchar2(200); --到量提示信息 
  begin
    o_result  := 0;
    o_message := '保存成功';
  
    V_QX := 104; --初始化权限代码
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    --输入参数是否正确
    if i_ADID is null then
      o_result  := 102;
      o_message := '输入参数有误，请检查！';
      return;
    end if;
  
    select count(1) into v_n from ad_adinfo where ADID = i_ADID;
  
    if v_n = 0 then
      o_result  := 104;
      o_message := '未找到指定广告，不能修改！';
      return;
    end if;
  
    V_MSGNOInstall := I_MSGNOInstall; --未安装提示-无需下载app则提示和未注册一致 
    V_MSGNoReg     := I_MSGNoReg; --未注册/已下载提示 
    V_MsgReg       := I_MsgReg; --已注册提示 
    V_MsgDayLimit  := I_MSGDayLimit; --日限量提示信息   
    V_MsgAllLimit  := I_MSGAllLimit; --到量提示信息 
  
    V_MSGNOInstall := replace(V_MSGNOInstall, '[adname]', I_ADName); --未安装提示-无需下载app则提示和未注册一致 
    V_MSGNoReg     := replace(I_MSGNoReg, '[adname]', I_ADName); --未注册/已下载提示 
    V_MsgReg       := replace(V_MsgReg, '[adname]', I_ADName); --已注册提示 
    V_MsgDayLimit  := replace(V_MsgDayLimit, '[adname]', I_ADName); --日限量提示信息   
    V_MsgAllLimit  := replace(V_MsgAllLimit, '[adname]', I_ADName); --到量提示信息 
  
    update ad_adinfo
       set title         = I_title,
           adname        = I_adname,
           money         = I_money,
           intro         = I_intro,
           status        = I_status,
           showtype      = I_showtype,
           starttime     = to_date(I_starttime, 'yyyy-mm-dd hh24:mi:ss'),
           stoptime      = to_date(I_stoptime, 'yyyy-mm-dd hh24:mi:ss'),
           phonetype     = I_phonetype,
           adtype        = I_adtype,
           appsize       = I_appsize,
           imgurl        = I_imgurl,
           description   = I_description,
           desimgurls    = I_DesImgUrls,
           adlink        = I_adlink,
           pagename      = I_pagename,
           iosadlink     = I_iosadlink,
           iospagename   = I_iospagename,
           iosurlschemes = I_iosurlschemes,
           iosproname    = I_iosproname,
           iosversion    = I_iosversion,
           ioskeyword    = I_ioskeyword,
           iosrank       = I_iosrank,
           appsign       = I_appsign,
           buttonshow    = I_buttonshow,
           buttonname    = I_buttonname,
           showorder     = I_showorder,
           msgnoinstall  = V_MSGNOInstall,
           msgnoreg      = V_MSGNoReg,
           msgreg        = V_MsgReg,
           msgdaylimit   = V_MsgDayLimit,
           msgalllimit   = V_MsgAllLimit,
           isrecommend   = I_ISRECOMMEND,
           is_easy       = I_ISEASY
     where ADID = i_ADID;
    commit;
  
    select count(1) into v_n from ad_activity where adid = I_ADID;
    if v_n > 0 then
      update ad_activity
         set etime = to_date(I_stoptime, 'yyyy-mm-dd hh24:mi:ss')
       where adid = I_ADID;
      commit;
    end if;
    /*    同步无积分广告信息
    P_SynAD_Data.PW_Syn_Wall@Xwanad_Link(I_ADID    => I_ADID,
                                         O_Result  => v_result,
                                         O_Message => v_Message);*/
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_MESSAGE := '修改失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pw_AD_Edit;

  procedure pq_HavGetedMoney
  /*****************************************************************
        Procedure Name :pq_HavGetedMoney
        Purp:2018-12-18 Edit by 胡银杜
    ****************************************************************/
  (I_USERID     In Number, --用户
   O_ISGETMONEY Out Number,
   O_Result     Out number,
   O_Message    Out varchar2) is
    v_n number;
  begin
    O_ISGETMONEY := 0;
    o_result     := 0;
    o_message    := '查询成功';
    select count(1) into v_n from ad_app_users where userid = I_USERID;
    if v_n > 0 then
      select nvl(getedmoney, 0)
        into O_ISGETMONEY
        from ad_app_users
       where userid = I_USERID;
    end if;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '获取失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end pq_HavGetedMoney;
  procedure PQ_Common
  /*****************************************************************
        Procedure Name :PQ_Common
        Purpose: 普通固定奖励发放
        Edit: 2018-04-11 add by 小沈
    ****************************************************************/
  (I_ADID     In Number, --广告ID
   I_APPId    In Number, --渠道应用ID
   I_Deviceid In Varchar2, --设备号ID
   I_SIMID    In Varchar2, --返回sim卡id
   I_Userid   In Number, --闲玩用户编号
   I_PType    In Number, --1、ios  2、安卓
   I_MerId    In Varchar2, --用户注册帐号id
   I_MerName  In Varchar2, --用户注册帐号
   I_Levle    In Number, --用户等级、金额等
   I_AGroup   In Number, --组别
   O_AMoney   Out Number, --奖励金额
   O_Result   Out Number,
   O_Message  Out Varchar2) is
    v_n            Number;
    v_ptype        Number; -- 下载时手机类型 1苹果  2安卓
    v_Deviceid     varchar2(100); --设备号
    v_ADStatus     Number; --投放状态（0未投放，1正常投放，2日到量，3总到量，4停止投放） 
    v_adname       Varchar2(100); --广告名称--对外
    v_adtype       Number; --广告类型（1游戏，2应用，3其他） 
    V_IsShow       Number; --是否显示 0 否  1是  判断用户是否可以体验
    v_ordernum     Varchar2(100); --订单编号
    v_pagename     Varchar2(100); --包名
    v_pagename_and Varchar2(100); --安卓包名
    v_pagename_ios Varchar2(100); --苹果包名
    v_appsign      Varchar2(200); --渠道应用标识符号、渠道用户id
    v_urlid        Number; --下载编号
    v_dlevel       number; --奖励级别
    v_event        Varchar2(500); --奖励说明
    v_AGroup       number; --奖励组别
    cursor myCur_award is
      select dlevel,
             event,
             needlevel,
             times,
             atype,
             awardgroup,
             price,
             amoney,
             isshow
        from ad_awardset
       where adid = I_ADID
         and appid = I_APPId
         and awardgroup = I_AGroup
       order by dlevel desc;
  
  begin
    O_Result  := 0;
    O_Message := '奖励成功！';
    O_AMoney  := 0; --奖励金额
  
    if I_ADID is null then
      O_Result  := 10;
      O_Message := '请返回后刷新，再重新点击进入';
      return;
    end if;
  
    --去空格处理
    v_DeviceId := fq_str_delspace(i_str => I_Deviceid);
    --设备号校验是否合法 0否 1是
    if p_base_fun.fq_deviceid_check(v_DeviceId, I_PType) = 0 then
      O_Result  := 10;
      O_Message := '请先对APP进行授权';
      return;
    end if;
  
    if v_DeviceId is null then
      O_Result  := 10;
      O_Message := '需要先对APP进行授权';
      return;
    end if;
  
    --获取广告名称和包名
    select status, adname, pagename, iospagename, adtype
      into v_ADStatus, v_adname, v_pagename_and, v_pagename_ios, v_adtype
      from ad_adinfo
     where adid = I_ADID;
  
    if v_ADStatus in (0, 4) then
      O_Result  := 10;
      O_Message := '广告未投放或已停止！';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_awardset
     where adid = i_adid
       and appid = I_APPId
       and awardgroup = I_AGroup;
    if v_n = 0 then
      O_RESULT  := 10;
      O_MESSAGE := '奖励参数尚未设置';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_app_bind
     where adid = I_ADID
       and merid = I_MerId;
    --如果1个账号ID存在2个以上 则说明有问题，直接不显示
    if v_n >= 2 then
      O_RESULT  := 15;
      O_MESSAGE := '您的应用账号存在异常，不予奖励！请联系管理员';
      return;
    end if;
  
    --判断用户是否被限制
    --设备号限制表判断
    select count(1)
      into v_n
      from ad_limit_deviceid
     where adid = i_adid
       and deviceid = v_DeviceId;
    if v_n > 0 then
      O_RESULT  := 18;
      O_MESSAGE := '您暂时无法体验该任务，不予奖励！请联系管理员';
      return;
    end if;
  
    --用户限制表判断
    select count(1)
      into v_n
      from ad_limit_user
     where adid = i_adid
       and userid = i_userid;
    if v_n > 0 then
      O_RESULT  := 20;
      O_MESSAGE := '您暂时无法体验该任务，不予奖励！请联系管理员';
      return;
    end if;
  
    ---判断用户是否可以参与该广告
    -- 是否显示 0 不显示 1 显示 
  
    v_IsShow := p_ad_isshow_v2.fq_isshow(i_adid     => i_adid,
                                         i_appid    => i_appid,
                                         i_deviceid => v_DeviceId,
                                         i_userid   => i_userid,
                                         i_ptype    => i_ptype);
  
    if v_IsShow = 0 then
      O_Result  := 10;
      O_Message := '您无法参与该广告，请返回后体验其他广告！';
      return;
    end if;
  
    select count(1)
      into v_n
      from ad_app_bind
     where adid = I_ADID
       and appid = I_APPId
       and userid = I_Userid
       and upper(merid) = upper(I_MerId); --用帐号匹配更恰当，判断帐号是否一致
  
    if v_n <= 0 then
      O_RESULT  := 11;
      O_MESSAGE := '您还未下载或注册该任务';
      return;
    end if;
  
    --判断是否有注册奖励，如果有的话，需要先完成
    select count(1)
      into v_n
      from ad_awardset
     where adid = i_adid
       and appid = I_APPId
       and atype = 1;
  
    if v_n > 0 then
      select dlevel, event, awardgroup
        into v_dlevel, v_event, v_AGroup
        from ad_awardset
       where adid = i_adid
         and appid = I_APPId
         and atype = 1;
    
      if v_AGroup != I_AGroup then
        select count(1)
          into v_n
          from ad_app_flux
         where adid = I_ADID
           and userid = I_Userid
           and dlevel = v_dlevel;
      
        if v_n <= 0 then
          O_RESULT  := 11;
          O_MESSAGE := '请先完成' || v_event;
          return;
        end if;
      end if;
    end if;
  
    --判断同组奖励该设备号是否已存在有则不奖励  t_ad_channel_order
    if I_AGroup >= 90 then
      --如果为同组奖励 表示该组别中的奖励 用户只能领取其中一个 ，领取过其中一个则该组别其他奖励均为过期
      --不加 appid 放宽 查询条件
      select count(1)
        into v_n
        from ad_app_flux
       where adid = I_ADID
         and (userid = I_Userid or deviceid = upper(v_DeviceId))
         and dlevel in (select dlevel
                          from ad_awardset
                         where adid = I_ADID
                           and appid = I_APPId
                           and awardgroup = I_AGroup);
    
      if v_n > 0 then
        O_RESULT  := 12;
        O_MESSAGE := '已经有过该奖励了';
        return;
      end if;
    
    end if;
  
    --获取当时用户下载时的设备 为苹果还是安卓，和渠道标识
    select ptype, appsign, urlid
      into v_ptype, v_appsign, v_urlid
      from ad_app_bind
     where adid = I_ADID
       and appid = I_APPId
       and userid = I_Userid;
  
    ---- 下载时手机类型 1苹果  2安卓
    if v_ptype = 1 then
      v_pagename := v_pagename_ios;
    else
    
      v_pagename := v_pagename_and;
    end if;
  
    for cur in myCur_award loop
    
      --内部循环奖励也需要判断 
      --判断同组奖励该设备号是否已存在有则不奖励  t_ad_channel_order
      if I_AGroup >= 90 then
        --如果为同组奖励 表示该组别中的奖励 用户只能领取其中一个 ，领取过其中一个则该组别其他奖励均为过期
        select count(1)
          into v_n
          from ad_app_flux
         where adid = I_ADID
           and (userid = I_Userid or deviceid = upper(v_DeviceId))
           and dlevel in (select dlevel
                            from ad_awardset
                           where adid = I_ADID
                             and appid = I_APPId
                             and awardgroup = I_AGroup);
      
        if v_n > 0 then
          O_RESULT  := 12;
          O_MESSAGE := '已经获得过该奖励了';
          return;
        end if;
      
      end if;
    
      select count(1)
        into v_n
        from ad_app_flux
       where adid = I_ADID
         and (userid = I_Userid or deviceid = upper(v_DeviceId))
         and dlevel = cur.dlevel;
    
      --如果该设备已经获取过该奖励则跳过
      if v_n >= cur.times then
        GOTO CONTINUE_LOOP;
      end if;
    
      --游戏级别不够，不奖励
      if cur.needlevel > I_Levle then
        GOTO CONTINUE_LOOP;
      end if;
    
      insert into ad_app_flux
        (id,
         adid,
         appid,
         deviceid,
         appsign,
         dlevel,
         merid,
         money,
         event,
         adtype,
         atype,
         simid,
         urlid,
         price,
         userid,
         ptype)
        select SQ_AD_FLUX.NEXTVAL,
               I_ADID,
               I_APPId,
               upper(v_DeviceId),
               v_appsign,
               cur.dlevel,
               I_MerId,
               cur.amoney,
               cur.event,
               v_adtype,
               cur.atype,
               I_simid,
               v_urlid,
               cur.price,
               i_userid,
               i_ptype
          from dual
         where (select count(1)
                  from ad_app_flux
                 where adid = I_ADID
                   and (userid = I_Userid or deviceid = upper(v_DeviceId))
                   and dlevel = cur.dlevel) < cur.times;
    
      if cur.isshow = 1 then
      
        --累加奖励
        O_AMoney := O_AMoney + cur.amoney;
      
        v_ordernum := I_APPId || to_char(sysdate, 'yyyymmddhh24miss') ||
                      I_ADID || dbms_random.string('x', 5) ||
                      trunc(dbms_random.value(0, 10));
      
        insert into ad_channel_order
          (adid,
           adname,
           appid,
           ordernum,
           dlevel,
           awardgroup,
           pagename,
           deviceid,
           simid,
           appsign,
           merid,
           mername,
           event,
           price,
           money)
        values
          (I_ADID,
           v_adname,
           I_APPId,
           v_ordernum,
           cur.dlevel,
           cur.awardgroup,
           v_pagename,
           I_Deviceid,
           I_SIMID,
           v_appsign,
           I_MerId,
           I_MerName,
           v_adname || cur.event,
           cur.price,
           cur.amoney);
      
      end if;
      commit;
      select count(1)
        into v_n
        from ad_app_users
       where userid = I_Userid
         and getedmoney = 0;
      if v_n > 0 then
        update ad_app_users set getedmoney = 1 where userid = I_Userid;
        commit;
      end if;
      <<CONTINUE_LOOP>>
      null;
    
    end loop;
  
  exception
    --失败
    when others then
      rollback;
      O_Result  := 1001;
      O_Message := '领取奖励异常！';
      -- o_message := '领取奖励异常 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PQ_Common;

  procedure PQ_AwardOrderCheck
  /*****************************************************************
        Procedure Name :PQ_AwardOrderCheck
        Purpose: 奖励订单审核
        Edit: 2018-11-01 add by 小胡
    ****************************************************************/
  (I_AdmInId  In Varchar2, --管理员id
   I_ORDERNUM In Varchar2, --订单编号
   I_STATUS   In Number, --订单状态
   I_ADID     In Varchar2,
   I_APPID    In Varchar2,
   O_Result   Out Number,
   O_Message  Out Varchar2) is
    V_QX number;
    v_n  number;
  begin
    O_Result  := 0;
    O_Message := '审核成功';
    V_QX      := 104; --初始化权限代码  
  
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
  
    select count(1)
      into v_n
      from ad_channel_order
     where ordernum = I_ORDERNUM
       and adid = I_ADID
       and appid = I_APPID;
    if v_n > 0 then
      if I_STATUS = 0 then
        update ad_channel_order
           set p_status = I_STATUS,
               p_ntime  = sysdate - (2 / (24 * 60)),
               p_times  = 0
         where ordernum = I_ORDERNUM
           and adid = I_ADID
           and appid = I_APPID;
      else
        update ad_channel_order
           set p_status = I_STATUS
         where ordernum = I_ORDERNUM
           and adid = I_ADID
           and appid = I_APPID;
      end if;
      commit;
    end if;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '查询失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PQ_AwardOrderCheck;

  procedure PQ_Syncad
  /*****************************************************************
        Procedure Name :PQ_syncad
        Purpose: 同步闲玩广告
        Edit: 2019-05-29 add by 小刘
    ****************************************************************/
  (I_AdmInId In Varchar2, --管理员id
   I_ADID    In Varchar2,
   O_Result  Out Number,
   O_Message Out Varchar2) is
    V_QX     number;
    v_n      number;
    new_adid number;
  
  begin
    O_Result  := 0;
    O_Message := '同步成功';
    V_QX      := 471; --初始化权限代码  
  
    --管理员是否有操作此模块的权限
    IF p_admin.fq_isqx(I_ADMINID => I_ADMINID, I_QXID => V_QX) = 0 THEN
      O_RESULT  := 101;
      O_MESSAGE := '您没有权限进行此操作，请检查！';
      RETURN;
    END IF;
    select count(1) into v_n from ad_adinfo@dbl_adwll where adid = I_ADID;
    if v_n <= 0 then 
      O_Result  := 101;
       O_Message := '没有该广告';
      end if;
    if v_n > 0 then
      new_adid := SQ_AD_INFO.NEXTVAL;
    
      insert into ad_adinfo
        (adid,
         title,
         adname,
         money,
         intro,
         status,
         showtype,
         starttime,
         stoptime,
         phonetype,
         adtype,
         appsize,
         imgurl,
         description,
         desimgurls,
         adlink,
         pagename,
         iosadlink,
         iospagename,
         iosurlschemes,
         iosproname,
         iosversion,
         ioskeyword,
         iosrank,
         appsign,
         buttonshow,
         buttonname,
         showorder,
         msgnoinstall,
         msgnoreg,
         msgreg,
         msgdaylimit,
         msgalllimit,
         isrecommend,
         is_easy)
        select new_adid as adid,
               title,
               adname,
               money,
               intro,
               status,
               0,
               starttime,
               stoptime,
               phonetype,
               adtype,
               appsize,
               imgurl,
               description,
               desimgurls,
               'https://h5.51xianwan.com/try/try_list_plus.aspx?adid='||new_adid,
               pagename,
               iosadlink,
               iospagename,
               iosurlschemes,
               iosproname,
               iosversion,
               ioskeyword,
               iosrank,
               appsign,
               buttonshow,
               buttonname,
               showorder,
               msgnoinstall,
               msgnoreg,
               msgreg,
               msgdaylimit,
               msgalllimit,
               isrecommend,
               is_easy
          from ad_adinfo@dbl_adwll
         where adid = I_ADID;
      select count(1)
        into v_n
        from AD_AWARDSET@DBL_ADWLL
       where adid = I_ADID;
      if v_n > 0 then
        insert into AD_AWARDSET
          (adid,
           appid,
           type,
           dlevel,
           event,
           needlevel,
           times,
           atype,
           awardgroup,
           groupname,
           psecond,
           price,
           amoney,
           isshow)
          select new_adid as adid,
                 appid,
                 type,
                 dlevel,
                 event,
                 needlevel,
                 times,
                 atype,
                 awardgroup,
                 groupname,
                 psecond,
                 price,
                 amoney,
                 isshow
            from ad_awardset@dbl_adwll
           where adid = I_ADID and appid = 1010;
      end if;
      O_Message := 'adid:'||new_adid ||O_Message;
      commit;
    end if;
  
  EXCEPTION
    --失败
    WHEN OTHERS THEN
      rollback;
      O_Result  := 110;
      O_Message := '查询失败 错误编码：' || SQLCODE || '  错误信息 ：' || sqlerrm;
      return;
  end PQ_Syncad;
end p_package_test;
/


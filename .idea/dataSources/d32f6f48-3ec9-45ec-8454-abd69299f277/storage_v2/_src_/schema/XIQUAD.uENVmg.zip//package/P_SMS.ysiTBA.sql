create package P_SMS is

  TYPE T_CURSOR IS REF CURSOR;

  /*短信处理*/

  procedure PW_Alarm_Add
  /*****************************************************************
        Procedure Name :PW_Aalarm_Add
        Purpose: 报警短信添加 
        Edit: 2017-07-29 add by 小沈
    ****************************************************************/
  (I_Phone     In Varchar2, --手机号码
   I_Message   In Varchar2, --消息内容 
   I_SendLevel In Number, --发送优先级,99为手工插入，最高优先级 
   I_SendType  In Number, --发送类型 1：渠道推送失败
   O_Result    Out Number,
   O_Message   Out Varchar2);

  procedure PQ_Alarm_List
  /*****************************************************************
        Procedure Name :PQ_Alarm_List
        Purpose: 获取报警短信列表
        Edit: 2017-07-30 add by 小沈
    ****************************************************************/
  (I_PageSize       In Number,
   I_PageNO         In Number,
   O_OutRecordCount Out Number,
   O_OutCursor      Out t_cursor, --返回游标
   O_Result         Out Number,
   O_Message        Out Varchar2);

  procedure PW_UpStatus
  /*****************************************************************
        Procedure Name :PW_UpStatus
        Purpose: 修改短信状态为正在发送中 
        Edit: 2017-07-29 add by 小沈
    ****************************************************************/
  (I_SmsId   In Number, --短信ID 
   O_Result  Out Number,
   O_Message Out Varchar2);

  procedure PW_Result
  /*****************************************************************
        Procedure Name :PW_Result
        Purpose: 短信发送结果返回 
        Edit: 2017-07-29 add by 小沈
    ****************************************************************/
  (I_SmsId   In Number, --短信ID 
   I_Status  In Number, -- 返回状态 0：失败  1：成功
   I_Result  In Varchar2, --返回信息
   O_Result  Out Number,
   O_Message Out Varchar2);

end P_SMS;
/


create PACKAGE P_Job_Monitoring AS
  TYPE T_CURSOR IS REF CURSOR;

  /*监控jobs*/

  procedure Job_AD;
  /*****************************************************************
      procedure name: Job_AD
      purpose: 广告监控
     edit: 2017-07-30 add by 小沈
  ****************************************************************/

end P_Job_Monitoring;
/

